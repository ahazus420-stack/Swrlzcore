# 07_Android_Architecture

Jetpack Compose, repositories, ViewModels, navigation, permissions.

> This is the v3 foundation chapter and is intended to be expanded with screenshots, diagrams, and implementation details.
