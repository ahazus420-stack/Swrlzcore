# 09_Theme_Bible

Glitch, Ice, Void, Solar, White dragons and future theme system.

> This is the v3 foundation chapter and is intended to be expanded with screenshots, diagrams, and implementation details.
