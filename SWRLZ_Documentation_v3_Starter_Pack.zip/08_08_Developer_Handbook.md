# 08_Developer_Handbook

Adding missions, themes, dragons, modules, diagnostics.

> This is the v3 foundation chapter and is intended to be expanded with screenshots, diagrams, and implementation details.
