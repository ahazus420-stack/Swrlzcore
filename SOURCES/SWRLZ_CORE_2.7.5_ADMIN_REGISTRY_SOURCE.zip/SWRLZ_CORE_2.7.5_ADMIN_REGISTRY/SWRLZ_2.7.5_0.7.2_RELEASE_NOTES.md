# SWRLZ Release 2.7.5 / 0.7.2 — Admin Registry + Device Ledger

## Android client 2.7.5

Adds `More -> Admin Registry`, an app-side control panel for device and queue administration. The operator can refresh the device ledger, inspect nodes, clear queues, force offline, trust/block, and forget ghost devices from inside the APK.

## Local Node Server 0.7.2

Adds server-side Device Ledger admin APIs, queue inspector APIs, heartbeat lease states, stale/blocked state handling, and queue-clearing/forget-device operations.

## Status

Source patched and packaged. APK still needs GitHub/Codespaces build verification.
