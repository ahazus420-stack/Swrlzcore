package sh.swurlz.core.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import sh.swurlz.core.net.Api
import sh.swurlz.core.net.CoreNodeApi
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

private data class AdminDeviceModel(
    val deviceId: String,
    val label: String,
    val role: String,
    val groupId: String,
    val trustLevel: String,
    val onlineState: String,
    val lastSeen: String,
    val lastSeenSeconds: Int,
    val queuedPackets: Int,
    val appVersion: String,
    val patchLabel: String,
    val clientIp: String,
    val capabilities: String,
)

private data class AdminPacketModel(
    val packetId: String,
    val title: String,
    val commandType: String,
    val status: String,
    val targetDevice: String,
    val groupId: String,
)

@Composable
fun AdminRegistryScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tokens = LocalSwurlzTokens.current
    var status by remember { mutableStateOf("standing by") }
    var raw by remember { mutableStateOf("") }
    var devices by remember { mutableStateOf<List<AdminDeviceModel>>(emptyList()) }
    var packets by remember { mutableStateOf<List<AdminPacketModel>>(emptyList()) }

    fun launchAdmin(label: String, block: suspend () -> String) {
        scope.launch {
            status = "$label…"
            runCatching { block() }
                .onSuccess { body ->
                    status = "$label ok"
                    raw = body
                    parseDevices(body).takeIf { it.isNotEmpty() }?.let { devices = it }
                    parsePackets(body).takeIf { it.isNotEmpty() }?.let { packets = it }
                }
                .onFailure { err ->
                    status = "$label failed: ${CoreNodeApi.cleanFailure(err)}"
                    raw = err.message.orEmpty()
                }
        }
    }

    LaunchedEffect(Unit) {
        launchAdmin("Load registry") { CoreNodeApi.adminDeviceLedger(ctx) }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Text("▸ ADMIN REGISTRY", color = tokens.status.admin, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Operator control panel for device ledger, ghost nodes, trust state, and packet queues. Admin session must be active from Core Admin.",
            color = tokens.text.secondary,
            fontSize = 12.sp,
            lineHeight = 17.sp,
        )
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.admin).background(tokens.cards.bg).padding(12.dp)) {
            Text("SERVER ADMIN STATE", color = tokens.status.admin, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(status, color = tokens.text.primary, fontSize = 12.sp, lineHeight = 17.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminButton("REFRESH", tokens.status.info, Modifier.weight(1f)) { launchAdmin("Refresh registry") { CoreNodeApi.adminDeviceLedger(ctx) } }
                AdminButton("QUEUES", tokens.status.warning, Modifier.weight(1f)) { launchAdmin("Load queues") { CoreNodeApi.adminQueues(ctx) } }
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("DEVICE REGISTRY", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (devices.isEmpty()) {
            InfoCard("No admin devices loaded yet. Tap REFRESH after activating admin session.", tokens.status.warning)
        } else {
            devices.forEach { d ->
                DeviceAdminCard(
                    device = d,
                    onInspect = { launchAdmin("Inspect ${d.deviceId}") { CoreNodeApi.adminInspectDevice(ctx, d.deviceId) } },
                    onForceOffline = { launchAdmin("Force offline ${d.deviceId}") { CoreNodeApi.adminDeviceAction(ctx, d.deviceId, "force-offline") } },
                    onClearQueue = { launchAdmin("Clear queue ${d.deviceId}") { CoreNodeApi.adminDeviceAction(ctx, d.deviceId, "clear-queue") } },
                    onTrust = { launchAdmin("Trust ${d.deviceId}") { CoreNodeApi.adminDeviceAction(ctx, d.deviceId, "trust") } },
                    onBlock = { launchAdmin("Block ${d.deviceId}") { CoreNodeApi.adminDeviceAction(ctx, d.deviceId, "block") } },
                    onForget = { launchAdmin("Forget ${d.deviceId}") { CoreNodeApi.adminForgetDevice(ctx, d.deviceId, clearQueue = true) } },
                )
                Spacer(Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("QUEUE INSPECTOR", color = tokens.status.warning, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (packets.isEmpty()) {
            InfoCard("Tap QUEUES to load packet ownership and stale queue state.", tokens.borders.neutral)
        } else {
            packets.take(80).forEach { p -> PacketAdminCard(p) }
        }
        Spacer(Modifier.height(12.dp))
        SelectionContainer {
            Text(raw.take(1800), color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 13.sp)
        }
    }
}

@Composable
private fun DeviceAdminCard(
    device: AdminDeviceModel,
    onInspect: () -> Unit,
    onForceOffline: () -> Unit,
    onClearQueue: () -> Unit,
    onTrust: () -> Unit,
    onBlock: () -> Unit,
    onForget: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val tone = stateTone(device.onlineState)
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(tokens.cards.bgAlt).padding(12.dp)) {
        Text(device.label.ifBlank { device.deviceId }.uppercase(), color = tone, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(5.dp))
        Text("${device.onlineState.uppercase()} · queued ${device.queuedPackets} · ${device.trustLevel}", color = tokens.text.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("id: ${device.deviceId}", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        Text("group: ${device.groupId} · role: ${device.role}", color = tokens.text.secondary, fontSize = 11.sp)
        Text("seen: ${device.lastSeen} · age: ${device.lastSeenSeconds}s", color = tokens.text.secondary, fontSize = 11.sp)
        if (device.appVersion.isNotBlank() || device.patchLabel.isNotBlank()) Text("build: ${device.appVersion} · ${device.patchLabel}", color = tokens.text.secondary, fontSize = 11.sp)
        if (device.clientIp.isNotBlank()) Text("ip: ${device.clientIp}", color = tokens.text.secondary, fontSize = 11.sp)
        if (device.capabilities.isNotBlank()) Text("caps: ${device.capabilities}", color = tokens.text.muted, fontSize = 10.sp, lineHeight = 14.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AdminButton("INSPECT", tokens.status.info, Modifier.weight(1f), onInspect)
            AdminButton("CLEAR Q", tokens.status.warning, Modifier.weight(1f), onClearQueue)
            AdminButton("OFFLINE", tokens.status.warning, Modifier.weight(1f), onForceOffline)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AdminButton("TRUST", tokens.status.success, Modifier.weight(1f), onTrust)
            AdminButton("BLOCK", tokens.status.danger, Modifier.weight(1f), onBlock)
            AdminButton("FORGET", tokens.status.danger, Modifier.weight(1f), onForget)
        }
    }
}

@Composable
private fun PacketAdminCard(packet: AdminPacketModel) {
    val tokens = LocalSwurlzTokens.current
    val tone = stateTone(packet.status)
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(tokens.cards.bg).padding(10.dp)) {
        Text(packet.title.ifBlank { packet.commandType }, color = tone, fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text("${packet.status} · ${packet.commandType} · target ${packet.targetDevice}", color = tokens.text.secondary, fontSize = 11.sp)
        Text(packet.packetId, color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun InfoCard(text: String, tone: Color) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(tokens.cards.bg).padding(12.dp)) {
        Text(text, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
    }
}

@Composable
private fun AdminButton(label: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color, containerColor = tokens.buttons.ghostBg),
        border = BorderStroke(1.dp, color),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        modifier = modifier,
    ) { Text(label, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold) }
}

private fun stateTone(state: String): Color = when (state.lowercase()) {
    "online", "trusted", "completed", "ready" -> Color(0xFF51FF7A)
    "idle", "queued", "pending", "displayed", "acknowledged" -> Color(0xFFFFCC45)
    "blocked", "failed", "rejected", "ghost" -> Color(0xFFFF4B64)
    "stale", "offline", "expired", "archived" -> Color(0xFF9CA3AF)
    else -> Color(0xFF24E6FF)
}

private fun parseDevices(raw: String): List<AdminDeviceModel> = runCatching {
    val root = Api.json.parseToJsonElement(raw).jsonObject
    root["devices"]?.jsonArray?.mapNotNull { it.asObj()?.toAdminDevice() }.orEmpty()
}.getOrDefault(emptyList())

private fun parsePackets(raw: String): List<AdminPacketModel> = runCatching {
    val root = Api.json.parseToJsonElement(raw).jsonObject
    root["packets"]?.jsonArray?.mapNotNull { it.asObj()?.toAdminPacket() }.orEmpty()
}.getOrDefault(emptyList())

private fun JsonElement.asObj(): JsonObject? = this as? JsonObject

private fun JsonObject.toAdminDevice(): AdminDeviceModel = AdminDeviceModel(
    deviceId = str("device_id", "deviceId").orEmpty(),
    label = str("device_label", "deviceLabel", "label").orEmpty(),
    role = str("role").orEmpty(),
    groupId = str("group_id", "groupId").orEmpty(),
    trustLevel = str("trust_level", "trustLevel").orEmpty().ifBlank { if (bool("blocked") == true) "blocked" else "group" },
    onlineState = str("online_state", "onlineState", "status").orEmpty().ifBlank { if (bool("online") == true) "online" else "offline" },
    lastSeen = str("last_seen_at", "lastSeenAt", "last_checkin_at", "lastCheckinAt").orEmpty(),
    lastSeenSeconds = intAny("last_seen_seconds", "lastSeenSeconds") ?: -1,
    queuedPackets = intAny("queued_packets", "queuedPackets") ?: 0,
    appVersion = str("app_version", "appVersion").orEmpty(),
    patchLabel = str("patch_label", "patchLabel").orEmpty(),
    clientIp = str("client_ip", "clientIp").orEmpty(),
    capabilities = get("capabilities")?.toString().orEmpty(),
)

private fun JsonObject.toAdminPacket(): AdminPacketModel = AdminPacketModel(
    packetId = str("packet_id", "packetId", "id").orEmpty(),
    title = str("title").orEmpty(),
    commandType = str("command_type", "commandType", "type").orEmpty(),
    status = str("status").orEmpty(),
    targetDevice = str("target_device_id", "targetDeviceId").orEmpty(),
    groupId = str("group_id", "groupId").orEmpty(),
)

private fun JsonObject.str(vararg keys: String): String? = keys.firstNotNullOfOrNull { key -> get(key)?.jsonPrimitive?.contentOrNull }
private fun JsonObject.bool(vararg keys: String): Boolean? = keys.firstNotNullOfOrNull { key -> get(key)?.jsonPrimitive?.booleanOrNull }
private fun JsonObject.intAny(vararg keys: String): Int? = keys.firstNotNullOfOrNull { key -> get(key)?.jsonPrimitive?.intOrNull ?: get(key)?.jsonPrimitive?.contentOrNull?.toIntOrNull() }
