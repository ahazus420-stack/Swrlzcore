# SWRLZ-Core 2.7.5 — Admin Registry

Adds an app-side Admin Registry panel under `More -> Admin Registry`.

## Main features

- Device Registry cards for all admin-visible devices.
- Inspect device details and queue ownership.
- Clear device queue from APK.
- Force device offline from APK.
- Trust/block device from APK.
- Forget ghost/stale device from APK, with optional queue clear.
- Queue Inspector panel for server packet records.
- Preserves Theme Armor and Cockpit Shell navigation.

## Test target

From the 2.7.4 field case: Radar showed `1 group / 3 devices / 2 online / 4 queued`. In 2.7.5, activate admin session, open Admin Registry, inspect the offline/ghost node, clear queue, forget device, then refresh Radar.

## Build identity

- versionName: `0.2.7.5-admin-registry`
- versionCode: `18`
- patch: `2.7.5-ADMIN-REGISTRY`
