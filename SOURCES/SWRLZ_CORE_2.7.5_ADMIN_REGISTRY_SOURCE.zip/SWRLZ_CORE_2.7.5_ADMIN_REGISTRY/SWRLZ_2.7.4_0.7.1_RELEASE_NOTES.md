# SWRLZ Release 2.7.4 / 0.7.1

## Android Client

SWRLZ-Core 2.7.4 — Cockpit Shell

- Version: `0.2.7.4-cockpit-shell`
- Code: `17`
- Patch: `2.7.4-COCKPIT-SHELL`
- Roadmap: `2.7.4`

## Local Node Server

Local Node Server 0.7.1 — Presence Index

- Server unchanged in this release.

## Highlights

- Cleaner top navigation.
- New More / Advanced Drawer.
- Radar Guided Pairing Ladder.
- Radar Device Roster Summary.
- Queue lifecycle read-only terminal cards.
- Theme Armor preserved.
- Node Heartbeat / Auto Presence preserved.

## Build note

APK must be built in Codespaces/GitHub with Java 17. This environment cannot download Gradle from services.gradle.org.
