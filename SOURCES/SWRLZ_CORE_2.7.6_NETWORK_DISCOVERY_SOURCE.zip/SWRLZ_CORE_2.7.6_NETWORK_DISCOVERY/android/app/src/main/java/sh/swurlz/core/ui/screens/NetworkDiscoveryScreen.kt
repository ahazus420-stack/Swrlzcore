package sh.swurlz.core.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeConfig
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import java.net.HttpURLConnection
import java.net.URL

@Composable
fun NetworkDiscoveryScreen(
    onOpenSetup: () -> Unit,
    onOpenCore: () -> Unit,
) {
    val ctx = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    var nodeUrl by remember { mutableStateOf("http://127.0.0.1:8787") }
    var token by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("Standing by. Tap TEST SIGNATURE to probe /discovery/signature.") }
    var foundUrl by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val saved = Prefs.coreNodeConfig(ctx)
        if (saved.nodeUrl.isNotBlank()) nodeUrl = saved.nodeUrl
        token = saved.pairingToken
    }

    fun test(url: String) {
        scope.launch {
            result = "Probing ${normalizeBaseUrl(url)}/discovery/signature …"
            val probe = withContext(Dispatchers.IO) { probeSignature(url) }
            result = probe
            if (probe.startsWith("VALID SWRLZ NODE")) foundUrl = normalizeBaseUrl(url)
        }
    }

    fun scanCandidates() {
        scope.launch {
            val candidates = candidateUrls(nodeUrl)
            result = "Scanning candidates:\n" + candidates.joinToString("\n")
            for (candidate in candidates) {
                val probe = withContext(Dispatchers.IO) { probeSignature(candidate, timeoutMs = 900) }
                if (probe.startsWith("VALID SWRLZ NODE")) {
                    foundUrl = normalizeBaseUrl(candidate)
                    nodeUrl = foundUrl
                    result = "FOUND\n$probe"
                    return@launch
                }
            }
            result = "No valid SWRLZ node found in candidate list.\n\nTried:\n" + candidates.joinToString("\n")
        }
    }

    fun save() {
        scope.launch {
            val normalized = normalizeBaseUrl(foundUrl.ifBlank { nodeUrl })
            Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(nodeUrl = normalized, pairingToken = token))
            result = "Saved Core Node URL:\n$normalized\n\nNext: open Core Admin or Radar and refresh."
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
    ) {
        Text("▸ NETWORK DISCOVERY", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Find, verify, save, and reuse a local SWRLZ node without manual IP hunting.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(12.dp))

        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.selected).background(tokens.cards.bg).padding(12.dp)) {
            Text("BUILD IDENTITY", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Version: v${BuildConfig.VERSION_NAME} · code ${BuildConfig.VERSION_CODE}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Patch: ${BuildConfig.PATCH_LABEL}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Roadmap: ${BuildConfig.ROADMAP_REVISION}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Source: ${BuildConfig.SOURCE_ZIP}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = nodeUrl,
            onValueChange = { nodeUrl = it },
            label = { Text("Node URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Pairing token / API token, optional") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("TEST SIGNATURE", onClick = { test(nodeUrl) })
            DiscoveryButton("SCAN LOCAL", onClick = { scanCandidates() })
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("SAVE NODE", onClick = { save() })
            DiscoveryButton("OPEN CORE ADMIN", onClick = onOpenCore)
        }
        Spacer(Modifier.height(8.dp))
        DiscoveryButton("OPEN SETUP", onClick = onOpenSetup)

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
            Text("DISCOVERY RESULT", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(result, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 16.sp)
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.info).background(tokens.cards.bg).padding(12.dp)) {
            Text("EXPECTED SIGNATURE", color = tokens.status.info, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "GET /discovery/signature\n\n{\"ok\":true,\"server\":\"swrlz-local-node\",\"version\":\"0.7.3-discovery-signature\",\"patch\":\"LNS-0.7.3-DISCOVERY-SIGNATURE\",\"port\":8787}",
                color = tokens.text.secondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 15.sp,
            )
        }
    }
}

@Composable
private fun DiscoveryButton(label: String, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.accents.primary, containerColor = tokens.buttons.ghostBg),
        border = BorderStroke(1.dp, tokens.accents.primary),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp),
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
    }
}

private fun candidateUrls(seed: String): List<String> {
    return listOf(
        seed,
        "http://127.0.0.1:8787",
        "http://localhost:8787",
        "http://10.0.2.2:8787",
        "http://192.168.0.1:8787",
        "http://192.168.1.1:8787",
        "http://192.168.4.1:8787",
    ).map { normalizeBaseUrl(it) }.filter { it.isNotBlank() }.distinct()
}

private fun normalizeBaseUrl(input: String): String {
    val trimmed = input.trim().trimEnd('/')
    return when {
        trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
        trimmed.isNotBlank() -> "http://$trimmed"
        else -> ""
    }
}

private fun probeSignature(input: String, timeoutMs: Int = 1500): String {
    val base = normalizeBaseUrl(input)
    if (base.isBlank()) return "INVALID URL: empty node URL"
    val url = "$base/discovery/signature"
    var connection: HttpURLConnection? = null
    return try {
        connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = timeoutMs
        connection.readTimeout = timeoutMs
        connection.requestMethod = "GET"
        connection.setRequestProperty("Accept", "application/json")
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        val lower = body.lowercase()
        if (code in 200..299 && lower.contains("swrlz-local-node") && lower.contains("discovery-signature")) {
            "VALID SWRLZ NODE\nURL: $base\nHTTP: $code\n\n$body"
        } else {
            "NOT A VALID SWRLZ DISCOVERY SIGNATURE\nURL: $base\nHTTP: $code\n\n$body"
        }
    } catch (err: Throwable) {
        "PROBE FAILED\nURL: $base\nError: ${err.javaClass.simpleName}: ${err.message}"
    } finally {
        connection?.disconnect()
    }
}
