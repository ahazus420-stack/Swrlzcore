# SWRLZ Swurlzer

This directory contains the production-oriented Android Studio project for the SWRLZ local node host. The user-facing product name is **Swurlzer**; source paths, package identity, and protocol-facing `NODE_HOST` terminology remain unchanged for compatibility.

## What is included
- Default Glitch Dragon Glass Swurlzer User Mode with Core, Nodes, Missions, and Settings
- Switchable Swurlzer Dev Mode preserving the complete legacy overview and diagnostics cockpit
- Persisted interface-mode and reduced-motion preferences
- Truthful runtime atmosphere derived from actual listener, stored-node, and stored-mission state
- Living Citadel core, eye, perimeter, handshake-gate, and mission effects driven only by sanitized authoritative state
- Lifecycle-aware low-frequency drift, finite event pulses, and a static reduced-motion fallback
- Explicit OFFLINE, STARTING, READY, DEGRADED, and FAILED Citadel state labels
- Separate CLIENT connection, identity, proof, trust, legacy, and route presentation
- Android 12+ crystalline launcher splash using the existing adaptive-icon resources
- New 4096×4096 Swurlzer launcher-icon master and Android launcher assets
- Kotlin + Jetpack Compose UI
- Room-backed persistence for nodes and missions
- Foreground service entry point
- Embedded private and local-link HTTP runtime
- Read-only CLIENT compatibility routes with authoritative-empty presence truth
- Deterministic Glitch Dragon Core launcher resources
- Basic theme, permissions, diagnostics, and mission views
- Build scripts and Android manifest

## Build status
This source archive is the `SERVER_CFv2.0.3_SWRLZ` Living Citadel effects checkpoint. Static contract, protected-file, node-key, Compose-import, launcher/splash-resource, accessibility, reduced-motion, and archive checks are recorded in `SOURCES/SERVER/SERVER_CFv2.0.3_SWRLZ.md`. Compilation and APK assembly are intentionally deferred to the owner's GitHub build.

The effects checkpoint does not change protocol/schema version 1, Room schema version 1, listener exposure, discovery signatures, pairing/trust rules, mission authority, private proof handling, or offline-first routing.
