package sh.swrlz.nodehost.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Durable registration inventory. Live presence is derived from lastSeen and connectionState. */
@Entity(tableName = "nodes")
data class NodeEntity(
    @PrimaryKey val nodeId: String,
    val label: String,
    val status: String,
    val capabilities: String,
    val trust: String,
    val lastSeen: Long,
    val deviceId: String = "",
    val installationId: String = "",
    val deviceType: String = "android-client",
    val appVersion: String = "",
    val protocolVersion: Int = 1,
    val firstRegisteredAt: Long = lastSeen,
    val registrationState: String = "REGISTERED",
    val connectionState: String = status.uppercase(),
    val identityState: String = "CONFIRMED",
    val proofState: String = "PENDING",
    val currentMissionId: String? = null,
    val archived: Boolean = false,
)
