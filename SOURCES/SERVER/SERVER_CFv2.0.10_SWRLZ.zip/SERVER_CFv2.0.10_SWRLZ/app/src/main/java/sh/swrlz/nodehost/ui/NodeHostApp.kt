package sh.swrlz.nodehost.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel

@Composable
fun NodeHostApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val viewModel: HostViewModel = hiltViewModel()
    val mode by SwurlzerUiPreferences.modeFlow(context).collectAsState(initial = SwurlzerInterfaceMode.User)
    val motionEnabled by SwurlzerUiPreferences.motionEnabledFlow(context).collectAsState(initial = true)

    fun switchMode(next: SwurlzerInterfaceMode) {
        scope.launch { SwurlzerUiPreferences.setMode(context, next) }
    }

    fun setMotion(enabled: Boolean) {
        scope.launch { SwurlzerUiPreferences.setMotionEnabled(context, enabled) }
    }

    when (mode) {
        SwurlzerInterfaceMode.User -> SwurlzerUserScreen(
            viewModel = viewModel,
            motionEnabled = motionEnabled,
            onMotionChanged = ::setMotion,
            onOpenDeveloper = { switchMode(SwurlzerInterfaceMode.Developer) },
        )
        SwurlzerInterfaceMode.Developer -> HostScreen(
            viewModel = viewModel,
            motionEnabled = motionEnabled,
            onOpenUserMode = { switchMode(SwurlzerInterfaceMode.User) },
        )
    }
}
