package sh.swrlz.nodehost.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.sin
import sh.swrlz.nodehost.R
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.service.ListenerStatus
import sh.swrlz.nodehost.service.RuntimeStatus
import sh.swrlz.nodehost.ui.viewmodel.HostUiState

internal enum class SwurlzerEnergyTarget(val x: Float, val y: Float) {
    Core(.63f, .55f), Nodes(.75f, .38f), Missions(.54f, .72f),
    Settings(.24f, .82f), Developer(.42f, .48f),
}

internal data class SwurlzerEnergySignal(
    val id: Int = 0,
    val target: SwurlzerEnergyTarget = SwurlzerEnergyTarget.Core,
)

internal enum class SwurlzerCitadelState(val label: String) {
    Offline("OFFLINE"), Starting("STARTING"), Ready("READY"),
    Degraded("DEGRADED"), Failed("FAILED"),
}

internal enum class SwurlzerConnectionStage(val label: String, val rank: Int) {
    Stored("STORED ONLY", 0), Discovered("DISCOVERED", 1), Reachable("REACHABLE", 2),
    IdentityConfirmed("IDENTITY CONFIRMED", 3), Connected("CONNECTED", 4),
    Disconnected("DISCONNECTED", 0),
}

internal enum class SwurlzerProofStage(val label: String) {
    NotReported("PROOF NOT VERIFIED"), Verified("PROOF VERIFIED"), Failed("PROOF FAILED"),
}

internal enum class SwurlzerTrustStage(val label: String) {
    Unverified("UNVERIFIED"), Pending("PENDING"), Legacy("LEGACY"),
    Trusted("TRUSTED"), Failed("FAILED"),
}

internal enum class SwurlzerRouteStage(val label: String) {
    NotReported("ROUTE NOT REPORTED"), Local("LOCAL ROUTE"), Remote("REMOTE ROUTE"),
}

internal enum class SwurlzerMissionAtmosphere {
    Idle, Active, Paused, ApprovalPending, ManualIntervention,
}

internal data class SwurlzerClientLinkState(
    val nodeId: String? = null,
    val connection: SwurlzerConnectionStage = SwurlzerConnectionStage.Stored,
    val identityConfirmed: Boolean = false,
    val proof: SwurlzerProofStage = SwurlzerProofStage.NotReported,
    val trust: SwurlzerTrustStage = SwurlzerTrustStage.Unverified,
    val route: SwurlzerRouteStage = SwurlzerRouteStage.NotReported,
    val failureCategory: String? = null,
) {
    val admitsCore: Boolean
        get() = connection == SwurlzerConnectionStage.Connected && identityConfirmed &&
            proof == SwurlzerProofStage.Verified && trust == SwurlzerTrustStage.Trusted

    val accessibilityDescription: String
        get() = buildString {
            append("Connection ").append(connection.label.lowercase())
            append(". Identity ").append(if (identityConfirmed) "confirmed" else "not confirmed")
            append(". ").append(proof.label.lowercase())
            append(". Trust ").append(trust.label.lowercase())
            append(". ").append(route.label.lowercase())
            failureCategory?.let { append(". Failure category ").append(it.lowercase()) }
        }
}

internal data class SwurlzerVisualState(
    val runtimeStatus: RuntimeStatus = RuntimeStatus.STOPPED,
    val privateApiStatus: ListenerStatus = ListenerStatus.STOPPED,
    val discoveryLoopbackStatus: ListenerStatus = ListenerStatus.STOPPED,
    val discoveryLanStatus: ListenerStatus = ListenerStatus.STOPPED,
    val link: SwurlzerClientLinkState = SwurlzerClientLinkState(),
    val missionAtmosphere: SwurlzerMissionAtmosphere = SwurlzerMissionAtmosphere.Idle,
) {
    val citadelState: SwurlzerCitadelState
        get() = when (runtimeStatus) {
            RuntimeStatus.STOPPED -> SwurlzerCitadelState.Offline
            RuntimeStatus.STARTING -> SwurlzerCitadelState.Starting
            RuntimeStatus.FAILED -> SwurlzerCitadelState.Failed
            RuntimeStatus.DEGRADED -> SwurlzerCitadelState.Degraded
            RuntimeStatus.MAINTENANCE -> SwurlzerCitadelState.Degraded
            RuntimeStatus.RELOADING_CONFIGURATION -> SwurlzerCitadelState.Starting
            RuntimeStatus.RESTARTING_SERVICES -> SwurlzerCitadelState.Starting
            RuntimeStatus.SHUTTING_DOWN -> SwurlzerCitadelState.Starting
            RuntimeStatus.RUNNING -> if (
                privateApiStatus == ListenerStatus.RUNNING &&
                discoveryLoopbackStatus == ListenerStatus.RUNNING
            ) SwurlzerCitadelState.Ready else SwurlzerCitadelState.Degraded
        }

    val missionActive: Boolean
        get() = missionAtmosphere == SwurlzerMissionAtmosphere.Active
}

@Composable
internal fun SwurlzerBackdrop(
    motionEnabled: Boolean,
    state: SwurlzerVisualState,
    signal: SwurlzerEnergySignal = SwurlzerEnergySignal(),
    artAlpha: Float = .32f,
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var foreground by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, _ ->
            foreground = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (motionEnabled && foreground && state.citadelState != SwurlzerCitadelState.Failed) {
        AnimatedSwurlzerScene(state, signal, artAlpha)
    } else {
        SwurlzerScene(state, signal.target, artAlpha, 0f, .94f, .36f, 0f, 0f, 0f, 0f)
    }
}

@Composable
private fun AnimatedSwurlzerScene(
    state: SwurlzerVisualState,
    signal: SwurlzerEnergySignal,
    artAlpha: Float,
) {
    val transition = rememberInfiniteTransition(label = "swurlzer-citadel-ambient")
    val drift by transition.animateFloat(
        -5f, 5f, infiniteRepeatable(tween(18_000), RepeatMode.Reverse),
        label = "swurlzer-dragon-drift",
    )
    val breath by transition.animateFloat(
        .90f, 1f,
        infiniteRepeatable(tween(if (state.missionActive) 2_800 else 5_600), RepeatMode.Reverse),
        label = "swurlzer-dragon-breath",
    )
    val shimmer by transition.animateFloat(
        0f, 1f, infiniteRepeatable(tween(12_000), RepeatMode.Restart),
        label = "swurlzer-crystal-shimmer",
    )
    val energy = remember { Animatable(0f) }
    val runtimeEvent = remember { Animatable(0f) }
    val proofEvent = remember { Animatable(0f) }
    val missionEvent = remember { Animatable(0f) }

    LaunchedEffect(signal.id) {
        if (signal.id <= 0) return@LaunchedEffect
        energy.snapTo(0f); energy.animateTo(1f, tween(220)); energy.animateTo(0f, tween(460))
    }
    LaunchedEffect(state.citadelState) {
        if (state.citadelState != SwurlzerCitadelState.Ready) return@LaunchedEffect
        runtimeEvent.snapTo(0f); runtimeEvent.animateTo(1f, tween(240)); runtimeEvent.animateTo(0f, tween(520))
    }
    LaunchedEffect(state.link.nodeId, state.link.proof, state.link.connection) {
        if (state.link.proof != SwurlzerProofStage.Verified) return@LaunchedEffect
        proofEvent.snapTo(0f); proofEvent.animateTo(1f, tween(220)); proofEvent.animateTo(0f, tween(520))
    }
    LaunchedEffect(state.missionAtmosphere) {
        if (state.missionAtmosphere != SwurlzerMissionAtmosphere.Active) return@LaunchedEffect
        missionEvent.snapTo(0f); missionEvent.animateTo(1f, tween(240)); missionEvent.animateTo(0f, tween(500))
    }

    SwurlzerScene(
        state, signal.target, artAlpha, drift, breath, shimmer, energy.value,
        runtimeEvent.value, proofEvent.value, missionEvent.value,
    )
}

@Composable
private fun SwurlzerScene(
    state: SwurlzerVisualState,
    target: SwurlzerEnergyTarget,
    artAlpha: Float,
    drift: Float,
    breath: Float,
    shimmer: Float,
    energy: Float,
    runtimeEvent: Float,
    proofEvent: Float,
    missionEvent: Float,
) {
    val tone = swurlzerTone(state)
    val secondary = when {
        state.link.trust == SwurlzerTrustStage.Legacy -> SwurlzerPalette.Violet
        state.link.proof == SwurlzerProofStage.Verified -> SwurlzerPalette.Trust
        else -> SwurlzerPalette.Violet
    }
    val intensity = when (state.citadelState) {
        SwurlzerCitadelState.Ready -> 1.06f
        SwurlzerCitadelState.Starting -> 1f
        SwurlzerCitadelState.Degraded -> .94f
        SwurlzerCitadelState.Failed -> .86f
        SwurlzerCitadelState.Offline -> .82f
    }
    val effectiveDrift = when (state.citadelState) {
        SwurlzerCitadelState.Offline -> drift * .22f
        SwurlzerCitadelState.Degraded -> drift * .55f
        SwurlzerCitadelState.Failed -> 0f
        else -> drift
    }
    val missionScale = when (state.missionAtmosphere) {
        SwurlzerMissionAtmosphere.Paused,
        SwurlzerMissionAtmosphere.ApprovalPending -> .96f
        SwurlzerMissionAtmosphere.ManualIntervention -> .93f
        else -> 1f
    }
    val degradedFlutter = if (state.citadelState == SwurlzerCitadelState.Degraded) {
        sin(shimmer * 12.566f) * .018f + sin(shimmer * 31.416f) * .009f
    } else 0f
    val shardSpecs = remember {
        arrayOf(
            floatArrayOf(.86f, .18f, 22f, .58f),
            floatArrayOf(.79f, .32f, -28f, .40f),
            floatArrayOf(.91f, .76f, 70f, .46f),
        )
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painterResource(R.drawable.glitch_dragon_swurlzer),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                translationX = effectiveDrift
                translationY = -effectiveDrift * .25f
                scaleX = 1.075f; scaleY = 1.075f
                alpha = (artAlpha * breath * intensity * missionScale + degradedFlutter).coerceIn(0f, .42f)
            },
        )
        Canvas(Modifier.fillMaxSize()) {
            val core = Offset(size.width * .65f, size.height * .58f)
            val eye = Offset(size.width * .62f, size.height * .31f)
            val eventStrength = maxOf(runtimeEvent, proofEvent, missionEvent)
            val coreTone = when {
                proofEvent > 0f -> SwurlzerPalette.Trust
                state.missionAtmosphere == SwurlzerMissionAtmosphere.Paused ||
                    state.missionAtmosphere == SwurlzerMissionAtmosphere.ApprovalPending -> SwurlzerPalette.Amber
                state.missionAtmosphere == SwurlzerMissionAtmosphere.ManualIntervention -> SwurlzerPalette.Caution
                else -> tone
            }

            drawCircle(coreTone.copy(alpha = .045f + .08f * breath + .14f * eventStrength), size.minDimension * (.18f + .035f * eventStrength), core)
            drawCircle(coreTone.copy(alpha = .20f + .35f * eventStrength), 7f + 15f * eventStrength, core)
            drawCircle(coreTone.copy(alpha = .10f + .40f * maxOf(runtimeEvent, proofEvent)), 4f + 10f * maxOf(runtimeEvent, proofEvent), eye)

            val radius = size.minDimension * .145f
            val topLeft = Offset(core.x - radius, core.y - radius)
            val arcSize = Size(radius * 2f, radius * 2f)
            val startingSegment = (shimmer * 8f).toInt().coerceIn(0, 7)
            repeat(8) { index ->
                val active = when (state.citadelState) {
                    SwurlzerCitadelState.Starting -> index <= startingSegment
                    SwurlzerCitadelState.Ready -> true
                    SwurlzerCitadelState.Degraded -> index % 3 != startingSegment % 3
                    SwurlzerCitadelState.Failed -> index == 0 || index == 7
                    SwurlzerCitadelState.Offline -> false
                }
                drawArc(tone.copy(alpha = if (active) .32f else .07f), -90f + index * 45f, 28f, false, topLeft, arcSize, style = Stroke(if (active) 3f else 1.5f))
            }

            shardSpecs.forEachIndexed { index, spec ->
                val wave = sin(shimmer * 6.283f + index).toFloat()
                val x = size.width * spec[0]
                val y = size.height * spec[1] + wave * 5f
                val h = 42f * spec[3]
                val w = 12f * spec[3]
                val alpha = .035f + .035f * (wave + 1f)
                rotate(spec[2], Offset(x, y)) {
                    drawLine(tone.copy(alpha = alpha), Offset(x, y - h / 2f), Offset(x, y + h / 2f), 1.4f)
                    drawLine(secondary.copy(alpha = alpha), Offset(x - w / 2f, y), Offset(x + w / 2f, y), 1.2f)
                }
            }

            drawClientLink(state.link, core, shimmer)
            if (energy > 0f) {
                val center = Offset(size.width * target.x, size.height * target.y)
                drawCircle(tone.copy(alpha = .20f * energy), 20f + 105f * energy, center, style = Stroke(3f))
                drawCircle(tone.copy(alpha = .12f * energy), 26f + 62f * energy, center)
                drawLine(secondary.copy(alpha = .28f * energy), center, core, 2f)
            }
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xA8050713), Color(0x79050713), Color(0xE8070914)))))
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawClientLink(
    link: SwurlzerClientLinkState,
    core: Offset,
    shimmer: Float,
) {
    if (link.nodeId == null || link.connection == SwurlzerConnectionStage.Stored ||
        link.connection == SwurlzerConnectionStage.Disconnected) return

    val perimeter = Offset(size.width * .94f, size.height * .46f)
    val identityGate = Offset(size.width * .84f, size.height * .49f)
    val proofGate = Offset(size.width * .77f, size.height * .52f)
    val trustGate = Offset(size.width * .71f, size.height * .55f)
    val flow = .18f + .08f * sin(shimmer * 6.283f).toFloat()
    val proofTone = when {
        link.proof == SwurlzerProofStage.Failed -> SwurlzerPalette.Danger
        link.trust == SwurlzerTrustStage.Legacy -> SwurlzerPalette.Violet
        link.proof == SwurlzerProofStage.Verified -> SwurlzerPalette.Trust
        else -> SwurlzerPalette.Muted
    }

    drawCircle(SwurlzerPalette.Cyan.copy(alpha = .40f), 7f, perimeter, style = Stroke(2f))
    if (link.identityConfirmed) drawLine(SwurlzerPalette.Cyan.copy(alpha = flow), perimeter, identityGate, 2f)
    drawCircle(SwurlzerPalette.Blue.copy(alpha = if (link.identityConfirmed) .48f else .12f), 6f, identityGate, style = Stroke(2f))
    if (link.identityConfirmed) drawLine(SwurlzerPalette.Blue.copy(alpha = flow), identityGate, proofGate, 2f)
    drawCircle(proofTone.copy(alpha = if (link.proof != SwurlzerProofStage.NotReported) .52f else .12f), 6f, proofGate, style = Stroke(2f))
    if (link.proof == SwurlzerProofStage.Verified) drawLine(SwurlzerPalette.Trust.copy(alpha = flow), proofGate, trustGate, 2f)
    val trustTone = when (link.trust) {
        SwurlzerTrustStage.Trusted -> SwurlzerPalette.Trust
        SwurlzerTrustStage.Legacy -> SwurlzerPalette.Violet
        SwurlzerTrustStage.Pending -> SwurlzerPalette.Amber
        SwurlzerTrustStage.Failed -> SwurlzerPalette.Danger
        SwurlzerTrustStage.Unverified -> SwurlzerPalette.Muted
    }
    drawCircle(trustTone.copy(alpha = if (link.trust != SwurlzerTrustStage.Unverified) .48f else .12f), 6f, trustGate, style = Stroke(2f))
    if (link.admitsCore) drawLine(SwurlzerPalette.Trust.copy(alpha = flow + .10f), trustGate, core, 2.4f)
}

@Composable
internal fun SwurlzerGlassPanel(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val border = Brush.linearGradient(
        if (highlighted) listOf(SwurlzerPalette.Cyan, SwurlzerPalette.Violet, SwurlzerPalette.Blue)
        else listOf(
            SwurlzerPalette.Cyan.copy(alpha = .34f), Color(0xFF263B55).copy(alpha = .36f),
            SwurlzerPalette.Violet.copy(alpha = .28f),
        )
    )
    Box(modifier.background(border, shape).padding(1.dp)) {
        Column(
            Modifier.fillMaxWidth().background(
                Brush.linearGradient(listOf(Color(0xCE0A1120), Color(0xB8101830))), shape,
            ).padding(15.dp),
            content = content,
        )
    }
}

internal object SwurlzerPalette {
    val Cyan = Color(0xFF38E8FF); val Blue = Color(0xFF5CA8FF)
    val Violet = Color(0xFF9A55FF); val Trust = Color(0xFF4DFFB4)
    val Amber = Color(0xFFFFD45A); val Caution = Color(0xFFFF755C)
    val Danger = Color(0xFFFF4D68); val Text = Color(0xFFF7FBFF)
    val SecondaryText = Color(0xFFD7E7F5); val Muted = Color(0xFF91A9C0)
}

internal fun swurlzerTone(state: SwurlzerVisualState): Color = when {
    state.missionAtmosphere == SwurlzerMissionAtmosphere.ManualIntervention -> SwurlzerPalette.Caution
    state.missionAtmosphere == SwurlzerMissionAtmosphere.ApprovalPending -> SwurlzerPalette.Amber
    state.missionAtmosphere == SwurlzerMissionAtmosphere.Paused -> SwurlzerPalette.Amber
    state.citadelState == SwurlzerCitadelState.Ready -> SwurlzerPalette.Cyan
    state.citadelState == SwurlzerCitadelState.Starting -> SwurlzerPalette.Blue
    state.citadelState == SwurlzerCitadelState.Degraded -> SwurlzerPalette.Amber
    state.citadelState == SwurlzerCitadelState.Failed -> SwurlzerPalette.Danger
    else -> Color(0xFF426983)
}

internal fun HostUiState.toSwurlzerVisualState(): SwurlzerVisualState = SwurlzerVisualState(
    runtimeStatus = health.runtimeStatus,
    privateApiStatus = health.privateApi.status,
    discoveryLoopbackStatus = health.discoveryLoopback.status,
    discoveryLanStatus = health.discoveryLan.status,
    link = nodes.map { it.toSwurlzerClientLinkState() }.maxWithOrNull(
        compareBy<SwurlzerClientLinkState>({ it.visualRank }, { it.nodeId.orEmpty() })
    ) ?: SwurlzerClientLinkState(),
    missionAtmosphere = missionAtmosphere(),
)

internal fun NodeEntity.toSwurlzerClientLinkState(): SwurlzerClientLinkState {
    val statusValue = status.toVisualToken()
    val trustValue = trust.toVisualToken()
    val all = "${statusValue}_${trustValue}"
    val proof = when {
        all.hasAny("proof_failed", "proof_rejected", "device_proof_failed") -> SwurlzerProofStage.Failed
        all.hasAny("proof_verified", "device_proof_verified") -> SwurlzerProofStage.Verified
        else -> SwurlzerProofStage.NotReported
    }
    val connection = when {
        statusValue.hasAny("disconnected", "offline") -> SwurlzerConnectionStage.Disconnected
        statusValue.hasAny("connected") -> SwurlzerConnectionStage.Connected
        statusValue.hasAny("identity_confirmed") -> SwurlzerConnectionStage.IdentityConfirmed
        statusValue.hasAny("reachable") -> SwurlzerConnectionStage.Reachable
        statusValue.hasAny("discovered") -> SwurlzerConnectionStage.Discovered
        else -> SwurlzerConnectionStage.Stored
    }
    val identityConfirmed = statusValue.hasAny("identity_confirmed") || trustValue.hasAny("identity_confirmed")
    val trustStage = when {
        trustValue.hasAny("legacy") -> SwurlzerTrustStage.Legacy
        trustValue.hasAny("revoked", "blocked", "trust_failed", "rejected") -> SwurlzerTrustStage.Failed
        trustValue.hasAny("pending") -> SwurlzerTrustStage.Pending
        trustValue.hasAny("trusted", "enrolled") -> SwurlzerTrustStage.Trusted
        else -> SwurlzerTrustStage.Unverified
    }
    val route = when {
        all.hasAny("local_route", "route_local") -> SwurlzerRouteStage.Local
        all.hasAny("remote_route", "route_remote") -> SwurlzerRouteStage.Remote
        else -> SwurlzerRouteStage.NotReported
    }
    val failure = when {
        proof == SwurlzerProofStage.Failed -> "DEVICE PROOF VERIFICATION"
        all.hasAny("identity_failed", "identity_rejected") -> "IDENTITY CONFIRMATION"
        trustValue.hasAny("revoked") -> "REVOKED"
        trustValue.hasAny("blocked") -> "BLOCKED"
        trustStage == SwurlzerTrustStage.Failed -> "TRUST EVALUATION"
        else -> null
    }
    return SwurlzerClientLinkState(nodeId, connection, identityConfirmed, proof, trustStage, route, failure)
}

private val SwurlzerClientLinkState.visualRank: Int
    get() = connection.rank * 100 + (if (identityConfirmed) 30 else 0) +
        (if (proof == SwurlzerProofStage.Verified) 20 else 0) +
        (if (trust == SwurlzerTrustStage.Trusted) 10 else 0)

private fun HostUiState.missionAtmosphere(): SwurlzerMissionAtmosphere {
    val states = missions.map { it.state.toVisualToken() }
    return when {
        states.any { it.hasAny("take_over", "manual_intervention") } -> SwurlzerMissionAtmosphere.ManualIntervention
        states.any { it.hasAny("approval_required", "pending_approval") } -> SwurlzerMissionAtmosphere.ApprovalPending
        states.any { it.hasAny("paused") } -> SwurlzerMissionAtmosphere.Paused
        states.any { it.hasAny("accepted", "active", "running", "executing", "starting", "in_progress") } -> SwurlzerMissionAtmosphere.Active
        else -> SwurlzerMissionAtmosphere.Idle
    }
}

private fun String.toVisualToken(): String = trim().lowercase()
    .replace('-', '_').replace(' ', '_').replace('/', '_')
    .replace(',', '_').replace('|', '_').replace(';', '_').replace(':', '_')

private fun String.hasAny(vararg values: String): Boolean {
    val padded = "_${trim('_')}_"
    return values.any { "_${it.trim('_')}_" in padded }
}
