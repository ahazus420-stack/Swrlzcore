package sh.swrlz.nodehost.service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.R

@AndroidEntryPoint
class NodeHostService : Service() {
    @Inject lateinit var nodeRuntime: NodeRuntime

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        NodeHostNotificationChannel.ensure(this)
        startForeground(NOTIFICATION_ID, buildNotification(NodeHealth(runtimeStatus = RuntimeStatus.STARTING)))

        serviceScope.launch {
            nodeRuntime.health.collectLatest { health ->
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID, buildNotification(health))
            }
        }
        serviceScope.launch {
            nodeRuntime.start()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        nodeRuntime.stop()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(health: NodeHealth): Notification {
        val text = when (health.runtimeStatus) {
            RuntimeStatus.STARTING -> "Starting local node runtime"
            RuntimeStatus.RUNNING -> "Private and discovery listeners active"
            RuntimeStatus.DEGRADED -> "Loopback active; LAN discovery unavailable"
            RuntimeStatus.MAINTENANCE -> "Maintenance mode; normal work paused"
            RuntimeStatus.RELOADING_CONFIGURATION -> "Reloading configuration"
            RuntimeStatus.RESTARTING_SERVICES -> "Restarting services"
            RuntimeStatus.SHUTTING_DOWN -> "Shutdown sequence ${health.shutdownStep}/10"
            RuntimeStatus.FAILED -> "Runtime failed: ${health.lastFailure?.stage ?: "startup"}"
            RuntimeStatus.STOPPED -> "Local node runtime stopped"
        }
        return NotificationCompat.Builder(this, NodeHostNotificationChannel.CHANNEL_ID)
            .setContentTitle("SWRLZ Node Host")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOnlyAlertOnce(true)
            .setOngoing(health.runtimeStatus != RuntimeStatus.FAILED && health.runtimeStatus != RuntimeStatus.STOPPED)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1
    }
}
