package sh.swrlz.nodehost.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import sh.swrlz.nodehost.data.NodeHostDatabase
import sh.swrlz.nodehost.data.repository.NodeRepository
import sh.swrlz.nodehost.service.NodeRuntime

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NodeHostDatabase {
        return Room.databaseBuilder(context, NodeHostDatabase::class.java, "swrlz_node_host.db")
            .addMigrations(MIGRATION_1_2)
            .build()
    }

    @Provides
    @Singleton
    fun provideRepository(database: NodeHostDatabase): NodeRepository = NodeRepository(database)

    @Provides
    @Singleton
    fun provideNodeRuntime(@ApplicationContext context: Context, repository: NodeRepository): NodeRuntime = NodeRuntime(context, repository)

    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE nodes ADD COLUMN deviceId TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN installationId TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN deviceType TEXT NOT NULL DEFAULT 'android-client'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN appVersion TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN protocolVersion INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE nodes ADD COLUMN firstRegisteredAt INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE nodes ADD COLUMN registrationState TEXT NOT NULL DEFAULT 'REGISTERED'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN connectionState TEXT NOT NULL DEFAULT 'OFFLINE'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN identityState TEXT NOT NULL DEFAULT 'CONFIRMED'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN proofState TEXT NOT NULL DEFAULT 'PENDING'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN currentMissionId TEXT")
            db.execSQL("ALTER TABLE nodes ADD COLUMN archived INTEGER NOT NULL DEFAULT 0")
            db.execSQL("UPDATE nodes SET firstRegisteredAt = lastSeen WHERE firstRegisteredAt = 0")
        }
    }
}
