package sh.swrlz.nodehost.service

import org.json.JSONObject
import sh.swrlz.nodehost.data.entity.NodeEntity

internal data class RegistrationDecision(val response: DiscoveryHttpResponse, val node: NodeEntity? = null)

/** Verification and persistence contract. Registration never grants mission trust. */
internal object NodeRegistrationProtocol {
    const val REGISTER_PATH = "/nodes/register"
    const val HEARTBEAT_PATH = "/nodes/heartbeat"
    const val INVENTORY_PATH = "/nodes"

    fun handles(path: String): Boolean = path == REGISTER_PATH || path == HEARTBEAT_PATH || path == INVENTORY_PATH

    fun register(request: DiscoveryHttpRequest, now: Long, existing: NodeEntity?): RegistrationDecision {
        if (request.method != "POST") return error(405, "METHOD_NOT_ALLOWED", "POST required")
        val json = runCatching { JSONObject(request.body) }.getOrNull() ?: return error(400, "INVALID_JSON", "Registration body is invalid")
        val nodeId = json.optString("nodeId").trim()
        val deviceId = json.optString("deviceId").trim()
        val installationId = json.optString("installationId").trim()
        val label = json.optString("displayName", "SWRLZ CLIENT").take(96)
        val appVersion = json.optString("appVersion").take(64)
        val protocol = json.optInt("protocolVersion", 0)
        if (!nodeId.startsWith("client-") || deviceId.length < 8 || installationId.length < 8) return error(422, "IDENTITY_REJECTED", "Stable CLIENT identity fields are required")
        if (protocol != 1) return error(409, "PROTOCOL_INCOMPATIBLE", "Protocol version 1 required")
        val proofPresented = request.headers["x-swrlz-device-proof"].orEmpty().length >= 16
        val proofState = if (proofPresented) "PRESENTED" else "PENDING"
        val first = existing?.firstRegisteredAt ?: now
        val node = NodeEntity(
            nodeId=nodeId, label=label, status="CONNECTED", capabilities=json.optJSONArray("capabilities")?.toString() ?: "[]",
            trust=existing?.trust ?: "UNTRUSTED", lastSeen=now, deviceId=deviceId, installationId=installationId,
            deviceType=json.optString("deviceType", "android-client"), appVersion=appVersion, protocolVersion=protocol,
            firstRegisteredAt=first, registrationState="REGISTERED", connectionState="CONNECTED",
            identityState="CONFIRMED", proofState=proofState, currentMissionId=null, archived=false,
        )
        return RegistrationDecision(ok("REGISTERED", node), node)
    }

    fun heartbeat(request: DiscoveryHttpRequest, now: Long, existing: NodeEntity?): RegistrationDecision {
        if (request.method != "POST") return error(405, "METHOD_NOT_ALLOWED", "POST required")
        val json = runCatching { JSONObject(request.body) }.getOrNull() ?: return error(400, "INVALID_JSON", "Heartbeat body is invalid")
        val nodeId = json.optString("nodeId")
        if (existing == null || existing.nodeId != nodeId) return error(404, "NOT_REGISTERED", "Register before heartbeat")
        val requested = json.optString("state", "CONNECTED").uppercase()
        val state = if (requested in setOf("CONNECTED","BUSY","CONNECTING","VERIFYING","REGISTERING")) requested else "CONNECTED"
        val missionId = json.optString("missionId").takeIf { it.isNotBlank() }
        return RegistrationDecision(ok("HEARTBEAT_ACCEPTED", existing.copy(status=state, connectionState=state, lastSeen=now, currentMissionId=missionId)), existing.copy(status=state, connectionState=state, lastSeen=now, currentMissionId=missionId))
    }

    fun inventory(nodes: List<NodeEntity>): DiscoveryHttpResponse {
        val body = nodes.joinToString(prefix="{\"ok\":true,\"nodes\":[", postfix="]}") { n ->
            "{\"nodeId\":\"${esc(n.nodeId)}\",\"label\":\"${esc(n.label)}\",\"state\":\"${esc(n.connectionState)}\",\"trust\":\"${esc(n.trust)}\",\"lastSeen\":${n.lastSeen}}"
        }
        return DiscoveryHttpResponse(200,"OK",body,mapOf("Cache-Control" to "no-store"))
    }

    private fun ok(code: String, node: NodeEntity) = DiscoveryHttpResponse(200,"OK","{\"ok\":true,\"code\":\"$code\",\"nodeId\":\"${esc(node.nodeId)}\",\"registrationState\":\"${node.registrationState}\",\"connectionState\":\"${node.connectionState}\",\"trust\":\"${node.trust}\",\"proofState\":\"${node.proofState}\"}",mapOf("Cache-Control" to "no-store"))
    private fun error(status:Int, code:String, message:String)=RegistrationDecision(DiscoveryHttpResponse(status,"Error","{\"ok\":false,\"error\":{\"code\":\"$code\",\"message\":\"${esc(message)}\"}}",mapOf("Cache-Control" to "no-store")))
    private fun esc(v:String)=v.replace("\\","\\\\").replace("\"","\\\"")
}
