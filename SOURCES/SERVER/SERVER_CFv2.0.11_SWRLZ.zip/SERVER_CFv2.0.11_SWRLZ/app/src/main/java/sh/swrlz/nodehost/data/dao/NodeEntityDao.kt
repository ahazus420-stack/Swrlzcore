package sh.swrlz.nodehost.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.entity.NodeEntity

@Dao
interface NodeEntityDao {
    @Query("SELECT * FROM nodes WHERE archived = 0 ORDER BY CASE connectionState WHEN 'CONNECTING' THEN 0 WHEN 'VERIFYING' THEN 1 WHEN 'REGISTERING' THEN 2 WHEN 'CONNECTED' THEN 3 WHEN 'BUSY' THEN 4 ELSE 5 END, lastSeen DESC")
    fun observeNodes(): Flow<List<NodeEntity>>

    @Query("SELECT * FROM nodes WHERE nodeId = :nodeId LIMIT 1")
    suspend fun find(nodeId: String): NodeEntity?

    @Query("SELECT * FROM nodes WHERE deviceBindingFingerprint = :binding LIMIT 1")
    suspend fun findByBinding(binding: String): NodeEntity?

    @Query("SELECT * FROM nodes WHERE deviceId = :deviceId AND archived = 0 ORDER BY lastSeen DESC LIMIT 1")
    suspend fun findByDeviceId(deviceId: String): NodeEntity?

    @Query("UPDATE nodes SET archived = 1, registrationState = 'SUPERSEDED', connectionState = 'OFFLINE', status = 'OFFLINE' WHERE deviceId = :deviceId AND nodeId != :canonicalNodeId")
    suspend fun archiveDuplicates(deviceId: String, canonicalNodeId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(node: NodeEntity)

    @Query("UPDATE nodes SET connectionState = :state, status = :state, lastSeen = :lastSeen, currentMissionId = :missionId WHERE nodeId = :nodeId")
    suspend fun updatePresence(nodeId: String, state: String, lastSeen: Long, missionId: String?)

    @Query("UPDATE nodes SET connectionState = 'OFFLINE', status = 'OFFLINE' WHERE connectionState IN ('CONNECTED','BUSY','CONNECTING','VERIFYING','REGISTERING') AND lastSeen < :cutoff")
    suspend fun markStaleOffline(cutoff: Long)
}
