package sh.swrlz.nodehost.data.repository

import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.NodeHostDatabase
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity

class NodeRepository(private val db: NodeHostDatabase) {
    fun observeNodes(): Flow<List<NodeEntity>> = db.nodeEntityDao().observeNodes()

    suspend fun upsertNode(node: NodeEntity) = db.nodeEntityDao().upsert(node)

    suspend fun findNode(nodeId: String): NodeEntity? = db.nodeEntityDao().find(nodeId)
    suspend fun findByBinding(binding: String): NodeEntity? = db.nodeEntityDao().findByBinding(binding)
    suspend fun findByDeviceId(deviceId: String): NodeEntity? = db.nodeEntityDao().findByDeviceId(deviceId)
    suspend fun archiveDuplicates(deviceId: String, canonicalNodeId: String) = db.nodeEntityDao().archiveDuplicates(deviceId, canonicalNodeId)

    suspend fun updatePresence(nodeId: String, state: String, lastSeen: Long, missionId: String? = null) =
        db.nodeEntityDao().updatePresence(nodeId, state, lastSeen, missionId)

    suspend fun markStaleOffline(cutoff: Long) = db.nodeEntityDao().markStaleOffline(cutoff)

    fun observeMissions(): Flow<List<MissionEntity>> = db.missionEntityDao().observeMissions()

    suspend fun upsertMission(mission: MissionEntity) = db.missionEntityDao().upsert(mission)
}
