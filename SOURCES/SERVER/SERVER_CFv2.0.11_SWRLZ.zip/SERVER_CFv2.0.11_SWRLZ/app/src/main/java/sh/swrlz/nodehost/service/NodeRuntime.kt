package sh.swrlz.nodehost.service

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import sh.swrlz.nodehost.data.repository.NodeRepository
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

class NodeRuntime(context: Context, private val repository: NodeRepository) {
    private val appContext = context.applicationContext
    private val running = AtomicBoolean(false)
    private val runtimeGeneration = AtomicLong(0L)

    @Volatile
    private var intentionalLifecycleTransition = false
    private val identityStore = NodeIdentityStore(appContext)
    private val diagnostics = RuntimeDiagnostics(appContext)
    private val _health = MutableStateFlow(NodeHealth())
    val health: StateFlow<NodeHealth> = _health.asStateFlow()
    val diagnosticSnapshot: StateFlow<RuntimeDiagnosticSnapshot> = diagnostics.snapshot

    @Volatile
    private var activeIdentity: NodeHostIdentity? = null

    @Volatile
    private var hostVersion: String = ""

    private var privateServerSocket: ServerSocket? = null
    private var privateServerThread: Thread? = null
    private var presenceSweepThread: Thread? = null
    private val discoverySockets = CopyOnWriteArrayList<ServerSocket>()
    private val discoveryThreads = CopyOnWriteArrayList<Thread>()

    @Synchronized
    fun start(): NodeHealth {
        if (running.get()) return _health.value

        // FAILED and stale states are recoverable without reinstalling. Fully retire
        // any previous generation before binding a new set of listeners.
        intentionalLifecycleTransition = true
        running.set(false)
        closeResourcesAndAwait()
        val generation = runtimeGeneration.incrementAndGet()
        intentionalLifecycleTransition = false
        running.set(true)

        _health.value = NodeHealth(
            runtimeStatus = RuntimeStatus.STARTING,
            privateApi = ListenerHealth(ListenerStatus.STARTING),
            discoveryLoopback = ListenerHealth(ListenerStatus.STARTING),
            discoveryLan = ListenerHealth(ListenerStatus.STARTING),
            lastFailure = _health.value.lastFailure,
            lastSuccessfulStartEpochMs = _health.value.lastSuccessfulStartEpochMs,
        )
        diagnostics.record("INFO", "runtime_starting")

        var stage = "identity"
        var privateSocket: ServerSocket? = null
        try {
            val identity = identityStore.loadOrCreate()
            stage = "version"
            val version = resolveHostVersion()

            stage = "private_8080"
            val boundPrivateSocket = ServerSocket(PRIVATE_PORT, BACKLOG, InetAddress.getLoopbackAddress())
            privateSocket = boundPrivateSocket
            _health.value = _health.value.copy(privateApi = ListenerHealth(ListenerStatus.RUNNING, "127.0.0.1:$PRIVATE_PORT"))
            diagnostics.record("INFO", "listener_bound", "private_api 127.0.0.1:$PRIVATE_PORT")

            stage = "discovery_8787"
            val localDiscoverySockets = bindDiscoverySockets()
            val loopbackSocket = localDiscoverySockets.firstOrNull { it.inetAddress.isLoopbackAddress }
            if (loopbackSocket == null) {
                boundPrivateSocket.close()
                throw IllegalStateException("Discovery loopback listener is unavailable")
            }
            val lanCount = localDiscoverySockets.count { !it.inetAddress.isLoopbackAddress }

            activeIdentity = identity
            hostVersion = version
            privateServerSocket = boundPrivateSocket
            discoverySockets.addAll(localDiscoverySockets)

            val now = System.currentTimeMillis()
            _health.value = _health.value.copy(
                runtimeStatus = if (lanCount > 0) RuntimeStatus.RUNNING else RuntimeStatus.DEGRADED,
                discoveryLoopback = ListenerHealth(ListenerStatus.RUNNING, "127.0.0.1:${DiscoveryProtocol.PORT}"),
                discoveryLan = if (lanCount > 0) {
                    ListenerHealth(ListenerStatus.RUNNING, "$lanCount approved LAN listener(s)")
                } else {
                    ListenerHealth(ListenerStatus.UNAVAILABLE, "No approved LAN interface; loopback remains active")
                },
                lastSuccessfulStartEpochMs = now,
            )

            privateServerThread = listenerThread("swrlz-private-runtime-g$generation") {
                servePrivateRuntime(boundPrivateSocket, generation)
                reportUnexpectedListenerExit(
                    listener = ListenerKind.PRIVATE_API,
                    detail = "Private API listener terminated unexpectedly",
                    generation = generation,
                )
            }
            privateServerThread?.start()
            presenceSweepThread = listenerThread("swrlz-presence-sweep") {
                while (isGenerationActive(generation)) {
                    runBlocking { repository.markStaleOffline(System.currentTimeMillis() - PRESENCE_TIMEOUT_MS) }
                    try { Thread.sleep(PRESENCE_SWEEP_INTERVAL_MS) } catch (_: InterruptedException) { break }
                }
            }.also { it.start() }

            localDiscoverySockets.forEach { socket ->
                val address = socket.inetAddress.hostAddress ?: "unknown"
                listenerThread("swrlz-discovery-$address-g$generation") {
                    serveDiscovery(socket, generation)
                    reportUnexpectedListenerExit(
                        listener = if (socket.inetAddress.isLoopbackAddress) {
                            ListenerKind.DISCOVERY_LOOPBACK
                        } else {
                            ListenerKind.DISCOVERY_LAN
                        },
                        detail = "Discovery listener $address terminated unexpectedly",
                        generation = generation,
                    )
                }.also { thread ->
                    discoveryThreads += thread
                    thread.start()
                }
                diagnostics.record("INFO", "listener_bound", "discovery $address:${DiscoveryProtocol.PORT}")
            }

            val registryCount = runBlocking { repository.observeNodes().first().size }
            diagnostics.record("INFO", "registry_loaded", "database=swrlz_node_host.db schema=3 registered=$registryCount")
            diagnostics.record("INFO", "runtime_started", "status=${_health.value.runtimeStatus}")
            return _health.value
        } catch (error: Exception) {
            intentionalLifecycleTransition = true
            running.set(false)
            privateSocket?.closeQuietly()
            closeResourcesAndAwait()
            intentionalLifecycleTransition = false
            val failure = RuntimeFailure(
                timestampEpochMs = System.currentTimeMillis(),
                stage = stage,
                listener = when (stage) {
                    "private_8080" -> "private_api"
                    "discovery_8787" -> "discovery"
                    else -> null
                },
                errorType = error.javaClass.simpleName.take(64),
                message = sanitizeError(error.message),
            )
            _health.value = terminalStartupFailureHealth(
                previous = _health.value,
                stage = stage,
                failure = failure,
            )
            diagnostics.record("ERROR", "runtime_start_failed", "stage=$stage type=${failure.errorType} message=${failure.message}")
            return _health.value
        }
    }

    @Synchronized
    fun stop() {
        if (!running.get() && _health.value.runtimeStatus == RuntimeStatus.STOPPED) return
        intentionalLifecycleTransition = true
        running.set(false)
        runtimeGeneration.incrementAndGet()
        closeResourcesAndAwait()
        _health.value = _health.value.copy(
            runtimeStatus = RuntimeStatus.STOPPED,
            privateApi = ListenerHealth(),
            discoveryLoopback = ListenerHealth(),
            discoveryLan = ListenerHealth(),
            shutdownStep = 0,
            lifecycleDetail = "Stopped cleanly",
        )
        intentionalLifecycleTransition = false
        diagnostics.record("INFO", "runtime_stopped")
    }

    fun readRecentDiagnostics(): String = diagnostics.readRecent()

    fun clearDiagnostics() = diagnostics.clear()

    @Synchronized
    private fun reportUnexpectedListenerExit(listener: ListenerKind, detail: String, generation: Long) {
        if (!isGenerationActive(generation) || intentionalLifecycleTransition) return

        val failure = RuntimeFailure(
            timestampEpochMs = System.currentTimeMillis(),
            stage = "listener_loop",
            listener = listener.wireName,
            errorType = "ListenerTerminated",
            message = sanitizeError(detail),
        )
        _health.value = unexpectedListenerExitHealth(_health.value, listener, failure)
        diagnostics.record(
            "ERROR",
            "listener_terminated",
            "listener=${listener.wireName} message=${failure.message}",
        )
    }

    private fun servePrivateRuntime(server: ServerSocket, generation: Long) {
        while (isGenerationActive(generation)) {
            val client = try {
                server.accept()
            } catch (_: SocketException) {
                break
            } catch (_: Exception) {
                if (!running.get()) break else continue
            }
            try {
                client.use(::handlePrivateClient)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private fun handlePrivateClient(socket: Socket) {
        val started = System.nanoTime()
        socket.soTimeout = SOCKET_TIMEOUT_MS
        val requestLine = readHttpLine(socket.getInputStream(), MAX_REQUEST_LINE_BYTES) ?: return
        val parts = requestLine.split(' ')
        val method = parts.getOrNull(0) ?: "UNKNOWN"
        val path = parts.getOrNull(1)?.substringBefore('?') ?: "/"
        val payload = when (path) {
            "/status" -> "{\"ok\":true,\"node\":\"SWRLZ Node Host\",\"mode\":\"embedded\"}"
            "/health" -> "healthy"
            else -> "not found"
        }.toByteArray(StandardCharsets.UTF_8)
        val statusCode = if (path == "/status" || path == "/health") 200 else 404
        socket.getOutputStream().use { output ->
            output.write(buildPrivateResponse(payload, statusCode))
            output.flush()
        }
        diagnostics.recordHttp(method, path, statusCode, elapsedMs(started), "private")
    }

    private fun serveDiscovery(server: ServerSocket, generation: Long) {
        while (isGenerationActive(generation)) {
            val client = try {
                server.accept()
            } catch (_: SocketException) {
                break
            } catch (_: Exception) {
                if (!running.get()) break else continue
            }
            try {
                client.use(::handleDiscoveryClient)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private fun handleDiscoveryClient(socket: Socket) {
        val started = System.nanoTime()
        socket.soTimeout = SOCKET_TIMEOUT_MS
        var method = "UNKNOWN"
        var path = "/"
        val response = try {
            val request = parseDiscoveryRequest(socket.getInputStream())
            method = request.method
            path = request.path
            if (NodeRegistrationProtocol.handles(request.path)) {
                handleRegistrationRequest(request)
            } else if (NodeCompatibilityProtocol.handles(request.path)) {
                val runtime = _health.value
                NodeCompatibilityProtocol.handle(
                    request = request,
                    snapshot = NodeCompatibilitySnapshot(
                        phase = runtime.runtimeStatus.name,
                        identityReady = activeIdentity != null,
                        discoveryHealthy = runtime.discoveryLoopback.status == ListenerStatus.RUNNING,
                        privateHealthy = runtime.privateApi.status == ListenerStatus.RUNNING,
                        nodeId = activeIdentity?.nodeId,
                        installationId = activeIdentity?.installationId,
                        hostVersion = hostVersion,
                        lanUrls = discoverySockets
                            .asSequence()
                            .filter { socket -> !socket.isClosed && !socket.inetAddress.isLoopbackAddress }
                            .mapNotNull { socket ->
                                socket.inetAddress.hostAddress?.let { address ->
                                    "http://$address:${socket.localPort}"
                                }
                            }
                            .toList(),
                    ),
                )
            } else {
                DiscoveryProtocol.handle(request, activeIdentity, hostVersion)
            }
        } catch (_: BadHttpRequest) {
            DiscoveryHttpResponse(
                statusCode = 400,
                reason = "Bad Request",
                body = "{\"ok\":false,\"error\":{\"code\":\"BAD_REQUEST\",\"message\":\"Malformed discovery request\"},\"protocolVersion\":1,\"schemaVersion\":1}",
                headers = mapOf("Cache-Control" to "no-store"),
            )
        } catch (_: Exception) {
            DiscoveryHttpResponse(
                statusCode = 500,
                reason = "Internal Server Error",
                body = "{\"ok\":false,\"error\":{\"code\":\"DISCOVERY_ERROR\",\"message\":\"Discovery response unavailable\"},\"protocolVersion\":1,\"schemaVersion\":1}",
                headers = mapOf("Cache-Control" to "no-store"),
            )
        }

        socket.getOutputStream().use { output ->
            output.write(buildDiscoveryResponse(response))
            output.flush()
        }
        diagnostics.recordHttp(method, path, response.statusCode, elapsedMs(started), "discovery")
    }


    private fun handleRegistrationRequest(request: DiscoveryHttpRequest): DiscoveryHttpResponse = runBlocking {
        val now = System.currentTimeMillis()
        repository.markStaleOffline(now - PRESENCE_TIMEOUT_MS)
        when (request.path) {
            NodeRegistrationProtocol.REGISTER_PATH, NodeRegistrationProtocol.HEARTBEAT_PATH, NodeRegistrationProtocol.DISCONNECT_PATH
                -> if (_health.value.runtimeStatus == RuntimeStatus.MAINTENANCE || _health.value.runtimeStatus == RuntimeStatus.SHUTTING_DOWN) {
                    return@runBlocking DiscoveryHttpResponse(503, "Service Unavailable", "{\"ok\":false,\"error\":{\"code\":\"LIFECYCLE_UNAVAILABLE\",\"message\":\"Registration and heartbeat are paused by server lifecycle state\"}}")
                } else when (request.path) {
                    NodeRegistrationProtocol.REGISTER_PATH -> {
                        val json = runCatching { org.json.JSONObject(request.body) }.getOrElse { org.json.JSONObject() }
                        val candidateId = json.optString("nodeId")
                        val binding = json.optString("deviceBindingFingerprint")
                        val deviceId = json.optString("deviceId")
                        val existing = repository.findByBinding(binding) ?: repository.findByDeviceId(deviceId) ?: repository.findNode(candidateId)
                        val decision = NodeRegistrationProtocol.register(request, now, existing)
                        decision.node?.let { node ->
                            repository.upsertNode(node)
                            if (deviceId.isNotBlank()) repository.archiveDuplicates(deviceId, node.nodeId)
                        }
                        decision.response
                    }
                    NodeRegistrationProtocol.DISCONNECT_PATH -> {
                        val candidateId = runCatching { org.json.JSONObject(request.body).optString("nodeId") }.getOrDefault("")
                        val decision = NodeRegistrationProtocol.disconnect(request, now, repository.findNode(candidateId))
                        decision.node?.let { repository.upsertNode(it) }
                        decision.response
                    }
                    else -> {
                        val candidateId = runCatching { org.json.JSONObject(request.body).optString("nodeId") }.getOrDefault("")
                        val decision = NodeRegistrationProtocol.heartbeat(request, now, repository.findNode(candidateId))
                        decision.node?.let { repository.upsertNode(it) }
                        decision.response
                    }
                }
            NodeRegistrationProtocol.INVENTORY_PATH -> {
                if (request.method != "GET") DiscoveryHttpResponse(405, "Method Not Allowed", "{\"ok\":false}")
                else NodeRegistrationProtocol.inventory(repository.observeNodes().first())
            }
            else -> DiscoveryHttpResponse(404, "Not Found", "{\"ok\":false}")
        }
    }

    @Synchronized fun enterMaintenance(): NodeHealth {
        if (!running.get()) return _health.value
        _health.value = _health.value.copy(runtimeStatus = RuntimeStatus.MAINTENANCE, lifecycleDetail = "Pausing new missions and registrations")
        Thread.sleep(150)
        _health.value = _health.value.copy(lifecycleDetail = "Maintenance active; administration remains available")
        diagnostics.record("INFO", "maintenance_entered")
        return _health.value
    }

    @Synchronized fun reloadConfiguration(): NodeHealth {
        if (!running.get()) return _health.value
        _health.value = _health.value.copy(runtimeStatus = RuntimeStatus.RELOADING_CONFIGURATION, lifecycleDetail = "Reloading configuration")
        Thread.sleep(150)
        _health.value = _health.value.copy(lifecycleDetail = "Validating runtime-safe configuration")
        Thread.sleep(150)
        diagnostics.record("INFO", "configuration_reloaded")
        _health.value = _health.value.copy(runtimeStatus = effectiveOnlineStatus(), lifecycleDetail = "Configuration reloaded")
        return _health.value
    }

    @Synchronized fun restartServices(): NodeHealth {
        if (!running.get()) return start()
        _health.value = _health.value.copy(
            runtimeStatus = RuntimeStatus.RESTARTING_SERVICES,
            lifecycleDetail = "Retiring current listener generation",
        )
        diagnostics.record("INFO", "services_restart_begin", "generation=${runtimeGeneration.get()}")

        intentionalLifecycleTransition = true
        running.set(false)
        runtimeGeneration.incrementAndGet()
        closeResourcesAndAwait()
        _health.value = _health.value.copy(lifecycleDetail = "Starting replacement listener generation")
        Thread.sleep(150)
        intentionalLifecycleTransition = false

        return start()
    }

    @Synchronized fun beginShutdownSequence() {
        if (!running.get()) { stop(); return }
        _health.value = _health.value.copy(runtimeStatus = RuntimeStatus.SHUTTING_DOWN, shutdownStep = 1, lifecycleDetail = "Stopping new client connections")
        val steps = listOf("Notify connected clients","Drain or safely cancel active operations","Flush pending writes and queues","Save runtime/session state","Rotate and finalize logs","Close encrypted stores","Stop workers and services","Shutdown networking","Power down cleanly")
        steps.forEachIndexed { index, detail ->
            _health.value = _health.value.copy(shutdownStep = index + 2, lifecycleDetail = detail)
            diagnostics.record("INFO", "shutdown_step", "step=${index+2} detail=$detail")
            Thread.sleep(100)
        }
        stop()
    }

    private fun effectiveOnlineStatus(): RuntimeStatus = if (_health.value.discoveryLan.status == ListenerStatus.RUNNING) RuntimeStatus.RUNNING else RuntimeStatus.DEGRADED


    private fun readBody(input: InputStream, length: Int): String {
        val bytes = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val read = input.read(bytes, offset, length - offset)
            if (read < 0) throw BadHttpRequest()
            offset += read
        }
        return String(bytes, StandardCharsets.UTF_8)
    }

    private fun elapsedMs(startedNanos: Long): Long =
        (System.nanoTime() - startedNanos).coerceAtLeast(0L) / 1_000_000L

    private fun parseDiscoveryRequest(input: InputStream): DiscoveryHttpRequest {
        val requestLine = readHttpLine(input, MAX_REQUEST_LINE_BYTES) ?: throw BadHttpRequest()
        val parts = requestLine.split(' ')
        if (parts.size != 3 || !parts[2].startsWith("HTTP/1.")) throw BadHttpRequest()

        val target = parts[1]
        if (!target.startsWith('/')) throw BadHttpRequest()
        val headers = linkedMapOf<String, String>()
        var totalHeaderBytes = 0

        repeat(MAX_HEADER_COUNT) {
            val line = readHttpLine(input, MAX_HEADER_LINE_BYTES) ?: throw BadHttpRequest()
            totalHeaderBytes += line.length
            if (totalHeaderBytes > MAX_TOTAL_HEADER_BYTES) throw BadHttpRequest()
            if (line.isEmpty()) {
                val rawContentLength = headers["content-length"]
                val contentLength = when {
                    rawContentLength == null -> 0L
                    else -> rawContentLength.toLongOrNull() ?: throw BadHttpRequest()
                }
                if (contentLength < 0L || contentLength > MAX_REQUEST_BODY_BYTES) throw BadHttpRequest()
                val body = if (contentLength > 0L) readBody(input, contentLength.toInt()) else ""
                return DiscoveryHttpRequest(
                    method = parts[0],
                    path = target.substringBefore('?'),
                    headers = headers,
                    contentLength = contentLength,
                    body = body,
                )
            }

            val separator = line.indexOf(':')
            if (separator <= 0) throw BadHttpRequest()
            val name = line.substring(0, separator).trim().lowercase(Locale.US)
            val value = line.substring(separator + 1).trim()
            if (name.isEmpty()) throw BadHttpRequest()
            headers[name] = headers[name]?.let { "$it,$value" } ?: value
        }
        throw BadHttpRequest()
    }

    /**
     * Binds loopback plus explicit local-link interface addresses. It never uses
     * 0.0.0.0, and it excludes known cellular, VPN, and tunnel interface names.
     */
    private fun bindDiscoverySockets(): List<ServerSocket> {
        val addresses = approvedDiscoveryAddresses()
        val loopback = addresses.firstOrNull { it is Inet4Address && it.isLoopbackAddress }
            ?: return emptyList()
        val loopbackSocket = bindDiscoverySocket(loopback) ?: return emptyList()
        val sockets = mutableListOf(loopbackSocket)

        addresses.asSequence()
            .filterNot(InetAddress::isLoopbackAddress)
            .forEach { address ->
                bindDiscoverySocket(address)?.let(sockets::add)
            }
        return sockets
    }

    private fun bindDiscoverySocket(address: InetAddress): ServerSocket? = try {
        ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(address, DiscoveryProtocol.PORT), BACKLOG)
        }
    } catch (_: Exception) {
        // Approved addresses can disappear while Android changes network state.
        null
    }

    private fun approvedDiscoveryAddresses(): List<InetAddress> {
        val addresses = linkedMapOf<String, InetAddress>()
        val ipv4Loopback = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))
        addresses[ipv4Loopback.hostAddress ?: "127.0.0.1"] = ipv4Loopback

        val interfaces = try {
            NetworkInterface.getNetworkInterfaces()
        } catch (_: SocketException) {
            null
        } ?: return addresses.values.toList()

        while (interfaces.hasMoreElements()) {
            val networkInterface = interfaces.nextElement()
            val name = networkInterface.name.lowercase(Locale.US)
            val usable = try {
                networkInterface.isUp && !networkInterface.isLoopback && !networkInterface.isVirtual
            } catch (_: SocketException) {
                false
            }
            if (!usable || isBlockedInterface(name) || !isApprovedLocalInterface(name)) continue

            val interfaceAddresses = networkInterface.inetAddresses
            while (interfaceAddresses.hasMoreElements()) {
                val address = interfaceAddresses.nextElement()
                if (address is Inet4Address &&
                    !address.isLoopbackAddress &&
                    (address.isSiteLocalAddress || address.isLinkLocalAddress)
                ) {
                    addresses[address.hostAddress] = address
                }
            }
        }
        return addresses.values.toList()
    }

    private fun isApprovedLocalInterface(name: String): Boolean = APPROVED_INTERFACE_PREFIXES.any(name::startsWith)

    private fun isBlockedInterface(name: String): Boolean = BLOCKED_INTERFACE_PREFIXES.any(name::startsWith)

    @Suppress("DEPRECATION")
    private fun resolveHostVersion(): String {
        val packageInfo = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
        return packageInfo.versionName?.trim()?.takeIf(String::isNotEmpty)
            ?: throw IllegalStateException("NODE_HOST package version is unavailable")
    }

    private fun buildPrivateResponse(payload: ByteArray, statusCode: Int): ByteArray {
        val statusText = if (statusCode == 200) "OK" else "NOT FOUND"
        val headers = "HTTP/1.1 $statusCode $statusText\r\n" +
            "Content-Type: text/plain; charset=utf-8\r\n" +
            "Content-Length: ${payload.size}\r\n" +
            "Connection: close\r\n\r\n"
        return headers.toByteArray(StandardCharsets.UTF_8) + payload
    }

    private fun buildDiscoveryResponse(response: DiscoveryHttpResponse): ByteArray {
        val payload = response.body.toByteArray(StandardCharsets.UTF_8)
        val headers = buildString {
            append("HTTP/1.1 ${response.statusCode} ${response.reason}\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n")
            response.headers.forEach { (name, value) -> append("$name: $value\r\n") }
            append("Content-Length: ${payload.size}\r\n")
            append("Connection: close\r\n\r\n")
        }
        return headers.toByteArray(StandardCharsets.UTF_8) + payload
    }

    private fun readHttpLine(input: InputStream, maxBytes: Int): String? {
        val buffer = ByteArrayOutputStream()
        var sawAny = false
        while (true) {
            if (buffer.size() >= maxBytes) throw BadHttpRequest()
            val value = input.read()
            if (value == -1) return if (sawAny) buffer.toString(StandardCharsets.UTF_8.name()) else null
            sawAny = true
            if (value == '\n'.code) {
                val bytes = buffer.toByteArray()
                val length = if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) bytes.size - 1 else bytes.size
                return String(bytes, 0, length, StandardCharsets.UTF_8)
            }
            buffer.write(value)
        }
    }


    private fun sanitizeError(message: String?): String = message
        ?.replace(Regex("[\r\n\t]+"), " ")
        ?.trim()
        ?.take(200)
        ?.takeIf { it.isNotEmpty() }
        ?: "Operation failed"

    private fun listenerThread(name: String, block: () -> Unit): Thread = Thread(block, name).apply {
        isDaemon = true
    }

    private fun isGenerationActive(generation: Long): Boolean =
        running.get() && runtimeGeneration.get() == generation && !intentionalLifecycleTransition

    private fun closeResourcesAndAwait() {
        val current = Thread.currentThread()
        val privateThread = privateServerThread
        val discoveryThreadSnapshot = discoveryThreads.toList()
        val presenceThread = presenceSweepThread

        privateServerSocket?.closeQuietly()
        discoverySockets.forEach { it.closeQuietly() }
        privateThread?.interrupt()
        discoveryThreadSnapshot.forEach(Thread::interrupt)
        presenceThread?.interrupt()

        privateThread.joinQuietly(current)
        discoveryThreadSnapshot.forEach { it.joinQuietly(current) }
        presenceThread.joinQuietly(current)

        privateServerSocket = null
        privateServerThread = null
        presenceSweepThread = null
        discoverySockets.clear()
        discoveryThreads.clear()
        activeIdentity = null
        hostVersion = ""
    }

    private fun Thread?.joinQuietly(current: Thread) {
        val thread = this ?: return
        if (thread === current) return
        try {
            thread.join(LISTENER_JOIN_TIMEOUT_MS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private fun ServerSocket.closeQuietly() {
        try {
            close()
        } catch (_: Exception) {
            // Stop is idempotent.
        }
    }

    private class BadHttpRequest : Exception()

    companion object {
        private const val PRIVATE_PORT = 8080
        private const val BACKLOG = 50
        private const val PRESENCE_TIMEOUT_MS = 90_000L
        private const val PRESENCE_SWEEP_INTERVAL_MS = 15_000L
        private const val LISTENER_JOIN_TIMEOUT_MS = 2_000L
        private const val SOCKET_TIMEOUT_MS = 2_000
        private const val MAX_REQUEST_LINE_BYTES = 4_096
        private const val MAX_HEADER_LINE_BYTES = 8_192
        private const val MAX_TOTAL_HEADER_BYTES = 16_384
        private const val MAX_HEADER_COUNT = 64
        private const val MAX_REQUEST_BODY_BYTES = 8_192L

        private val APPROVED_INTERFACE_PREFIXES = listOf(
            "wlan", "swlan", "ap", "eth", "en", "rndis", "usb", "bnep", "bt-pan",
        )
        private val BLOCKED_INTERFACE_PREFIXES = listOf(
            "rmnet", "ccmni", "pdp", "wwan", "tun", "tap", "ppp", "ipsec", "vti", "wg",
        )
    }
}
