package sh.swrlz.nodehost.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.TextButton
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swrlz.nodehost.data.entity.MissionEntity
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.service.ListenerHealth
import sh.swrlz.nodehost.service.ListenerStatus
import sh.swrlz.nodehost.service.RuntimeStatus
import sh.swrlz.nodehost.ui.viewmodel.HostUiState
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel

private enum class SwurlzerTab(val label: String, val icon: ImageVector, val energy: SwurlzerEnergyTarget) {
    Core("Core", Icons.Outlined.Home, SwurlzerEnergyTarget.Core),
    Nodes("Nodes", Icons.Outlined.Hub, SwurlzerEnergyTarget.Nodes),
    Groups("Groups", Icons.Outlined.Hub, SwurlzerEnergyTarget.Nodes),
    Missions("Missions", Icons.Outlined.ListAlt, SwurlzerEnergyTarget.Missions),
    Activity("Activity", Icons.Outlined.Dns, SwurlzerEnergyTarget.Settings),
    Settings("Settings", Icons.Outlined.Settings, SwurlzerEnergyTarget.Settings),
}

@Composable
fun SwurlzerUserScreen(
    viewModel: HostViewModel,
    motionEnabled: Boolean,
    onMotionChanged: (Boolean) -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    val state by viewModel.state.collectAsState()
    var selectedName by rememberSaveable { mutableStateOf(SwurlzerTab.Core.name) }
    val selected = SwurlzerTab.entries.firstOrNull { it.name == selectedName } ?: SwurlzerTab.Core
    var signal by remember { mutableStateOf(SwurlzerEnergySignal()) }

    fun pulse(target: SwurlzerEnergyTarget) {
        signal = SwurlzerEnergySignal(signal.id + 1, target)
    }

    fun select(tab: SwurlzerTab) {
        pulse(tab.energy)
        selectedName = tab.name
    }

    val visualState = state.toSwurlzerVisualState()
    Box(Modifier.fillMaxSize().background(Color(0xFF03030B))) {
        SwurlzerBackdrop(motionEnabled, visualState, signal)
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = { SwurlzerTopBar(selected, state) },
            bottomBar = { SwurlzerBottomBar(selected, ::select) },
        ) { padding ->
            AnimatedContent(
                targetState = selected,
                transitionSpec = {
                    if (motionEnabled) {
                        (fadeIn(tween(230)) + scaleIn(tween(260), initialScale = .98f)) togetherWith
                            (fadeOut(tween(170)) + scaleOut(tween(190), targetScale = .992f))
                    } else {
                        fadeIn(tween(90)) togetherWith fadeOut(tween(70))
                    }
                },
                label = "swurlzer-user-tab",
                modifier = Modifier.fillMaxSize().padding(padding),
            ) { tab ->
                when (tab) {
                    SwurlzerTab.Core -> SwurlzerCoreScreen(
                        state = state,
                        onStart = {
                            pulse(SwurlzerEnergyTarget.Core)
                            viewModel.startNode()
                        },
                        onStop = {
                            pulse(SwurlzerEnergyTarget.Core)
                            viewModel.stopNode()
                        },
                        onMaintenance = viewModel::enterMaintenance,
                        onReload = viewModel::reloadConfiguration,
                        onRestart = viewModel::restartServices,
                        onOpenNodes = { select(SwurlzerTab.Nodes) },
                        onOpenMissions = { select(SwurlzerTab.Missions) },
                    )
                    SwurlzerTab.Nodes -> SwurlzerNodesScreen(state, viewModel::disconnectNode, viewModel::createGroup, viewModel::assignNodeToGroup)
                    SwurlzerTab.Groups -> SwurlzerGroupsScreen(state, viewModel::createGroup, viewModel::assignNodeToGroup)
                    SwurlzerTab.Missions -> SwurlzerMissionsScreen(state)
                    SwurlzerTab.Activity -> SwurlzerActivityScreen(state)
                    SwurlzerTab.Settings -> SwurlzerSettingsScreen(
                        motionEnabled = motionEnabled,
                        onMotionChanged = onMotionChanged,
                        onOpenDeveloper = {
                            pulse(SwurlzerEnergyTarget.Developer)
                            onOpenDeveloper()
                        },
                    )
                }
            }
        }
    }
}

private fun lifecycleLabel(status: RuntimeStatus): String = when (status) {
    RuntimeStatus.STOPPED -> "STOPPED"
    RuntimeStatus.STARTING -> "STARTING"
    RuntimeStatus.RUNNING, RuntimeStatus.DEGRADED -> "ACTIVE"
    RuntimeStatus.MAINTENANCE -> "MAINTENANCE"
    RuntimeStatus.RELOADING_CONFIGURATION -> "RELOADING"
    RuntimeStatus.RESTARTING_SERVICES -> "RESTARTING"
    RuntimeStatus.SHUTTING_DOWN -> "SHUTTING DOWN"
    RuntimeStatus.FAILED -> "FAILED"
}

@Composable
private fun SwurlzerTopBar(selected: SwurlzerTab, state: HostUiState) {
    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val visualState = state.toSwurlzerVisualState()
    val lifecycle = lifecycleLabel(state.health.runtimeStatus)
    val tone = if (state.health.runtimeActive) SwurlzerPalette.Cyan else swurlzerTone(visualState)
    Row(
        Modifier.fillMaxWidth()
            .background(Color(0xB8070A17))
            .border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .20f))
            .padding(top = statusPadding + 8.dp, bottom = 10.dp, start = 16.dp, end = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp)
                .background(Brush.linearGradient(listOf(SwurlzerPalette.Cyan.copy(alpha = .26f), SwurlzerPalette.Violet.copy(alpha = .28f))), RoundedCornerShape(13.dp))
                .border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .68f), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text("Ω", color = SwurlzerPalette.Text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SWURLZER", color = SwurlzerPalette.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(
                "${selected.label.uppercase()} · $lifecycle",
                color = tone,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 1.2.sp,
            )
        }
        StatusPill(lifecycle, tone)
    }
}

@Composable
private fun SwurlzerBottomBar(selected: SwurlzerTab, onSelect: (SwurlzerTab) -> Unit) {
NavigationBar(
        containerColor = Color(0xC4070A17),
        tonalElevation = 0.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .18f)),
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            SwurlzerTab.entries.forEach { tab ->
                NavigationBarItem(
                    selected = tab == selected,
                    onClick = { onSelect(tab) },
                    modifier = Modifier.width(88.dp),
                    icon = { Icon(tab.icon, contentDescription = null) },
                    label = { Text(tab.label, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SwurlzerPalette.Cyan,
                        selectedTextColor = SwurlzerPalette.Text,
                        indicatorColor = SwurlzerPalette.Cyan.copy(alpha = .14f),
                        unselectedIconColor = SwurlzerPalette.Muted,
                        unselectedTextColor = SwurlzerPalette.Muted,
                    ),
                )
            }
        }
    }
}

@Composable
private fun SwurlzerCoreScreen(
    state: HostUiState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onMaintenance: () -> Unit,
    onReload: () -> Unit,
    onRestart: () -> Unit,
    onOpenNodes: () -> Unit,
    onOpenMissions: () -> Unit,
) {
    val visualState = state.toSwurlzerVisualState()
    val citadelState = visualState.citadelState
    val tone = swurlzerTone(visualState)
    val headline = when (citadelState) {
        SwurlzerCitadelState.Offline -> "Your Swurlzer is offline."
        SwurlzerCitadelState.Starting -> "Your Swurlzer is starting."
        SwurlzerCitadelState.Ready -> "Your Swurlzer is ready."
        SwurlzerCitadelState.Degraded -> "Your Swurlzer needs attention."
        SwurlzerCitadelState.Failed -> "Your Swurlzer failed to initialize."
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("LOCAL NODE RUNTIME")
            Text(
                headline,
                color = SwurlzerPalette.Text,
                style = MaterialTheme.typography.headlineMedium,
            )
            Text(
                "Private compatibility and approved local-link discovery remain separate, visible surfaces.",
                color = SwurlzerPalette.SecondaryText,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }
        item {
            SwurlzerGlassPanel(
                modifier = Modifier.semantics {
                    stateDescription = "Swurlzer ${citadelState.label.lowercase()}. " +
                        "Private API ${state.health.privateApi.status.name.lowercase()}. " +
                        "Loopback discovery ${state.health.discoveryLoopback.status.name.lowercase()}. " +
                        "Approved local-link listener ${state.health.discoveryLan.status.name.lowercase()}."
                },
                highlighted = citadelState == SwurlzerCitadelState.Ready,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(tone, CircleShape))
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(citadelState.label, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                        Text(runtimeEvidenceLabel(citadelState), color = SwurlzerPalette.Muted, fontSize = 10.sp)
                        if (state.health.runtimeStatus == RuntimeStatus.DEGRADED || state.health.runtimeStatus == RuntimeStatus.FAILED) {
                            Text(state.health.operatorReason, color = SwurlzerPalette.Amber, fontSize = 10.sp, lineHeight = 14.sp)
                        }
                    }
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        StatusPill(if (state.health.runtimeActive) "ACTIVE" else "INACTIVE", if (state.health.runtimeActive) SwurlzerPalette.Cyan else SwurlzerPalette.Muted)
                        StatusPill(citadelState.label, tone)
                    }
                }
                Spacer(Modifier.height(13.dp))
                ListenerLine("Private API · loopback 8080", state.health.privateApi)
                ListenerLine("Discovery · loopback 8787", state.health.discoveryLoopback)
                ListenerLine("Discovery · approved local-link listener", state.health.discoveryLan)
                if (state.health.discoveryLan.status == ListenerStatus.RUNNING) {
                    Text("Listener availability does not by itself claim a CLIENT connection.", color = SwurlzerPalette.Muted, fontSize = 9.sp, lineHeight = 13.sp)
                }
                state.health.lastFailure?.let {
                    Spacer(Modifier.height(8.dp))
                    Text("Last failure: ${it.stage} · ${it.errorType}: ${it.message}", color = SwurlzerPalette.Amber, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        item {
            val running = state.health.runtimeActive
            val transitioning = state.health.runtimeStatus in setOf(
                RuntimeStatus.STARTING,
                RuntimeStatus.RELOADING_CONFIGURATION,
                RuntimeStatus.RESTARTING_SERVICES,
                RuntimeStatus.SHUTTING_DOWN,
            )
            if (transitioning) {
                SwurlzerGlassPanel(highlighted = true) {
                    Text(lifecycleLabel(state.health.runtimeStatus), color = SwurlzerPalette.Cyan, fontWeight = FontWeight.Bold)
                    Text(state.health.lifecycleDetail ?: "Lifecycle operation in progress", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
                    if (state.health.runtimeStatus == RuntimeStatus.SHUTTING_DOWN) {
                        Text("STEP ${state.health.shutdownStep.coerceIn(1,10)} OF 10", color = SwurlzerPalette.Amber, fontSize = 10.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            if (running) {
                OutlinedButton(onClick = onStop, enabled = state.health.runtimeStatus != RuntimeStatus.SHUTTING_DOWN, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Outlined.Stop, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text(if (state.health.runtimeStatus == RuntimeStatus.SHUTTING_DOWN) "SHUTDOWN IN PROGRESS · ${state.health.shutdownStep}/10" else "BEGIN SHUTDOWN SEQUENCE")
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = onMaintenance, enabled = !transitioning, modifier = Modifier.weight(1f)) { Text("MAINTENANCE", fontSize = 9.sp) }
                    OutlinedButton(onClick = onReload, enabled = !transitioning, modifier = Modifier.weight(1f)) { Text("RELOAD", fontSize = 9.sp) }
                    OutlinedButton(onClick = onRestart, enabled = !transitioning, modifier = Modifier.weight(1f)) { Text("RESTART", fontSize = 9.sp) }
                }
            } else {
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text("INITIALIZE SERVER")
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryCard("REGISTERED", state.nodes.size.toString(), Modifier.weight(1f).semantics { contentDescription = "Open ${state.nodes.size} registered nodes" }, onOpenNodes)
                SummaryCard("ONLINE", state.nodes.count { it.connectionState in setOf("CONNECTED","BUSY") }.toString(), Modifier.weight(1f), onOpenNodes)
                SummaryCard("OFFLINE", state.nodes.count { it.connectionState == "OFFLINE" }.toString(), Modifier.weight(1f), onOpenNodes)
            }
            Spacer(Modifier.height(8.dp))
            SummaryCard("GROUPS", state.groups.count { it.status == "ACTIVE" }.toString(), Modifier.fillMaxWidth(), onOpenNodes)
            if (state.nodes.isEmpty() && state.health.discoveryLoopback.status == ListenerStatus.RUNNING) {
                Text(
                    "Discovery is reachable, but no CLIENT has completed authoritative enrollment/presence registration. Reachability alone is not shown as a trusted connection.",
                    color = SwurlzerPalette.Amber,
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
        item {
            SwurlzerGlassPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Shield, contentDescription = null, tint = SwurlzerPalette.Trust)
                    Spacer(Modifier.width(9.dp))
                    Text(
                        "CLIENT approval and Truth Firewall gates remain authoritative. Swurlzer availability does not bypass them.",
                        color = SwurlzerPalette.SecondaryText,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun SwurlzerNodesScreen(state: HostUiState, onDisconnect: (NodeEntity) -> Unit, onCreateGroup: (String,String) -> Unit, onAssignToGroup: (NodeEntity,String) -> Unit) {
    var showCreateGroup by remember { mutableStateOf(false) }
    var groupName by remember { mutableStateOf("") }
    var leaderNodeId by remember { mutableStateOf("") }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("KNOWN NODE RECORDS")
            Text("Identity stays exact.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Stored status is shown as stored; it is not promoted into a live connection claim.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        item {
            SwurlzerGlassPanel {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("NODE GROUPS", color=SwurlzerPalette.Text, fontWeight=FontWeight.Bold)
                        Text("${state.groups.count { it.status == "ACTIVE" }} active groups", color=SwurlzerPalette.SecondaryText, fontSize=11.sp)
                    }
                    Button(onClick={showCreateGroup=true}) { Text("CREATE GROUP") }
                }
                state.groups.forEach { group ->
                    Spacer(Modifier.height(8.dp))
                    Text(group.displayName, color=SwurlzerPalette.Cyan, fontWeight=FontWeight.SemiBold)
                    Text("Leader ${group.leaderNodeId} · ${group.status}", color=SwurlzerPalette.Muted, fontSize=10.sp)
                }
            }
        }
        if (state.nodes.isEmpty()) {
            item { SwurlzerGlassPanel { Text("No known node records.", color = SwurlzerPalette.Muted) } }
        } else {
            items(state.nodes, key = NodeEntity::nodeId) { node -> SwurlzerNodeCard(node, state.groups, state.groupMemberships, onDisconnect, onAssignToGroup) }
        }
    }
    if(showCreateGroup) AlertDialog(onDismissRequest={showCreateGroup=false}, title={Text("Create SERVER group")}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(value=groupName,onValueChange={groupName=it},label={Text("Unique group name")})
        OutlinedTextField(value=leaderNodeId,onValueChange={leaderNodeId=it},label={Text("Leader node ID")})
        Text("The SERVER validates uniqueness and stores canonical membership. The chosen leader retains final join approval.",fontSize=11.sp)
    }}, confirmButton={TextButton(enabled=groupName.trim().length in 3..48 && leaderNodeId.isNotBlank(),onClick={onCreateGroup(groupName,leaderNodeId);showCreateGroup=false;groupName=""}){Text("CREATE")}}, dismissButton={TextButton(onClick={showCreateGroup=false}){Text("CANCEL")}})
}


@Composable
private fun SwurlzerGroupsScreen(
    state: HostUiState,
    onCreateGroup: (String, String) -> Unit,
    onAssignToGroup: (NodeEntity, String) -> Unit,
) {
    var showCreate by remember { mutableStateOf(false) }
    var groupName by remember { mutableStateOf("") }
    var leaderNodeId by remember { mutableStateOf("") }
    var selectedGroupId by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("COLLABORATION CONTROL")
            Text("Server groups.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("The SERVER validates names, stores membership, and publishes the authoritative group state.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        item {
            SwurlzerGlassPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("GROUP STATUS", color = SwurlzerPalette.Text, fontWeight = FontWeight.Bold)
                        Text("${state.groups.count { it.status == "ACTIVE" }} active · ${state.nodes.count { it.status == "CONNECTED" }} nodes connected", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
                    }
                    Button(onClick = { showCreate = true }) { Text("CREATE GROUP") }
                }
            }
        }
        if (state.groups.isEmpty()) {
            item { SwurlzerGlassPanel { Text("No groups exist. Create one and assign a registered leader node.", color = SwurlzerPalette.Muted) } }
        } else {
            items(state.groups, key = { it.groupId }) { group ->
                val members = state.nodes.filter { node -> node.nodeId == group.leaderNodeId }
                SwurlzerGlassPanel {
                    Text(group.displayName, color = SwurlzerPalette.Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Leader ${group.leaderNodeId} · ${group.status}", color = SwurlzerPalette.SecondaryText, fontSize = 10.sp)
                    Text("Visible registered nodes ${members.size}", color = SwurlzerPalette.Muted, fontSize = 10.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { selectedGroupId = group.groupId }) { Text("OPEN") }
                        TextButton(onClick = { selectedGroupId = group.groupId }) { Text("MEMBERS") }
                        TextButton(onClick = { selectedGroupId = group.groupId }) { Text("INVITES") }
                    }
                }
            }
        }
    }

    if (showCreate) AlertDialog(
        onDismissRequest = { showCreate = false },
        title = { Text("Create SERVER group") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = groupName, onValueChange = { groupName = it }, label = { Text("Unique group name") })
                OutlinedTextField(value = leaderNodeId, onValueChange = { leaderNodeId = it }, label = { Text("Leader node ID") })
                Text("The chosen leader owns join decisions. Membership and invite validity remain SERVER-enforced.", fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(enabled = groupName.trim().length in 3..48 && leaderNodeId.isNotBlank(), onClick = { onCreateGroup(groupName.trim(), leaderNodeId.trim()); showCreate = false; groupName = ""; leaderNodeId = "" }) { Text("CREATE") } },
        dismissButton = { TextButton(onClick = { showCreate = false }) { Text("CANCEL") } },
    )

    selectedGroupId?.let { groupId ->
        val group = state.groups.firstOrNull { it.groupId == groupId }
        AlertDialog(
            onDismissRequest = { selectedGroupId = null },
            title = { Text(group?.displayName ?: "Group") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Group ID: $groupId", fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Text("Leader: ${group?.leaderNodeId.orEmpty()}")
                    Text("Assign a registered node below. Changes enter the authoritative state immediately.", fontSize = 11.sp)
                    state.nodes.forEach { node ->
                        OutlinedButton(onClick = { onAssignToGroup(node, groupId) }, modifier = Modifier.fillMaxWidth()) { Text("ADD ${node.label}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selectedGroupId = null }) { Text("DONE") } },
        )
    }
}

@Composable
private fun SwurlzerNodeCard(node: NodeEntity, groups: List<sh.swrlz.nodehost.data.entity.GroupEntity>, memberships: List<sh.swrlz.nodehost.data.entity.GroupMembershipEntity>, onDisconnect: (NodeEntity) -> Unit, onAssignToGroup: (NodeEntity,String) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var confirmDisconnect by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    var showMissionCouncil by remember { mutableStateOf(false) }
    var missionDraft by remember { mutableStateOf("") }
    var showAssignGroup by remember { mutableStateOf(false) }
    val link = node.toSwurlzerClientLinkState()
    val trustTone = trustTone(link.trust)
    val nodeMemberships = memberships.filter { it.nodeId == node.nodeId && it.membershipState == "ACTIVE" }
    val groupLabels = nodeMemberships.mapNotNull { membership ->
        groups.firstOrNull { it.groupId == membership.groupId }?.let { group -> "${group.displayName} · ${membership.role}" }
    }
    SwurlzerGlassPanel(
        modifier = Modifier.semantics { stateDescription = link.accessibilityDescription },
        highlighted = link.admitsCore,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).background(connectionTone(link.connection).copy(alpha = .22f), CircleShape).border(1.dp, connectionTone(link.connection), CircleShape), contentAlignment = Alignment.Center) {
                Text("◆", color = connectionTone(link.connection), fontSize = if (node.connectionState in setOf("CONNECTING","VERIFYING","REGISTERING")) 15.sp else 12.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(node.label, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                Text("Active state: ${node.connectionState}", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
                Text("Registration: ${node.registrationState} · Trust: ${node.trust}", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
                Text("Capabilities: ${node.capabilities}", color = SwurlzerPalette.Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Groups: ${groupLabels.ifEmpty { listOf("None") }.joinToString(" · ")}", color = if (groupLabels.isEmpty()) SwurlzerPalette.Muted else SwurlzerPalette.Cyan, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Outlined.MoreVert, contentDescription = "Node actions", tint = SwurlzerPalette.Cyan) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text={Text("View details")}, onClick={menu=false;showDetails=true})
                    DropdownMenuItem(text={Text("Send mission")}, onClick={menu=false;showMissionCouncil=true})
                    DropdownMenuItem(text={Text("Assign to group")}, onClick={menu=false;showAssignGroup=true})
                    DropdownMenuItem(text={Text("Disconnect from SERVER")}, onClick={menu=false;confirmDisconnect=true})
                }
            }
        }

        if(showAssignGroup) AlertDialog(onDismissRequest={showAssignGroup=false},title={Text("Assign ${node.label} to group")},text={Column{ if(groups.isEmpty()) Text("No groups exist. Create one from NODE GROUPS first.") else groups.forEach { g -> TextButton(onClick={onAssignToGroup(node,g.groupId);showAssignGroup=false}){Text(g.displayName)} } }},confirmButton={},dismissButton={TextButton(onClick={showAssignGroup=false}){Text("CANCEL")}})

        if (showDetails) AlertDialog(
            onDismissRequest={showDetails=false},
            title={Text("Node details")},
            text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Text(node.label)
                Text("Node ID: ${node.nodeId}")
                Text("Connection: ${node.connectionState}")
                Text("Last heartbeat: ${node.lastSeen}")
                Text("Registration: ${node.registrationState}")
                Text("Identity: ${node.identityState} · Proof: ${node.proofState}")
                Text("Trust: ${node.trust}")
                Text("Current mission: ${node.currentMissionId ?: "None"}")
                Text("Groups: ${groupLabels.ifEmpty { listOf("None") }.joinToString(" · ")}")
                Text("Installation lineage count: ${node.installationCount}")
                Text("Live progress is shown only when reported by the node; otherwise state remains unknown.")
            }},
            confirmButton={TextButton(onClick={showDetails=false}){Text("CLOSE")}},
        )
        if (showMissionCouncil) AlertDialog(
            onDismissRequest={showMissionCouncil=false},
            title={Text("Mission Council · ${node.label}")},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("Describe the mission naturally. CLIENT consent and Truth Firewall gates remain authoritative.")
                OutlinedTextField(value=missionDraft,onValueChange={missionDraft=it},label={Text("Mission request")},minLines=4)
                Text("This checkpoint stores a draft/review intent only; unrestricted execution is not enabled.")
            }},
            confirmButton={TextButton(enabled=missionDraft.isNotBlank(),onClick={showMissionCouncil=false}){Text("REVIEW")}},
            dismissButton={TextButton(onClick={showMissionCouncil=false}){Text("CANCEL")}},
        )

        if (confirmDisconnect) AlertDialog(
            onDismissRequest={confirmDisconnect=false},
            title={Text("Disconnect this node?")},
            text={Text("This ends the current session but preserves registration, group membership, trust records, and lineage.")},
            confirmButton={TextButton(onClick={confirmDisconnect=false;onDisconnect(node)}){Text("DISCONNECT")}},
            dismissButton={TextButton(onClick={confirmDisconnect=false}){Text("CANCEL")}},
        )
        Spacer(Modifier.height(10.dp))
        HandshakeLine("CONNECTION", link.connection.label, connectionTone(link.connection))
        HandshakeLine("IDENTITY GATE", if (link.identityConfirmed) "IDENTITY CONFIRMED" else "NOT CONFIRMED", if (link.identityConfirmed) SwurlzerPalette.Blue else SwurlzerPalette.Muted)
        HandshakeLine("PROOF GATE", link.proof.label, proofTone(link.proof))
        HandshakeLine("TRUST", link.trust.label, trustTone)
        HandshakeLine("ROUTE", link.route.label, routeTone(link.route))
        link.failureCategory?.let { HandshakeLine("FAILURE", it, SwurlzerPalette.Danger) }
        if (link.trust == SwurlzerTrustStage.Legacy) Text("LEGACY enrollment does not imply modern device-proof verification.", color = SwurlzerPalette.Amber, fontSize = 9.sp, lineHeight = 13.sp)
        if (!link.admitsCore) Text("The visual link stops before the central core until connection, identity, proof, and modern trust are all explicitly represented.", color = SwurlzerPalette.Muted, fontSize = 9.sp, lineHeight = 13.sp)
    }
}

@Composable
private fun SwurlzerMissionsScreen(state: HostUiState) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("STORED MISSION RECORDS")
            Text("Mission truth, not theater.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Swurlzer shows persisted state and priority; this surface does not grant approval or execution authority.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        if (state.missions.isEmpty()) {
            item { SwurlzerGlassPanel { Text("No stored mission records.", color = SwurlzerPalette.Muted) } }
        } else {
            items(state.missions, key = MissionEntity::id) { mission -> SwurlzerMissionCard(mission) }
        }
    }
}

@Composable
private fun SwurlzerMissionCard(mission: MissionEntity) {
    val atmosphere = mission.state.toMissionAtmosphere()
    val tone = missionTone(atmosphere)
    val active = atmosphere == SwurlzerMissionAtmosphere.Active
    SwurlzerGlassPanel(highlighted = active) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.ListAlt, contentDescription = null, tint = tone)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(mission.title, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                Text("Priority: ${mission.priority}", color = SwurlzerPalette.Muted, fontSize = 10.sp)
            }
            StatusPill(mission.state.uppercase(), tone)
        }
        if (atmosphere == SwurlzerMissionAtmosphere.ApprovalPending) Text("PENDING APPROVAL · no acceptance is implied.", color = SwurlzerPalette.Amber, fontSize = 9.sp)
        if (atmosphere == SwurlzerMissionAtmosphere.ManualIntervention) Text("MANUAL INTERVENTION · safety gates remain authoritative.", color = SwurlzerPalette.Caution, fontSize = 9.sp)
    }
}


@Composable
private fun SwurlzerActivityScreen(state: HostUiState) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("OPERATOR ACTIVITY")
            Text("What the server user should know.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Actionable runtime, listener, node, trust, and mission information. Raw traces remain in Developer Mode.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        item {
            SwurlzerGlassPanel {
                Text("RUNTIME · ${state.health.runtimeStatus.name}", color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                ListenerLine("Private API · loopback 8080", state.health.privateApi)
                ListenerLine("Discovery · loopback 8787", state.health.discoveryLoopback)
                ListenerLine("Discovery · approved local-link listener", state.health.discoveryLan)
                state.health.lastFailure?.let { Text("ACTION REQUIRED · ${it.stage}: ${it.message}", color = SwurlzerPalette.Amber, fontSize = 10.sp, lineHeight = 14.sp) }
            }
        }
        item {
            SwurlzerGlassPanel {
                Text("KNOWN NODES · ${state.nodes.size}", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                state.nodes.take(5).forEach { node ->
                    Text("${node.label} · ${node.status} · ${node.trust}", color = SwurlzerPalette.SecondaryText, fontSize = 10.sp, lineHeight = 15.sp)
                }
                if (state.nodes.isEmpty()) Text("No node records yet.", color = SwurlzerPalette.Muted, fontSize = 10.sp)
            }
        }
        item {
            SwurlzerGlassPanel {
                Text("STORED MISSIONS · ${state.missions.size}", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                state.missions.take(5).forEach { mission -> Text("${mission.title} · ${mission.state}", color = SwurlzerPalette.SecondaryText, fontSize = 10.sp, lineHeight = 15.sp) }
                if (state.missions.isEmpty()) Text("No stored missions.", color = SwurlzerPalette.Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun SwurlzerSettingsScreen(
    motionEnabled: Boolean,
    onMotionChanged: (Boolean) -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("SWURLZER SETTINGS")
            Text("Simple outside. Exact inside.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Visual settings never alter runtime, trust, discovery, or protocol authority.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        item {
            val context = LocalContext.current
            val scope = rememberCoroutineScope()
            val family by SwurlzerUiPreferences.themeFamilyFlow(context).collectAsState(initial = "Glitch Dragon Glass")
            val variant by SwurlzerUiPreferences.themeVariantFlow(context).collectAsState(initial = "Dark")
            SwurlzerGlassPanel {
                SectionLabel("THEME ARMOR")
                Text("$family · $variant", color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                Text("Themes change presentation only; status, trust, permissions, and protocol truth remain unchanged.", color = SwurlzerPalette.Muted, fontSize = 10.sp, lineHeight = 14.sp)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val all = sh.swrlz.nodehost.ui.theme.SwurlzerThemeCatalog.families
                        val next = all[(all.indexOf(family).coerceAtLeast(0) + 1) % all.size]
                        scope.launch { SwurlzerUiPreferences.setTheme(context, next, variant) }
                    }, modifier = Modifier.weight(1f)) { Text("NEXT THEME", fontSize = 9.sp) }
                    OutlinedButton(onClick = {
                        val all = sh.swrlz.nodehost.ui.theme.SwurlzerThemeCatalog.variants
                        val next = all[(all.indexOf(variant).coerceAtLeast(0) + 1) % all.size]
                        scope.launch { SwurlzerUiPreferences.setTheme(context, family, next) }
                    }, modifier = Modifier.weight(1f)) { Text("NEXT VARIANT", fontSize = 9.sp) }
                }
            }
        }
        item {
            SwurlzerGlassPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Decorative motion", color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                        Text("Dragon drift, shimmer, pulses, and crystal transitions", color = SwurlzerPalette.Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Switch(checked = motionEnabled, onCheckedChange = onMotionChanged)
                }
            }
        }
        item {
            SwurlzerGlassPanel {
                Text("LOCAL-FIRST BOUNDARY", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(6.dp))
                Text("Private API remains loopback-only. Discovery remains limited to loopback and approved local-link interfaces. No remote-node mode is added.", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        item {
            OutlinedButton(onClick = onOpenDeveloper, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Icon(Icons.Outlined.DeveloperMode, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("SWITCH TO SWURLZER DEV MODE")
            }
        }
    }
}

@Composable
private fun ListenerLine(label: String, health: ListenerHealth) {
    val tone = listenerTone(health.status)
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(tone, CircleShape))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
            health.detail?.takeIf { it.isNotBlank() }?.let { Text(it, color = SwurlzerPalette.Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
        }
        StatusPill(health.status.name, tone)
    }
}

@Composable
private fun HandshakeLine(label: String, value: String, tone: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = SwurlzerPalette.Muted, fontFamily = FontFamily.Monospace, fontSize = 8.sp, modifier = Modifier.width(94.dp))
        Text("◆", color = tone, fontSize = 9.sp)
        Spacer(Modifier.width(6.dp))
        Text(value, color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 88.dp), contentPadding = PaddingValues(10.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = SwurlzerPalette.Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(label, color = SwurlzerPalette.SecondaryText, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .8.sp, maxLines = 2)
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.7.sp)
}

@Composable
internal fun StatusPill(text: String, tone: Color) {
    Box(
        Modifier.background(Color(0x99070A17), CircleShape)
            .border(1.dp, tone.copy(alpha = .58f), CircleShape)
            .padding(horizontal = 8.dp, vertical = 5.dp),
    ) {
        Text(text, color = tone, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .6.sp, maxLines = 2)
    }
}

private fun listenerTone(status: ListenerStatus): Color = when (status) {
    ListenerStatus.RUNNING -> SwurlzerPalette.Cyan
    ListenerStatus.STARTING -> SwurlzerPalette.Blue
    ListenerStatus.UNAVAILABLE -> SwurlzerPalette.Amber
    ListenerStatus.FAILED -> SwurlzerPalette.Danger
    ListenerStatus.STOPPED -> SwurlzerPalette.Muted
}

private fun runtimeEvidenceLabel(state: SwurlzerCitadelState): String = when (state) {
    SwurlzerCitadelState.Offline -> "Runtime stopped"
    SwurlzerCitadelState.Starting -> "Initialization in progress"
    SwurlzerCitadelState.Ready -> "Required local services verified running"
    SwurlzerCitadelState.Degraded -> "Runtime available with reduced service health"
    SwurlzerCitadelState.Failed -> "Initialization or required listener failed"
}
internal fun connectionTone(stage: SwurlzerConnectionStage): Color = when (stage) {
    SwurlzerConnectionStage.Connected, SwurlzerConnectionStage.Reachable -> SwurlzerPalette.Cyan
    SwurlzerConnectionStage.IdentityConfirmed, SwurlzerConnectionStage.Discovered -> SwurlzerPalette.Blue
    SwurlzerConnectionStage.Disconnected, SwurlzerConnectionStage.Stored -> SwurlzerPalette.Muted
}
internal fun proofTone(stage: SwurlzerProofStage): Color = when (stage) {
    SwurlzerProofStage.Verified -> SwurlzerPalette.Trust
    SwurlzerProofStage.Failed -> SwurlzerPalette.Danger
    SwurlzerProofStage.NotReported -> SwurlzerPalette.Muted
}
internal fun trustTone(stage: SwurlzerTrustStage): Color = when (stage) {
    SwurlzerTrustStage.Trusted -> SwurlzerPalette.Trust
    SwurlzerTrustStage.Legacy -> SwurlzerPalette.Violet
    SwurlzerTrustStage.Pending -> SwurlzerPalette.Amber
    SwurlzerTrustStage.Failed -> SwurlzerPalette.Danger
    SwurlzerTrustStage.Unverified -> SwurlzerPalette.Muted
}
internal fun routeTone(stage: SwurlzerRouteStage): Color = when (stage) {
    SwurlzerRouteStage.Local -> SwurlzerPalette.Cyan
    SwurlzerRouteStage.Remote -> SwurlzerPalette.Violet
    SwurlzerRouteStage.NotReported -> SwurlzerPalette.Muted
}
private fun String.toMissionAtmosphere(): SwurlzerMissionAtmosphere {
    val value = trim().lowercase().replace('-', '_').replace(' ', '_')
    fun has(token: String): Boolean = "_${value.trim('_')}_".contains("_${token.trim('_')}_")
    return when {
        has("take_over") || has("manual_intervention") -> SwurlzerMissionAtmosphere.ManualIntervention
        has("approval_required") || has("pending_approval") -> SwurlzerMissionAtmosphere.ApprovalPending
        has("paused") -> SwurlzerMissionAtmosphere.Paused
        listOf("accepted", "active", "running", "executing", "starting", "in_progress").any { has(it) } -> SwurlzerMissionAtmosphere.Active
        else -> SwurlzerMissionAtmosphere.Idle
    }
}
private fun missionTone(state: SwurlzerMissionAtmosphere): Color = when (state) {
    SwurlzerMissionAtmosphere.Active -> SwurlzerPalette.Cyan
    SwurlzerMissionAtmosphere.Paused, SwurlzerMissionAtmosphere.ApprovalPending -> SwurlzerPalette.Amber
    SwurlzerMissionAtmosphere.ManualIntervention -> SwurlzerPalette.Caution
    SwurlzerMissionAtmosphere.Idle -> SwurlzerPalette.Muted
}
