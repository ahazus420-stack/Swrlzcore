# Release Notes

## 2.0.0 — GLITCH-DRAGON-SWURLZER-DUAL-MODE
- Renamed the user-facing local node host experience to **Swurlzer** while preserving SERVER archive naming and `NODE_HOST` source/protocol identities.
- Added a streamlined Glitch Dragon Glass User Mode for Core, stored Nodes, stored Missions, and visual Settings.
- Upgraded the original Overview and Diagnostics cockpit as switchable Swurlzer Dev Mode without removing legacy controls.
- Added persisted mode and reduced-motion preferences plus lifecycle-aware, bounded decorative animation.
- Added a new 4096×4096 crystalline Swurlzer icon master and density/adaptive launcher resources.
- Preserved loopback/private API, approved local-link discovery, trust/pairing, proof binding, mission, and protocol/schema version 1 semantics.
- Source identity advanced to `versionCode 3` / `versionName 2.0.0`.
- Compile and APK assembly intentionally deferred to the owner's GitHub build.

## 1.0.3
- Added truthful CLIENT compatibility routes on the local-link listener.
- Empty presence now returns authoritative zero counts and empty collections instead of `404`.
- Preserved discovery signature, durable identity, protocol/schema version 1, and trust boundaries.
- Added deterministic Glitch Dragon Core launcher icons.
- Source version advanced to `versionCode 2` / `versionName 1.0.3`.

## 1.0
- Initial Android Studio project for SWRLZ Node Host.
- Compose UI, Room persistence, foreground service, and embedded local runtime.
- Mission-first dashboard with node and mission state.
