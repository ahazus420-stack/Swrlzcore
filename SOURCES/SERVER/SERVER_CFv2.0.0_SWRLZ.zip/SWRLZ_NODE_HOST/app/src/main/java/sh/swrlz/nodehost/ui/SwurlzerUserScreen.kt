package sh.swrlz.nodehost.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.service.ListenerHealth
import sh.swrlz.nodehost.service.ListenerStatus
import sh.swrlz.nodehost.service.RuntimeStatus
import sh.swrlz.nodehost.ui.viewmodel.HostUiState
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel

private enum class SwurlzerTab(val label: String, val icon: ImageVector, val energy: SwurlzerEnergyTarget) {
    Core("Core", Icons.Outlined.Home, SwurlzerEnergyTarget.Core),
    Nodes("Nodes", Icons.Outlined.Hub, SwurlzerEnergyTarget.Nodes),
    Missions("Missions", Icons.Outlined.ListAlt, SwurlzerEnergyTarget.Missions),
    Settings("Settings", Icons.Outlined.Settings, SwurlzerEnergyTarget.Settings),
}

@Composable
fun SwurlzerUserScreen(
    viewModel: HostViewModel,
    motionEnabled: Boolean,
    onMotionChanged: (Boolean) -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    val state by viewModel.state.collectAsState()
    var selectedName by rememberSaveable { mutableStateOf(SwurlzerTab.Core.name) }
    val selected = SwurlzerTab.entries.firstOrNull { it.name == selectedName } ?: SwurlzerTab.Core
    var signal by remember { mutableStateOf(SwurlzerEnergySignal()) }

    fun pulse(target: SwurlzerEnergyTarget) {
        signal = SwurlzerEnergySignal(signal.id + 1, target)
    }

    fun select(tab: SwurlzerTab) {
        pulse(tab.energy)
        selectedName = tab.name
    }

    val visualState = state.toVisualState()
    Box(Modifier.fillMaxSize().background(Color(0xFF03030B))) {
        SwurlzerBackdrop(motionEnabled, visualState, signal)
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = { SwurlzerTopBar(selected, state) },
            bottomBar = { SwurlzerBottomBar(selected, ::select) },
        ) { padding ->
            AnimatedContent(
                targetState = selected,
                transitionSpec = {
                    if (motionEnabled) {
                        (fadeIn(tween(230)) + scaleIn(tween(260), initialScale = .985f)) togetherWith
                            (fadeOut(tween(170)) + scaleOut(tween(190), targetScale = .992f))
                    } else {
                        fadeIn(tween(90)) togetherWith fadeOut(tween(70))
                    }
                },
                label = "swurlzer-user-tab",
                modifier = Modifier.fillMaxSize().padding(padding),
            ) { tab ->
                when (tab) {
                    SwurlzerTab.Core -> SwurlzerCoreScreen(
                        state = state,
                        onStart = {
                            pulse(SwurlzerEnergyTarget.Core)
                            viewModel.startNode()
                        },
                        onStop = {
                            pulse(SwurlzerEnergyTarget.Core)
                            viewModel.stopNode()
                        },
                        onOpenNodes = { select(SwurlzerTab.Nodes) },
                        onOpenMissions = { select(SwurlzerTab.Missions) },
                    )
                    SwurlzerTab.Nodes -> SwurlzerNodesScreen(state)
                    SwurlzerTab.Missions -> SwurlzerMissionsScreen(state)
                    SwurlzerTab.Settings -> SwurlzerSettingsScreen(
                        motionEnabled = motionEnabled,
                        onMotionChanged = onMotionChanged,
                        onOpenDeveloper = {
                            pulse(SwurlzerEnergyTarget.Developer)
                            onOpenDeveloper()
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun SwurlzerTopBar(selected: SwurlzerTab, state: HostUiState) {
    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val tone = swurlzerTone(state.toVisualState())
    Row(
        Modifier.fillMaxWidth()
            .background(Color(0xB8070A17))
            .border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .20f))
            .padding(top = statusPadding + 8.dp, bottom = 10.dp, start = 16.dp, end = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(40.dp)
                .background(Brush.linearGradient(listOf(SwurlzerPalette.Cyan.copy(alpha = .26f), SwurlzerPalette.Violet.copy(alpha = .28f))), RoundedCornerShape(13.dp))
                .border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .68f), RoundedCornerShape(13.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text("Ω", color = SwurlzerPalette.Text, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SWURLZER", color = SwurlzerPalette.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text(
                "${selected.label.uppercase()} · ${state.health.runtimeStatus.name}",
                color = tone,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 1.2.sp,
            )
        }
        StatusPill(state.health.summary.uppercase(), tone)
    }
}

@Composable
private fun SwurlzerBottomBar(selected: SwurlzerTab, onSelect: (SwurlzerTab) -> Unit) {
    NavigationBar(
        containerColor = Color(0xC4070A17),
        tonalElevation = 0.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .18f)),
    ) {
        SwurlzerTab.entries.forEach { tab ->
            NavigationBarItem(
                selected = tab == selected,
                onClick = { onSelect(tab) },
                icon = { Icon(tab.icon, contentDescription = null) },
                label = { Text(tab.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = SwurlzerPalette.Cyan,
                    selectedTextColor = SwurlzerPalette.Text,
                    indicatorColor = SwurlzerPalette.Cyan.copy(alpha = .14f),
                    unselectedIconColor = SwurlzerPalette.Muted,
                    unselectedTextColor = SwurlzerPalette.Muted,
                ),
            )
        }
    }
}

@Composable
private fun SwurlzerCoreScreen(
    state: HostUiState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onOpenNodes: () -> Unit,
    onOpenMissions: () -> Unit,
) {
    val running = state.health.runtimeStatus == RuntimeStatus.RUNNING
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("LOCAL NODE RUNTIME")
            Text(
                if (running) "Your Swurlzer is available." else "Your Swurlzer is at rest.",
                color = SwurlzerPalette.Text,
                style = MaterialTheme.typography.headlineMedium,
            )
            Text(
                "Private compatibility and approved local-link discovery remain separate, visible surfaces.",
                color = SwurlzerPalette.SecondaryText,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }
        item {
            SwurlzerGlassPanel(highlighted = running) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).background(swurlzerTone(state.toVisualState()), CircleShape))
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(state.health.summary, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                        Text("Verified runtime state", color = SwurlzerPalette.Muted, fontSize = 10.sp)
                    }
                    StatusPill(state.health.runtimeStatus.name, swurlzerTone(state.toVisualState()))
                }
                Spacer(Modifier.height(13.dp))
                ListenerLine("Private API · loopback 8080", state.health.privateApi)
                ListenerLine("Discovery · loopback 8787", state.health.discoveryLoopback)
                ListenerLine("Discovery · approved local link", state.health.discoveryLan)
                state.health.lastFailure?.let {
                    Spacer(Modifier.height(8.dp))
                    Text("Last failure: ${it.stage} · ${it.errorType}: ${it.message}", color = SwurlzerPalette.Amber, fontSize = 10.sp, lineHeight = 14.sp)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStart, enabled = state.health.runtimeStatus !in setOf(RuntimeStatus.RUNNING, RuntimeStatus.STARTING), modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text("START SWURLZER")
                }
                OutlinedButton(onClick = onStop, enabled = state.health.runtimeStatus != RuntimeStatus.STOPPED, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Icon(Icons.Outlined.Stop, contentDescription = null)
                    Spacer(Modifier.width(7.dp))
                    Text("STOP SWURLZER")
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SummaryCard("KNOWN NODES", state.nodes.size.toString(), Modifier.weight(1f).semantics { contentDescription = "Open ${state.nodes.size} known node records" }, onOpenNodes)
                SummaryCard("STORED MISSIONS", state.missions.size.toString(), Modifier.weight(1f).semantics { contentDescription = "Open ${state.missions.size} stored mission records" }, onOpenMissions)
            }
        }
        item {
            SwurlzerGlassPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Shield, contentDescription = null, tint = SwurlzerPalette.Trust)
                    Spacer(Modifier.width(9.dp))
                    Text(
                        "CLIENT approval and Truth Firewall gates remain authoritative. Swurlzer availability does not bypass them.",
                        color = SwurlzerPalette.SecondaryText,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun SwurlzerNodesScreen(state: HostUiState) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("KNOWN NODE RECORDS")
            Text("Identity stays exact.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Stored status is shown as stored; it is not promoted into a live connection claim.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        if (state.nodes.isEmpty()) {
            item { SwurlzerGlassPanel { Text("No known node records.", color = SwurlzerPalette.Muted) } }
        } else {
            items(state.nodes, key = NodeEntity::id) { node -> SwurlzerNodeCard(node) }
        }
    }
}

@Composable
private fun SwurlzerNodeCard(node: NodeEntity) {
    val trusted = node.trust.equals("trusted", ignoreCase = true)
    SwurlzerGlassPanel(highlighted = trusted) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Dns, contentDescription = null, tint = if (trusted) SwurlzerPalette.Trust else SwurlzerPalette.Cyan)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(node.label, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                Text("Stored status: ${node.status}", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
                Text("Capabilities: ${node.capabilities}", color = SwurlzerPalette.Muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            StatusPill("TRUST · ${node.trust.uppercase()}", if (trusted) SwurlzerPalette.Trust else SwurlzerPalette.Amber)
        }
    }
}

@Composable
private fun SwurlzerMissionsScreen(state: HostUiState) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("STORED MISSION RECORDS")
            Text("Mission truth, not theater.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Swurlzer shows persisted state and priority; this surface does not grant approval or execution authority.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        if (state.missions.isEmpty()) {
            item { SwurlzerGlassPanel { Text("No stored mission records.", color = SwurlzerPalette.Muted) } }
        } else {
            items(state.missions, key = MissionEntity::id) { mission -> SwurlzerMissionCard(mission) }
        }
    }
}

@Composable
private fun SwurlzerMissionCard(mission: MissionEntity) {
    val active = mission.state.isActiveMissionState()
    SwurlzerGlassPanel(highlighted = active) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.ListAlt, contentDescription = null, tint = if (active) SwurlzerPalette.Cyan else SwurlzerPalette.Muted)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(mission.title, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                Text("Priority: ${mission.priority}", color = SwurlzerPalette.Muted, fontSize = 10.sp)
            }
            StatusPill(mission.state.uppercase(), if (active) SwurlzerPalette.Cyan else SwurlzerPalette.Muted)
        }
    }
}

@Composable
private fun SwurlzerSettingsScreen(
    motionEnabled: Boolean,
    onMotionChanged: (Boolean) -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("SWURLZER SETTINGS")
            Text("Simple outside. Exact inside.", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Visual settings never alter runtime, trust, discovery, or protocol authority.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        item {
            SwurlzerGlassPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Decorative motion", color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
                        Text("Dragon drift, shimmer, pulses, and crystal transitions", color = SwurlzerPalette.Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Switch(checked = motionEnabled, onCheckedChange = onMotionChanged)
                }
            }
        }
        item {
            SwurlzerGlassPanel {
                Text("LOCAL-FIRST BOUNDARY", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(6.dp))
                Text("Private API remains loopback-only. Discovery remains limited to loopback and approved local-link interfaces. No remote-node mode is added.", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        item {
            OutlinedButton(onClick = onOpenDeveloper, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Icon(Icons.Outlined.DeveloperMode, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("SWITCH TO SWURLZER DEV MODE")
            }
        }
    }
}

@Composable
private fun ListenerLine(label: String, health: ListenerHealth) {
    val tone = listenerTone(health.status)
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).background(tone, CircleShape))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
            health.detail?.takeIf { it.isNotBlank() }?.let { Text(it, color = SwurlzerPalette.Muted, fontSize = 9.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
        }
        StatusPill(health.status.name, tone)
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.height(88.dp), contentPadding = PaddingValues(10.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = SwurlzerPalette.Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(label, color = SwurlzerPalette.SecondaryText, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.7.sp)
}

@Composable
internal fun StatusPill(text: String, tone: Color) {
    Box(
        Modifier.background(Color(0x99070A17), CircleShape)
            .border(1.dp, tone.copy(alpha = .58f), CircleShape)
            .padding(horizontal = 8.dp, vertical = 5.dp),
    ) {
        Text(text, color = tone, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .6.sp, maxLines = 1)
    }
}

private fun listenerTone(status: ListenerStatus): Color = when (status) {
    ListenerStatus.RUNNING -> SwurlzerPalette.Cyan
    ListenerStatus.STARTING -> SwurlzerPalette.Blue
    ListenerStatus.UNAVAILABLE -> SwurlzerPalette.Amber
    ListenerStatus.FAILED -> SwurlzerPalette.Danger
    ListenerStatus.STOPPED -> SwurlzerPalette.Muted
}

private fun HostUiState.toVisualState(): SwurlzerVisualState = SwurlzerVisualState(
    runtimeStatus = health.runtimeStatus,
    localLinkAvailable = health.discoveryLan.status == ListenerStatus.RUNNING,
    trustedKnownNodePresent = nodes.any { it.trust.equals("trusted", ignoreCase = true) },
    missionActive = missions.any { it.state.isActiveMissionState() },
)

private fun String.isActiveMissionState(): Boolean = trim().lowercase() in setOf(
    "accepted", "active", "running", "executing", "starting", "in_progress", "in progress",
)
