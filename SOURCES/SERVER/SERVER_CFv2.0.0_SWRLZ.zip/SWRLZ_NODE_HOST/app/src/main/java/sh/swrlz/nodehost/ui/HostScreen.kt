package sh.swrlz.nodehost.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.service.DiagnosticEntry
import sh.swrlz.nodehost.service.ListenerStatus
import sh.swrlz.nodehost.service.RuntimeDiagnosticSnapshot
import sh.swrlz.nodehost.service.RuntimeStatus
import sh.swrlz.nodehost.ui.viewmodel.HostUiState
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel

private enum class HostTab { OVERVIEW, DIAGNOSTICS }

@Composable
fun HostScreen(
    viewModel: HostViewModel,
    motionEnabled: Boolean,
    onOpenUserMode: () -> Unit,
) {
    val state by viewModel.state.collectAsState()
    var tab by remember { mutableStateOf(HostTab.OVERVIEW) }
    var filter by remember { mutableStateOf("ALL") }
    var signal by remember { mutableStateOf(SwurlzerEnergySignal(target = SwurlzerEnergyTarget.Developer)) }

    fun pulse(target: SwurlzerEnergyTarget = SwurlzerEnergyTarget.Developer) {
        signal = SwurlzerEnergySignal(signal.id + 1, target)
    }

    val visualState = SwurlzerVisualState(
        runtimeStatus = state.health.runtimeStatus,
        localLinkAvailable = state.health.discoveryLan.status == ListenerStatus.RUNNING,
        trustedKnownNodePresent = state.nodes.any { it.trust.equals("trusted", ignoreCase = true) },
        missionActive = state.missions.any { it.state.trim().lowercase() in setOf("accepted", "active", "running", "executing", "starting", "in_progress", "in progress") },
    )

    Box(Modifier.fillMaxSize().background(Color(0xFF03030B))) {
        SwurlzerBackdrop(motionEnabled, visualState, signal, artAlpha = .22f)
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                SwurlzerDevHeader(
                    state = state,
                    selected = tab,
                    onSelect = {
                        pulse()
                        tab = it
                    },
                    onOpenUserMode = {
                        pulse(SwurlzerEnergyTarget.Core)
                        onOpenUserMode()
                    },
                )
            },
        ) { padding ->
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    if (motionEnabled) {
                        (fadeIn(tween(220)) + scaleIn(tween(250), initialScale = .987f)) togetherWith
                            (fadeOut(tween(160)) + scaleOut(tween(180), targetScale = .993f))
                    } else {
                        fadeIn(tween(90)) togetherWith fadeOut(tween(70))
                    }
                },
                label = "swurlzer-dev-tab",
                modifier = Modifier.fillMaxSize().padding(padding),
            ) { selected ->
                when (selected) {
                    HostTab.OVERVIEW -> OverviewContent(
                        state = state,
                        onStart = {
                            pulse(SwurlzerEnergyTarget.Core)
                            viewModel.startNode()
                        },
                        onStop = {
                            pulse(SwurlzerEnergyTarget.Core)
                            viewModel.stopNode()
                        },
                        onSeed = viewModel::seedDemoData,
                    )
                    HostTab.DIAGNOSTICS -> DiagnosticsContent(
                        snapshot = state.diagnostics,
                        filter = filter,
                        onFilter = { filter = it },
                        onClear = viewModel::clearDiagnostics,
                    )
                }
            }
        }
    }
}

@Composable
private fun SwurlzerDevHeader(
    state: HostUiState,
    selected: HostTab,
    onSelect: (HostTab) -> Unit,
    onOpenUserMode: () -> Unit,
) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Column(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xEC070817), Color(0xD30A1020))), RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
            .border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .34f), RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
            .padding(top = top + 8.dp, bottom = 10.dp, start = 13.dp, end = 13.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp)
                    .background(Brush.linearGradient(listOf(SwurlzerPalette.Cyan.copy(alpha = .24f), SwurlzerPalette.Violet.copy(alpha = .30f))), RoundedCornerShape(13.dp))
                    .border(1.dp, SwurlzerPalette.Cyan.copy(alpha = .66f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Outlined.DeveloperMode, contentDescription = null, tint = SwurlzerPalette.Text)
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text("SWURLZER DEV MODE", color = SwurlzerPalette.Text, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                Text("FULL LEGACY ENGINEERING SURFACE", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 1.1.sp)
            }
            OutlinedButton(onClick = onOpenUserMode, contentPadding = PaddingValues(horizontal = 11.dp, vertical = 5.dp)) {
                Icon(Icons.Outlined.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text("USER MODE", fontSize = 9.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            OutlinedButton(onClick = { onSelect(HostTab.OVERVIEW) }) { Text("OVERVIEW") }
            OutlinedButton(onClick = { onSelect(HostTab.DIAGNOSTICS) }) { Text("DIAGNOSTICS") }
            StatusPill(state.health.runtimeStatus.name, swurlzerTone(SwurlzerVisualState(runtimeStatus = state.health.runtimeStatus)))
        }
    }
}

@Composable
private fun OverviewContent(
    state: HostUiState,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onSeed: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("MISSION-FIRST LOCAL NODE RUNTIME", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.5.sp)
            Text("Swurlzer engineering cockpit", color = SwurlzerPalette.Text, style = MaterialTheme.typography.headlineMedium)
            Text("Offline-first, discovery-ready, and bounded to verified runtime truth.", color = SwurlzerPalette.SecondaryText, fontSize = 12.sp)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("START NODE") }
                OutlinedButton(onClick = onStop, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("STOP NODE") }
                OutlinedButton(onClick = onSeed, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("SEED DEMO DATA") }
            }
        }
        item {
            SwurlzerGlassPanel(highlighted = state.health.runtimeStatus == RuntimeStatus.RUNNING) {
                Text("Runtime Health", color = SwurlzerPalette.Text, style = MaterialTheme.typography.titleMedium)
                DevLine("State", state.health.runtimeStatus.name)
                DevLine("Private API", "${state.health.privateApi.status} ${state.health.privateApi.detail.orEmpty()}")
                DevLine("Discovery loopback", "${state.health.discoveryLoopback.status} ${state.health.discoveryLoopback.detail.orEmpty()}")
                DevLine("Discovery LAN", "${state.health.discoveryLan.status} ${state.health.discoveryLan.detail.orEmpty()}")
                DevLine("Requests", "${state.diagnostics.totalRequests} · 2xx ${state.diagnostics.responses2xx} · 4xx ${state.diagnostics.responses4xx} · 5xx ${state.diagnostics.responses5xx}")
                state.health.lastFailure?.let { Text("Last failure: ${it.stage} — ${it.errorType}: ${it.message}", color = SwurlzerPalette.Amber, fontSize = 10.sp) }
                state.message?.let { Text(it, color = SwurlzerPalette.Cyan, fontSize = 11.sp) }
            }
        }
        item { Text("Known Nodes", color = SwurlzerPalette.Text, style = MaterialTheme.typography.titleMedium) }
        if (state.nodes.isEmpty()) item { Text("No known nodes.", color = SwurlzerPalette.Muted) }
        items(state.nodes, key = NodeEntity::id) { NodeCard(it) }
        item { Text("Missions", color = SwurlzerPalette.Text, style = MaterialTheme.typography.titleMedium) }
        if (state.missions.isEmpty()) item { Text("No stored missions.", color = SwurlzerPalette.Muted) }
        items(state.missions, key = MissionEntity::id) { MissionCard(it) }
    }
}

@Composable
private fun DiagnosticsContent(
    snapshot: RuntimeDiagnosticSnapshot,
    filter: String,
    onFilter: (String) -> Unit,
    onClear: () -> Unit,
) {
    val visible = snapshot.entries.filter { entry -> filter == "ALL" || entry.level == filter || entry.category == filter }.asReversed()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            SwurlzerGlassPanel(highlighted = true) {
                Text("Live Runtime Console", color = SwurlzerPalette.Text, style = MaterialTheme.typography.titleLarge)
                Text("Requests ${snapshot.totalRequests} · 2xx ${snapshot.responses2xx} · 4xx ${snapshot.responses4xx} · 5xx ${snapshot.responses5xx}", color = SwurlzerPalette.SecondaryText)
                Text("Last request: ${snapshot.lastRequestEpochMs?.let(::formatTime) ?: "None"}", color = SwurlzerPalette.Muted, fontSize = 10.sp)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("ALL", "INFO", "WARN", "ERROR", "HTTP", "RUNTIME").forEach { value ->
                    OutlinedButton(onClick = { onFilter(value) }) { Text(value) }
                }
                Button(onClick = onClear) { Text("CLEAR") }
            }
        }
        if (visible.isEmpty()) item { Text("No diagnostic entries for this filter.", color = SwurlzerPalette.Muted) }
        items(visible, key = DiagnosticEntry::sequence) { DiagnosticCard(it) }
    }
}

@Composable
private fun DiagnosticCard(entry: DiagnosticEntry) {
    SwurlzerGlassPanel {
        Text("${formatTime(entry.timestampEpochMs)}  ${entry.level}  ${entry.category}", color = SwurlzerPalette.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
        Text(entry.event, color = SwurlzerPalette.Text)
        entry.detail?.let { Text(it, color = SwurlzerPalette.Muted, fontSize = 10.sp, maxLines = 5, overflow = TextOverflow.Ellipsis) }
    }
}

@Composable
private fun NodeCard(node: NodeEntity) {
    SwurlzerGlassPanel(highlighted = node.trust.equals("trusted", ignoreCase = true)) {
        Text(node.label, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
        Text("Status: ${node.status} · Trust: ${node.trust}", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
        Text("Capabilities: ${node.capabilities}", color = SwurlzerPalette.Muted, fontSize = 10.sp)
    }
}

@Composable
private fun MissionCard(mission: MissionEntity) {
    SwurlzerGlassPanel {
        Text(mission.title, color = SwurlzerPalette.Text, fontWeight = FontWeight.SemiBold)
        Text("State: ${mission.state} · Priority: ${mission.priority}", color = SwurlzerPalette.SecondaryText, fontSize = 11.sp)
    }
}

@Composable
private fun DevLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = SwurlzerPalette.Muted, fontSize = 10.sp, modifier = Modifier.width(122.dp))
        Text(value, color = SwurlzerPalette.SecondaryText, fontSize = 10.sp, modifier = Modifier.weight(1f))
    }
}

private fun formatTime(epochMs: Long): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(epochMs))
