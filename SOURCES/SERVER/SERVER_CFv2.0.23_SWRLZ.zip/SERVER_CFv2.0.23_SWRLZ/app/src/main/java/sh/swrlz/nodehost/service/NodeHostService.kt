package sh.swrlz.nodehost.service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.R
import sh.swrlz.nodehost.ui.SwurlzerUiPreferences

@AndroidEntryPoint
class NodeHostService : Service() {
    @Inject lateinit var nodeRuntime: NodeRuntime

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        NodeHostNotificationChannel.ensure(this)
        startForeground(
            NOTIFICATION_ID,
            buildNotification(
                health = NodeHealth(runtimeStatus = RuntimeStatus.STARTING),
                enhanced = true,
                themeFamily = "Glitch Dragon Glass",
                themeVariant = "Dark",
            ),
        )

        serviceScope.launch {
            combine(
                nodeRuntime.health,
                SwurlzerUiPreferences.statusNotificationEnabledFlow(this@NodeHostService),
                SwurlzerUiPreferences.themeFamilyFlow(this@NodeHostService),
                SwurlzerUiPreferences.themeVariantFlow(this@NodeHostService),
            ) { health, enhanced, family, variant ->
                NotificationState(health, enhanced, family, variant)
            }.collectLatest { state ->
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(
                    NOTIFICATION_ID,
                    buildNotification(state.health, state.enhanced, state.themeFamily, state.themeVariant),
                )
            }
        }
        serviceScope.launch {
            nodeRuntime.start()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        nodeRuntime.stop()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(
        health: NodeHealth,
        enhanced: Boolean,
        themeFamily: String,
        themeVariant: String,
    ): Notification {
        val text = when (health.runtimeStatus) {
            RuntimeStatus.STARTING -> "Starting local node runtime"
            RuntimeStatus.RUNNING -> "Private and discovery listeners active"
            RuntimeStatus.DEGRADED -> "Loopback active; LAN discovery unavailable"
            RuntimeStatus.MAINTENANCE -> "Maintenance mode; normal work paused"
            RuntimeStatus.RELOADING_CONFIGURATION -> "Reloading configuration"
            RuntimeStatus.RESTARTING_SERVICES -> "Restarting services"
            RuntimeStatus.SHUTTING_DOWN -> "Shutdown sequence ${health.shutdownStep}/10"
            RuntimeStatus.FAILED -> "Runtime failed: ${health.lastFailure?.stage ?: "startup"}"
            RuntimeStatus.STOPPED -> "Local node runtime stopped"
        }
        val expanded = buildString {
            append(text)
            if (enhanced) {
                append("\nPrivate API: ").append(health.privateApi.status.name)
                append(" · Discovery: ").append(health.discoveryLoopback.status.name)
                append("\nLAN listener: ").append(health.discoveryLan.status.name)
                append("\nTheme armor: ").append(themeFamily).append(" · ").append(themeVariant)
            }
        }
        return NotificationCompat.Builder(this, NodeHostNotificationChannel.CHANNEL_ID)
            .setContentTitle(if (enhanced) "Ω  SWURLZ Server · ${health.runtimeStatus.name}" else "SWRLZ Server active")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expanded))
            .setSubText(if (enhanced) "Glitch Dragon Core" else null)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(health.runtimeStatus != RuntimeStatus.FAILED && health.runtimeStatus != RuntimeStatus.STOPPED)
            .build()
    }

    private data class NotificationState(
        val health: NodeHealth,
        val enhanced: Boolean,
        val themeFamily: String,
        val themeVariant: String,
    )

    companion object {
        private const val NOTIFICATION_ID = 1
    }
}
