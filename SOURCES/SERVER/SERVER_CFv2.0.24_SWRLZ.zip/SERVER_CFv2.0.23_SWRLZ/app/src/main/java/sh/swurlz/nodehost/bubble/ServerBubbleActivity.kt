package sh.swurlz.nodehost.bubble

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class ServerBubbleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var draft by remember { mutableStateOf("") }
                    var transcript by remember { mutableStateOf("Server channel ready.") }
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text("Ω  SWRLZ SERVER CHAT", style = MaterialTheme.typography.titleLarge)
                        Text(intent.getStringExtra("status") ?: "Server runtime active")
                        Text(transcript)
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Message nodes") },
                        )
                        Button(
                            onClick = {
                                val value = draft.trim()
                                if (value.isNotEmpty()) {
                                    transcript = "Admin: $value"
                                    draft = ""
                                }
                            },
                            enabled = draft.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("SEND")
                        }
                        Button(
                            onClick = {
                                packageManager
                                    .getLaunchIntentForPackage(packageName)
                                    ?.also(::startActivity)
                            },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text("OPEN SERVER")
                        }
                    }
                }
            }
        }
    }
}
