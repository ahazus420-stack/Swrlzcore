package sh.swrlz.nodehost.ui

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import sh.swrlz.nodehost.ui.theme.SwurlzerThemeCatalog
import sh.swrlz.nodehost.identity.ThemeIdentityManager

private val Context.swurlzerUiDataStore by preferencesDataStore(name = "swurlzer_ui")

enum class SwurlzerInterfaceMode(val storageValue: String) {
    User("user"),
    Developer("developer");

    companion object {
        fun fromStorage(value: String?): SwurlzerInterfaceMode =
            entries.firstOrNull { it.storageValue == value?.trim()?.lowercase() } ?: User
    }
}

object SwurlzerUiPreferences {
    private val MODE = stringPreferencesKey("interface_mode")
    private val MOTION = booleanPreferencesKey("motion_enabled")
    private val THEME_FAMILY = stringPreferencesKey("theme_family")
    private val THEME_VARIANT = stringPreferencesKey("theme_variant")
    private val SETUP_COMPLETE = booleanPreferencesKey("setup_complete")
    private val START_ON_LAUNCH = booleanPreferencesKey("start_server_on_launch")
    private val STATUS_NOTIFICATION_ENABLED = booleanPreferencesKey("status_notification_enabled")

    fun modeFlow(context: Context): Flow<SwurlzerInterfaceMode> =
        context.swurlzerUiDataStore.data.map { SwurlzerInterfaceMode.fromStorage(it[MODE]) }

    fun motionEnabledFlow(context: Context): Flow<Boolean> =
        context.swurlzerUiDataStore.data.map { it[MOTION] ?: true }

    fun themeFamilyFlow(context: Context): Flow<String> =
        context.swurlzerUiDataStore.data.map { it[THEME_FAMILY] ?: "Glitch Dragon Glass" }

    fun themeVariantFlow(context: Context): Flow<String> =
        context.swurlzerUiDataStore.data.map { it[THEME_VARIANT] ?: "Dark" }

    fun setupCompleteFlow(context: Context): Flow<Boolean> =
        context.swurlzerUiDataStore.data.map { it[SETUP_COMPLETE] ?: false }

    fun startOnLaunchFlow(context: Context): Flow<Boolean> =
        context.swurlzerUiDataStore.data.map { it[START_ON_LAUNCH] ?: true }

    fun statusNotificationEnabledFlow(context: Context): Flow<Boolean> =
        context.swurlzerUiDataStore.data.map { it[STATUS_NOTIFICATION_ENABLED] ?: true }

    suspend fun setMode(context: Context, mode: SwurlzerInterfaceMode) {
        context.swurlzerUiDataStore.edit { it[MODE] = mode.storageValue }
    }

    suspend fun setMotionEnabled(context: Context, enabled: Boolean) {
        context.swurlzerUiDataStore.edit { it[MOTION] = enabled }
    }

    suspend fun setSetupComplete(context: Context, complete: Boolean) {
        context.swurlzerUiDataStore.edit { it[SETUP_COMPLETE] = complete }
    }

    suspend fun setStartOnLaunch(context: Context, enabled: Boolean) {
        context.swurlzerUiDataStore.edit { it[START_ON_LAUNCH] = enabled }
    }

    suspend fun setStatusNotificationEnabled(context: Context, enabled: Boolean) {
        context.swurlzerUiDataStore.edit { it[STATUS_NOTIFICATION_ENABLED] = enabled }
    }

    suspend fun setTheme(context: Context, family: String, variant: String) {
        require(family in SwurlzerThemeCatalog.families)
        require(variant in SwurlzerThemeCatalog.variants)
        context.swurlzerUiDataStore.edit {
            it[THEME_FAMILY] = family
            it[THEME_VARIANT] = variant
        }
        ThemeIdentityManager.requestApply(context, family)
    }
}
