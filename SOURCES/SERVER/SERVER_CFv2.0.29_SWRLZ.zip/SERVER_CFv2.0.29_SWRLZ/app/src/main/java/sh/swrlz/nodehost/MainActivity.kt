package sh.swrlz.nodehost

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import dagger.hilt.android.AndroidEntryPoint
import sh.swrlz.nodehost.ui.NodeHostApp

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) sh.swrlz.nodehost.identity.ThemeIdentityManager.applyPending(applicationContext)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Surface(modifier = Modifier.fillMaxSize()) { NodeHostApp() }
        }
    }
}
