package sh.swrlz.nodehost.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NodeService @Inject constructor(@ApplicationContext private val context: Context, private val runtime: NodeRuntime) {
    fun start() {
        ContextCompat.startForegroundService(context, Intent(context, NodeHostService::class.java))
    }

    fun stop() { runtime.beginShutdownSequence(); context.stopService(Intent(context, NodeHostService::class.java)) }
    fun enterMaintenance() = runtime.enterMaintenance()
    fun reloadConfiguration() = runtime.reloadConfiguration()
    fun restartServices() = runtime.restartServices()

}
