# SWRLZ Node Host

This directory contains a production-oriented Android Studio project for the SWRLZ Node Host application.

## What is included
- Kotlin + Jetpack Compose UI
- Room-backed persistence for nodes and missions
- Foreground service entry point
- Embedded private and local-link HTTP runtime
- Read-only CLIENT compatibility routes with authoritative-empty presence truth
- Deterministic Glitch Dragon Core launcher resources
- Basic theme, permissions, diagnostics, and mission views
- Build scripts and Android manifest

## Build status
This source archive is the v1.0.3 SERVER candidate. Source-level contract and launcher-resource checks pass. Committing the canonical ZIP to `SOURCES/SERVER/` triggers the repository's SERVER APK build; installation and on-device route verification remain required before acceptance.
