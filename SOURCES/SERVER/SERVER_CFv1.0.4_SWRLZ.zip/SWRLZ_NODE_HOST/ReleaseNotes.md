# Release Notes

## 1.0.3
- Added truthful CLIENT compatibility routes on the local-link listener.
- Empty presence now returns authoritative zero counts and empty collections instead of `404`.
- Preserved discovery signature, durable identity, protocol/schema version 1, and trust boundaries.
- Added deterministic Glitch Dragon Core launcher icons.
- Source version advanced to `versionCode 2` / `versionName 1.0.3`.

## 1.0
- Initial Android Studio project for SWRLZ Node Host.
- Compose UI, Room persistence, foreground service, and embedded local runtime.
- Mission-first dashboard with node and mission state.
