package sh.swrlz.nodehost.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.service.DiagnosticEntry
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel

private enum class HostTab { OVERVIEW, DIAGNOSTICS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostScreen(viewModel: HostViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()
    var tab by remember { mutableStateOf(HostTab.OVERVIEW) }
    var filter by remember { mutableStateOf("ALL") }

    Scaffold(topBar = { TopAppBar(title = { Text("SWRLZ Node Host") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(onClick = { tab = HostTab.OVERVIEW }) { Text("Overview") }
                OutlinedButton(onClick = { tab = HostTab.DIAGNOSTICS }) { Text("Diagnostics") }
            }
            when (tab) {
                HostTab.OVERVIEW -> OverviewContent(state, viewModel)
                HostTab.DIAGNOSTICS -> DiagnosticsContent(state.diagnostics, filter, { filter = it }, viewModel::clearDiagnostics)
            }
        }
    }
}

@Composable
private fun OverviewContent(state: sh.swrlz.nodehost.ui.viewmodel.HostUiState, viewModel: HostViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Mission-first local node runtime", style = MaterialTheme.typography.headlineMedium)
            Text("Offline-first, discovery-ready, and compatible with the SWRLZ local node server concepts.")
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = viewModel::startNode) { Text("Start Node") }
                Button(onClick = viewModel::stopNode) { Text("Stop Node") }
                Button(onClick = viewModel::seedDemoData) { Text("Seed Demo Data") }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Runtime Health", style = MaterialTheme.typography.titleMedium)
                    Text("State: ${state.health.runtimeStatus}")
                    Text("Private API: ${state.health.privateApi.status} ${state.health.privateApi.detail.orEmpty()}")
                    Text("Discovery loopback: ${state.health.discoveryLoopback.status} ${state.health.discoveryLoopback.detail.orEmpty()}")
                    Text("Discovery LAN: ${state.health.discoveryLan.status} ${state.health.discoveryLan.detail.orEmpty()}")
                    Text("Requests: ${state.diagnostics.totalRequests} | 2xx ${state.diagnostics.responses2xx} | 4xx ${state.diagnostics.responses4xx} | 5xx ${state.diagnostics.responses5xx}")
                    state.health.lastFailure?.let { Text("Last failure: ${it.stage} — ${it.errorType}: ${it.message}") }
                    state.message?.let { Text(it) }
                }
            }
        }
        item { Text("Known Nodes", style = MaterialTheme.typography.titleMedium) }
        items(state.nodes) { NodeCard(it) }
        item { Text("Missions", style = MaterialTheme.typography.titleMedium) }
        items(state.missions) { MissionCard(it) }
    }
}

@Composable
private fun DiagnosticsContent(
    snapshot: sh.swrlz.nodehost.service.RuntimeDiagnosticSnapshot,
    filter: String,
    onFilter: (String) -> Unit,
    onClear: () -> Unit,
) {
    val visible = snapshot.entries.filter { entry ->
        filter == "ALL" || entry.level == filter || entry.category == filter
    }.asReversed()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Live Runtime Console", style = MaterialTheme.typography.titleLarge)
                    Text("Requests ${snapshot.totalRequests} • 2xx ${snapshot.responses2xx} • 4xx ${snapshot.responses4xx} • 5xx ${snapshot.responses5xx}")
                    Text("Last request: ${snapshot.lastRequestEpochMs?.let(::formatTime) ?: "None"}")
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                listOf("ALL", "INFO", "WARN", "ERROR", "HTTP", "RUNTIME").forEach { value ->
                    OutlinedButton(onClick = { onFilter(value) }) { Text(value) }
                }
                Button(onClick = onClear) { Text("Clear") }
            }
        }
        if (visible.isEmpty()) item { Text("No diagnostic entries for this filter.") }
        items(visible, key = DiagnosticEntry::sequence) { entry -> DiagnosticCard(entry) }
    }
}

@Composable
private fun DiagnosticCard(entry: DiagnosticEntry) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("${formatTime(entry.timestampEpochMs)}  ${entry.level}  ${entry.category}", style = MaterialTheme.typography.labelMedium)
            Text(entry.event, style = MaterialTheme.typography.bodyLarge)
            entry.detail?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

private fun formatTime(epochMs: Long): String =
    SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(epochMs))

@Composable
private fun NodeCard(node: NodeEntity) {
    Card(modifier = Modifier.padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(node.label)
            Text("Status: ${node.status} | Trust: ${node.trust}")
            Text("Capabilities: ${node.capabilities}")
        }
    }
}

@Composable
private fun MissionCard(mission: MissionEntity) {
    Card(modifier = Modifier.padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(mission.title)
            Text("State: ${mission.state} | Priority: ${mission.priority}")
        }
    }
}
