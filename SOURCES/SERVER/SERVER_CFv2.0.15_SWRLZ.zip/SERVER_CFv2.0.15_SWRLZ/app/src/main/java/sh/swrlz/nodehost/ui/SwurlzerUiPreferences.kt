package sh.swrlz.nodehost.ui

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import sh.swrlz.nodehost.ui.theme.SwurlzerThemeCatalog

private val Context.swurlzerUiDataStore by preferencesDataStore(name = "swurlzer_ui")

enum class SwurlzerInterfaceMode(val storageValue: String) {
    User("user"),
    Developer("developer");

    companion object {
        fun fromStorage(value: String?): SwurlzerInterfaceMode =
            entries.firstOrNull { it.storageValue == value?.trim()?.lowercase() } ?: User
    }
}

object SwurlzerUiPreferences {
    private val MODE = stringPreferencesKey("interface_mode")
    private val MOTION = booleanPreferencesKey("motion_enabled")
    private val THEME_FAMILY = stringPreferencesKey("theme_family")
    private val THEME_VARIANT = stringPreferencesKey("theme_variant")

    fun modeFlow(context: Context): Flow<SwurlzerInterfaceMode> =
        context.swurlzerUiDataStore.data.map { SwurlzerInterfaceMode.fromStorage(it[MODE]) }

    fun motionEnabledFlow(context: Context): Flow<Boolean> =
        context.swurlzerUiDataStore.data.map { it[MOTION] ?: true }

    fun themeFamilyFlow(context: Context): Flow<String> =
        context.swurlzerUiDataStore.data.map { it[THEME_FAMILY] ?: "Glitch Dragon Glass" }

    fun themeVariantFlow(context: Context): Flow<String> =
        context.swurlzerUiDataStore.data.map { it[THEME_VARIANT] ?: "Dark" }

    suspend fun setMode(context: Context, mode: SwurlzerInterfaceMode) {
        context.swurlzerUiDataStore.edit { it[MODE] = mode.storageValue }
    }

    suspend fun setMotionEnabled(context: Context, enabled: Boolean) {
        context.swurlzerUiDataStore.edit { it[MOTION] = enabled }
    }

    suspend fun setTheme(context: Context, family: String, variant: String) {
        require(family in SwurlzerThemeCatalog.families)
        require(variant in SwurlzerThemeCatalog.variants)
        context.swurlzerUiDataStore.edit {
            it[THEME_FAMILY] = family
            it[THEME_VARIANT] = variant
        }
    }
}
