package sh.swrlz.nodehost.data.dao
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.entity.*
@Dao interface GroupDao {
 @Query("SELECT * FROM node_groups WHERE status != 'ARCHIVED' ORDER BY displayName") fun observeGroups():Flow<List<GroupEntity>>
 @Query("SELECT * FROM node_groups WHERE groupId=:id LIMIT 1") suspend fun findGroup(id:String):GroupEntity?
 @Query("SELECT * FROM node_groups WHERE normalizedName=:name AND status != 'ARCHIVED' LIMIT 1") suspend fun findByName(name:String):GroupEntity?
 @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertGroup(group:GroupEntity)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertMembership(value:GroupMembershipEntity)
 @Query("SELECT * FROM group_memberships WHERE groupId=:groupId AND membershipState='ACTIVE'") suspend fun members(groupId:String):List<GroupMembershipEntity>
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertInvite(value:GroupInviteEntity)
 @Query("UPDATE group_invites SET active=0 WHERE groupId=:groupId") suspend fun invalidateInvites(groupId:String)
 @Query("SELECT * FROM group_invites WHERE codeHash=:hash AND active=1 LIMIT 1") suspend fun findInvite(hash:String):GroupInviteEntity?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertJoinRequest(value:GroupJoinRequestEntity)
 @Query("SELECT * FROM group_join_requests WHERE groupId=:groupId AND state='PENDING_APPROVAL' ORDER BY requestedAt") fun observePending(groupId:String):Flow<List<GroupJoinRequestEntity>>
 @Query("SELECT * FROM group_join_requests WHERE requestId=:requestId LIMIT 1") suspend fun findJoinRequest(requestId:String):GroupJoinRequestEntity?
 @Query("SELECT COUNT(*) FROM node_groups WHERE status='ACTIVE'") fun observeActiveCount():Flow<Int>
 @Query("SELECT g.* FROM node_groups g INNER JOIN group_memberships m ON g.groupId=m.groupId WHERE m.nodeId=:nodeId AND m.membershipState='ACTIVE' AND g.status!='ARCHIVED' ORDER BY g.displayName") suspend fun groupsForNode(nodeId:String):List<GroupEntity>
}