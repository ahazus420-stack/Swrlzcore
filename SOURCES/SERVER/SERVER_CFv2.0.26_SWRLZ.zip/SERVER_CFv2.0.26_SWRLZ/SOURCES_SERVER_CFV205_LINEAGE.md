# SERVER CFv2.0.5 Lineage

- Baseline: SERVER_CFv2.0.4_SWRLZ.zip
- Baseline SHA-256: f33365786a04d729afc1546cd1a63dc1b1efb2560a01fe8094b4c2be72aefd88
- Checkpoint: INT-UI-013A
- Android identity: versionCode 8 / versionName 2.0.5
- Build: NOT RUN
- Integration law: Integrate, do not overwrite.
