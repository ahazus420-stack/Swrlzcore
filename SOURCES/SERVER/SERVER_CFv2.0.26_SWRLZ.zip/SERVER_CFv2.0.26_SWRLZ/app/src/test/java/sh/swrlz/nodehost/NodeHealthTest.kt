package sh.swrlz.nodehost

import org.junit.Assert.assertEquals
import org.junit.Test
import sh.swrlz.nodehost.service.ListenerHealth
import sh.swrlz.nodehost.service.ListenerStatus
import sh.swrlz.nodehost.service.NodeHealth
import sh.swrlz.nodehost.service.RuntimeStatus

class NodeHealthTest {
    @Test
    fun summaryNeverClaimsRunningForStartingFailedOrStoppedStates() {
        assertEquals("Node starting", NodeHealth(runtimeStatus = RuntimeStatus.STARTING).summary)
        assertEquals("Node failed", NodeHealth(runtimeStatus = RuntimeStatus.FAILED).summary)
        assertEquals("Node stopped", NodeHealth(runtimeStatus = RuntimeStatus.STOPPED).summary)
    }

    @Test
    fun degradedStatePreservesIndependentListenerFacts() {
        val health = NodeHealth(
            runtimeStatus = RuntimeStatus.DEGRADED,
            privateApi = ListenerHealth(ListenerStatus.RUNNING),
            discoveryLoopback = ListenerHealth(ListenerStatus.RUNNING),
            discoveryLan = ListenerHealth(ListenerStatus.UNAVAILABLE),
        )
        assertEquals("Node degraded", health.summary)
        assertEquals(ListenerStatus.RUNNING, health.discoveryLoopback.status)
        assertEquals(ListenerStatus.UNAVAILABLE, health.discoveryLan.status)
    }
}
