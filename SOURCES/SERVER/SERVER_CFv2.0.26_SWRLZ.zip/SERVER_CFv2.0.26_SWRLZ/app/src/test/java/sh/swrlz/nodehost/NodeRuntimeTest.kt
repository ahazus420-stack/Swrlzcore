package sh.swrlz.nodehost

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import sh.swrlz.nodehost.service.ListenerHealth
import sh.swrlz.nodehost.service.ListenerKind
import sh.swrlz.nodehost.service.ListenerStatus
import sh.swrlz.nodehost.service.NodeHealth
import sh.swrlz.nodehost.service.RuntimeFailure
import sh.swrlz.nodehost.service.RuntimeStatus
import sh.swrlz.nodehost.service.terminalStartupFailureHealth
import sh.swrlz.nodehost.service.unexpectedListenerExitHealth

class NodeRuntimeTest {
    private fun failure(listener: String? = null) = RuntimeFailure(
        timestampEpochMs = 1L,
        stage = "test",
        listener = listener,
        errorType = "TestFailure",
        message = "simulated failure",
    )

    @Test
    fun discoveryStartupFailureClosesPreviouslyRunningPrivateListenerTruthfully() {
        val previous = NodeHealth(
            runtimeStatus = RuntimeStatus.STARTING,
            privateApi = ListenerHealth(ListenerStatus.RUNNING),
            discoveryLoopback = ListenerHealth(ListenerStatus.STARTING),
            discoveryLan = ListenerHealth(ListenerStatus.STARTING),
        )

        val health = terminalStartupFailureHealth(previous, "discovery_8787", failure("discovery"))

        assertEquals(RuntimeStatus.FAILED, health.runtimeStatus)
        assertEquals(ListenerStatus.STOPPED, health.privateApi.status)
        assertEquals(ListenerStatus.FAILED, health.discoveryLoopback.status)
        assertEquals(ListenerStatus.STOPPED, health.discoveryLan.status)
    }

    @Test
    fun earlyStartupFailureLeavesNoListenerStartingOrRunning() {
        val previous = NodeHealth(
            runtimeStatus = RuntimeStatus.STARTING,
            privateApi = ListenerHealth(ListenerStatus.STARTING),
            discoveryLoopback = ListenerHealth(ListenerStatus.STARTING),
            discoveryLan = ListenerHealth(ListenerStatus.STARTING),
        )

        val health = terminalStartupFailureHealth(previous, "identity", failure())
        listOf(health.privateApi, health.discoveryLoopback, health.discoveryLan).forEach {
            assertNotEquals(ListenerStatus.STARTING, it.status)
            assertNotEquals(ListenerStatus.RUNNING, it.status)
        }
    }

    @Test
    fun unexpectedPrivateListenerExitFailsRuntime() {
        val health = unexpectedListenerExitHealth(
            previous = NodeHealth(
                runtimeStatus = RuntimeStatus.RUNNING,
                privateApi = ListenerHealth(ListenerStatus.RUNNING),
                discoveryLoopback = ListenerHealth(ListenerStatus.RUNNING),
                discoveryLan = ListenerHealth(ListenerStatus.RUNNING),
            ),
            listener = ListenerKind.PRIVATE_API,
            failure = failure("private_api"),
        )

        assertEquals(RuntimeStatus.FAILED, health.runtimeStatus)
        assertEquals(ListenerStatus.FAILED, health.privateApi.status)
    }

    @Test
    fun unexpectedLanListenerExitDegradesRuntime() {
        val health = unexpectedListenerExitHealth(
            previous = NodeHealth(
                runtimeStatus = RuntimeStatus.RUNNING,
                privateApi = ListenerHealth(ListenerStatus.RUNNING),
                discoveryLoopback = ListenerHealth(ListenerStatus.RUNNING),
                discoveryLan = ListenerHealth(ListenerStatus.RUNNING),
            ),
            listener = ListenerKind.DISCOVERY_LAN,
            failure = failure("discovery_lan"),
        )

        assertEquals(RuntimeStatus.DEGRADED, health.runtimeStatus)
        assertEquals(ListenerStatus.FAILED, health.discoveryLan.status)
    }
}
