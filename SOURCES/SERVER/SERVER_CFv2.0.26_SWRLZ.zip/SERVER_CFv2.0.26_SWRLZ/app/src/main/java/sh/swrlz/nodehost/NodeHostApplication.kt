package sh.swrlz.nodehost

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class NodeHostApplication : Application()
