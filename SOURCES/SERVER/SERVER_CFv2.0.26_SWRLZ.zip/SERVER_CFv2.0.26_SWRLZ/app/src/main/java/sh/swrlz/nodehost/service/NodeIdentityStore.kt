package sh.swrlz.nodehost.service

import android.content.Context
import android.util.AtomicFile
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.Properties
import java.util.UUID

internal data class NodeHostIdentity(
    val nodeId: String,
    val installationId: String,
)

/**
 * Durable NODE_HOST identity storage kept outside Room and Android backup.
 *
 * The no-backup directory survives process death, reboot, and app updates, while
 * normal Android data clearing or uninstall/reinstall removes it. AtomicFile
 * prevents a partial write from silently becoming a new identity.
 */
internal class NodeIdentityStore(context: Context) {
    private val identityFile = AtomicFile(
        File(context.applicationContext.noBackupFilesDir, IDENTITY_FILE_NAME),
    )

    @Synchronized
    fun loadOrCreate(): NodeHostIdentity {
        val storeExisted = identityFile.baseFile.exists()
        val existing = readProperties()
        val parsed = existing?.toIdentityOrNull()
        if (parsed != null) return parsed

        val generated = NodeHostIdentity(
            nodeId = newId(NODE_ID_PREFIX),
            installationId = newId(INSTALLATION_ID_PREFIX),
        )
        val replacement = Properties().apply {
            setProperty(KEY_NODE_ID, generated.nodeId)
            setProperty(KEY_INSTALLATION_ID, generated.installationId)
            if (storeExisted) {
                setProperty(KEY_RESET_AT_MS, System.currentTimeMillis().toString())
                existing?.getProperty(KEY_NODE_ID)
                    ?.takeIf { isValidId(it, NODE_ID_PREFIX) }
                    ?.let { setProperty(KEY_PREVIOUS_NODE_ID, it) }
            }
        }
        persistAndVerify(replacement, generated)
        return generated
    }

    /**
     * Reserved for a future explicit user-authorized rotation surface.
     * It changes only nodeId and preserves installationId plus lineage receipt.
     */
    @Synchronized
    fun rotateNodeIdentity(): NodeHostIdentity {
        val current = loadOrCreate()
        val rotated = current.copy(nodeId = newId(NODE_ID_PREFIX))
        val properties = readProperties() ?: Properties()
        properties.setProperty(KEY_PREVIOUS_NODE_ID, current.nodeId)
        properties.setProperty(KEY_NODE_ID, rotated.nodeId)
        properties.setProperty(KEY_INSTALLATION_ID, rotated.installationId)
        properties.setProperty(KEY_ROTATED_AT_MS, System.currentTimeMillis().toString())
        persistAndVerify(properties, rotated)
        return rotated
    }

    private fun readProperties(): Properties? {
        if (!identityFile.baseFile.exists()) return null
        return try {
            identityFile.openRead().use { input ->
                InputStreamReader(input, StandardCharsets.UTF_8).use { reader ->
                    Properties().apply { load(reader) }
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun persistAndVerify(properties: Properties, expected: NodeHostIdentity) {
        var stream: FileOutputStream? = null
        try {
            stream = identityFile.startWrite()
            properties.store(stream, null)
            stream.flush()
            identityFile.finishWrite(stream)
            stream = null
        } catch (error: Exception) {
            stream?.let(identityFile::failWrite)
            throw IllegalStateException("Unable to persist NODE_HOST identity", error)
        }

        val readBack = readProperties()?.toIdentityOrNull()
        if (readBack != expected) {
            throw IllegalStateException("NODE_HOST identity failed durable read-back verification")
        }
    }

    private fun Properties.toIdentityOrNull(): NodeHostIdentity? {
        val nodeId = getProperty(KEY_NODE_ID) ?: return null
        val installationId = getProperty(KEY_INSTALLATION_ID) ?: return null
        if (!isValidId(nodeId, NODE_ID_PREFIX)) return null
        if (!isValidId(installationId, INSTALLATION_ID_PREFIX)) return null
        return NodeHostIdentity(nodeId, installationId)
    }

    companion object {
        internal const val NODE_ID_PREFIX = "swrlz-node-"
        internal const val INSTALLATION_ID_PREFIX = "swrlz-install-"

        private const val IDENTITY_FILE_NAME = "node_host_identity.properties"
        private const val KEY_NODE_ID = "node_id"
        private const val KEY_INSTALLATION_ID = "installation_id"
        private const val KEY_PREVIOUS_NODE_ID = "previous_node_id"
        private const val KEY_ROTATED_AT_MS = "rotated_at_ms"
        private const val KEY_RESET_AT_MS = "identity_reset_at_ms"

        private fun newId(prefix: String): String = prefix + UUID.randomUUID().toString()

        internal fun isValidId(value: String, prefix: String): Boolean {
            if (!value.startsWith(prefix)) return false
            val suffix = value.removePrefix(prefix)
            if (suffix.length != 36) return false
            val uuid = try {
                UUID.fromString(suffix)
            } catch (_: IllegalArgumentException) {
                return false
            }
            return uuid.toString().equals(suffix, ignoreCase = true) && uuid.version() == 4
        }
    }
}
