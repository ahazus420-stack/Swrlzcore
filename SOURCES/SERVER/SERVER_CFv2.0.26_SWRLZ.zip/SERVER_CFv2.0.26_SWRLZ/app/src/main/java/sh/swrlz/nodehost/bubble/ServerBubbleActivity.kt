package sh.swrlz.nodehost.bubble

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sh.swrlz.nodehost.ui.SwurlzerUiPreferences
import sh.swrlz.nodehost.ui.theme.SwrlzTheme
import sh.swrlz.nodehost.ui.theme.SwurlzerThemeCatalog

class ServerBubbleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val family by SwurlzerUiPreferences.themeFamilyFlow(this)
                .collectAsState(initial = "Glitch Dragon Glass")
            val variant by SwurlzerUiPreferences.themeVariantFlow(this)
                .collectAsState(initial = "Dark")
            val tokens = SwurlzerThemeCatalog.resolve(family, variant)
            SwrlzTheme(family, variant) {
                var draft by remember { mutableStateOf("") }
                var transcript by remember { mutableStateOf("Server command link ready.") }
                val status = intent.getStringExtra("status") ?: "Server runtime active"

                Surface(modifier = Modifier.fillMaxSize(), color = tokens.background) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(tokens.background)
                            .padding(14.dp),
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(
                                color = tokens.surface,
                                shape = RoundedCornerShape(22.dp),
                                border = BorderStroke(1.dp, tokens.primary),
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(
                                            "Ω",
                                            color = tokens.primary,
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.Black,
                                        )
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(start = 10.dp),
                                        ) {
                                            Text(
                                                "SWRLZ · SERVER",
                                                color = tokens.text,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Black,
                                            )
                                            Text(
                                                "COMMAND LINK",
                                                color = tokens.tertiary,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                            )
                                        }
                                        Text(
                                            "ACTIVE",
                                            color = tokens.tertiary,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                        )
                                    }

                                    Surface(
                                        color = tokens.panel,
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, tokens.secondary),
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp),
                                        ) {
                                            Text(
                                                "SERVER STATUS",
                                                color = tokens.primary,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            Text(status, color = tokens.secondaryText)
                                        }
                                    }

                                    Surface(
                                        color = tokens.panel,
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, tokens.primary.copy(alpha = 0.45f)),
                                    ) {
                                        Text(
                                            transcript,
                                            modifier = Modifier.padding(12.dp),
                                            color = tokens.text,
                                        )
                                    }

                                    OutlinedTextField(
                                        value = draft,
                                        onValueChange = { draft = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Message connected nodes") },
                                        maxLines = 3,
                                    )

                                    Button(
                                        onClick = {
                                            val value = draft.trim()
                                            if (value.isNotEmpty()) {
                                                transcript = "Admin: $value"
                                                draft = ""
                                            }
                                        },
                                        enabled = draft.isNotBlank(),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = tokens.primary.copy(alpha = 0.18f),
                                            contentColor = tokens.primary,
                                        ),
                                        border = BorderStroke(1.dp, tokens.primary),
                                    ) {
                                        Text("SEND", fontWeight = FontWeight.Black)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            packageManager
                                                .getLaunchIntentForPackage(packageName)
                                                ?.also(::startActivity)
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        border = BorderStroke(1.dp, tokens.secondary),
                                    ) {
                                        Text("OPEN SERVER", color = tokens.secondary)
                                    }
                                }
                            }

                            Spacer(Modifier.height(2.dp))
                            Text(
                                "Floating Dragon · $family · $variant",
                                color = tokens.muted,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.align(Alignment.CenterHorizontally),
                            )
                        }
                    }
                }
            }
        }
    }
}
