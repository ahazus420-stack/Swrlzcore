package sh.swrlz.nodehost.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val state: String,
    val priority: String,
    val createdAt: Long,
    val updatedAt: Long,
)
