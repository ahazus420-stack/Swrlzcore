package sh.swrlz.nodehost.data.entity
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
@Entity(tableName="group_join_requests", indices=[Index("groupId"),Index("nodeId")])
data class GroupJoinRequestEntity(@PrimaryKey val requestId:String,val groupId:String,val nodeId:String,val nodeLabel:String,val deviceType:String,val capabilities:String,val registrationState:String,val trustState:String,val proofState:String,val requestedAt:Long,val state:String="PENDING_APPROVAL",val decidedAt:Long?=null,val decidedBy:String?=null)
