package sh.swrlz.nodehost.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.entity.MissionEntity

@Dao
interface MissionEntityDao {
    @Query("SELECT * FROM missions ORDER BY updatedAt DESC")
    fun observeMissions(): Flow<List<MissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(mission: MissionEntity)
}
