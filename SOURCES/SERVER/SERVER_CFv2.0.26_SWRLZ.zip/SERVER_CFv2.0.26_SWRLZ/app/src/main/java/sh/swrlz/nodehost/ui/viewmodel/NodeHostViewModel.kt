package sh.swrlz.nodehost.ui.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.service.NodeService

@HiltViewModel
class NodeHostViewModel @Inject constructor(private val nodeService: NodeService) : ViewModel() {
    private val _uiState = mutableStateOf(NodeUiState())
    val uiState: State<NodeUiState> = _uiState

    fun startNode() {
        viewModelScope.launch {
            nodeService.start()
            _uiState.value = _uiState.value.copy(status = "Running")
        }
    }

    fun stopNode() {
        viewModelScope.launch {
            nodeService.stop()
            _uiState.value = _uiState.value.copy(status = "Stopped")
        }
    }
}

data class NodeUiState(val status: String = "Idle")
