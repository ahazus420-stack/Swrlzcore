package sh.swrlz.nodehost.data

import androidx.room.Database
import androidx.room.RoomDatabase
import sh.swrlz.nodehost.data.dao.NodeEntityDao
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.dao.MissionEntityDao
import sh.swrlz.nodehost.data.dao.GroupDao
import sh.swrlz.nodehost.data.entity.GroupEntity
import sh.swrlz.nodehost.data.entity.GroupMembershipEntity
import sh.swrlz.nodehost.data.entity.GroupInviteEntity
import sh.swrlz.nodehost.data.entity.GroupJoinRequestEntity

@Database(entities = [NodeEntity::class, MissionEntity::class, GroupEntity::class, GroupMembershipEntity::class, GroupInviteEntity::class, GroupJoinRequestEntity::class], version = 4, exportSchema = false)
abstract class NodeHostDatabase : RoomDatabase() {
    abstract fun nodeEntityDao(): NodeEntityDao
    abstract fun missionEntityDao(): MissionEntityDao
    abstract fun groupDao(): GroupDao
}
