package sh.swrlz.nodehost.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

data class ServerThemeTokens(
    val family: String,
    val variant: String,
    val background: Color,
    val surface: Color,
    val panel: Color,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val text: Color,
    val secondaryText: Color,
    val muted: Color,
)

object SwurlzerThemeCatalog {
    val families = listOf("Glitch Dragon Glass", "Original Core", "Glitch Neon", "Pharaoh Emerald", "Void Jester")
    val variants = listOf("Dark", "Sunlight", "Inverse")

    fun resolve(family: String, variant: String): ServerThemeTokens {
        val base = when (family) {
            "Original Core" -> ServerThemeTokens(family, "Dark", Color(0xFF050607), Color(0xFF090D10), Color(0xFF0D1216), Color(0xFF40EFFF), Color(0xFFFFD75A), Color(0xFFC95DFF), Color(0xFFF5F7FA), Color(0xFFD5DDE5), Color(0xFF8A969F))
            "Glitch Neon" -> ServerThemeTokens(family, "Dark", Color(0xFF02050A), Color(0xFF07121A), Color(0xFF0B1822), Color(0xFF38E8FF), Color(0xFF9A55FF), Color(0xFF4DFFB4), Color(0xFFF7FBFF), Color(0xFFD7E7F5), Color(0xFF91A9C0))
            "Pharaoh Emerald" -> ServerThemeTokens(family, "Dark", Color(0xFF020906), Color(0xFF06100D), Color(0xFF0C1A14), Color(0xFF00E6B0), Color(0xFFFFD166), Color(0xFFB66DFF), Color(0xFFF4FFF9), Color(0xFFD8F1E4), Color(0xFF83A694))
            "Void Jester" -> ServerThemeTokens(family, "Dark", Color(0xFF05000B), Color(0xFF0D0418), Color(0xFF190A2A), Color(0xFF9B5CFF), Color(0xFFFFC857), Color(0xFFFF3DDA), Color(0xFFFFF8FF), Color(0xFFE6D7FF), Color(0xFF9C86B8))
            else -> ServerThemeTokens("Glitch Dragon Glass", "Dark", Color(0xFF03030B), Color(0xFF081020), Color(0xFF0A1120), Color(0xFF38E8FF), Color(0xFF9A55FF), Color(0xFF4DFFB4), Color(0xFFF7FBFF), Color(0xFFD7E7F5), Color(0xFF91A9C0))
        }
        return when (variant) {
            "Sunlight" -> base.copy(variant = variant, background = Color.Black, surface = Color(0xFF050607), panel = Color(0xFF0A0D10), text = Color.White, secondaryText = Color(0xFFF0F3F5), muted = Color(0xFFC9D0D6))
            "Inverse" -> base.copy(variant = variant, background = Color(0xFFEAF3F5), surface = Color.White, panel = Color(0xFFE6EEF1), primary = Color(0xFF007D91), secondary = Color(0xFF9A6B00), tertiary = Color(0xFF7B2CBF), text = Color(0xFF061014), secondaryText = Color(0xFF17252B), muted = Color(0xFF53646E))
            else -> base
        }
    }
}

@Composable
fun SwrlzTheme(family: String = "Glitch Dragon Glass", variant: String = "Dark", content: @Composable () -> Unit) {
    val t = SwurlzerThemeCatalog.resolve(family, variant)
    val colors = if (variant == "Inverse") lightColorScheme(
        primary=t.primary, secondary=t.secondary, tertiary=t.tertiary, background=t.background,
        surface=t.surface, onPrimary=Color.White, onBackground=t.text, onSurface=t.text
    ) else darkColorScheme(
        primary=t.primary, secondary=t.secondary, tertiary=t.tertiary, background=t.background,
        surface=t.surface, onPrimary=Color.Black, onBackground=t.text, onSurface=t.text
    )
    MaterialTheme(colorScheme = colors, content = content)
}
