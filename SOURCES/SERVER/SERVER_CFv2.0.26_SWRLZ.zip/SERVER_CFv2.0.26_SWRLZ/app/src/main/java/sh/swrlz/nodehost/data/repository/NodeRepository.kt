package sh.swrlz.nodehost.data.repository

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.NodeHostDatabase
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.data.entity.*

class NodeRepository(private val db: NodeHostDatabase) {
    fun observeNodes(): Flow<List<NodeEntity>> = db.nodeEntityDao().observeNodes()

    suspend fun upsertNode(node: NodeEntity) = db.nodeEntityDao().upsert(node)

    suspend fun findNode(nodeId: String): NodeEntity? = db.nodeEntityDao().find(nodeId)
    suspend fun findByBinding(binding: String): NodeEntity? = db.nodeEntityDao().findByBinding(binding)
    suspend fun findByDeviceId(deviceId: String): NodeEntity? = db.nodeEntityDao().findByDeviceId(deviceId)
    suspend fun archiveDuplicates(deviceId: String, canonicalNodeId: String) = db.nodeEntityDao().archiveDuplicates(deviceId, canonicalNodeId)
    suspend fun archiveDuplicatesByBinding(binding: String, canonicalNodeId: String) =
        db.nodeEntityDao().archiveDuplicatesByBinding(binding, canonicalNodeId)

    /**
     * Serializes identity lookup, canonical-node selection, persistence, and duplicate
     * archival in one Room transaction so concurrent reinstall registrations cannot
     * create competing logical nodes.
     */
    suspend fun <T> inRegistrationTransaction(block: suspend NodeRepository.() -> T): T =
        db.withTransaction { block(this@NodeRepository) }

    suspend fun updatePresence(nodeId: String, state: String, lastSeen: Long, missionId: String? = null) =
        db.nodeEntityDao().updatePresence(nodeId, state, lastSeen, missionId)

    suspend fun markStaleOffline(cutoff: Long) = db.nodeEntityDao().markStaleOffline(cutoff)

    fun observeMissions(): Flow<List<MissionEntity>> = db.missionEntityDao().observeMissions()

    suspend fun upsertMission(mission: MissionEntity) = db.missionEntityDao().upsert(mission)

    fun observeGroups(): Flow<List<GroupEntity>> = db.groupDao().observeGroups()
    fun observeActiveMemberships(): Flow<List<GroupMembershipEntity>> = db.groupDao().observeActiveMemberships()
    fun observeActiveGroupCount(): Flow<Int> = db.groupDao().observeActiveCount()
    suspend fun findGroup(id:String)=db.groupDao().findGroup(id)
    suspend fun findGroupByName(name:String)=db.groupDao().findByName(name.trim().lowercase())
    suspend fun createGroup(group:GroupEntity)=db.groupDao().insertGroup(group)
    suspend fun upsertMembership(value:GroupMembershipEntity)=db.groupDao().upsertMembership(value)
    suspend fun members(groupId:String)=db.groupDao().members(groupId)
    suspend fun membership(groupId:String,nodeId:String)=db.groupDao().membership(groupId,nodeId)
    suspend fun activeMemberCount(groupId:String)=db.groupDao().activeMemberCount(groupId)
    suspend fun invalidateInvites(groupId:String)=db.groupDao().invalidateInvites(groupId)
    suspend fun upsertInvite(value:GroupInviteEntity)=db.groupDao().upsertInvite(value)
    suspend fun findInvite(hash:String)=db.groupDao().findInvite(hash)
    suspend fun upsertJoinRequest(value:GroupJoinRequestEntity)=db.groupDao().upsertJoinRequest(value)
    suspend fun findJoinRequest(id:String)=db.groupDao().findJoinRequest(id)
    suspend fun groupsForNode(nodeId:String)=db.groupDao().groupsForNode(nodeId)
}
