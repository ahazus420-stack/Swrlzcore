package sh.swrlz.nodehost.service

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class DiagnosticEntry(
    val sequence: Long,
    val timestampEpochMs: Long,
    val level: String,
    val category: String,
    val event: String,
    val detail: String? = null,
)

data class RuntimeDiagnosticSnapshot(
    val entries: List<DiagnosticEntry> = emptyList(),
    val totalRequests: Long = 0,
    val responses2xx: Long = 0,
    val responses4xx: Long = 0,
    val responses5xx: Long = 0,
    val lastRequestEpochMs: Long? = null,
)

class RuntimeDiagnostics(context: Context) {
    private val logFile = File(context.applicationContext.filesDir, "diagnostics/node_runtime.log")
    private val lock = Any()
    private val sequence = AtomicLong(0)
    private val _snapshot = MutableStateFlow(RuntimeDiagnosticSnapshot())
    val snapshot: StateFlow<RuntimeDiagnosticSnapshot> = _snapshot.asStateFlow()

    fun record(level: String, event: String, detail: String? = null, category: String = "RUNTIME") {
        val safeLevel = sanitize(level.uppercase(Locale.US), 12)
        val safeCategory = sanitize(category.uppercase(Locale.US), 16)
        val safeEvent = sanitize(event, 64)
        val safeDetail = detail?.let { sanitize(it, 240) }
        val now = System.currentTimeMillis()
        val entry = DiagnosticEntry(
            sequence = sequence.incrementAndGet(),
            timestampEpochMs = now,
            level = safeLevel,
            category = safeCategory,
            event = safeEvent,
            detail = safeDetail,
        )
        val timestamp = DATE_FORMAT.get().format(Date(now))
        val line = buildString {
            append(timestamp).append(' ').append(safeLevel).append(' ')
            append(safeCategory).append(' ').append(safeEvent)
            if (!safeDetail.isNullOrBlank()) append(" | ").append(safeDetail)
            append('\n')
        }
        synchronized(lock) {
            logFile.parentFile?.mkdirs()
            rotateIfNeeded(line.toByteArray().size)
            logFile.appendText(line, Charsets.UTF_8)
            val current = _snapshot.value
            _snapshot.value = current.copy(entries = (current.entries + entry).takeLast(MAX_ENTRIES))
        }
    }

    fun recordHttp(method: String, path: String, statusCode: Int, durationMs: Long, surface: String) {
        val level = when {
            statusCode >= 500 -> "ERROR"
            statusCode >= 400 -> "WARN"
            else -> "INFO"
        }
        val safeMethod = sanitize(method.uppercase(Locale.US), 12)
        val safePath = sanitize(path.substringBefore('?'), 160)
        record(level, "request", "$safeMethod $safePath -> $statusCode ${durationMs}ms surface=$surface", "HTTP")
        synchronized(lock) {
            val current = _snapshot.value
            _snapshot.value = current.copy(
                totalRequests = current.totalRequests + 1,
                responses2xx = current.responses2xx + if (statusCode in 200..299) 1 else 0,
                responses4xx = current.responses4xx + if (statusCode in 400..499) 1 else 0,
                responses5xx = current.responses5xx + if (statusCode >= 500) 1 else 0,
                lastRequestEpochMs = System.currentTimeMillis(),
            )
        }
    }

    fun clear() = synchronized(lock) {
        if (logFile.exists()) logFile.delete()
        _snapshot.value = RuntimeDiagnosticSnapshot()
    }

    fun readRecent(maxChars: Int = 16_384): String = synchronized(lock) {
        if (!logFile.exists()) return@synchronized ""
        val text = logFile.readText(Charsets.UTF_8)
        if (text.length <= maxChars) text else text.takeLast(maxChars)
    }

    private fun rotateIfNeeded(incomingBytes: Int) {
        if (logFile.exists() && logFile.length() + incomingBytes > MAX_BYTES) {
            val previous = File(logFile.parentFile, "node_runtime.previous.log")
            if (previous.exists()) previous.delete()
            logFile.renameTo(previous)
        }
    }

    private fun sanitize(value: String, maxLength: Int): String = value
        .replace(Regex("[\\r\\n\\t]+"), " ")
        .replace(Regex("(?i)(authorization|token|secret|password)=?[^ ]*"), "\$1=[REDACTED]")
        .trim()
        .take(maxLength)

    companion object {
        private const val MAX_BYTES = 128 * 1024L
        private const val MAX_ENTRIES = 250
        private val DATE_FORMAT = ThreadLocal.withInitial {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US)
        }
    }
}
