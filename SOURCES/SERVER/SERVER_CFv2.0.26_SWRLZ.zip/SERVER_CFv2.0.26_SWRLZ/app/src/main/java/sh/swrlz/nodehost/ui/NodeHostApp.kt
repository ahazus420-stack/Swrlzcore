package sh.swrlz.nodehost.ui

import android.Manifest
import android.os.Build
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel
import sh.swrlz.nodehost.ui.theme.SwrlzTheme
import sh.swrlz.nodehost.ui.theme.SwurlzerThemeCatalog

@Composable
fun NodeHostApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val viewModel: HostViewModel = hiltViewModel()
    val mode by SwurlzerUiPreferences.modeFlow(context).collectAsState(initial = SwurlzerInterfaceMode.User)
    val motionEnabled by SwurlzerUiPreferences.motionEnabledFlow(context).collectAsState(initial = true)
    val themeFamily by SwurlzerUiPreferences.themeFamilyFlow(context).collectAsState(initial = "Glitch Dragon Glass")
    val themeVariant by SwurlzerUiPreferences.themeVariantFlow(context).collectAsState(initial = "Dark")
    val setupComplete by SwurlzerUiPreferences.setupCompleteFlow(context).collectAsState(initial = false)
    val startOnLaunch by SwurlzerUiPreferences.startOnLaunchFlow(context).collectAsState(initial = true)

    fun switchMode(next: SwurlzerInterfaceMode) {
        scope.launch { SwurlzerUiPreferences.setMode(context, next) }
    }

    fun setMotion(enabled: Boolean) {
        scope.launch { SwurlzerUiPreferences.setMotionEnabled(context, enabled) }
    }

    LaunchedEffect(setupComplete, startOnLaunch) {
        if (setupComplete && startOnLaunch) viewModel.startNode()
    }

    val themeTokens = SwurlzerThemeCatalog.resolve(themeFamily, themeVariant)
    SwurlzerPalette.applyTheme(themeTokens)
    SwrlzTheme(themeFamily, themeVariant) {
        if (!setupComplete) {
            ServerFirstRunPermissions(
                startOnLaunch = startOnLaunch,
                onStartOnLaunchChanged = { enabled ->
                    scope.launch { SwurlzerUiPreferences.setStartOnLaunch(context, enabled) }
                },
                onComplete = {
                    scope.launch { SwurlzerUiPreferences.setSetupComplete(context, true) }
                },
            )
        } else {
            when (mode) {
                SwurlzerInterfaceMode.User -> SwurlzerUserScreen(
                    viewModel = viewModel,
                    motionEnabled = motionEnabled,
                    onMotionChanged = ::setMotion,
                    onOpenDeveloper = { switchMode(SwurlzerInterfaceMode.Developer) },
                )
                SwurlzerInterfaceMode.Developer -> HostScreen(
                    viewModel = viewModel,
                    motionEnabled = motionEnabled,
                    onOpenUserMode = { switchMode(SwurlzerInterfaceMode.User) },
                )
            }
        }
    }
}

@Composable
private fun ServerFirstRunPermissions(
    startOnLaunch: Boolean,
    onStartOnLaunchChanged: (Boolean) -> Unit,
    onComplete: () -> Unit,
) {
    val context = LocalContext.current
    var notificationGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notificationGranted = it
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
        ) {
            Text("SWRLZ SERVER SETUP", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text("Approve notification access so Android can display the required foreground-service status.")
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationGranted) {
                        launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                },
                enabled = !notificationGranted,
            ) {
                Text(if (notificationGranted) "NOTIFICATIONS ACCEPTED" else "ACCEPT ALL REQUIRED PERMISSIONS")
            }
            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Start server on launch")
                    Text("Enabled initially. You can change it later in Settings.", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = startOnLaunch, onCheckedChange = onStartOnLaunchChanged)
            }
            Spacer(Modifier.height(20.dp))
            Button(onClick = onComplete, enabled = notificationGranted) {
                Text("CONTINUE")
            }
        }
    }
}
