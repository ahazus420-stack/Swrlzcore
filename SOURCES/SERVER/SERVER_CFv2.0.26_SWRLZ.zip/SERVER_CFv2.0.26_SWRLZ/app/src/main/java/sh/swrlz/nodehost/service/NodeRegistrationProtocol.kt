package sh.swrlz.nodehost.service

import org.json.JSONObject
import sh.swrlz.nodehost.data.entity.NodeEntity

internal data class RegistrationDecision(val response: DiscoveryHttpResponse, val node: NodeEntity? = null)

/** Verification and persistence contract. Registration never grants mission trust. */
internal object NodeRegistrationProtocol {
    const val REGISTER_PATH = "/nodes/register"
    const val HEARTBEAT_PATH = "/nodes/heartbeat"
    const val INVENTORY_PATH = "/nodes"
    const val DISCONNECT_PATH = "/nodes/disconnect"
    const val HEARTBEAT_INTERVAL_MS = 10_000L
    const val DELAYED_AFTER_MS = 20_000L
    const val UNAVAILABLE_AFTER_MS = 40_000L
    const val DISCONNECTED_AFTER_MS = 60_000L

    fun handles(path: String): Boolean = path == REGISTER_PATH || path == HEARTBEAT_PATH || path == DISCONNECT_PATH || path == INVENTORY_PATH

    fun register(request: DiscoveryHttpRequest, now: Long, existing: NodeEntity?): RegistrationDecision {
        if (request.method != "POST") return error(405, "METHOD_NOT_ALLOWED", "POST required")
        val json = runCatching { JSONObject(request.body) }.getOrNull()
            ?: return error(400, "INVALID_JSON", "Registration body is invalid")

        val protocol = json.optInt("protocolVersion", 0)
        if (protocol !in 1..2) {
            return error(409, "PROTOCOL_INCOMPATIBLE", "Protocol version 1 or 2 required")
        }

        val candidateNodeId = json.optString("candidateNodeId")
            .ifBlank { json.optString("nodeId") }
            .trim()
        val installationId = json.optString("installationId").trim()
        val recoveryId = json.optString("deviceRecoveryId")
            .ifBlank { json.optString("deviceBindingFingerprint") }
            .trim()
        val legacyDeviceId = if (protocol == 1) json.optString("deviceId").trim() else ""
        val identitySchemaVersion = json.optInt("identitySchemaVersion", if (protocol == 1) 1 else 0)
        val label = json.optString("displayName", "SWRLZ CLIENT").take(96)
        val appVersion = json.optString("appVersion").take(64)

        if (!candidateNodeId.startsWith("client-") ||
            installationId.length !in 8..128 ||
            !recoveryId.matches(Regex("^[0-9a-f]{64}$")) ||
            identitySchemaVersion !in 1..2
        ) {
            return error(422, "IDENTITY_REJECTED", "Valid CLIENT recovery identity fields are required")
        }
        if (protocol == 1 && legacyDeviceId.length < 8) {
            return error(422, "IDENTITY_REJECTED", "Protocol 1 requires its legacy device identifier")
        }

        val proofPresented = request.headers["x-swrlz-device-proof"].orEmpty().length >= 16
        val isNewInstallation = existing != null && existing.installationId != installationId
        val recoveredExistingNode = existing != null &&
            (existing.deviceBindingFingerprint == recoveryId || existing.nodeId == candidateNodeId)

        val priorInstallations = runCatching {
            org.json.JSONArray(existing?.installationLineage ?: "[]")
        }.getOrElse { org.json.JSONArray() }
        val seen = (0 until priorInstallations.length())
            .map { priorInstallations.optString(it) }
            .filter { it.isNotBlank() }
            .toMutableSet()
        existing?.installationId?.takeIf { it.isNotBlank() }?.let(seen::add)
        seen += installationId

        val canonicalNodeId = existing?.nodeId?.takeIf { it.isNotBlank() } ?: candidateNodeId
        val trustRequiresReapproval = recoveredExistingNode && isNewInstallation && !proofPresented
        val node = NodeEntity(
            nodeId = canonicalNodeId,
            label = label,
            status = "CONNECTED",
            capabilities = json.optJSONArray("capabilities")?.toString() ?: "[]",
            trust = if (trustRequiresReapproval) "UNTRUSTED" else existing?.trust ?: "UNTRUSTED",
            lastSeen = now,
            // Protocol 2 deliberately does not persist raw ANDROID_ID.
            deviceId = legacyDeviceId.ifBlank { existing?.deviceId.orEmpty() },
            installationId = installationId,
            deviceBindingFingerprint = recoveryId,
            installationLineage = org.json.JSONArray(seen.toList().sorted()).toString(),
            installationCount = seen.size,
            deviceType = json.optString("deviceType", "android-client"),
            appVersion = appVersion,
            protocolVersion = protocol,
            firstRegisteredAt = existing?.firstRegisteredAt ?: now,
            registrationState = "REGISTERED",
            connectionState = "CONNECTED",
            identityState = if (recoveredExistingNode && isNewInstallation) "RECOVERED" else "CONFIRMED",
            proofState = when {
                trustRequiresReapproval -> "REAPPROVAL_REQUIRED"
                proofPresented -> "PRESENTED"
                else -> "PENDING"
            },
            currentMissionId = null,
            archived = false,
        )
        return RegistrationDecision(
            ok(
                code = if (recoveredExistingNode && isNewInstallation) "REINSTALLED_DEVICE_RECOVERED" else "REGISTERED",
                node = node,
                recoveredExistingNode = recoveredExistingNode && isNewInstallation,
                trustRequiresReapproval = trustRequiresReapproval,
            ),
            node,
        )
    }

    fun heartbeat(request: DiscoveryHttpRequest, now: Long, existing: NodeEntity?): RegistrationDecision {
        if (request.method != "POST") return error(405, "METHOD_NOT_ALLOWED", "POST required")
        val json = runCatching { JSONObject(request.body) }.getOrNull() ?: return error(400, "INVALID_JSON", "Heartbeat body is invalid")
        val nodeId = json.optString("nodeId")
        if (existing == null || existing.nodeId != nodeId) return error(404, "NOT_REGISTERED", "Register before heartbeat")
        if (existing.connectionState == "DISCONNECTED_ADMIN") {
            return error(409, "ADMIN_DISCONNECTED", "SERVER ended this session; manual reconnect approval is required")
        }
        val requested = json.optString("state", "CONNECTED").uppercase()
        val state = if (requested in setOf("CONNECTED","BUSY","CONNECTING","VERIFYING","REGISTERING")) requested else "CONNECTED"
        val missionId = json.optString("missionId").takeIf { it.isNotBlank() }
        return RegistrationDecision(ok("HEARTBEAT_ACCEPTED", existing.copy(status=state, connectionState=state, lastSeen=now, currentMissionId=missionId)), existing.copy(status=state, connectionState=state, lastSeen=now, currentMissionId=missionId))
    }

    fun disconnect(request: DiscoveryHttpRequest, now: Long, existing: NodeEntity?): RegistrationDecision {
        if (request.method != "POST") return error(405, "METHOD_NOT_ALLOWED", "POST required")
        val json = runCatching { JSONObject(request.body) }.getOrNull() ?: return error(400, "INVALID_JSON", "Disconnect body is invalid")
        val nodeId = json.optString("nodeId")
        if (existing == null || existing.nodeId != nodeId) return error(404, "NOT_REGISTERED", "Registered node not found")
        val reason = json.optString("reason", "USER_DISCONNECT").uppercase()
        val state = if (reason == "ADMIN_DISCONNECT") "DISCONNECTED_ADMIN" else "OFFLINE"
        val node = existing.copy(status=state, connectionState=state, lastSeen=now, currentMissionId=null)
        return RegistrationDecision(ok("DISCONNECTED", node), node)
    }

    fun inventory(nodes: List<NodeEntity>): DiscoveryHttpResponse {
        val body = nodes.joinToString(prefix="{\"ok\":true,\"nodes\":[", postfix="]}") { n ->
            "{\"nodeId\":\"${esc(n.nodeId)}\",\"label\":\"${esc(n.label)}\",\"state\":\"${esc(n.connectionState)}\",\"trust\":\"${esc(n.trust)}\",\"lastSeen\":${n.lastSeen}}"
        }
        return DiscoveryHttpResponse(200,"OK",body,mapOf("Cache-Control" to "no-store"))
    }

    private fun ok(
        code: String,
        node: NodeEntity,
        recoveredExistingNode: Boolean = false,
        trustRequiresReapproval: Boolean = false,
    ): DiscoveryHttpResponse {
        val now = System.currentTimeMillis()
        val sequence = now / HEARTBEAT_INTERVAL_MS
        val body = JSONObject()
            .put("ok", true)
            .put("code", code)
            .put("nodeId", node.nodeId)
            .put("registrationState", node.registrationState)
            .put("connectionState", node.connectionState)
            .put("trust", node.trust)
            .put("proofState", node.proofState)
            .put("recoveredExistingNode", recoveredExistingNode)
            .put("trustRequiresReapproval", trustRequiresReapproval)
            .put(
                "serverHeartbeat",
                JSONObject()
                    .put("authority", "SERVER")
                    .put("sequence", sequence)
                    .put("serverTimeEpochMs", now)
                    .put("intervalMs", HEARTBEAT_INTERVAL_MS)
                    .put("delayedAfterMs", DELAYED_AFTER_MS)
                    .put("unavailableAfterMs", UNAVAILABLE_AFTER_MS)
                    .put("disconnectedAfterMs", DISCONNECTED_AFTER_MS),
            )
            .toString()
        return DiscoveryHttpResponse(200, "OK", body, mapOf("Cache-Control" to "no-store"))
    }
    private fun error(status:Int, code:String, message:String)=RegistrationDecision(DiscoveryHttpResponse(status,"Error","{\"ok\":false,\"error\":{\"code\":\"$code\",\"message\":\"${esc(message)}\"}}",mapOf("Cache-Control" to "no-store")))
    private fun esc(v:String)=v.replace("\\","\\\\").replace("\"","\\\"")
}
