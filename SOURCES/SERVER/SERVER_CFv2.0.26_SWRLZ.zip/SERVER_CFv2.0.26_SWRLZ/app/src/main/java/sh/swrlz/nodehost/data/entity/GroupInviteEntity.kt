package sh.swrlz.nodehost.data.entity
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
@Entity(tableName="group_invites", indices=[Index("groupId"),Index(value=["codeHash"],unique=true)])
data class GroupInviteEntity(@PrimaryKey val inviteId:String,val groupId:String,val codeHash:String,val codeHint:String,val issuedByNodeId:String,val createdAt:Long,val expiresAt:Long,val maxUses:Int=1,val uses:Int=0,val active:Boolean=true,val generation:Int=1)
