package sh.swrlz.nodehost.service

enum class ListenerStatus {
    STOPPED,
    STARTING,
    RUNNING,
    UNAVAILABLE,
    FAILED,
}

data class ListenerHealth(
    val status: ListenerStatus = ListenerStatus.STOPPED,
    val detail: String? = null,
)

enum class RuntimeStatus {
    STOPPED,
    STARTING,
    RUNNING,
    DEGRADED,
    MAINTENANCE,
    RELOADING_CONFIGURATION,
    RESTARTING_SERVICES,
    SHUTTING_DOWN,
    FAILED,
}

data class RuntimeFailure(
    val timestampEpochMs: Long,
    val stage: String,
    val listener: String?,
    val errorType: String,
    val message: String,
)

data class NodeHealth(
    val runtimeStatus: RuntimeStatus = RuntimeStatus.STOPPED,
    val privateApi: ListenerHealth = ListenerHealth(),
    val discoveryLoopback: ListenerHealth = ListenerHealth(),
    val discoveryLan: ListenerHealth = ListenerHealth(),
    val lastFailure: RuntimeFailure? = null,
    val lastSuccessfulStartEpochMs: Long? = null,
    val shutdownStep: Int = 0,
    val lifecycleDetail: String? = null,
) {
    /** True whenever the runtime owns active or starting listener resources. */
    val runtimeActive: Boolean
        get() = runtimeStatus == RuntimeStatus.STARTING ||
            runtimeStatus == RuntimeStatus.RUNNING ||
            runtimeStatus == RuntimeStatus.DEGRADED ||
            runtimeStatus == RuntimeStatus.MAINTENANCE ||
            runtimeStatus == RuntimeStatus.RELOADING_CONFIGURATION ||
            runtimeStatus == RuntimeStatus.RESTARTING_SERVICES ||
            runtimeStatus == RuntimeStatus.SHUTTING_DOWN

    /** Operator-facing reason that preserves the health classification and explains reduced service. */
    val operatorReason: String
        get() = when {
            privateApi.status == ListenerStatus.FAILED ->
                "PRIVATE API FAILED · ${privateApi.detail ?: "loopback listener unavailable"}"
            privateApi.status == ListenerStatus.UNAVAILABLE ->
                "PRIVATE API UNAVAILABLE · Authoritative operational routes remain separately reported"
            runtimeStatus == RuntimeStatus.DEGRADED && discoveryLan.status == ListenerStatus.UNAVAILABLE ->
                "LOCAL-ONLY · No approved Wi-Fi or LAN interface; loopback remains active"
            runtimeStatus == RuntimeStatus.DEGRADED && discoveryLan.status == ListenerStatus.FAILED ->
                "LAN LISTENER FAILED · Local loopback service remains active"
            runtimeStatus == RuntimeStatus.FAILED ->
                lastFailure?.let { "${it.stage} · ${it.errorType}: ${it.message}" } ?: "Runtime failed"
            else -> summary
        }

    val summary: String
        get() = when (runtimeStatus) {
            RuntimeStatus.STOPPED -> "Node stopped"
            RuntimeStatus.STARTING -> "Node starting"
            RuntimeStatus.RUNNING -> "Node running"
            RuntimeStatus.DEGRADED -> "Node degraded"
            RuntimeStatus.MAINTENANCE -> "Maintenance mode"
            RuntimeStatus.RELOADING_CONFIGURATION -> "Reloading configuration"
            RuntimeStatus.RESTARTING_SERVICES -> "Restarting services"
            RuntimeStatus.SHUTTING_DOWN -> "Shutdown sequence ${shutdownStep.coerceIn(1,10)}/10"
            RuntimeStatus.FAILED -> "Node failed"
        }
}

internal enum class ListenerKind(val wireName: String) {
    PRIVATE_API("private_api"),
    DISCOVERY_LOOPBACK("discovery_loopback"),
    DISCOVERY_LAN("discovery_lan"),
}

/**
 * Produces the truthful terminal snapshot after all startup resources have been closed.
 * No listener may remain STARTING or RUNNING after this mapper is used.
 */
internal fun terminalStartupFailureHealth(
    previous: NodeHealth,
    stage: String,
    failure: RuntimeFailure,
): NodeHealth {
    val stopped = ListenerHealth(ListenerStatus.STOPPED, "Closed during failed startup")
    val failed = ListenerHealth(ListenerStatus.FAILED, failure.message)
    return previous.copy(
        runtimeStatus = RuntimeStatus.FAILED,
        privateApi = if (stage == "private_8080") failed else stopped,
        discoveryLoopback = if (stage == "discovery_8787") failed else stopped,
        discoveryLan = stopped,
        lastFailure = failure,
    )
}

/** Updates health after a listener loop exits while the runtime still intends to run. */
internal fun unexpectedListenerExitHealth(
    previous: NodeHealth,
    listener: ListenerKind,
    failure: RuntimeFailure,
): NodeHealth {
    val failed = ListenerHealth(ListenerStatus.FAILED, failure.message)
    return when (listener) {
        ListenerKind.PRIVATE_API -> previous.copy(
            runtimeStatus = RuntimeStatus.FAILED,
            privateApi = failed,
            lastFailure = failure,
        )
        ListenerKind.DISCOVERY_LOOPBACK -> previous.copy(
            runtimeStatus = RuntimeStatus.FAILED,
            discoveryLoopback = failed,
            lastFailure = failure,
        )
        ListenerKind.DISCOVERY_LAN -> previous.copy(
            runtimeStatus = RuntimeStatus.DEGRADED,
            discoveryLan = failed,
            lastFailure = failure,
        )
    }
}
