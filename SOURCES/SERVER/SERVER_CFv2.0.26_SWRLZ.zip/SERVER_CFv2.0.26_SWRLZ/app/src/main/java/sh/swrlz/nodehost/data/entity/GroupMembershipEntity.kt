package sh.swrlz.nodehost.data.entity
import androidx.room.Entity
import androidx.room.Index
@Entity(tableName="group_memberships", primaryKeys=["groupId","nodeId"], indices=[Index("nodeId")])
data class GroupMembershipEntity(val groupId:String,val nodeId:String,val role:String="MEMBER",val membershipState:String="PENDING_APPROVAL",val joinedAt:Long=0,val approvedAt:Long?=null,val approvedBy:String?=null)
