package sh.swrlz.nodehost.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

@Singleton
class NodeService @Inject constructor(@ApplicationContext private val context: Context, private val runtime: NodeRuntime) {
    private val lifecycleScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun start() {
        ContextCompat.startForegroundService(context, Intent(context, NodeHostService::class.java))
    }

    fun stop() {
        lifecycleScope.launch {
            runtime.beginShutdownSequence()
            context.stopService(Intent(context, NodeHostService::class.java))
        }
    }
    fun enterMaintenance() { lifecycleScope.launch { runtime.enterMaintenance() } }
    fun reloadConfiguration() { lifecycleScope.launch { runtime.reloadConfiguration() } }
    fun restartServices() { lifecycleScope.launch { runtime.restartServices() } }

}
