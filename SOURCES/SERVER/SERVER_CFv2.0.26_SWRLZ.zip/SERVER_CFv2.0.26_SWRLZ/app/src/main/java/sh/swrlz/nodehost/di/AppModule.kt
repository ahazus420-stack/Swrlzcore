package sh.swrlz.nodehost.di

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import sh.swrlz.nodehost.data.NodeHostDatabase
import sh.swrlz.nodehost.data.repository.NodeRepository
import sh.swrlz.nodehost.service.NodeRuntime

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NodeHostDatabase {
        return Room.databaseBuilder(context, NodeHostDatabase::class.java, "swrlz_node_host.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
            .build()
    }

    @Provides
    @Singleton
    fun provideRepository(database: NodeHostDatabase): NodeRepository = NodeRepository(database)

    @Provides
    @Singleton
    fun provideNodeRuntime(@ApplicationContext context: Context, repository: NodeRepository): NodeRuntime = NodeRuntime(context, repository)


    private val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS node_groups (groupId TEXT NOT NULL PRIMARY KEY, displayName TEXT NOT NULL, normalizedName TEXT NOT NULL, leaderNodeId TEXT NOT NULL, status TEXT NOT NULL, createdAt INTEGER NOT NULL, updatedAt INTEGER NOT NULL)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_node_groups_normalizedName ON node_groups(normalizedName)")
            db.execSQL("CREATE TABLE IF NOT EXISTS group_memberships (groupId TEXT NOT NULL, nodeId TEXT NOT NULL, role TEXT NOT NULL, membershipState TEXT NOT NULL, joinedAt INTEGER NOT NULL, approvedAt INTEGER, approvedBy TEXT, PRIMARY KEY(groupId,nodeId))")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_group_memberships_nodeId ON group_memberships(nodeId)")
            db.execSQL("CREATE TABLE IF NOT EXISTS group_invites (inviteId TEXT NOT NULL PRIMARY KEY, groupId TEXT NOT NULL, codeHash TEXT NOT NULL, codeHint TEXT NOT NULL, issuedByNodeId TEXT NOT NULL, createdAt INTEGER NOT NULL, expiresAt INTEGER NOT NULL, maxUses INTEGER NOT NULL, uses INTEGER NOT NULL, active INTEGER NOT NULL, generation INTEGER NOT NULL)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_group_invites_groupId ON group_invites(groupId)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_group_invites_codeHash ON group_invites(codeHash)")
            db.execSQL("CREATE TABLE IF NOT EXISTS group_join_requests (requestId TEXT NOT NULL PRIMARY KEY, groupId TEXT NOT NULL, nodeId TEXT NOT NULL, nodeLabel TEXT NOT NULL, deviceType TEXT NOT NULL, capabilities TEXT NOT NULL, registrationState TEXT NOT NULL, trustState TEXT NOT NULL, proofState TEXT NOT NULL, requestedAt INTEGER NOT NULL, state TEXT NOT NULL, decidedAt INTEGER, decidedBy TEXT)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_group_join_requests_groupId ON group_join_requests(groupId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_group_join_requests_nodeId ON group_join_requests(nodeId)")
        }
    }

    private val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE nodes ADD COLUMN deviceBindingFingerprint TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN installationLineage TEXT NOT NULL DEFAULT '[]'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN installationCount INTEGER NOT NULL DEFAULT 1")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_nodes_deviceBindingFingerprint ON nodes(deviceBindingFingerprint)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_nodes_deviceId ON nodes(deviceId)")
        }
    }

    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE nodes ADD COLUMN deviceId TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN installationId TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN deviceType TEXT NOT NULL DEFAULT 'android-client'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN appVersion TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE nodes ADD COLUMN protocolVersion INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE nodes ADD COLUMN firstRegisteredAt INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE nodes ADD COLUMN registrationState TEXT NOT NULL DEFAULT 'REGISTERED'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN connectionState TEXT NOT NULL DEFAULT 'OFFLINE'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN identityState TEXT NOT NULL DEFAULT 'CONFIRMED'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN proofState TEXT NOT NULL DEFAULT 'PENDING'")
            db.execSQL("ALTER TABLE nodes ADD COLUMN currentMissionId TEXT")
            db.execSQL("ALTER TABLE nodes ADD COLUMN archived INTEGER NOT NULL DEFAULT 0")
            db.execSQL("UPDATE nodes SET firstRegisteredAt = lastSeen WHERE firstRegisteredAt = 0")
        }
    }
}
