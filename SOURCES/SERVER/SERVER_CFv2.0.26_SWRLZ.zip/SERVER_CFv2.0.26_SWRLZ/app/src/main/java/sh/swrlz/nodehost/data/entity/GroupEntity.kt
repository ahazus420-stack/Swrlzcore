package sh.swrlz.nodehost.data.entity
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
@Entity(tableName="node_groups", indices=[Index(value=["normalizedName"], unique=true)])
data class GroupEntity(@PrimaryKey val groupId:String, val displayName:String, val normalizedName:String, val leaderNodeId:String, val status:String="ACTIVE", val createdAt:Long, val updatedAt:Long)
