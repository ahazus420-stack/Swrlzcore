# INT-BUILD-020A SERVER Source Resolution

Baseline: SERVER CFv2.0.9
Target: SERVER CFv2.0.10

## Purpose

Provide a new unambiguous canonical source package with an exact same-basename checksum pair for the SWRLZ APK Router.

## Required repository pair

- `SERVER_CFv2.0.10_SWRLZ.zip`
- `SERVER_CFv2.0.10_SWRLZ.sha256`

The checksum file must contain the SHA-256 digest followed by the exact ZIP filename above.

## Scope

No runtime, protocol, trust, identity, Room-schema, or UI behavior was changed. Only component version identity and source-resolution documentation were advanced.
