# API

The NODE_HOST exposes two deliberately separate local surfaces.

## Private same-device runtime

Bound only to loopback:

```text
127.0.0.1:8080
```

- `GET /status` — returns the existing embedded-node status payload.
- `GET /health` — returns the existing `healthy` payload.

This compatibility surface remains unchanged and is not used for discovery.

## Local-link discovery

Protocol: `SWRLZ-DISCOVERY-IDENTITY-001`, protocol version `1`, schema version `1`.

The listener is active only while the user-visible NODE_HOST runtime is running. It binds IPv4 loopback plus explicitly approved active LAN interfaces on:

```text
TCP 8787
```

It does not use a wildcard `0.0.0.0` bind. Known cellular, VPN, PPP, WireGuard, and tunnel interfaces are excluded by default.

### `GET /discovery/signature`

Required request characteristics:

- method: `GET`;
- no request body;
- `Accept` must permit `application/json`;
- authentication and pairing are not required for this read-only endpoint.

Successful response:

```http
HTTP/1.1 200 OK
Content-Type: application/json; charset=utf-8
Cache-Control: no-store
```

```json
{
  "ok": true,
  "service": "swrlz-local-node",
  "endpoint": "discovery-signature",
  "protocolVersion": 1,
  "schemaVersion": 1,
  "nodeId": "swrlz-node-<uuid-v4>",
  "installationId": "swrlz-install-<uuid-v4>",
  "displayName": "SWRLZ Node Host",
  "hostVersion": "<installed-version-name>",
  "port": 8787,
  "capabilities": ["discovery"],
  "trust": {
    "policy": "pairing_required",
    "missionAuthorization": "trusted_only"
  }
}
```

Discovery identifies a candidate node. It does not establish trust, authorize missions, expose credentials, or mutate identity.


## CLIENT dashboard compatibility routes

The local-link listener on TCP `8787` also exposes a bounded read-only
compatibility surface for the SWRLZ CLIENT network dashboard. These paths are
handled by `NodeCompatibilityProtocol` and report only state the Android
NODE_HOST can prove locally:

| Route | Successful result |
|---|---|
| `GET /status` | Durable node/installation identity, installed version, runtime phase, listener health, and current local/LAN URLs |
| `GET /presence/summary` | Authoritative empty counts and arrays until a separately accepted persistent presence registry exists |
| `GET /presence/groups` | `groups: []` and `count: 0` |
| `GET /presence/devices` | `devices: []`, `count: 0`, and `online_count: 0` |

Compatibility responses use protocol version `1` and schema version `1`, are
marked `Cache-Control: no-store`, and preserve the existing
`GET /discovery/signature` contract. Empty presence is a successful truthful
state; no demo rows, synthetic devices, groups, trust, pairing, or mission
authority are introduced.

If durable identity or the installed version is unavailable or invalid, the
compatibility surface fails closed with `503` rather than emitting a partial
success payload. Wrong methods return `405`, request bodies return `400`, and
an `Accept` header that excludes JSON returns `406`.

### Errors

All discovery-route errors use JSON and include protocol/schema versions.

| Condition | Status | Required behavior |
|---|---:|---|
| Unknown route | `404` | JSON `NOT_FOUND` error |
| Method other than `GET` | `405` | `Allow: GET` |
| Request body present or malformed request | `400` | Fail closed |
| JSON not accepted | `406` | JSON `JSON_REQUIRED` error |
| Durable identity or host version unavailable | `503` | Never emit a partial success payload |
| Unexpected internal failure | `500` | Bounded generic error; no secrets |
