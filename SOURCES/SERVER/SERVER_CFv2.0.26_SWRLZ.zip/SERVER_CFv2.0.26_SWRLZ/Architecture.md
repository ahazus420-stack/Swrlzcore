# Architecture

## Layers

- UI: Jetpack Compose screens under `app/src/main/java/sh/swrlz/nodehost/ui`.
- Domain/runtime: `NodeRuntime`, `NodeHostService`, ViewModels, and the discovery protocol boundary.
- Identity: `NodeIdentityStore`, independent from Room node and mission data.
- Data: Room entities, DAOs, repository, and local database.
- Platform: Android manifest, foreground service, notifications, and resources.

## Runtime model

`NodeRuntime` starts and stops both HTTP planes as one user-visible runtime lifecycle:

1. **Private compatibility plane** — loopback port `8080`, preserving `/status` and `/health`.
2. **Discovery plane** — IPv4 port `8787`, exposing only `GET /discovery/signature` on loopback and explicitly approved local-link interfaces.

The discovery plane never performs a wildcard bind. Interface selection is fail-closed:

- allowlisted local families include Wi-Fi, hotspot, Ethernet, USB/RNDIS, and Bluetooth PAN naming patterns;
- known cellular, VPN, tunnel, PPP, IPsec, and WireGuard naming patterns are rejected;
- only IPv4 site-local or link-local addresses are selected;
- IPv4 loopback must bind successfully before the discovery listener is considered available.

No public-internet or remote-node mode is introduced.

## Persistent NODE_HOST identity

`NodeIdentityStore` owns two UUIDv4-derived identifiers:

- `nodeId`: `swrlz-node-<uuid-v4>` — logical NODE_HOST identity;
- `installationId`: `swrlz-install-<uuid-v4>` — current app installation/data instance.

The store uses an `AtomicFile` in `noBackupFilesDir` so identity is:

- independent from Room, demo nodes, missions, and destructive Room migration;
- stable across process death, stop/start, reboot, and ordinary app updates;
- removed by application-data clearing or uninstall/reinstall;
- protected from partial writes by atomic replacement and durable read-back verification;
- not silently cloned through ordinary Android backup.

An explicit future node-identity rotation can change only `nodeId`, preserve `installationId`, and retain the previous node ID as a local lineage receipt. No rotation UI or trust migration is added in this checkpoint.

## Protocol boundary

`DiscoveryProtocol` is the single serializer and validation authority for protocol version `1` and schema version `1`. It:

- enforces the exact route, method, body, and `Accept` contract;
- emits the legacy CLIENT sentinel strings inside structured JSON;
- advertises only the implemented `discovery` capability;
- advertises `pairing_required` and `trusted_only` policy without claiming established trust;
- returns bounded JSON errors and never exposes secrets.


## CLIENT compatibility boundary

`NodeCompatibilityProtocol` is a second read-only serializer on the existing
8787 listener. `NodeRuntime` delegates only `/status`, `/presence/summary`,
`/presence/groups`, and `/presence/devices` to it; all other discovery requests
continue through `DiscoveryProtocol`, including `/discovery/signature`.

The compatibility layer consumes an immutable snapshot of the already-observed
runtime and durable identity. It does not query or reclassify demo Room rows,
create presence records, establish trust, pair devices, authorize missions, or
claim remote state. Until a separately accepted persistent presence registry
exists, presence responses are authoritative-empty.

## Offline-first and trust preservation

All implementation is local and requires no cloud dependency. Discovery remains identification-only. Pairing, cryptographic proof, trust establishment, revocation, mission submission, and mission execution remain separate future contracts.

Room continues to persist known nodes and missions. NODE_HOST self-identity is intentionally outside that database so Seed Demo Data and database migration cannot alter it.
