# Build Instructions

1. Open the project folder in Android Studio.
2. Let Gradle sync complete.
3. Build the Debug APK or run the app on a device/emulator.

If building from the command line:

```bash
./gradlew :app:assembleDebug
```
