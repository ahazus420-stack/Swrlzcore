from pathlib import Path
r=Path(__file__).resolve().parent
reg=(r/'app/src/main/java/sh/swrlz/nodehost/service/NodeRegistrationProtocol.kt').read_text()
ent=(r/'app/src/main/java/sh/swrlz/nodehost/data/entity/NodeEntity.kt').read_text()
dao=(r/'app/src/main/java/sh/swrlz/nodehost/data/dao/NodeEntityDao.kt').read_text()
db=(r/'app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt').read_text()
mig=(r/'app/src/main/java/sh/swrlz/nodehost/di/AppModule.kt').read_text()
runtime=(r/'app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt').read_text()
gradle=(r/'app/build.gradle.kts').read_text()
checks={
 'disconnect route':'/nodes/disconnect' in reg,
 'binding and lineage':'deviceBindingFingerprint' in ent and 'installationLineage' in ent,
 'duplicate reconciliation':'findByBinding' in dao and 'archiveDuplicates' in dao,
 'room v3':'version = 3' in db and 'MIGRATION_2_3' in mig,
 'registry diagnostics':'registry_loaded' in runtime and 'schema=3' in runtime,
 'version':'versionCode = 14' in gradle and 'versionName = "2.0.11"' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
raise SystemExit(0 if all(checks.values()) else 1)
