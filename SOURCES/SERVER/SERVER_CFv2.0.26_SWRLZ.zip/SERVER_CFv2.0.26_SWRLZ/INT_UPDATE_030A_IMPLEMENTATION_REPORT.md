# SERVER CFv2.0.21 Implementation Report

## Scope

- Increased `versionCode` from 22 to 23.
- Updated version name to `2.0.21-update-and-onboarding`.
- Added stable SWRLZ signing configuration matching the client convention.
- Added first-run notification-permission setup.
- Added `Start server on launch`, defaulting to enabled.
- Starts the foreground server automatically after setup when the toggle is enabled.
- Exposed the same launch toggle in the server Settings tab.

## Verification

Static source checks completed. A full Gradle build was not executed in this environment.
CI should run `./gradlew test assembleDebug` with the stable SWRLZ signing variables configured.
