# INT-IMP-010E — Terminal-State Truth Corrections

## Scope

This bounded checkpoint corrects only the findings accepted in INT-VER-010D.

## Implemented

- Startup failure cleanup now maps every listener to a terminal state.
- A private listener closed after discovery startup failure is reported `STOPPED`, never `RUNNING`.
- Identity/version failures leave no listener in `STARTING`.
- Listener loops report unexpected termination while runtime intent remains active.
- Unexpected private or loopback termination produces aggregate `FAILED` health.
- Unexpected LAN termination produces aggregate `DEGRADED` health.
- Intended shutdown does not produce a false listener failure.
- Runtime tests are now pure JVM state-transition tests and no longer depend on `ApplicationProvider`.
- `android:allowBackup` is disabled to avoid restoring node-host state without an explicit lineage-safe backup contract.

## Preserved

- Discovery protocol and schema version 1.
- Port and route contract.
- Approved-interface policy.
- Durable identity implementation.
- Offline-first and local-only runtime behavior.

## Not performed

- APK build or installation.
- GitHub commit, push, workflow, release, or deployment.
- CLIENT changes.
- Protocol or trust expansion.
