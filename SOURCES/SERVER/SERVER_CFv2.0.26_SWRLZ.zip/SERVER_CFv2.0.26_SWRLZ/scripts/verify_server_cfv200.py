#!/usr/bin/env python3
"""Static SERVER CFv2.0.0 / Swurlzer UI checkpoint guard. Does not build or open sockets."""

import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app/src/main"
UI = APP / "java/sh/swrlz/nodehost/ui"
BUILD = ROOT / "app/build.gradle.kts"
MANIFEST = APP / "AndroidManifest.xml"
ICON_MASTER = ROOT / "branding/SWURLZER_GLITCH_DRAGON_ICON_MASTER_4096.png"
ICON_FOREGROUND = APP / "res/drawable-nodpi/ic_launcher_adaptive_foreground.png"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()[:24]
    require(data[:8] == b"\x89PNG\r\n\x1a\n", f"not a PNG: {path}")
    return struct.unpack(">II", data[16:24])


def main() -> int:
    build = BUILD.read_text(encoding="utf-8")
    manifest = MANIFEST.read_text(encoding="utf-8")
    app = (UI / "NodeHostApp.kt").read_text(encoding="utf-8")
    user = (UI / "SwurlzerUserScreen.kt").read_text(encoding="utf-8")
    dev = (UI / "HostScreen.kt").read_text(encoding="utf-8")
    visuals = (UI / "SwurlzerVisuals.kt").read_text(encoding="utf-8")
    prefs = (UI / "SwurlzerUiPreferences.kt").read_text(encoding="utf-8")

    require("versionCode = 3" in build, "SERVER versionCode 3 missing")
    require('versionName = "2.0.0"' in build, "SERVER versionName 2.0.0 missing")
    require('android:label="SWRLZ Swurlzer"' in manifest, "Swurlzer application label missing")

    for marker in (
        "SwurlzerInterfaceMode.User",
        "SwurlzerInterfaceMode.Developer",
        "SwurlzerUserScreen(",
        "HostScreen(",
    ):
        require(marker in app, f"dual-mode marker missing: {marker}")
    require("?: User" in prefs, "fresh-install User Mode default missing")
    require('preferencesDataStore(name = "swurlzer_ui")' in prefs, "separate UI preference store missing")
    require('booleanPreferencesKey("motion_enabled")' in prefs, "persistent motion preference missing")

    for marker in (
        "START SWURLZER",
        "STOP SWURLZER",
        "SWITCH TO SWURLZER DEV MODE",
        "Private API · loopback 8080",
        "Discovery · loopback 8787",
        "CLIENT approval and Truth Firewall gates remain authoritative",
        "it is not promoted into a live connection claim",
        "this surface does not grant approval or execution authority",
        "No remote-node mode is added",
    ):
        require(marker in user, f"truthful User Mode marker missing: {marker}")

    for marker in (
        "START NODE", "STOP NODE", "SEED DEMO DATA", "Runtime Health",
        "Known Nodes", "Missions", "Live Runtime Console", "CLEAR",
        'listOf("ALL", "INFO", "WARN", "ERROR", "HTTP", "RUNTIME")',
        "SWURLZER DEV MODE", "USER MODE",
    ):
        require(marker in dev, f"legacy Dev Mode control missing: {marker}")

    for marker in (
        "LifecycleEventObserver",
        "if (motionEnabled && foreground)",
        "AnimatedSwurlzerScene",
        "SwurlzerScene",
        "SwurlzerEnergySignal",
        "contentDescription = null",
    ):
        require(marker in visuals, f"motion/performance safeguard missing: {marker}")

    sensitive_log = re.compile(r"\bLog\.[A-Za-z]+\([^\n]*(token|password|secret|pairing)", re.IGNORECASE)
    for path in (UI / "NodeHostApp.kt", UI / "SwurlzerUserScreen.kt", UI / "HostScreen.kt", UI / "SwurlzerVisuals.kt"):
        require(not sensitive_log.search(path.read_text(encoding="utf-8")), f"sensitive UI log pattern found: {path}")

    require(png_size(ICON_MASTER) == (4096, 4096), "Swurlzer 4K icon master dimensions changed")
    require(png_size(ICON_FOREGROUND) == (432, 432), "Swurlzer adaptive foreground dimensions changed")
    for density, size in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
        for name in ("ic_launcher.png", "ic_launcher_round.png"):
            path = APP / f"res/mipmap-{density}/{name}"
            require(png_size(path) == (size, size), f"launcher size mismatch: {path}")

    print("SERVER CFv2.0.0 / SWURLZER STATIC VERIFY PASS")
    print("default User Mode and switchable upgraded legacy Dev Mode present")
    print("truth-model labels, reduced-motion fallback, and lifecycle pause markers present")
    print("4096x4096 Swurlzer icon master plus adaptive/density launcher resources present")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"SERVER CFv2.0.0 STATIC VERIFY FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
