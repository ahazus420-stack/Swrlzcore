#!/usr/bin/env python3
"""Static verifier for the SERVER CFv2.0.3 SWURLZER source checkpoint.

This verifier intentionally does not invoke Gradle, build an APK, or contact GitHub.
"""

from __future__ import annotations

import hashlib
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []

PROTECTED_SHA256 = {
    "app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt":
        "f5c034f498173a0a2152bed708f67d8cb6c1ae193289d0b828d6e609814ebdb5",
    "app/src/main/java/sh/swrlz/nodehost/data/entity/NodeEntity.kt":
        "b27f866866ee1725353f8e26ce671a45fc1d8c928b1ab941715da71040173f36",
    "app/src/main/java/sh/swrlz/nodehost/service/DiscoveryProtocol.kt":
        "36c248b3d2ad5cee53d8a048607b41aa3fea32ae9578afbe5773ae06cee21a97",
    "app/src/main/java/sh/swrlz/nodehost/service/NodeCompatibilityProtocol.kt":
        "43325599ffa1fb97cf7c508b5eef600aad5e4247cdcf384924e655867754c319",
    "app/src/main/java/sh/swrlz/nodehost/service/NodeRuntime.kt":
        "e840908f19f6801ab85306fa4ff410efccdc75b3746a4b885acbcab46c594572",
    "app/src/main/java/sh/swrlz/nodehost/security/ProofBindingSidecar.kt":
        "f7196774ddb3b019cfabd4a89338b3b33dc92e961bf41e6fe70b988509753ba7",
    "app/src/main/java/sh/swrlz/nodehost/security/RequestProofVerifier.kt":
        "5c8dff3a85b0dd65c3b2bb874d479f3a56d2ab9fb79fb083ebeaf21a95b38767",
}

UNCHANGED_VISUAL_RESOURCE_SHA256 = {
    "branding/SWURLZER_GLITCH_DRAGON_ICON_MASTER_4096.png":
        "de069cda3c4cdf1c6ebef1021364ef4ca5c1fed7241832027cc1879f697ebf3e",
    "app/src/main/res/drawable-nodpi/glitch_dragon_swurlzer.jpg":
        "bd75868cf076a712471aeabffde584c262e0e6244c68a5d529a0856457319e17",
    "app/src/main/res/drawable-nodpi/ic_launcher_adaptive_foreground.png":
        "9361c4b8733fbf384ebc156a37b8d8b9c8dbe9394a9866af9cfe71c4bdd1f81d",
    "app/src/main/res/drawable/ic_launcher_foreground.xml":
        "16a7373bea332b54dc4d89cce70c14f6b23bd9946e4eddb0aafcbfb596b48b08",
}

HOST = "app/src/main/java/sh/swrlz/nodehost/ui/HostScreen.kt"
USER = "app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt"
VISUALS = "app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerVisuals.kt"


def fail(message: str) -> None:
    ERRORS.append(message)


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        fail(f"missing required file: {relative}")
        return ""
    return path.read_text(encoding="utf-8")


def digest(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        fail(f"missing protected file: {relative}")
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(text: str, needle: str, context: str) -> None:
    if needle not in text:
        fail(f"{context}: missing {needle!r}")


def reject(text: str, needle: str, context: str) -> None:
    if needle in text:
        fail(f"{context}: forbidden {needle!r}")


def check_xml() -> None:
    for path in sorted((ROOT / "app/src/main/res").rglob("*.xml")) + [
        ROOT / "app/src/main/AndroidManifest.xml"
    ]:
        try:
            ET.parse(path)
        except (ET.ParseError, OSError) as exc:
            fail(f"invalid XML {path.relative_to(ROOT)}: {exc}")


def check_duplicate_value_resources() -> None:
    for values_dir in sorted((ROOT / "app/src/main/res").glob("values*")):
        seen: set[tuple[str, str]] = set()
        for xml_path in sorted(values_dir.glob("*.xml")):
            try:
                xml_root = ET.parse(xml_path).getroot()
            except (ET.ParseError, OSError):
                continue
            for element in xml_root:
                name = element.attrib.get("name")
                if not name:
                    continue
                resource_type = element.tag if element.tag != "item" else element.attrib.get("type", "item")
                key = (resource_type, name)
                if key in seen:
                    fail(f"duplicate resource in {values_dir.name}: {resource_type}/{name}")
                seen.add(key)


def check_no_packaged_outputs() -> None:
    forbidden_names = {"local.properties"}
    forbidden_suffixes = {".apk", ".aab", ".jks", ".keystore"}
    forbidden_parts = {".gradle", ".idea", "build"}
    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT)
        if path.name in forbidden_names or path.suffix.lower() in forbidden_suffixes:
            fail(f"forbidden packaged output/configuration: {relative}")
        if any(part in forbidden_parts for part in relative.parts):
            fail(f"forbidden cache/build path: {relative}")


def check_kotlin_delimiters() -> None:
    pairs = {")": "(", "]": "[", "}": "{"}
    opening = set(pairs.values())
    for path in sorted((ROOT / "app/src/main/java").rglob("*.kt")):
        source = path.read_text(encoding="utf-8")
        stack: list[tuple[str, int]] = []
        index = 0
        line = 1
        while index < len(source):
            char = source[index]
            next_char = source[index + 1] if index + 1 < len(source) else ""
            if char == "\n":
                line += 1
                index += 1
                continue
            if char == "/" and next_char == "/":
                end = source.find("\n", index + 2)
                index = len(source) if end < 0 else end
                continue
            if char == "/" and next_char == "*":
                end = source.find("*/", index + 2)
                if end < 0:
                    fail(f"unterminated block comment: {path.relative_to(ROOT)}:{line}")
                    break
                line += source[index:end + 2].count("\n")
                index = end + 2
                continue
            if source.startswith('"""', index):
                end = source.find('"""', index + 3)
                if end < 0:
                    fail(f"unterminated raw string: {path.relative_to(ROOT)}:{line}")
                    break
                line += source[index:end + 3].count("\n")
                index = end + 3
                continue
            if char in {'"', "'"}:
                quote = char
                index += 1
                while index < len(source):
                    if source[index] == "\n":
                        line += 1
                    if source[index] == "\\":
                        index += 2
                        continue
                    if source[index] == quote:
                        index += 1
                        break
                    index += 1
                else:
                    fail(f"unterminated quoted literal: {path.relative_to(ROOT)}:{line}")
                continue
            if char in opening:
                stack.append((char, line))
            elif char in pairs:
                if not stack or stack[-1][0] != pairs[char]:
                    fail(f"unbalanced Kotlin delimiter {char}: {path.relative_to(ROOT)}:{line}")
                    break
                stack.pop()
            index += 1
        if stack:
            token, token_line = stack[-1]
            fail(f"unclosed Kotlin delimiter {token}: {path.relative_to(ROOT)}:{token_line}")


def main() -> int:
    gradle = read("app/build.gradle.kts")
    manifest = read("app/src/main/AndroidManifest.xml")
    node = read("app/src/main/java/sh/swrlz/nodehost/data/entity/NodeEntity.kt")
    database = read("app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt")
    host = read(HOST)
    user = read(USER)
    visuals = read(VISUALS)
    all_kotlin = "\n".join(
        path.read_text(encoding="utf-8")
        for path in sorted((ROOT / "app/src/main/java").rglob("*.kt"))
    )

    require(gradle, "versionCode = 6", "Android identity")
    require(gradle, 'versionName = "2.0.3"', "Android identity")
    require(gradle, 'applicationId = "sh.swrlz.nodehost"', "package identity")
    require(manifest, 'android:label="SWRLZ Swurlzer"', "visible identity")
    require(manifest, 'android:theme="@style/Theme.SwrlzNodeHost.Starting"', "splash theme")
    require(read("app/src/main/res/values/themes.xml"), "Theme.SwrlzNodeHost.Starting", "base splash theme")
    v31 = read("app/src/main/res/values-v31/themes.xml")
    require(v31, "android:windowSplashScreenBackground", "Android 12 splash")
    require(v31, "@mipmap/ic_launcher", "Android 12 splash icon")
    require(read("app/src/main/res/values/colors.xml"), "swurlzer_splash_background", "splash color")

    require(node, "@PrimaryKey val nodeId: String", "NodeEntity authority")
    if re.search(r"\bval\s+id\s*:", node):
        fail("NodeEntity contains a duplicate id property")
    reject(all_kotlin, "NodeEntity::id", "node-key regression")
    for relative, text in ((HOST, host), (USER, user)):
        require(text, "key = NodeEntity::nodeId", f"{relative} stable node key")

    forbidden_imports = (
        "import androidx.compose.foundation.layout.calculateTopPadding",
        "import androidx.compose.foundation.layout.weight",
    )
    for item in forbidden_imports:
        reject(all_kotlin, item, "Compose import regression")
    require(host, ".calculateTopPadding()", "Host PaddingValues receiver usage")
    require(user, ".calculateTopPadding()", "User PaddingValues receiver usage")
    require(host, "Modifier.weight(", "Host scoped weight usage")
    require(user, "Modifier.weight(", "User scoped weight usage")
    require(host, "Row(", "Host RowScope presence")
    require(user, "Row(", "User RowScope presence")
    require(user, "Column(", "User ColumnScope presence")
    for shared_tone in ("connectionTone", "proofTone", "trustTone", "routeTone"):
        require(user, f"internal fun {shared_tone}", f"shared {shared_tone} visibility")
        require(host, f"{shared_tone}(", f"Host {shared_tone} usage")

    require(visuals, "privateApiStatus == ListenerStatus.RUNNING", "READY private API evidence")
    require(visuals, "discoveryLoopbackStatus == ListenerStatus.RUNNING", "READY loopback evidence")
    require(visuals, "connection == SwurlzerConnectionStage.Connected", "core admission connection gate")
    require(visuals, "proof == SwurlzerProofStage.Verified", "core admission proof gate")
    require(visuals, "trust == SwurlzerTrustStage.Trusted", "core admission trust gate")
    require(visuals, "SwurlzerTrustStage.Legacy", "legacy distinction")
    require(visuals, "SwurlzerRouteStage.Local", "local route state")
    require(visuals, "SwurlzerRouteStage.Remote", "remote route state")
    require(visuals, "Lifecycle.State.STARTED", "lifecycle suspension")
    require(visuals, "state.citadelState != SwurlzerCitadelState.Failed", "failed animation stop")
    require(visuals, "rememberInfiniteTransition", "single low-frequency ambient transition")
    if visuals.count("rememberInfiniteTransition") != 2:
        fail("expected one call plus one import for rememberInfiniteTransition")
    reject(visuals, "animateFloatAsState", "reduced-motion static rendering")
    require(user, "if (motionEnabled)", "reduced-motion transition branch")
    require(user, "stateDescription = link.accessibilityDescription", "spoken connection/trust description")
    require(visuals, "contentDescription = null", "decorative dragon accessibility exclusion")
    for label in ("OFFLINE", "STARTING", "READY", "DEGRADED", "FAILED",
                  "REACHABLE", "IDENTITY CONFIRMED", "PROOF VERIFIED",
                  "TRUSTED", "PENDING", "LEGACY", "CONNECTED", "DISCONNECTED"):
        require(all_kotlin, label, f"explicit textual state {label}")

    for relative, expected in PROTECTED_SHA256.items():
        actual = digest(relative)
        if actual and actual != expected:
            fail(f"protected architecture file changed: {relative} ({actual})")
    for relative, expected in UNCHANGED_VISUAL_RESOURCE_SHA256.items():
        actual = digest(relative)
        if actual and actual != expected:
            fail(f"baseline icon/art resource changed unexpectedly: {relative} ({actual})")

    require(database, "version = 1", "Room schema version")
    require(read("app/src/main/java/sh/swrlz/nodehost/service/DiscoveryProtocol.kt"),
            "PROTOCOL_VERSION = 1", "discovery protocol version")
    require(read("app/src/main/java/sh/swrlz/nodehost/service/NodeCompatibilityProtocol.kt"),
            "PROTOCOL_VERSION = 1", "compatibility protocol version")

    for relative in (HOST, USER, VISUALS):
        changed = read(relative)
        reject(changed, "android.util.Log", f"{relative} sensitive log guard")
        reject(changed, "println(", f"{relative} sensitive log guard")
        reject(changed, "printStackTrace(", f"{relative} sensitive log guard")

    check_xml()
    check_duplicate_value_resources()
    check_kotlin_delimiters()
    check_no_packaged_outputs()

    required_receipts = (
        "SOURCES/SERVER/SERVER_CFv2.0.2_SWRLZ.md",
        "SOURCES/SERVER/SERVER_CFv2.0.3_SWRLZ.md",
        "reports/SERVER_CFv2.0.2_GITHUB_BUILD_SUCCESS.md",
    )
    for relative in required_receipts:
        if not (ROOT / relative).is_file():
            fail(f"missing lineage/evidence document: {relative}")

    if ERRORS:
        print("SERVER CFv2.0.3 STATIC VERIFY FAIL")
        for error in ERRORS:
            print(f"- {error}")
        return 1

    print("SERVER CFv2.0.3 STATIC VERIFY PASS")
    print("- Android identity: versionCode 6 / versionName 2.0.3")
    print("- Node keys: NodeEntity::nodeId in HostScreen and SwurlzerUserScreen")
    print("- Compose imports: incompatible explicit weight/calculateTopPadding imports absent")
    print("- Architecture: protected data/security/service hashes unchanged")
    print("- Protocol and Room schema: unchanged at version 1")
    print("- Resources: adaptive icon and Android 12 splash references resolve")
    print("- Motion/accessibility: lifecycle, reduced-motion, text, and semantics guards present")
    print("- Build boundary: static verification only; no APK or Gradle build performed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
