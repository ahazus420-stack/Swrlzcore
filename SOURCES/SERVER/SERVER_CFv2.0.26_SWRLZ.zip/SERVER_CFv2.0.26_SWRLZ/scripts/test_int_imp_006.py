#!/usr/bin/env python3
"""Source-level contract checks for INT-IMP-006. Does not build or open sockets."""

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SERVICE = ROOT / "app/src/main/java/sh/swrlz/nodehost/service"
RUNTIME = (SERVICE / "NodeRuntime.kt").read_text(encoding="utf-8")
IDENTITY = (SERVICE / "NodeIdentityStore.kt").read_text(encoding="utf-8")
PROTOCOL = (SERVICE / "DiscoveryProtocol.kt").read_text(encoding="utf-8")
API = (ROOT / "API.md").read_text(encoding="utf-8")
ARCH = (ROOT / "Architecture.md").read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


# Preserved private compatibility plane.
require("private const val PRIVATE_PORT = 8080" in RUNTIME, "private port 8080 not preserved")
require('"/status" -> "{\\"ok\\":true,\\"node\\":\\"SWRLZ Node Host\\",\\"mode\\":\\"embedded\\"}"' in RUNTIME,
        "/status payload changed")
require('"/health" -> "healthy"' in RUNTIME, "/health payload changed")
require("InetAddress.getLoopbackAddress()" in RUNTIME, "private runtime is no longer loopback-bound")

# Exact discovery transport and wire contract.
for marker in (
    "const val PORT = 8787",
    'const val PATH = "/discovery/signature"',
    'private const val SERVICE = "swrlz-local-node"',
    'private const val ENDPOINT = "discovery-signature"',
    'append("\\\"capabilities\\\":[\\\"discovery\\\"],")',
    'append("\\\"policy\\\":\\\"pairing_required\\\",")',
    'append("\\\"missionAuthorization\\\":\\\"trusted_only\\\"")',
    'mapOf("Allow" to "GET")',
    'mapOf("Cache-Control" to "no-store")',
):
    require(marker in PROTOCOL, f"missing protocol marker: {marker}")

for field in (
    "ok", "service", "endpoint", "protocolVersion", "schemaVersion", "nodeId",
    "installationId", "displayName", "hostVersion", "port", "capabilities", "trust",
):
    require(f'\\"{field}\\"' in PROTOCOL, f"missing response field {field}")

require('request.method != "GET"' in PROTOCOL, "GET method is not enforced")
require("request.contentLength > 0L" in PROTOCOL, "request-body rejection is absent")
require("accept == null || !acceptsJson(accept)" in PROTOCOL, "JSON Accept enforcement is absent")
require("quality > 0.0" in PROTOCOL, "Accept q=0 is not rejected")
require("statusCode = 405" in PROTOCOL and "statusCode = 200" in PROTOCOL, "required response statuses absent")

# Durable identity is app-private, atomic, UUIDv4, and independent from Room.
for marker in (
    "context.applicationContext.noBackupFilesDir",
    "AtomicFile(",
    "UUID.randomUUID()",
    'NODE_ID_PREFIX = "swrlz-node-"',
    'INSTALLATION_ID_PREFIX = "swrlz-install-"',
    "uuid.version() == 4",
    "persistAndVerify",
    "identityFile.finishWrite(stream)",
    "readBack != expected",
    "KEY_PREVIOUS_NODE_ID",
):
    require(marker in IDENTITY, f"missing identity invariant: {marker}")
require("import androidx.room" not in IDENTITY and "NodeEntity(" not in IDENTITY,
        "self-identity depends on Room/demo nodes")

# Exposure is explicit and fail-closed rather than wildcard-bound.
require("InetSocketAddress(address, DiscoveryProtocol.PORT)" in RUNTIME, "discovery is not address-specific")
for forbidden in (
    'InetAddress.getByName("0.0.0.0")',
    "InetSocketAddress(DiscoveryProtocol.PORT)",
    "ServerSocket(DiscoveryProtocol.PORT",
):
    require(forbidden not in RUNTIME, f"wildcard discovery bind detected: {forbidden}")
require("Inet4Address" in RUNTIME and "isSiteLocalAddress" in RUNTIME, "IPv4 local-link filtering absent")
require("loopbackSocket = bindDiscoverySocket(loopback) ?: return emptyList()" in RUNTIME,
        "mandatory IPv4 loopback discovery bind absent")
for interface in ("wlan", "eth", "rndis", "rmnet", "tun", "ppp", "wg"):
    require(f'"{interface}"' in RUNTIME, f"interface policy marker absent: {interface}")

# Bounded parser and response metadata.
for marker in (
    "MAX_REQUEST_LINE_BYTES",
    "MAX_TOTAL_HEADER_BYTES",
    "MAX_HEADER_COUNT",
    "SOCKET_TIMEOUT_MS",
    'Content-Type: application/json; charset=utf-8',
):
    require(marker in RUNTIME, f"bounded HTTP marker absent: {marker}")

# Documentation records both planes and the trust boundary.
for text, label in ((API, "API.md"), (ARCH, "Architecture.md")):
    require("8080" in text and "8787" in text, f"{label} does not document both ports")
    require("/discovery/signature" in text, f"{label} omits discovery route")
require("does not establish trust" in API, "API trust boundary absent")
require("independent from Room" in ARCH, "identity/Room separation absent")

print("INT-IMP-006 source contract checks: PASS")
