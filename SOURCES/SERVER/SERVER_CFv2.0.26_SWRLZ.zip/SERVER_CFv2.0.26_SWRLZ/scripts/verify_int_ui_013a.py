from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
checks={
'app/build.gradle.kts':['versionCode = 8','versionName = "2.0.5"'],
'app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt':['SwurlzerTab.Activity','val running = state.health.runtimeStatus','What the server user should know.'],
'app/src/main/java/sh/swrlz/nodehost/data/NodeHostDatabase.kt':['version = 1'],
}
errors=[]
for rel,needles in checks.items():
 p=root/rel
 if not p.exists(): errors.append(f'missing {rel}'); continue
 t=p.read_text()
 for n in needles:
  if n not in t: errors.append(f'{rel}: missing {n}')
if errors:
 print('SERVER INT-UI-013A VERIFY FAIL'); print('\n'.join('- '+x for x in errors)); sys.exit(1)
print('SERVER INT-UI-013A VERIFY PASS')
