# INT-IMP-011A Runtime Diagnostics & Live Debug Console

## Implemented

- Reactive in-memory diagnostic snapshot exposed through `StateFlow`.
- Bounded 250-entry live console backed by the existing private rotating log.
- HTTP request instrumentation for private and discovery surfaces.
- Request totals and 2xx/4xx/5xx counters.
- Last-request timestamp.
- Runtime/HTTP categories and INFO/WARN/ERROR levels.
- Overview health card with listener details and request counters.
- Diagnostics tab with live entries, filters, and clear action.
- Secret redaction and local-only storage retained.

## Preserved boundaries

- No new network endpoint.
- No presence API implementation.
- No protocol/schema change.
- No remote upload or telemetry.
- No CLIENT changes.

## Verification

- INT-IMP-006 source contract checks: PASS.
- Gradle compilation: BLOCKED in the local environment because the Gradle 8.9 wrapper distribution was unavailable offline.
