# INT-IMP-010C — Runtime Ownership and Truth Repair

## Base artifact

- `SERVER_CFv1.0.1_SWRLZ.zip`
- Working-copy integration only; the uploaded base archive was not overwritten.

## Implemented

- `NodeHostService` is now the sole caller of `NodeRuntime.start()` and `NodeRuntime.stop()`.
- The service uses Hilt injection and starts immediately as a foreground service.
- `NodeService` uses `ContextCompat.startForegroundService()`.
- Added typed runtime, listener, and failure state in `NodeHealth.kt`.
- Added independent health for private API `8080`, discovery loopback `8787`, and LAN discovery.
- UI and notification text now derive from observed `NodeHealth`; no optimistic success assignment remains.
- Startup failures retain stage, listener, timestamp, safe exception type, and sanitized message.
- Added bounded app-private rolling diagnostics (`128 KiB` current + one previous file), with line normalization and basic secret redaction.
- Added API 34 `FOREGROUND_SERVICE_DATA_SYNC` permission matching the existing declared service type.
- Added pure state-model tests for truthful summaries and degraded listener state.
- Preserved discovery route, protocol/schema version, approved-interface rules, and no-wildcard binding policy.

## Verification performed

- `python scripts/test_int_imp_006.py` — PASS.
- Static ownership scan — only `NodeHostService` calls `NodeRuntime.start/stop`.
- Static optimistic-status scan — old unconditional `Node running` assignment and old notification claim removed.

## Verification limitation

`./gradlew testDebugUnitTest --no-daemon` could not run because the isolated environment could not download Gradle 8.9 from `services.gradle.org` (`UnknownHostException`). Therefore this candidate is source-verified but not compile-verified or APK-verified.

## Scope explicitly unchanged

- CLIENT source and behavior.
- Discovery protocol version 1 and schema version 1.
- Pairing/trust semantics.
- Mission execution.
- Cloud/hosted-node behavior.
- Repository, CI, release, and deployment state.
