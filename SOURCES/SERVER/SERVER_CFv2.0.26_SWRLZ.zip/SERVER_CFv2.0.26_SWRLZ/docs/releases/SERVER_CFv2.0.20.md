# SERVER CFv2.0.20 — Device Continuity

**Date:** 2026-07-23

## Changes

- Added protocol v2 reinstall recovery through `deviceRecoveryId`.
- Preserves the SERVER-owned canonical node ID when a matching device returns after reinstall.
- Tracks a new `installationId` in durable installation lineage instead of creating another node.
- Registration reconciliation now executes in one Room transaction.
- Duplicate active rows are archived by recovery digest and, for legacy clients, device ID.
- New installations recovered without device proof are marked `UNTRUSTED` and
  `REAPPROVAL_REQUIRED`.
- Protocol v1 remains accepted for staged migration.

## Verification

Static source verification passed. Gradle execution was attempted but the wrapper distribution was
not available locally and network access to `services.gradle.org` was unavailable. CI must run
`./gradlew testDebugUnitTest` before release signing.
