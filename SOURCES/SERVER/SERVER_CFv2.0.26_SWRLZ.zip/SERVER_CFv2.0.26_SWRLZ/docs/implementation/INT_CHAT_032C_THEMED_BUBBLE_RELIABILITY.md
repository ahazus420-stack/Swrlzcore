# INT_CHAT_032C — Themed Bubble Reliability Correction

## Client
- Replaced the generic Material bubble with a Glitch Dragon panel using the persisted Client theme.
- Added mission state, pause/resume, chat draft, and theme identity to the compact surface.
- Completed the conversation shortcut with person and locus metadata.
- Changed bubble settings flow to register the conversation before opening system settings.

## Server
- Replaced the generic white bubble with a themed server command surface.
- Reads persisted Server theme family and variant.
- Displays server status, local administrator draft state, and full-app navigation.
- Completed the conversation shortcut with person and locus metadata.

## Known boundary
Android and Samsung One UI decide whether a conversation auto-expands. SWRLZ can request, register, and publish a bubble but cannot force launcher presentation.
