# INT-FIX-028B — SERVER listener lifecycle hardening

## Evidence
The paired CLIENT failure was caused by routing operational traffic to the private compatibility port. The SERVER source confirms authoritative registration and Groups dispatch on the advertised operational listener. The private loopback listener remains separately visible and must not be treated as proof of CLIENT session health.

## Changes
- Private loopback binding now enables address reuse before bind, reducing restart/reload failures caused by recently retired socket generations.
- Operator health text explicitly prioritizes private-listener failure/unavailability.
- Listener health remains independent from registered/online CLIENT counts.

## Preserved laws
Discovery reachability alone does not imply enrollment, trust, or an online CLIENT session.
