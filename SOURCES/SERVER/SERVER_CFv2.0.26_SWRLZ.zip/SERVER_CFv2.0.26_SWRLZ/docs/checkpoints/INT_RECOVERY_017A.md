# INT-RECOVERY-017A — SERVER

Baseline: SERVER CFv2.0.7
Target: SERVER CFv2.0.8

- Added generation-aware listener ownership.
- Intentional stop/restart listener exits are ignored as expected lifecycle events.
- Restart now closes sockets, interrupts workers, joins listener threads, clears references, and only then starts a fresh generation.
- FAILED is recoverable through Initialize Server without reinstalling.
- UI displays lifecycle activity separately from health: ACTIVE/INACTIVE plus HEALTHY/DEGRADED/FAILED.
- No protocol-version, trust, or destructive persistence changes.
- Build not run in this checkpoint.
