# ADR-0023 — Themed Floating Dragon and Conversation Registration

## Status
Accepted

## Context
Android renders the collapsed bubble chrome, but the expanded bubble content is an embedded activity owned by SWRLZ. The first bubble implementation used default Material surfaces and did not consume the selected Client or Server theme. On some launchers the Client conversation also appeared only as an empty app bubble-settings entry because the dynamic shortcut lacked the complete conversation metadata expected by modern Android launchers.

## Decision
1. Expanded Client and Server bubbles render with their repository theme catalogs and persisted theme selection.
2. Conversation shortcuts are long-lived and include a stable shortcut ID, person metadata, and a `LocusId` on Android 10+.
3. Bubble notifications use `MessagingStyle`, the same shortcut ID, high-importance conversation channels, and explicit bubble metadata.
4. `OPEN DRAGON` republishes the conversation with auto-expand requested.
5. `BUBBLE SETTINGS` first publishes/registers the conversation, then opens Android's app bubble settings so the settings page is not entered before the conversation exists.
6. Android remains authoritative over whether the notification expands as a bubble.

## Security
The bubble remains a presentation surface. It does not bypass trust, mission approval, lock-screen privacy, or server authorization. Current message composer text remains local UI state until authenticated chat transport is implemented.

## Performance
The bubble observes only persisted theme flows and current in-process mission/runtime state. No polling loop or new network connection is introduced.

## Compatibility
Launchers may decline auto-expansion even when bubbles are enabled. The notification remains functional and can be promoted by the user through Android conversation settings.

## Verification
The release gate must compile both apps, launch each `BubbleActivity`, publish each conversation, verify the shortcut appears in Android conversation settings, and verify Dark/Sunlight/Inverse theme changes are reflected after reopening the bubble.
