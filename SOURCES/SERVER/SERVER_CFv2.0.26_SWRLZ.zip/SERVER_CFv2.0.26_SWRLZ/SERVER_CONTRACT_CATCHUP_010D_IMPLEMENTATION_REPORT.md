# SERVER-CONTRACT-CATCHUP-010D — v1.0.3 Implementation Report

## Canonical lineage

- Base: `SERVER_CFv1.0.2_SWRLZ.zip`
- Required base SHA-256: `9d278bed4944eee20d6b9dc1ea89ba9363c30a7e7daa5b91b44836c386abd200`
- Successor: `SERVER_CFv1.0.3_SWRLZ.zip`
- Protocol version: `1`
- Schema version: `1`

## Implemented

- Added truthful read-only compatibility routes on TCP 8787:
  - `GET /status`
  - `GET /presence/summary`
  - `GET /presence/groups`
  - `GET /presence/devices`
- Empty presence returns successful zero counts and empty arrays.
- Missing or invalid durable identity/version fails closed with `503`.
- Existing `/discovery/signature` routing remains under `DiscoveryProtocol`.
- Added deterministic Glitch Dragon Core adaptive, round, and density launcher resources.
- Updated source version to `versionCode 2` / `versionName 1.0.3`.
- Updated API, architecture, README, and release documentation in the source archive.

## Canonical-base integration correction

The checksum-matching v1.0.2 source uses the accepted `NodeHealth` / `_health`
runtime model. An earlier staged one-shot applicator expected stale symbols
(`RuntimeEventStore`, `NodeRuntimeState`, and `_state.value`) and a request-line
marker that are not present in the canonical archive. This candidate therefore
integrates directly against the actual canonical source and maps compatibility
truth from `NodeHealth`, active durable identity, and the bound discovery
sockets. The stale manual applicator/workflow is not modified or dispatched by
this source checkpoint.

## Preserved boundaries

- No synthetic devices or groups.
- No pairing, trust establishment, mission authority, or remote state.
- No CLIENT modification.
- No hosted-node or paid runtime dependency.
- No APK is embedded in this source archive.

## Verification

- Exact base checksum: PASS.
- ZIP integrity and path safety: PASS.
- Compatibility route/source contract checks: PASS.
- Launcher inventory and deterministic PNG reconstruction: PASS.
- Deterministic source archive reproduction: verified outside this report before promotion.

## Device proof still required

After repository auto-build, install the generated SERVER APK and verify the
four routes, launcher rendering, and CLIENT dashboard behavior on-device.
