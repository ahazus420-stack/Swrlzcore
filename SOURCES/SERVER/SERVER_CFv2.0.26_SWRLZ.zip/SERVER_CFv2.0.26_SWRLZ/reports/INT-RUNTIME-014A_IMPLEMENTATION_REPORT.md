# INT-RUNTIME-014A SERVER implementation

- Advanced SERVER to CFv2.0.6 (`versionCode 9`).
- Added authoritative `NodeHealth.runtimeActive`; STARTING, RUNNING, and DEGRADED now render STOP SWURLZER.
- Added operator-facing degraded reason text, including local-only/no-approved-Wi-Fi-or-LAN guidance.
- Renamed the summary to REGISTERED NODES and added truthful guidance when discovery is reachable but no CLIENT has completed enrollment/presence registration.
- No fake connection state was introduced. Reachability remains distinct from identity, proof, trust, and persisted presence.
- No APK/Gradle build was run here.
- No Room migration, protocol-version change, new endpoint, trust weakening, release, or deployment was performed.
