# INT-CONNECT-021A SERVER Static Verification

PASS:
- /nodes/disconnect route present;
- Room schema version 3 and MIGRATION_2_3 present;
- binding/device lookup and duplicate archival DAO operations present;
- registration preserves installation lineage;
- registry_loaded diagnostic present;
- versionCode 14 / 2.0.11 identity present.
