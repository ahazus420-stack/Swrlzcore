# SERVER CFv2.0.4 SWURLZER Lineage

- Checkpoint: `INT-CONV-012A`
- Canonical baseline: `SERVER_CFv2.0.3_SWRLZ.zip`
- Baseline SHA-256: `c1176f1e7dd1fd52bb20bd85b90e22ddb36c4b151f0edc79c2af82f9c1ba3966`
- Baseline compilation: owner-confirmed GitHub SUCCESS
- New identity: versionCode 7 / versionName `2.0.4`
- Build: NOT RUN
- Integration law: Integrate, do not overwrite.

Final archive digest is recorded in the sibling checksum and delivery receipt because embedding a ZIP's own digest would change the archive.
