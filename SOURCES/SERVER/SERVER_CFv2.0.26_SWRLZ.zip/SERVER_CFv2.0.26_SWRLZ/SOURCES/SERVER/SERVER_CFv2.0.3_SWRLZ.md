# SERVER CFv2.0.3 SWURLZER Source Lineage Receipt

**Patch label:** `SWURLZER-LIVING-CITADEL-EFFECTS`  
**Visible product identity:** SWURLZER  
**Repository/workflow transport identity:** SERVER  
**Integration law:** Integrate, do not overwrite.

## Baseline authority

- Canonical source: `SERVER_CFv2.0.2_SWRLZ.zip`
- Canonical source SHA-256: `6978332cfe46a3a1d7154c25fe8f677e48bed2fee24cdf506307cfb830af057a`
- Baseline Android identity: `versionCode 5`, `versionName 2.0.2`
- New Android identity: `versionCode 6`, `versionName 2.0.3`
- Visual compatibility reference, read only: `CLIENT_CFv2.0.2_SWRLZ.zip`
- CLIENT reference SHA-256: `95e84eeb74776a1d4fe719678fc0743f11088d3460d9b721abcc20d71b314d0c`

Both canonical ZIP/checksum pairs matched and passed structural ZIP integrity checks before implementation. CLIENT source was not modified.

## Confirmed CFv2.0.2 GitHub build evidence

The canonical baseline compiled successfully in GitHub Actions before this checkpoint:

- Workflow: `SWRLZ APK Router — Manual / Auto`
- Workflow file: `.github/workflows/swrlz-apk-router.yml`
- Commit: `cf68aaeb216ff4bb52e7f67a277537c3f5cb800e`
- Result: `SUCCESS`
- Duration: `6m 32s`
- Artifact count: `1`
- Source: `SERVER_CFv2.0.2_SWRLZ.zip`
- Source SHA-256: `6978332cfe46a3a1d7154c25fe8f677e48bed2fee24cdf506307cfb830af057a`

The complete baseline evidence and checksum/archive incident history are preserved at `reports/SERVER_CFv2.0.2_GITHUB_BUILD_SUCCESS.md`. Device/runtime verification for CFv2.0.2 remains separate evidence.

## Exact modified and added source paths

Modified:

- `README.md`
- `ReleaseNotes.md`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/sh/swrlz/nodehost/ui/HostScreen.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerVisuals.kt`
- `app/src/main/res/values/colors.xml`
- `app/src/main/res/values/themes.xml`

Added:

- `app/src/main/res/values-v31/themes.xml`
- `reports/SERVER_CFv2.0.2_GITHUB_BUILD_SUCCESS.md`
- `scripts/verify_server_cfv203.py`
- `SOURCES/SERVER/SERVER_CFv2.0.3_SWRLZ.md`

No CLIENT path, Room entity/DAO/database path, service/runtime path, security path, discovery path, protocol path, Gradle module name, namespace, or package identity was modified.

## Living Citadel effects

- Low-frequency central-core breathing luminance and restrained dragon drift.
- Sparse remembered crystal-edge shimmer with three fixed shard traces.
- Sequential STARTING perimeter activation.
- One finite cyan READY pulse and brief decorative eye pulse.
- Restrained amber DEGRADED irregularity.
- Static restrained red FAILED boundary with nonessential animation stopped.
- Finite control/navigation energy ripple.
- Finite mission-start pulse and restrained active-mission rhythm.
- Amber paused/approval atmosphere and caution manual-intervention atmosphere.
- Compact perimeter-to-core CLIENT link with separate identity, proof, trust, and route gates.
- Android 12+ splash theme using the preserved adaptive launcher icon.
- Crystal-panel fade/scale transition updated to approximately 98% to 100% within 180–320 ms.
- Dragon art effective visibility increased selectively from the CFv2.0.2 default without raising text-panel opacity.

## Authoritative runtime fields driving effects

| Effect or label | Existing sanitized source field |
|---|---|
| OFFLINE / STARTING / FAILED | `HostUiState.health.runtimeStatus` |
| READY | `runtimeStatus == RUNNING` plus `health.privateApi.status == RUNNING` and `health.discoveryLoopback.status == RUNNING` |
| DEGRADED | Existing `RuntimeStatus.DEGRADED`, or RUNNING without both required local services confirmed RUNNING |
| LAN listener detail | `HostUiState.health.discoveryLan.status` |
| Mission active/paused/pending/manual | Persisted `MissionEntity.state`, token-matched conservatively |
| DISCOVERED / REACHABLE / IDENTITY CONFIRMED / CONNECTED | Persisted `NodeEntity.status`, exact normalized tokens only |
| PROOF VERIFIED / PROOF FAILED | Exact proof tokens in persisted sanitized node status/trust text |
| TRUSTED / PENDING / LEGACY / FAILED | Persisted `NodeEntity.trust`, exact normalized tokens only |
| LOCAL ROUTE / REMOTE ROUTE | Exact local/remote route tokens in persisted sanitized status/trust text |
| Node-linked animation identity | `NodeEntity.nodeId` |

A trusted stored node is not promoted to CONNECTED. An ordinary online status is not promoted to REACHABLE. The visual link enters the central core only when CONNECTED, IDENTITY CONFIRMED, PROOF VERIFIED, and TRUSTED are all explicitly represented. LEGACY remains violet/amber and never implies modern proof verification.

## nodeId regression verification

- `NodeEntity::id`: absent from all Kotlin source.
- `NodeEntity::nodeId`: retained as the `LazyColumn` node key in both `HostScreen.kt` and `SwurlzerUserScreen.kt`.
- `NodeEntity` remains `@PrimaryKey val nodeId: String`.
- No duplicate `id` property was added.
- No row uses index, label, hostname, URL, connection state, trust state, or last-seen time as its key.
- Node-linked visual state carries the authoritative `nodeId`.

## Compose-import regression verification

The following incompatible explicit imports remain absent:

```kotlin
import androidx.compose.foundation.layout.calculateTopPadding
import androidx.compose.foundation.layout.weight
```

`calculateTopPadding()` resolves from `WindowInsets.statusBars.asPaddingValues()`. Every `Modifier.weight(...)` call remains inside a `RowScope` or `ColumnScope`. The static verifier rejects either forbidden import.

## Accessibility behavior

- Critical states remain explicit text, never color alone.
- Node connection, identity, proof, trust, legacy, failure category, and route are separate labels.
- Node cards expose a combined spoken state description preserving connection/trust separation.
- Decorative dragon art and decorative icons use null accessibility descriptions.
- Core state includes a spoken state description and evidence text.
- Touch controls retain at least the established 50–54 dp control height; summary controls use an 88 dp minimum height.
- Compact screens retain scrolling navigation; status pills permit two lines.
- Large text is allowed to wrap instead of being clipped to one line.
- Animation never obscures diagnostics or removes controls.

## Reduced-motion behavior

When decorative motion is disabled:

- ambient dragon drift, breathing, shimmer, shard motion, eye pulses, and event ripples are not composed;
- the Citadel renders a static state-correct fallback;
- navigation uses a short opacity-only transition;
- all controls and textual states remain available.

Decorative animation also suspends when the lifecycle is below STARTED. FAILED stops nonessential decorative animation even when motion is enabled.

## Performance safeguards

- One low-frequency ambient transition for the entire backdrop.
- Four bounded `Animatable` event pulses; no per-node infinite transitions.
- Three remembered shard specifications; no continuous particle spawning.
- No per-frame bitmap decode or allocation.
- Existing cached drawable resources are reused.
- No full-screen blur recomputation.
- Lifecycle-aware suspension and reduced-motion static fallback.
- Stable `nodeId` list keys and immutable derived visual-state values.
- No decorative work while backgrounded.

## Icon and splash inventory

Preserved unchanged from CFv2.0.2:

- `branding/SWURLZER_GLITCH_DRAGON_ICON_MASTER_4096.png` — 4096×4096 master.
- `app/src/main/res/drawable-nodpi/ic_launcher_adaptive_foreground.png` — adaptive foreground.
- `app/src/main/res/drawable/ic_launcher_foreground.xml` — vector foreground.
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml`
- Density-specific regular and round PNGs under `mipmap-mdpi`, `mipmap-hdpi`, `mipmap-xhdpi`, `mipmap-xxhdpi`, and `mipmap-xxxhdpi`.
- `app/src/main/res/drawable-nodpi/glitch_dragon_swurlzer.jpg` — unchanged Citadel artwork.

Added splash resources:

- `@style/Theme.SwrlzNodeHost.Starting` in base values.
- Android 12+ overrides in `values-v31/themes.xml`.
- `@color/swurlzer_splash_background`.
- Existing `@mipmap/ic_launcher` is the Android 12+ splash icon.

## Architecture and security preservation

Protected hashes confirm that the Room database/entity authority, Node runtime, discovery protocol, CLIENT compatibility protocol, proof binding sidecar, and request-proof verifier are byte-for-byte CFv2.0.2. Protocol identifiers and protocol/schema version 1 are unchanged. Room database version 1 and its entity schema are unchanged. No migration was added. Trust, enrollment, revocation, proof, private token, request-HMAC, presence, and local-versus-remote boundaries are unchanged.

No sensitive key, token, proof material, pairing secret, HMAC secret, or unredacted sensitive context was added to logs or UI effects.

## Static verification

Run from the extracted project root:

```bash
python3 scripts/verify_server_cfv203.py
```

The verifier checks Android identity, nodeId keys, forbidden Compose imports, authoritative visual mappings, accessibility/reduced-motion markers, XML/resource validity, duplicate value-resource names, launcher/art hashes, protected architecture hashes, protocol/Room versions, and packaged-output exclusions. It never invokes Gradle or builds an APK.

## Archive integrity and final checksum

The authoritative final archive result and SHA-256 are recorded in the sibling transport deliverables:

- `SERVER_CFv2.0.3_SWRLZ.sha256`
- external `SERVER_CFv2.0.3_SWRLZ.md`

The final digest cannot be embedded inside the ZIP that it hashes without changing those same ZIP bytes. This in-archive receipt is sealed before final packaging; the sibling external receipt mirrors this lineage and records the tested final archive result and exact final digest. The ZIP must not be modified after hashing.

## Known limitations

- CFv2.0.3 has not been compiled; compilation is pending GitHub verification.
- No APK, device installation, screenshot, runtime handshake, or instrumentation evidence is claimed.
- The current data model exposes sanitized persisted node status/trust strings, not a dedicated live proof-stage event stream. Missing proof/route evidence therefore renders as NOT VERIFIED / NOT REPORTED and never admits the core link.
- One highest-evidence node drives the background handshake; every stored node remains independently visible in the node list.
- The eye remains decorative and state-reinforcing, not authoritative.
- Pre-Android-12 devices receive the base launch theme; the platform splash API refinements apply on Android 12+.
- CFv2.0.3 compilation is pending GitHub verification.

## Verification status

Source-only implementation and static verification are in scope. Local Gradle compilation and APK assembly are explicitly excluded. Repository commit, push, workflow trigger, release, and deployment are excluded.

**Protocols and Room schema were unchanged.**  
**CFv2.0.3 compilation is pending GitHub verification.**
