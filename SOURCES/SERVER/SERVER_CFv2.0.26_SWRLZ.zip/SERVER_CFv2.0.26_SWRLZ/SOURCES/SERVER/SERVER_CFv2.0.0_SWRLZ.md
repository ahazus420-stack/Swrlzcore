# SERVER CFv2.0.0 SWRLZ Lineage Receipt

**User-facing product name:** `SWRLZ Swurlzer`  
**Label:** `GLITCH-DRAGON-SWURLZER-DUAL-MODE`  
**Baseline source:** `SERVER_CFv1.0.4_SWRLZ.zip`  
**Baseline SHA-256:** `32114c2658a315dddc86d2ce2f0f790cc7d7e6a5bea506e1ef909aea404125e6`  
**New source:** `SERVER_CFv2.0.0_SWRLZ.zip`  
**Canonical source root:** `SWRLZ_NODE_HOST/`  
**Android identity:** `versionCode 3` / `versionName 2.0.0`  
**Protocol/schema change:** none; both remain version 1

## Exact files modified or added

- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/sh/swrlz/nodehost/MainActivity.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/NodeHostApp.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/HostScreen.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUiPreferences.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerVisuals.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/theme/Theme.kt`
- `app/src/main/res/drawable-nodpi/glitch_dragon_swurlzer.jpg`
- `app/src/main/res/drawable-nodpi/ic_launcher_adaptive_foreground.png`
- `app/src/main/res/mipmap-mdpi/ic_launcher.png`
- `app/src/main/res/mipmap-mdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-hdpi/ic_launcher.png`
- `app/src/main/res/mipmap-hdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xhdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xxhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png`
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher.png`
- `app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png`
- `branding/SWURLZER_GLITCH_DRAGON_ICON_MASTER_4096.png`
- `README.md`
- `ReleaseNotes.md`
- `scripts/verify_server_cfv200.py`
- `SOURCES/SERVER/SERVER_CFv2.0.0_SWRLZ.md`

All `data/`, `di/`, `security/`, and `service/` implementations remain byte-for-byte identical to the checksum-verified SERVER CFv1.0.4 baseline. The application ID, Kotlin package, canonical source root, archive prefix, protocol fields, and `NODE_HOST` engineering identity are preserved. “Swurlzer” is the user-facing term.

## Interface and runtime-state behavior

- Fresh installs open in streamlined Swurlzer User Mode with Core, Nodes, Missions, and Settings.
- A persisted switch opens Swurlzer Dev Mode; the original Overview and Diagnostics cockpit, Start/Stop, Seed Demo Data, listener health, known-node records, mission records, filters, and clear control remain present.
- Runtime atmosphere follows actual `RuntimeStatus` and listener health. Stored node status is explicitly labeled as stored and is never promoted into a connection claim.
- Trusted styling follows the stored trust record. Mission emphasis follows persisted mission state and does not grant execution or approval authority.
- CLIENT Truth Firewall and approval authority remain explicitly visible and are never represented as bypassed by Swurlzer availability.

## Accessibility and reduced motion

- Runtime, listener, trust, mission, and mode state have visible text labels in addition to color.
- Launcher and background dragon art are decorative; Compose background art has no accessibility description.
- Major controls use full-width 50–54 dp surfaces; bottom navigation retains standard Material touch targets.
- Motion preference persists independently of runtime/trust state.
- Motion Off selects the static backdrop, removes drift/shimmer/pulse loops, and keeps a short opacity-only panel transition.
- Decorative animation pauses whenever the Activity is below the STARTED lifecycle state.

## Performance safeguards

- One cached background drawable; no full-resolution decode during recomposition.
- One low-frequency ambient transition only while motion is enabled and the app is foregrounded.
- Three fixed remembered shards, no spawning particle system, no continuous blur, and no per-frame bitmap allocation.
- Touch/state energy uses a finite `Animatable` pulse.
- 4096×4096 artwork is a source master only; Android runtime uses the bounded 432×432 adaptive foreground and density-specific launcher assets.

## Protected semantics preserved

- Private API remains loopback-bound on port 8080.
- Discovery remains on port 8787 and is limited to loopback plus approved local-link interfaces.
- No wildcard bind, remote-node mode, or public exposure is added.
- Discovery signature, durable identity, pairing/trust, proof binding, mission policy, context boundaries, and protocol/schema version 1 are unchanged.

## Verification evidence

- `python3 scripts/verify_server_cfv200.py`: PASS.
- `python3 scripts/test_int_imp_006.py`: PASS.
- `python3 scripts/test_server_contract_catchup_010d.py .`: PASS.
- Protected `data/`, `di/`, `security/`, and `service/` implementation byte comparison against SERVER CFv1.0.4: PASS.
- `./gradlew :app:compileDebugKotlin`: NOT RUN — source-only delivery requested; deferred to owner GitHub build.
- `./gradlew :app:assembleDebug`: NOT RUN — source-only delivery requested; deferred to owner GitHub build.
- Archive integrity and extracted verifier: performed after this receipt is finalized and reported beside the download.
- Source-tree checksum (excluding this receipt): `d60f17a8392846fca2f61276d961ce2a023223a1f30ade3413199612c345056e`.
- Canonical ZIP SHA-256: recorded in sibling `SERVER_CFv2.0.0_SWRLZ.sha256` to avoid a self-referential archive checksum.

## Known limitations

- No APK or emulator/device test is included in this source-only checkpoint.
- Compact-display, large-text, screen-reader, lifecycle-background, and persisted-mode behavior still require device verification.
- Listener and connection accuracy depend on the preserved runtime health model; this UI checkpoint does not add a new connectivity contract.

## Rollback

Restore checksum-verified `SERVER_CFv1.0.4_SWRLZ.zip`. No data, schema, protocol, security, or trust migration is required.

**Operating law:** Integrate, do not overwrite.
