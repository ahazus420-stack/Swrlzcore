# SERVER CFv2.0.1 SWRLZ Lineage Receipt

**User-facing product name:** `SWRLZ Swurlzer`  
**Label:** `NODE-KEY-COMPILE-FIX`  
**Baseline source:** `SERVER_CFv2.0.0_SWRLZ.zip`  
**New source:** `SERVER_CFv2.0.1_SWRLZ.zip`  
**Canonical source root:** `SWRLZ_NODE_HOST/`  
**Android identity:** `versionCode 4` / `versionName 2.0.1`  
**Protocol/schema change:** none; both remain version 1

## Build failure evidence

GitHub Actions reached `:app:compileDebugKotlin` and failed in two source locations:

- `HostScreen.kt:235`
- `SwurlzerUserScreen.kt:320`

Both screens used:

```kotlin
items(state.nodes, key = NodeEntity::id)
```

`NodeEntity` does not define `id`; its Room primary key is:

```kotlin
@PrimaryKey val nodeId: String
```

The missing property caused Kotlin to mis-resolve the `items(...)` call and emit secondary argument-type and composable-context errors.

## Bounded repair

Changed only the affected key selectors:

```kotlin
items(state.nodes, key = NodeEntity::nodeId)
```

in:

- `app/src/main/java/sh/swrlz/nodehost/ui/HostScreen.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt`

Additional checkpoint updates:

- `app/build.gradle.kts`: `versionCode 4`, `versionName 2.0.1`
- `ReleaseNotes.md`: added CFv2.0.1 repair entry
- `README.md`: advanced canonical checkpoint wording
- `scripts/verify_server_cfv201.py`: added version checks and a regression guard for the NodeEntity key selector

## Preserved boundaries

No changes were made to:

- SERVER transport prefix or GitHub source-lane compatibility
- visible Swurlzer product identity
- package or module names
- Room entity schema
- protocol/schema versions
- discovery, pairing, trust, proof binding, enrollment, registry, mission, or Truth Firewall semantics
- CLIENT or NODE_HOST external contracts

## Verification

- Static checkpoint verifier: `python3 scripts/verify_server_cfv201.py`
- Existing integration guard: `python3 scripts/test_int_imp_006.py`
- Existing SERVER contract guard: `python3 scripts/test_server_contract_catchup_010d.py .`
- Archive integrity: verified after packaging
- APK compilation and assembly: intentionally deferred to the owner's GitHub workflow

## Expected GitHub result

The previously reported `NodeEntity::id` and associated LazyColumn overload errors should be removed. GitHub will provide authoritative compile and APK evidence.

**Operating law:** Integrate, do not overwrite.
