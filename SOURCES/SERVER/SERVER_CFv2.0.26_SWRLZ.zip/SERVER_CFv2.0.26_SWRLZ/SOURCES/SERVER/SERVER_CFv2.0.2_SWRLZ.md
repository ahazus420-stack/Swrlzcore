# SERVER CFv2.0.2 SWRLZ Lineage Receipt

**Visible product identity:** SWURLZER  
**Repository/build transport identity:** SERVER  
**Canonical baseline:** `SERVER_CFv2.0.1_SWRLZ.zip`  
**New source:** `SERVER_CFv2.0.2_SWRLZ.zip`  
**Android identity:** `versionCode 5` / `versionName 2.0.2`

## Scope

This checkpoint is a true version-synchronized repackage of the valid CFv2.0.1 source.

Applied changes:

- `app/build.gradle.kts`: `versionCode 4` → `5`
- `app/build.gradle.kts`: `versionName 2.0.1` → `2.0.2`
- `README.md`: active checkpoint reference updated
- `ReleaseNotes.md`: CFv2.0.2 entry added
- `scripts/verify_server_cfv202.py`: current static verifier added
- This lineage receipt added

## Preserved repair

The CFv2.0.1 node-list repair remains intact:

```kotlin
items(state.nodes, key = NodeEntity::nodeId)
```

in:

- `app/src/main/java/sh/swrlz/nodehost/ui/HostScreen.kt`
- `app/src/main/java/sh/swrlz/nodehost/ui/SwurlzerUserScreen.kt`

`NodeEntity::id` was not reintroduced.

## Non-changes

No changes were made to:

- Room schema
- `nodeId` semantics
- protocol identifiers or versions
- trust contracts
- cryptography
- source resolver behavior
- SERVER transport naming
- visible SWURLZER UI behavior
- CLIENT or NODE_HOST contracts

APK compilation and runtime verification remain pending the owner's GitHub workflow.

Core law: integrate, do not overwrite.
