# Migration

This project replaces the prior Termux-based workflow with a dedicated Android application.

## Migration notes
- The user taps Start Node from the app instead of running a shell script.
- The app uses an embedded local runtime and local persistence rather than a remote service.
- Existing SWRLZ server concepts are preserved as a compatibility baseline: status, health, missions, and nodes.
