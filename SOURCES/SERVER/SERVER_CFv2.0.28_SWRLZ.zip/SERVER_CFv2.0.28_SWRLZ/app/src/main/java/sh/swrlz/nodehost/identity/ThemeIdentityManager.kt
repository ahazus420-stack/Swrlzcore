package sh.swrlz.nodehost.identity

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import sh.swrlz.nodehost.R

/** Keeps launcher, bubble, shortcut, and notification identity synchronized with Theme Armor. */
object ThemeIdentityManager {
    private enum class Alias(val componentClass: String, val iconRes: Int) {
        GlitchDragon("sh.swrlz.nodehost.launcher.GlitchDragon", R.mipmap.ic_launcher_glitch_dragon),
        OriginalCore("sh.swrlz.nodehost.launcher.OriginalCore", R.mipmap.ic_launcher_original_core),
        GlitchNeon("sh.swrlz.nodehost.launcher.GlitchNeon", R.mipmap.ic_launcher_glitch_neon),
        PharaohEmerald("sh.swrlz.nodehost.launcher.PharaohEmerald", R.mipmap.ic_launcher_pharaoh_emerald),
        VoidJester("sh.swrlz.nodehost.launcher.VoidJester", R.mipmap.ic_launcher_void_jester);
    }

    fun apply(context: Context, themeFamily: String) {
        val selected = when (themeFamily) {
        "Glitch Dragon Glass" -> Alias.GlitchDragon
        "Original Core" -> Alias.OriginalCore
        "Glitch Neon" -> Alias.GlitchNeon
        "Pharaoh Emerald" -> Alias.PharaohEmerald
        "Void Jester" -> Alias.VoidJester
            else -> Alias.GlitchDragon
        }
        Alias.entries.forEach { alias ->
            val state = if (alias == selected)
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            context.packageManager.setComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
                state,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    fun activeIconResource(context: Context): Int =
        Alias.entries.firstOrNull { alias ->
            context.packageManager.getComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
            ) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        }?.iconRes ?: Alias.GlitchDragon.iconRes

    fun iconResource(themeFamily: String): Int = when (themeFamily) {
        "Glitch Dragon Glass" -> Alias.GlitchDragon
        "Original Core" -> Alias.OriginalCore
        "Glitch Neon" -> Alias.GlitchNeon
        "Pharaoh Emerald" -> Alias.PharaohEmerald
        "Void Jester" -> Alias.VoidJester
        else -> Alias.GlitchDragon
    }.iconRes

    fun accentColor(themeFamily: String): Int = when (themeFamily) {
        "Original Core" -> 0xFFA073FF.toInt()
        "Glitch Neon" -> 0xFFFF2DDC.toInt()
        "Pharaoh Emerald" -> 0xFF00E691.toInt()
        "Void Jester" -> 0xFFB150FF.toInt()
        else -> 0xFF00D2FF.toInt()
    }
}
