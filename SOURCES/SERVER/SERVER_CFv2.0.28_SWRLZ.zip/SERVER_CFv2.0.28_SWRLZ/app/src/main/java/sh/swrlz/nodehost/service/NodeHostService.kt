package sh.swrlz.nodehost.service

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.R
import sh.swrlz.nodehost.identity.ThemeIdentityManager
import sh.swrlz.nodehost.bubble.ServerBubbleController
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.data.repository.NodeRepository
import sh.swrlz.nodehost.ui.SwurlzerUiPreferences

@AndroidEntryPoint
class NodeHostService : Service() {
    @Inject lateinit var nodeRuntime: NodeRuntime
    @Inject lateinit var nodeRepository: NodeRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        NodeHostNotificationChannel.ensure(this)
        startForeground(
            NOTIFICATION_ID,
            buildNotification(
                health = NodeHealth(runtimeStatus = RuntimeStatus.STARTING),
                nodes = emptyList(),
                enhanced = true,
                themeFamily = "Glitch Dragon Glass",
                themeVariant = "Dark",
            ),
        )

        serviceScope.launch {
            combine(
                nodeRuntime.health,
                nodeRepository.observeNodes(),
                SwurlzerUiPreferences.statusNotificationEnabledFlow(this@NodeHostService),
                SwurlzerUiPreferences.themeFamilyFlow(this@NodeHostService),
                SwurlzerUiPreferences.themeVariantFlow(this@NodeHostService),
            ) { health, nodes, enhanced, family, variant ->
                NotificationState(health, nodes, enhanced, family, variant)
            }.collectLatest { state ->
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(
                    NOTIFICATION_ID,
                    buildNotification(state.health, state.nodes, state.enhanced, state.themeFamily, state.themeVariant),
                )
                if (state.enhanced) {
                    val online = state.nodes.count { it.connectionState in setOf("CONNECTED", "BUSY") }
                    ServerBubbleController.publish(
                        this@NodeHostService,
                        title = "SWRLZ Server · $online online",
                        detail = "${state.nodes.size} registered · ${state.health.runtimeStatus.name}",
                    )
                } else {
                    ServerBubbleController.cancel(this@NodeHostService)
                }
            }
        }
        serviceScope.launch {
            nodeRuntime.start()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        nodeRuntime.stop()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(
        health: NodeHealth,
        nodes: List<NodeEntity>,
        enhanced: Boolean,
        themeFamily: String,
        themeVariant: String,
    ): Notification {
        val text = when (health.runtimeStatus) {
            RuntimeStatus.STARTING -> "Starting local node runtime"
            RuntimeStatus.RUNNING -> "Private and discovery listeners active"
            RuntimeStatus.DEGRADED -> "Loopback active; LAN discovery unavailable"
            RuntimeStatus.MAINTENANCE -> "Maintenance mode; normal work paused"
            RuntimeStatus.RELOADING_CONFIGURATION -> "Reloading configuration"
            RuntimeStatus.RESTARTING_SERVICES -> "Restarting services"
            RuntimeStatus.SHUTTING_DOWN -> "Shutdown sequence ${health.shutdownStep}/10"
            RuntimeStatus.FAILED -> "Runtime failed: ${health.lastFailure?.stage ?: "startup"}"
            RuntimeStatus.STOPPED -> "Local node runtime stopped"
        }
        val onlineCount = nodes.count { it.connectionState in setOf("CONNECTED", "BUSY") }
        val offlineCount = nodes.count { it.connectionState == "OFFLINE" }
        val expanded = buildString {
            if (enhanced) {
                append("Nodes: ").append(onlineCount).append(" ONLINE · ")
                    .append(offlineCount).append(" OFFLINE · ")
                    .append(nodes.size).append(" REGISTERED\n")
            }
            append(text)
            if (enhanced) {
                append("\nPrivate API: ").append(health.privateApi.status.name)
                append(" · Discovery: ").append(health.discoveryLoopback.status.name)
                append("\nLAN listener: ").append(health.discoveryLan.status.name)
                append("\nTheme armor: ").append(themeFamily).append(" · ").append(themeVariant)
            }
        }
        return NotificationCompat.Builder(this, NodeHostNotificationChannel.CHANNEL_ID)
            .setContentTitle(if (enhanced) "Ω  SWURLZ Server · ${health.runtimeStatus.name}" else "SWRLZ Server active")
            .setContentText(if (enhanced) "$onlineCount online · ${nodes.size} registered" else text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(expanded))
            .setSubText(if (enhanced) "Glitch Dragon Core" else null)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setColor(ThemeIdentityManager.accentColor(themeFamily))
            .setColorized(false)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(health.runtimeStatus != RuntimeStatus.FAILED && health.runtimeStatus != RuntimeStatus.STOPPED)
            .build()
    }

    private data class NotificationState(
        val health: NodeHealth,
        val nodes: List<NodeEntity>,
        val enhanced: Boolean,
        val themeFamily: String,
        val themeVariant: String,
    )

    companion object {
        private const val NOTIFICATION_ID = 1
    }
}
