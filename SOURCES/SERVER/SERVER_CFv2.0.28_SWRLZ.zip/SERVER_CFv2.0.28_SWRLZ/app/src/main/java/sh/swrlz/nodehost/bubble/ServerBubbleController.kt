package sh.swrlz.nodehost.bubble

import android.content.LocusId
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat
import sh.swrlz.nodehost.identity.ThemeIdentityManager

object ServerBubbleController {
    private const val CHANNEL_ID = "swurlz_server_conversation"
    private const val NOTIFICATION_ID = 110
    private const val SHORTCUT_ID = "swurlz_server_chat"

    fun publish(context: Context, title: String, detail: String, autoExpand: Boolean = false) {
        ensureChannel(context)

        val bubbleIntent = Intent(context, ServerBubbleActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
            .putExtra("status", detail)

        val bubblePendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            bubbleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE,
        )

        val appIconResource = ThemeIdentityManager.activeIconResource(context)
        val shortcutIcon = Icon.createWithResource(context, appIconResource)
        val compatIcon = IconCompat.createWithResource(context, appIconResource)

        val person = Person.Builder()
            .setName("SWRLZ Server")
            .setIcon(compatIcon)
            .setImportant(true)
            .setKey(SHORTCUT_ID)
            .build()

        publishConversationShortcut(
            context = context,
            intent = bubbleIntent,
            shortcutIcon = shortcutIcon,
        )

        val style = NotificationCompat.MessagingStyle(person)
            .setConversationTitle(title)
            .setGroupConversation(false)
            .addMessage(detail, System.currentTimeMillis(), person)

        val bubbleMetadata = NotificationCompat.BubbleMetadata.Builder(
            bubblePendingIntent,
            compatIcon,
        )
            .setDesiredHeight(720)
            .setAutoExpandBubble(autoExpand)
            .setSuppressNotification(autoExpand)
            .build()

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(appIconResource)
            .setContentTitle(title)
            .setContentText(detail)
            .setContentIntent(bubblePendingIntent)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setShortcutId(SHORTCUT_ID)
            .setStyle(style)
            .setBubbleMetadata(bubbleMetadata)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }

    fun showNow(
        context: Context,
        title: String = "SWRLZ Server",
        detail: String = "Server command link ready",
    ) {
        publish(context, title, detail, autoExpand = true)
    }

    fun openBubbleSettings(context: Context) {
        publish(
            context = context,
            title = "SWRLZ Server",
            detail = "Server command link ready",
            autoExpand = false,
        )
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_BUBBLE_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
        } else {
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    private fun publishConversationShortcut(
        context: Context,
        intent: Intent,
        shortcutIcon: Icon,
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N_MR1) return
        val builder = ShortcutInfo.Builder(context, SHORTCUT_ID)
            .setShortLabel("SWRLZ Server Chat")
            .setLongLabel("SWRLZ Server")
            .setLongLived(true)
            .setIcon(shortcutIcon)
            .setIntent(intent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val platformPerson = android.app.Person.Builder()
                .setName("SWRLZ Server")
                .setImportant(true)
                .build()
            builder
                .setPersons(arrayOf(platformPerson))
                .setLocusId(LocusId(SHORTCUT_ID))
        }

        context.getSystemService(ShortcutManager::class.java)
            ?.pushDynamicShortcut(builder.build())
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SWRLZ Server Chat",
                NotificationManager.IMPORTANCE_HIGH,
            ).apply {
                description = "Conversation bubbles for server chat, node status, and approvals."
                setAllowBubbles(true)
            }
            manager.createNotificationChannel(channel)
        }
    }
}
