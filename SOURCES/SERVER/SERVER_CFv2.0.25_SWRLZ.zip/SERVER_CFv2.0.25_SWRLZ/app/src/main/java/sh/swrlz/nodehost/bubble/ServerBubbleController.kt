package sh.swrlz.nodehost.bubble

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat

object ServerBubbleController {
    private const val CHANNEL_ID = "swurlz_server_conversation"
    private const val NOTIFICATION_ID = 110
    private const val SHORTCUT_ID = "swurlz_server_chat"

    fun publish(context: Context, title: String, detail: String, autoExpand: Boolean = false) {
        ensureChannel(context)

        val bubbleIntent = Intent(context, ServerBubbleActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
            .putExtra("status", detail)
        val bubblePendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            bubbleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE,
        )

        val appIconResource = context.applicationInfo.icon
        val shortcutIcon = Icon.createWithResource(context, appIconResource)
        val compatIcon = IconCompat.createWithResource(context, appIconResource)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            val shortcut = ShortcutInfo.Builder(context, SHORTCUT_ID)
                .setShortLabel("Server Chat")
                .setLongLived(true)
                .setIcon(shortcutIcon)
                .setIntent(bubbleIntent)
                .build()
            context.getSystemService(ShortcutManager::class.java)
                ?.pushDynamicShortcut(shortcut)
        }

        val person = Person.Builder()
            .setName("SWRLZ Server")
            .setIcon(compatIcon)
            .setImportant(true)
            .build()

        val style = NotificationCompat.MessagingStyle(person)
            .setConversationTitle(title)
            .addMessage(detail, System.currentTimeMillis(), person)

        val bubbleMetadata = NotificationCompat.BubbleMetadata.Builder(
            bubblePendingIntent,
            compatIcon,
        )
            .setDesiredHeight(640)
            .setAutoExpandBubble(autoExpand)
            .setSuppressNotification(false)
            .build()

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(appIconResource)
            .setContentTitle(title)
            .setContentText(detail)
            .setContentIntent(bubblePendingIntent)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setShortcutId(SHORTCUT_ID)
            .setStyle(style)
            .setBubbleMetadata(bubbleMetadata)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }


    fun showNow(context: Context, title: String = "SWRLZ Server", detail: String = "Server command link ready") {
        publish(context, title, detail, autoExpand = true)
    }

    fun openBubbleSettings(context: Context) {
        val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_BUBBLE_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
        } else {
            Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SWRLZ Server Chat",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Conversation bubbles for server chat, node status, and approvals."
                setAllowBubbles(true)
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}
