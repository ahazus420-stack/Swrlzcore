## Permission priority, live node status, and explicit bubble controls

- Moved the sideloaded-app restricted-settings guide to the top of the Client Permission Centre.
- Added authoritative online/offline/registered node totals to the Server notification.
- Added explicit Client server-connection evidence to its notification.
- Added manual Floating Dragon launch and Android bubble-settings controls.
- Connected the Client telemetry side puck and strip to Floating Dragon.
- Corrected the Server bubble namespace and connected it to live runtime/node state.
- Documented the release in ADR-0022 and INT-UX-033A.

## Floating Dragon bubble release

## Floating Dragon build correction

- Corrected AndroidX conversation Person and IconCompat usage.
- Corrected client permission-route compilation.
- Removed fragile server generated-class dependencies from the bubble feature.


- Added Android-native conversation bubbles for compact SWRLZ chat and mission/server status.
- Added dedicated resizeable bubble activities and long-lived conversation shortcuts.
- Preserved full-app authority for sensitive actions.
- Documented phased chat transport boundaries in ADR-0021.

# Changelog

## INT-UX-031A

- Moved Accept All to the client first-mission acknowledgement screen.
- Restored the Android permission centre workflow.
- Added default-on, theme-aware client/server notification status widgets.
- Preserved Android's mandatory server foreground-service notification.

# SERVER CFv2.0.20 (2026-07-23)

- Transactional reinstall reconciliation by recovery digest.
- Canonical node IDs survive uninstall/reinstall.
- Recovered installations require trust reapproval unless proof is presented.
- Protocol v2 supported with protocol v1 compatibility.

# SERVER CFv2.0.17 — INT-FIX-026C

- Repaired SERVER group-list dispatch.
- Added canonical role, membership-state, leader, and member-count data.
- Added live roster retrieval and readable CLIENT synchronization errors.
- Prevented failed group requests from being labeled synchronized.

# INT-UX-026A — Navigation and Groups Workspace

- Added horizontally swipeable bottom navigation.
- Added a dedicated Groups destination.
- Added richer group creation, join, inspection, synchronization, and assignment UI while preserving SERVER authority.
- Advanced package identity to CFv2.0.16.
- No APK build or runtime verification was performed.

# SERVER CFv2.0.15

- Completed visible group-management dialogs, lists, assignment controls, and immediate post-mutation refresh.
- Corrected prior foundation-only UI claims.

# Changelog

## SERVER CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.
## CFv2.0.21
- Installable-update version bump, stable signing configuration, first-run permissions, and start-on-launch.