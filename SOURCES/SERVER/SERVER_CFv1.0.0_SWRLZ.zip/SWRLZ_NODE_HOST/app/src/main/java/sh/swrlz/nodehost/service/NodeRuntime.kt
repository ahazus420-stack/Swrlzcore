package sh.swrlz.nodehost.service

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean

class NodeRuntime(private val context: Context) {
    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var serverThread: Thread? = null

    fun start() {
        if (running.getAndSet(true)) return

        serverThread = Thread {
            try {
                serverSocket = ServerSocket(8080, 50, InetAddress.getLoopbackAddress())
                while (running.get()) {
                    val clientSocket = serverSocket?.accept() ?: break
                    clientSocket.use { socket ->
                        val reader = BufferedReader(InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8))
                        val requestLine = reader.readLine() ?: return@use
                        val path = requestLine.split(" ").getOrNull(1)?.substringBefore('?') ?: "/"
                        val payload = when (path) {
                            "/status" -> "{\"ok\":true,\"node\":\"SWRLZ Node Host\",\"mode\":\"embedded\"}"
                            "/health" -> "healthy"
                            else -> "not found"
                        }.toByteArray(StandardCharsets.UTF_8)

                        val response = buildResponse(payload, if (path == "/status" || path == "/health") 200 else 404)
                        socket.getOutputStream().use { output ->
                            output.write(response)
                            output.flush()
                        }
                    }
                }
            } catch (_: Exception) {
                running.set(false)
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        if (!running.getAndSet(false)) return
        serverSocket?.close()
        serverThread?.interrupt()
        serverSocket = null
        serverThread = null
    }

    private fun buildResponse(payload: ByteArray, statusCode: Int): ByteArray {
        val statusText = if (statusCode == 200) "OK" else "NOT FOUND"
        val headers = "HTTP/1.1 $statusCode $statusText\r\n" +
            "Content-Type: text/plain; charset=utf-8\r\n" +
            "Content-Length: ${payload.size}\r\n" +
            "Connection: close\r\n\r\n"
        return headers.toByteArray(StandardCharsets.UTF_8) + payload
    }
}
