# API

## Endpoints
- GET /status -> Returns basic node status information.
- GET /health -> Returns health check payload.

These endpoints are served by the embedded runtime in the Android app and are intended as the local server compatibility surface for SWRLZ node operations.
