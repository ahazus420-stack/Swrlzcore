# Architecture

## Layers
- UI: Jetpack Compose screens under app/src/main/java/sh/swrlz/nodehost/ui
- Domain/runtime: NodeRuntime, NodeHostService, and ViewModels
- Data: Room entities, DAOs, repository, and local database
- Platform: Android manifest, foreground service, notifications, and resources

## Runtime model
- The app hosts an embedded local server on localhost:8080 for status and health endpoints.
- Room persists nodes and missions locally for offline-first behavior.
- The UI exposes a mission-first dashboard for starting/stopping the node and viewing seeded demo data.
