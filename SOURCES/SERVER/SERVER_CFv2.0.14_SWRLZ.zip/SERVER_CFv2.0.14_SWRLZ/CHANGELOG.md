# Changelog

## SERVER CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.
