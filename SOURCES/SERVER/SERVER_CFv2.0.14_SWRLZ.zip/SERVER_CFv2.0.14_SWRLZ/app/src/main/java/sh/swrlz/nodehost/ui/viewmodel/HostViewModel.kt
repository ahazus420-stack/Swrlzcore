package sh.swrlz.nodehost.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.data.entity.GroupEntity
import sh.swrlz.nodehost.data.repository.NodeRepository
import sh.swrlz.nodehost.service.NodeHealth
import sh.swrlz.nodehost.service.NodeRuntime
import sh.swrlz.nodehost.service.RuntimeDiagnosticSnapshot
import sh.swrlz.nodehost.service.NodeService

@HiltViewModel
class HostViewModel @Inject constructor(
    private val repository: NodeRepository,
    private val nodeService: NodeService,
    private val nodeRuntime: NodeRuntime,
) : ViewModel() {
    private val _state = MutableStateFlow(HostUiState())
    val state: StateFlow<HostUiState> = _state

    init {
        viewModelScope.launch {
            repository.observeNodes().collect { nodes ->
                _state.value = _state.value.copy(nodes = nodes)
            }
        }
        viewModelScope.launch {
            repository.observeGroups().collect { groups -> _state.value = _state.value.copy(groups = groups) }
        }
        viewModelScope.launch {
            repository.observeMissions().collect { missions ->
                _state.value = _state.value.copy(missions = missions)
            }
        }
        viewModelScope.launch {
            nodeRuntime.health.collect { health ->
                _state.value = _state.value.copy(health = health)
            }
        }
        viewModelScope.launch {
            nodeRuntime.diagnosticSnapshot.collect { diagnostics ->
                _state.value = _state.value.copy(diagnostics = diagnostics)
            }
        }
    }

    fun startNode() = nodeService.start()

    fun stopNode() = nodeService.stop()
    fun enterMaintenance() = nodeService.enterMaintenance()
    fun reloadConfiguration() = nodeService.reloadConfiguration()
    fun restartServices() = nodeService.restartServices()

    fun clearDiagnostics() = nodeRuntime.clearDiagnostics()
    fun disconnectNode(node: NodeEntity) = viewModelScope.launch {
        repository.upsertNode(node.copy(connectionState="DISCONNECTED_ADMIN", status="DISCONNECTED_ADMIN", lastSeen=System.currentTimeMillis()))
        _state.value = _state.value.copy(message="${node.label} disconnected; registration and lineage retained")
    }

    fun seedDemoData() {
        viewModelScope.launch {
            repository.upsertNode(NodeEntity("node-01", "Glitch Dragon", "online", "mission,discovery", "trusted", System.currentTimeMillis()))
            repository.upsertMission(MissionEntity("mission-01", "Reconnaissance", "Queued", "High", System.currentTimeMillis(), System.currentTimeMillis()))
            _state.value = _state.value.copy(message = "Demo data seeded")
        }
    }
}

data class HostUiState(
    val health: NodeHealth = NodeHealth(),
    val diagnostics: RuntimeDiagnosticSnapshot = RuntimeDiagnosticSnapshot(),
    val message: String? = null,
    val nodes: List<NodeEntity> = emptyList(),
    val missions: List<MissionEntity> = emptyList(),
    val groups: List<GroupEntity> = emptyList(),
)
