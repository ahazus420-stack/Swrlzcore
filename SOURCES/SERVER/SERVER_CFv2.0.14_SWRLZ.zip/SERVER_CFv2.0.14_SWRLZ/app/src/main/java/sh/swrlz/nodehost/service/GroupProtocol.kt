package sh.swrlz.nodehost.service
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import org.json.JSONObject
import sh.swrlz.nodehost.data.entity.*
import sh.swrlz.nodehost.data.repository.NodeRepository
object GroupProtocol {
 const val CREATE="/v1/groups/create"; const val ROTATE="/v1/groups/invite/rotate"; const val JOIN="/v1/groups/join"; const val DECIDE="/v1/groups/join/decide"; const val ROSTER="/v1/groups/roster"
 fun handles(path:String)=path in setOf(CREATE,ROTATE,JOIN,DECIDE,ROSTER)
 private fun hash(code:String)=MessageDigest.getInstance("SHA-256").digest(code.uppercase().toByteArray()).joinToString(""){"%02x".format(it)}
 private fun code():String { val alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; val r=SecureRandom(); return "SWRL-"+(1..8).map{alphabet[r.nextInt(alphabet.length)]}.joinToString("").chunked(4).joinToString("-") }
 private fun ok(body:String)=DiscoveryHttpResponse(200,"OK",body,mapOf("Cache-Control" to "no-store"))
 private fun err(status:Int, code:String, detail:String)=DiscoveryHttpResponse(status,if(status==409)"Conflict" else "Bad Request",JSONObject().put("ok",false).put("code",code).put("detail",detail).toString())
 internal suspend fun handle(request:DiscoveryHttpRequest, repo:NodeRepository, now:Long):DiscoveryHttpResponse {
  val j=runCatching{JSONObject(request.body)}.getOrElse{JSONObject()}
  return when(request.path){
   CREATE->{ val name=j.optString("name").trim(); val leader=j.optString("leaderNodeId"); if(name.length !in 3..48||leader.isBlank()) err(400,"INVALID_GROUP","Name must be 3-48 characters and leader required") else if(repo.findGroupByName(name)!=null) err(409,"GROUP_NAME_EXISTS","An active group already uses that name") else { val id="group-${UUID.randomUUID()}"; repo.createGroup(GroupEntity(id,name,name.lowercase(),leader,createdAt=now,updatedAt=now)); repo.upsertMembership(GroupMembershipEntity(id,leader,"OWNER","ACTIVE",now,now,leader)); ok(JSONObject().put("ok",true).put("groupId",id).put("name",name).toString())}}
   ROTATE->{ val groupId=j.optString("groupId"); val leader=j.optString("leaderNodeId"); val g=repo.findGroup(groupId)?:return err(400,"GROUP_NOT_FOUND","Unknown group"); if(g.leaderNodeId!=leader) err(400,"LEADER_REQUIRED","Only group leader can rotate invite") else { repo.invalidateInvites(groupId); val raw=code(); val inv=GroupInviteEntity("invite-${UUID.randomUUID()}",groupId,hash(raw),raw.takeLast(4),leader,now,now+15*60_000,1,0,true,(j.optInt("generation",0)+1)); repo.upsertInvite(inv); ok(JSONObject().put("ok",true).put("inviteCode",raw).put("expiresAt",inv.expiresAt).toString())}}
   JOIN->{ val raw=j.optString("inviteCode"); val nodeId=j.optString("nodeId"); val inv=repo.findInvite(hash(raw))?:return err(400,"INVITE_INVALID","Invite is invalid or rotated"); if(inv.expiresAt<now||inv.uses>=inv.maxUses) return err(400,"INVITE_EXPIRED","Invite expired or exhausted"); val req=GroupJoinRequestEntity("join-${UUID.randomUUID()}",inv.groupId,nodeId,j.optString("nodeLabel"),j.optString("deviceType"),j.optString("capabilities"),j.optString("registrationState"),j.optString("trustState"),j.optString("proofState"),now); repo.upsertJoinRequest(req); ok(JSONObject().put("ok",true).put("code","PENDING_LEADER_APPROVAL").put("requestId",req.requestId).toString())}
   DECIDE->{ val req=repo.findJoinRequest(j.optString("requestId"))?:return err(400,"REQUEST_NOT_FOUND","Unknown join request"); val g=repo.findGroup(req.groupId)?:return err(400,"GROUP_NOT_FOUND","Unknown group"); val leader=j.optString("leaderNodeId"); if(g.leaderNodeId!=leader) err(400,"LEADER_REQUIRED","Leader approval required") else { val approve=j.optBoolean("approve"); repo.upsertJoinRequest(req.copy(state=if(approve)"APPROVED" else "DENIED",decidedAt=now,decidedBy=leader)); if(approve) repo.upsertMembership(GroupMembershipEntity(req.groupId,req.nodeId,"MEMBER","ACTIVE",now,now,leader)); ok(JSONObject().put("ok",true).put("state",if(approve)"ACTIVE" else "DENIED").toString())}}
   ROSTER->{ val groupId=j.optString("groupId"); val members=repo.members(groupId); ok(JSONObject().put("ok",true).put("groupId",groupId).put("members",org.json.JSONArray(members.map{JSONObject().put("nodeId",it.nodeId).put("role",it.role).put("state",it.membershipState)})).toString())}
   else->err(400,"NOT_FOUND","Unsupported group action")
  }
 }
}