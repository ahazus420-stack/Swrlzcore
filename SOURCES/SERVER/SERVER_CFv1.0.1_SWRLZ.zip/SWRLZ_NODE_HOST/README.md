# SWRLZ Node Host

This directory contains a production-oriented Android Studio project for the SWRLZ Node Host application.

## What is included
- Kotlin + Jetpack Compose UI
- Room-backed persistence for nodes and missions
- Foreground service entry point
- Embedded local HTTP server runtime
- Basic theme, permissions, diagnostics, and mission views
- Build scripts and Android manifest

## Build status
The project structure and source files are in place, but full Gradle build verification in this container is currently blocked by environment-level Gradle daemon crashes during the Android/Kotlin compile phase. The project is organized for Android Studio import and GitHub Actions, but the build must be re-run in a stable local or CI environment to complete APK generation.
