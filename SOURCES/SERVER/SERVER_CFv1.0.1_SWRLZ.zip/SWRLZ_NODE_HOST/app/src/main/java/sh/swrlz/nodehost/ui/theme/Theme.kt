package sh.swrlz.nodehost.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6A5CFF),
    secondary = Color(0xFF00D1FF),
    tertiary = Color(0xFFFF6B6B),
    background = Color(0xFF060816),
    surface = Color(0xFF101426),
    onPrimary = Color.White,
    onBackground = Color(0xFFECEEFF),
    onSurface = Color(0xFFECEEFF),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF6A5CFF),
    secondary = Color(0xFF00D1FF),
    tertiary = Color(0xFFFF6B6B),
    background = Color(0xFFF5F7FF),
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = Color(0xFF0D1120),
    onSurface = Color(0xFF0D1120),
)

@Composable
fun SwrlzTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
