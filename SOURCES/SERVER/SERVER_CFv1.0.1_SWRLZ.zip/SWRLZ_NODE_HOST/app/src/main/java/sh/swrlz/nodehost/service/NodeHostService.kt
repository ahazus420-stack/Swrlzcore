package sh.swrlz.nodehost.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.R

class NodeHostService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        NodeHostNotificationChannel.ensure(this)
        startForeground(1, buildNotification())
        serviceScope.launch {
            // Placeholder runtime loop for the embedded node host.
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.coroutineContext.cancelChildren()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): android.app.Notification {
        return NotificationCompat.Builder(this, "node_host")
            .setContentTitle("SWRLZ Node Host")
            .setContentText("Local node runtime is active")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .build()
    }
}
