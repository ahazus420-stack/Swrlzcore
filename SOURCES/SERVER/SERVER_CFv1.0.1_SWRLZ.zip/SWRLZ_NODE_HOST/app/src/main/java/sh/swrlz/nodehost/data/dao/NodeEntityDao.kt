package sh.swrlz.nodehost.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.entity.NodeEntity

@Dao
interface NodeEntityDao {
    @Query("SELECT * FROM nodes ORDER BY lastSeen DESC")
    fun observeNodes(): Flow<List<NodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(node: NodeEntity)
}
