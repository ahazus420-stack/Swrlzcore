package sh.swrlz.nodehost.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.ui.viewmodel.HostViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostScreen(viewModel: HostViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState()

    Scaffold(topBar = {
        TopAppBar(title = { Text("SWRLZ Node Host") })
    }) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Mission-first local node runtime", style = MaterialTheme.typography.headlineMedium)
                Text("Offline-first, discovery-ready, and compatible with the SWRLZ local node server concepts.")
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.startNode() }) { Text("Start Node") }
                    Button(onClick = { viewModel.stopNode() }) { Text("Stop Node") }
                    Button(onClick = { viewModel.seedDemoData() }) { Text("Seed Demo Data") }
                    Text("Status: ${state.status}")
                }
            }
            item {
                Text("Known Nodes", style = MaterialTheme.typography.titleMedium)
            }
            items(state.nodes) { node ->
                NodeCard(node)
            }
            item {
                Text("Missions", style = MaterialTheme.typography.titleMedium)
            }
            items(state.missions) { mission ->
                MissionCard(mission)
            }
        }
    }
}

@Composable
private fun NodeCard(node: NodeEntity) {
    Card(modifier = Modifier.padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(node.label)
            Text("Status: ${node.status} | Trust: ${node.trust}")
            Text("Capabilities: ${node.capabilities}")
        }
    }
}

@Composable
private fun MissionCard(mission: MissionEntity) {
    Card(modifier = Modifier.padding(vertical = 4.dp)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(mission.title)
            Text("State: ${mission.state} | Priority: ${mission.priority}")
        }
    }
}
