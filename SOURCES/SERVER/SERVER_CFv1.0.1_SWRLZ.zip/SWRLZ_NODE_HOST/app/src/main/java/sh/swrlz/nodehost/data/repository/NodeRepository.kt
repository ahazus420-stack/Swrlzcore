package sh.swrlz.nodehost.data.repository

import kotlinx.coroutines.flow.Flow
import sh.swrlz.nodehost.data.NodeHostDatabase
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity

class NodeRepository(private val db: NodeHostDatabase) {
    fun observeNodes(): Flow<List<NodeEntity>> = db.nodeEntityDao().observeNodes()

    suspend fun upsertNode(node: NodeEntity) = db.nodeEntityDao().upsert(node)

    fun observeMissions(): Flow<List<MissionEntity>> = db.missionEntityDao().observeMissions()

    suspend fun upsertMission(mission: MissionEntity) = db.missionEntityDao().upsert(mission)
}
