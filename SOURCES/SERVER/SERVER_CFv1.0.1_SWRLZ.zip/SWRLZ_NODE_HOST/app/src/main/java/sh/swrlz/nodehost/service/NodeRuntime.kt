package sh.swrlz.nodehost.service

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

class NodeRuntime(context: Context) {
    private val appContext = context.applicationContext
    private val running = AtomicBoolean(false)
    private val identityStore = NodeIdentityStore(appContext)

    @Volatile
    private var activeIdentity: NodeHostIdentity? = null

    @Volatile
    private var hostVersion: String = ""

    private var privateServerSocket: ServerSocket? = null
    private var privateServerThread: Thread? = null
    private val discoverySockets = CopyOnWriteArrayList<ServerSocket>()
    private val discoveryThreads = CopyOnWriteArrayList<Thread>()

    @Synchronized
    fun start() {
        if (!running.compareAndSet(false, true)) return

        try {
            val identity = identityStore.loadOrCreate()
            val version = resolveHostVersion()

            val privateSocket = ServerSocket(PRIVATE_PORT, BACKLOG, InetAddress.getLoopbackAddress())
            val localDiscoverySockets = bindDiscoverySockets()
            if (localDiscoverySockets.isEmpty()) {
                privateSocket.close()
                throw IllegalStateException("No approved IPv4 discovery interface is available")
            }

            activeIdentity = identity
            hostVersion = version
            privateServerSocket = privateSocket
            discoverySockets.addAll(localDiscoverySockets)

            privateServerThread = listenerThread("swrlz-private-runtime") {
                servePrivateRuntime(privateSocket)
            }
            privateServerThread?.start()

            localDiscoverySockets.forEach { socket ->
                val address = socket.inetAddress.hostAddress ?: "unknown"
                listenerThread("swrlz-discovery-$address") {
                    serveDiscovery(socket)
                }.also { thread ->
                    discoveryThreads += thread
                    thread.start()
                }
            }
        } catch (_: Exception) {
            running.set(false)
            closeResources()
        }
    }

    @Synchronized
    fun stop() {
        if (!running.getAndSet(false)) return
        closeResources()
    }

    private fun servePrivateRuntime(server: ServerSocket) {
        while (running.get()) {
            val client = try {
                server.accept()
            } catch (_: SocketException) {
                break
            } catch (_: Exception) {
                if (!running.get()) break else continue
            }
            try {
                client.use(::handlePrivateClient)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private fun handlePrivateClient(socket: Socket) {
        socket.soTimeout = SOCKET_TIMEOUT_MS
        val requestLine = readHttpLine(socket.getInputStream(), MAX_REQUEST_LINE_BYTES) ?: return
        val path = requestLine.split(' ').getOrNull(1)?.substringBefore('?') ?: "/"
        val payload = when (path) {
            "/status" -> "{\"ok\":true,\"node\":\"SWRLZ Node Host\",\"mode\":\"embedded\"}"
            "/health" -> "healthy"
            else -> "not found"
        }.toByteArray(StandardCharsets.UTF_8)
        val statusCode = if (path == "/status" || path == "/health") 200 else 404
        socket.getOutputStream().use { output ->
            output.write(buildPrivateResponse(payload, statusCode))
            output.flush()
        }
    }

    private fun serveDiscovery(server: ServerSocket) {
        while (running.get()) {
            val client = try {
                server.accept()
            } catch (_: SocketException) {
                break
            } catch (_: Exception) {
                if (!running.get()) break else continue
            }
            try {
                client.use(::handleDiscoveryClient)
            } catch (_: Exception) {
                if (!running.get()) break
            }
        }
    }

    private fun handleDiscoveryClient(socket: Socket) {
        socket.soTimeout = SOCKET_TIMEOUT_MS
        val response = try {
            val request = parseDiscoveryRequest(socket.getInputStream())
            DiscoveryProtocol.handle(request, activeIdentity, hostVersion)
        } catch (_: BadHttpRequest) {
            DiscoveryHttpResponse(
                statusCode = 400,
                reason = "Bad Request",
                body = "{\"ok\":false,\"error\":{\"code\":\"BAD_REQUEST\",\"message\":\"Malformed discovery request\"},\"protocolVersion\":1,\"schemaVersion\":1}",
                headers = mapOf("Cache-Control" to "no-store"),
            )
        } catch (_: Exception) {
            DiscoveryHttpResponse(
                statusCode = 500,
                reason = "Internal Server Error",
                body = "{\"ok\":false,\"error\":{\"code\":\"DISCOVERY_ERROR\",\"message\":\"Discovery response unavailable\"},\"protocolVersion\":1,\"schemaVersion\":1}",
                headers = mapOf("Cache-Control" to "no-store"),
            )
        }

        socket.getOutputStream().use { output ->
            output.write(buildDiscoveryResponse(response))
            output.flush()
        }
    }

    private fun parseDiscoveryRequest(input: InputStream): DiscoveryHttpRequest {
        val requestLine = readHttpLine(input, MAX_REQUEST_LINE_BYTES) ?: throw BadHttpRequest()
        val parts = requestLine.split(' ')
        if (parts.size != 3 || !parts[2].startsWith("HTTP/1.")) throw BadHttpRequest()

        val target = parts[1]
        if (!target.startsWith('/')) throw BadHttpRequest()
        val headers = linkedMapOf<String, String>()
        var totalHeaderBytes = 0

        repeat(MAX_HEADER_COUNT) {
            val line = readHttpLine(input, MAX_HEADER_LINE_BYTES) ?: throw BadHttpRequest()
            totalHeaderBytes += line.length
            if (totalHeaderBytes > MAX_TOTAL_HEADER_BYTES) throw BadHttpRequest()
            if (line.isEmpty()) {
                val rawContentLength = headers["content-length"]
                val contentLength = when {
                    rawContentLength == null -> 0L
                    else -> rawContentLength.toLongOrNull() ?: throw BadHttpRequest()
                }
                if (contentLength < 0L || contentLength > MAX_REQUEST_BODY_BYTES) throw BadHttpRequest()
                return DiscoveryHttpRequest(
                    method = parts[0],
                    path = target.substringBefore('?'),
                    headers = headers,
                    contentLength = contentLength,
                )
            }

            val separator = line.indexOf(':')
            if (separator <= 0) throw BadHttpRequest()
            val name = line.substring(0, separator).trim().lowercase(Locale.US)
            val value = line.substring(separator + 1).trim()
            if (name.isEmpty()) throw BadHttpRequest()
            headers[name] = headers[name]?.let { "$it,$value" } ?: value
        }
        throw BadHttpRequest()
    }

    /**
     * Binds loopback plus explicit local-link interface addresses. It never uses
     * 0.0.0.0, and it excludes known cellular, VPN, and tunnel interface names.
     */
    private fun bindDiscoverySockets(): List<ServerSocket> {
        val addresses = approvedDiscoveryAddresses()
        val loopback = addresses.firstOrNull { it is Inet4Address && it.isLoopbackAddress }
            ?: return emptyList()
        val loopbackSocket = bindDiscoverySocket(loopback) ?: return emptyList()
        val sockets = mutableListOf(loopbackSocket)

        addresses.asSequence()
            .filterNot(InetAddress::isLoopbackAddress)
            .forEach { address ->
                bindDiscoverySocket(address)?.let(sockets::add)
            }
        return sockets
    }

    private fun bindDiscoverySocket(address: InetAddress): ServerSocket? = try {
        ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(address, DiscoveryProtocol.PORT), BACKLOG)
        }
    } catch (_: Exception) {
        // Approved addresses can disappear while Android changes network state.
        null
    }

    private fun approvedDiscoveryAddresses(): List<InetAddress> {
        val addresses = linkedMapOf<String, InetAddress>()
        val ipv4Loopback = InetAddress.getByAddress(byteArrayOf(127, 0, 0, 1))
        addresses[ipv4Loopback.hostAddress ?: "127.0.0.1"] = ipv4Loopback

        val interfaces = try {
            NetworkInterface.getNetworkInterfaces()
        } catch (_: SocketException) {
            null
        } ?: return addresses.values.toList()

        while (interfaces.hasMoreElements()) {
            val networkInterface = interfaces.nextElement()
            val name = networkInterface.name.lowercase(Locale.US)
            val usable = try {
                networkInterface.isUp && !networkInterface.isLoopback && !networkInterface.isVirtual
            } catch (_: SocketException) {
                false
            }
            if (!usable || isBlockedInterface(name) || !isApprovedLocalInterface(name)) continue

            val interfaceAddresses = networkInterface.inetAddresses
            while (interfaceAddresses.hasMoreElements()) {
                val address = interfaceAddresses.nextElement()
                if (address is Inet4Address &&
                    !address.isLoopbackAddress &&
                    (address.isSiteLocalAddress || address.isLinkLocalAddress)
                ) {
                    addresses[address.hostAddress] = address
                }
            }
        }
        return addresses.values.toList()
    }

    private fun isApprovedLocalInterface(name: String): Boolean = APPROVED_INTERFACE_PREFIXES.any(name::startsWith)

    private fun isBlockedInterface(name: String): Boolean = BLOCKED_INTERFACE_PREFIXES.any(name::startsWith)

    @Suppress("DEPRECATION")
    private fun resolveHostVersion(): String {
        val packageInfo = appContext.packageManager.getPackageInfo(appContext.packageName, 0)
        return packageInfo.versionName?.trim()?.takeIf(String::isNotEmpty)
            ?: throw IllegalStateException("NODE_HOST package version is unavailable")
    }

    private fun buildPrivateResponse(payload: ByteArray, statusCode: Int): ByteArray {
        val statusText = if (statusCode == 200) "OK" else "NOT FOUND"
        val headers = "HTTP/1.1 $statusCode $statusText\r\n" +
            "Content-Type: text/plain; charset=utf-8\r\n" +
            "Content-Length: ${payload.size}\r\n" +
            "Connection: close\r\n\r\n"
        return headers.toByteArray(StandardCharsets.UTF_8) + payload
    }

    private fun buildDiscoveryResponse(response: DiscoveryHttpResponse): ByteArray {
        val payload = response.body.toByteArray(StandardCharsets.UTF_8)
        val headers = buildString {
            append("HTTP/1.1 ${response.statusCode} ${response.reason}\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n")
            response.headers.forEach { (name, value) -> append("$name: $value\r\n") }
            append("Content-Length: ${payload.size}\r\n")
            append("Connection: close\r\n\r\n")
        }
        return headers.toByteArray(StandardCharsets.UTF_8) + payload
    }

    private fun readHttpLine(input: InputStream, maxBytes: Int): String? {
        val buffer = ByteArrayOutputStream()
        var sawAny = false
        while (true) {
            if (buffer.size() >= maxBytes) throw BadHttpRequest()
            val value = input.read()
            if (value == -1) return if (sawAny) buffer.toString(StandardCharsets.UTF_8.name()) else null
            sawAny = true
            if (value == '\n'.code) {
                val bytes = buffer.toByteArray()
                val length = if (bytes.isNotEmpty() && bytes.last() == '\r'.code.toByte()) bytes.size - 1 else bytes.size
                return String(bytes, 0, length, StandardCharsets.UTF_8)
            }
            buffer.write(value)
        }
    }

    private fun listenerThread(name: String, block: () -> Unit): Thread = Thread(block, name).apply {
        isDaemon = true
    }

    private fun closeResources() {
        privateServerSocket?.closeQuietly()
        discoverySockets.forEach { it.closeQuietly() }
        privateServerThread?.interrupt()
        discoveryThreads.forEach(Thread::interrupt)
        privateServerSocket = null
        privateServerThread = null
        discoverySockets.clear()
        discoveryThreads.clear()
        activeIdentity = null
        hostVersion = ""
    }

    private fun ServerSocket.closeQuietly() {
        try {
            close()
        } catch (_: Exception) {
            // Stop is idempotent.
        }
    }

    private class BadHttpRequest : Exception()

    companion object {
        private const val PRIVATE_PORT = 8080
        private const val BACKLOG = 50
        private const val SOCKET_TIMEOUT_MS = 2_000
        private const val MAX_REQUEST_LINE_BYTES = 4_096
        private const val MAX_HEADER_LINE_BYTES = 8_192
        private const val MAX_TOTAL_HEADER_BYTES = 16_384
        private const val MAX_HEADER_COUNT = 64
        private const val MAX_REQUEST_BODY_BYTES = 8_192L

        private val APPROVED_INTERFACE_PREFIXES = listOf(
            "wlan", "swlan", "ap", "eth", "en", "rndis", "usb", "bnep", "bt-pan",
        )
        private val BLOCKED_INTERFACE_PREFIXES = listOf(
            "rmnet", "ccmni", "pdp", "wwan", "tun", "tap", "ppp", "ipsec", "vti", "wg",
        )
    }
}
