package sh.swrlz.nodehost.ui

import androidx.compose.runtime.Composable

@Composable
fun NodeHostApp() {
    HostScreen()
}
