package sh.swrlz.nodehost.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "nodes")
data class NodeEntity(
    @PrimaryKey val nodeId: String,
    val label: String,
    val status: String,
    val capabilities: String,
    val trust: String,
    val lastSeen: Long,
)
