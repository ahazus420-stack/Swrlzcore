package sh.swrlz.nodehost.di

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import sh.swrlz.nodehost.data.NodeHostDatabase
import sh.swrlz.nodehost.data.repository.NodeRepository
import sh.swrlz.nodehost.service.NodeRuntime

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NodeHostDatabase {
        return Room.databaseBuilder(context, NodeHostDatabase::class.java, "swrlz_node_host.db")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideRepository(database: NodeHostDatabase): NodeRepository = NodeRepository(database)

    @Provides
    @Singleton
    fun provideNodeRuntime(@ApplicationContext context: Context): NodeRuntime = NodeRuntime(context)
}
