package sh.swrlz.nodehost.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.data.repository.NodeRepository
import sh.swrlz.nodehost.service.NodeRuntime

@HiltViewModel
class HostViewModel @Inject constructor(
    private val repository: NodeRepository,
    private val nodeRuntime: NodeRuntime,
) : ViewModel() {
    private val _state = MutableStateFlow(HostUiState())
    val state: StateFlow<HostUiState> = _state

    init {
        viewModelScope.launch {
            repository.observeNodes().collect { nodes ->
                _state.value = _state.value.copy(nodes = nodes)
            }
        }
        viewModelScope.launch {
            repository.observeMissions().collect { missions ->
                _state.value = _state.value.copy(missions = missions)
            }
        }
    }

    fun startNode() {
        nodeRuntime.start()
        _state.value = _state.value.copy(status = "Node running")
    }

    fun stopNode() {
        nodeRuntime.stop()
        _state.value = _state.value.copy(status = "Node stopped")
    }

    fun seedDemoData() {
        viewModelScope.launch {
            repository.upsertNode(NodeEntity("node-01", "Glitch Dragon", "online", "mission,discovery", "trusted", System.currentTimeMillis()))
            repository.upsertMission(MissionEntity("mission-01", "Reconnaissance", "Queued", "High", System.currentTimeMillis(), System.currentTimeMillis()))
            _state.value = _state.value.copy(status = "Demo data seeded")
        }
    }
}

data class HostUiState(
    val status: String = "Idle",
    val nodes: List<NodeEntity> = emptyList(),
    val missions: List<MissionEntity> = emptyList(),
)
