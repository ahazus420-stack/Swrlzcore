package sh.swrlz.nodehost.service

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NodeService @Inject constructor(@ApplicationContext private val context: Context) {
    fun start() {
        context.startService(android.content.Intent(context, NodeHostService::class.java))
    }

    fun stop() {
        context.stopService(android.content.Intent(context, NodeHostService::class.java))
    }
}
