package sh.swrlz.nodehost.data

import androidx.room.Database
import androidx.room.RoomDatabase
import sh.swrlz.nodehost.data.dao.NodeEntityDao
import sh.swrlz.nodehost.data.entity.NodeEntity
import sh.swrlz.nodehost.data.entity.MissionEntity
import sh.swrlz.nodehost.data.dao.MissionEntityDao

@Database(entities = [NodeEntity::class, MissionEntity::class], version = 1, exportSchema = false)
abstract class NodeHostDatabase : RoomDatabase() {
    abstract fun nodeEntityDao(): NodeEntityDao
    abstract fun missionEntityDao(): MissionEntityDao
}
