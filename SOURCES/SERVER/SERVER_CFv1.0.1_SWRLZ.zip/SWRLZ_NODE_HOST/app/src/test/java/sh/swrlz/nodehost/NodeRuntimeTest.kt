package sh.swrlz.nodehost

import org.junit.Test
import sh.swrlz.nodehost.service.NodeRuntime
import org.junit.Assert.assertTrue

class NodeRuntimeTest {
    @Test
    fun runtimeStartsAndStopsWithoutCrashing() {
        val runtime = NodeRuntime(androidx.test.core.app.ApplicationProvider.getApplicationContext())
        runtime.start()
        runtime.stop()
        assertTrue(true)
    }
}
