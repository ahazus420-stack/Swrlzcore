# Release Notes

## 1.0
- Initial Android Studio project for SWRLZ Node Host.
- Compose UI, Room persistence, foreground service, and embedded local runtime.
- Mission-first dashboard with node and mission state.
