package sh.swrlz.nodehost.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NodeService @Inject constructor(@ApplicationContext private val context: Context) {
    fun start() {
        ContextCompat.startForegroundService(context, Intent(context, NodeHostService::class.java))
    }

    fun stop() {
        context.stopService(Intent(context, NodeHostService::class.java))
    }
}
