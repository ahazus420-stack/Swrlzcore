package sh.swrlz.nodehost.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import sh.swrlz.nodehost.R
import sh.swrlz.nodehost.service.RuntimeStatus

internal enum class SwurlzerEnergyTarget(val x: Float, val y: Float) {
    Core(.63f, .55f),
    Nodes(.75f, .38f),
    Missions(.54f, .72f),
    Settings(.24f, .82f),
    Developer(.42f, .48f),
}

internal data class SwurlzerEnergySignal(
    val id: Int = 0,
    val target: SwurlzerEnergyTarget = SwurlzerEnergyTarget.Core,
)

internal data class SwurlzerVisualState(
    val runtimeStatus: RuntimeStatus = RuntimeStatus.STOPPED,
    val localLinkAvailable: Boolean = false,
    val trustedKnownNodePresent: Boolean = false,
    val missionActive: Boolean = false,
)

@Composable
internal fun SwurlzerBackdrop(
    motionEnabled: Boolean,
    state: SwurlzerVisualState,
    signal: SwurlzerEnergySignal = SwurlzerEnergySignal(),
    artAlpha: Float = .30f,
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var foreground by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, _ ->
            foreground = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (motionEnabled && foreground) {
        AnimatedSwurlzerScene(state, signal, artAlpha)
    } else {
        SwurlzerScene(state, signal.target, artAlpha, 0f, .94f, .36f, 0f)
    }
}

@Composable
private fun AnimatedSwurlzerScene(
    state: SwurlzerVisualState,
    signal: SwurlzerEnergySignal,
    artAlpha: Float,
) {
    val transition = rememberInfiniteTransition(label = "swurlzer-dragon-ambient")
    val drift by transition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(tween(18_000), RepeatMode.Reverse),
        label = "swurlzer-dragon-drift",
    )
    val breath by transition.animateFloat(
        initialValue = .89f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (state.missionActive) 2_600 else 5_400), RepeatMode.Reverse),
        label = "swurlzer-dragon-breath",
    )
    val shimmer by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(12_000), RepeatMode.Restart),
        label = "swurlzer-shimmer",
    )
    val energy = remember { Animatable(0f) }
    LaunchedEffect(signal.id) {
        if (signal.id <= 0) return@LaunchedEffect
        energy.snapTo(0f)
        energy.animateTo(1f, tween(220))
        energy.animateTo(0f, tween(460))
    }
    SwurlzerScene(state, signal.target, artAlpha, drift, breath, shimmer, energy.value)
}

@Composable
private fun SwurlzerScene(
    state: SwurlzerVisualState,
    target: SwurlzerEnergyTarget,
    artAlpha: Float,
    drift: Float,
    breath: Float,
    shimmer: Float,
    energy: Float,
) {
    val tone = swurlzerTone(state)
    val secondary = if (state.trustedKnownNodePresent) SwurlzerPalette.Trust else SwurlzerPalette.Violet
    val intensity by animateFloatAsState(
        targetValue = when (state.runtimeStatus) {
            RuntimeStatus.RUNNING -> 1.06f
            RuntimeStatus.STARTING -> 1f
            RuntimeStatus.DEGRADED -> .94f
            RuntimeStatus.FAILED -> .88f
            RuntimeStatus.STOPPED -> .82f
        },
        animationSpec = tween(300),
        label = "swurlzer-runtime-intensity",
    )
    val shards = remember {
        listOf(
            floatArrayOf(.86f, .18f, 22f, .58f),
            floatArrayOf(.79f, .32f, -28f, .40f),
            floatArrayOf(.91f, .76f, 70f, .46f),
        )
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.glitch_dragon_swurlzer),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                translationX = drift
                translationY = -drift * .25f
                scaleX = 1.075f
                scaleY = 1.075f
                alpha = artAlpha.coerceIn(0f, 1f) * breath * intensity
            },
        )
        Canvas(Modifier.fillMaxSize()) {
            val core = Offset(size.width * .65f, size.height * .58f)
            drawCircle(
                brush = Brush.radialGradient(listOf(tone.copy(alpha = .14f), Color.Transparent), core, size.minDimension * .31f),
                center = core,
                radius = size.minDimension * .31f,
            )
            shards.forEachIndexed { index, spec ->
                val wave = kotlin.math.sin(shimmer * 6.283f + index).toFloat()
                val x = size.width * spec[0]
                val y = size.height * spec[1] + wave * 5f
                val h = 42f * spec[3]
                val w = 12f * spec[3]
                val path = Path().apply {
                    moveTo(x, y - h / 2f)
                    lineTo(x + w / 2f, y + h * .2f)
                    lineTo(x, y + h / 2f)
                    lineTo(x - w / 2f, y + h * .2f)
                    close()
                }
                rotate(spec[2], Offset(x, y)) {
                    drawPath(path, Brush.linearGradient(listOf(tone, secondary)), alpha = .06f + .05f * (wave + 1f))
                }
            }
            if (energy > 0f) {
                val center = Offset(size.width * target.x, size.height * target.y)
                drawCircle(tone.copy(alpha = .20f * energy), 20f + 105f * energy, center, style = Stroke(3f))
                drawCircle(
                    Brush.radialGradient(listOf(tone.copy(alpha = .18f * energy), Color.Transparent), center, 94f),
                    94f,
                    center,
                )
                drawLine(secondary.copy(alpha = .28f * energy), center, core, 2f)
            }
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xA5050713), Color(0x7A050713), Color(0xE7070914)))
            )
        )
    }
}

@Composable
internal fun SwurlzerGlassPanel(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(22.dp)
    val border = Brush.linearGradient(
        if (highlighted) {
            listOf(SwurlzerPalette.Cyan, SwurlzerPalette.Violet, SwurlzerPalette.Blue)
        } else {
            listOf(SwurlzerPalette.Cyan.copy(alpha = .34f), Color(0xFF263B55).copy(alpha = .36f), SwurlzerPalette.Violet.copy(alpha = .28f))
        }
    )
    Box(modifier.background(border, shape).padding(1.dp)) {
        Column(
            Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(Color(0xC90A1120), Color(0xB3101830))), shape)
                .padding(15.dp),
            content = content,
        )
    }
}

internal object SwurlzerPalette {
    val Cyan = Color(0xFF38E8FF)
    val Blue = Color(0xFF5CA8FF)
    val Violet = Color(0xFF9A55FF)
    val Trust = Color(0xFF4DFFB4)
    val Amber = Color(0xFFFFD45A)
    val Danger = Color(0xFFFF4D68)
    val Text = Color(0xFFF7FBFF)
    val SecondaryText = Color(0xFFD7E7F5)
    val Muted = Color(0xFF91A9C0)
}

internal fun swurlzerTone(state: SwurlzerVisualState): Color = when (state.runtimeStatus) {
    RuntimeStatus.RUNNING -> SwurlzerPalette.Cyan
    RuntimeStatus.STARTING -> SwurlzerPalette.Blue
    RuntimeStatus.DEGRADED -> SwurlzerPalette.Amber
    RuntimeStatus.FAILED -> SwurlzerPalette.Danger
    RuntimeStatus.STOPPED -> Color(0xFF426983)
}
