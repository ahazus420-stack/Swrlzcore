# SWRLZ Swurlzer

This directory contains the production-oriented Android Studio project for the SWRLZ local node host. The user-facing product name is **Swurlzer**; source paths, package identity, and protocol-facing `NODE_HOST` terminology remain unchanged for compatibility.

## What is included
- Default Glitch Dragon Glass Swurlzer User Mode with Core, Nodes, Missions, and Settings
- Switchable Swurlzer Dev Mode preserving the complete legacy overview and diagnostics cockpit
- Persisted interface-mode and reduced-motion preferences
- Truthful runtime atmosphere derived from actual listener, stored-node, and stored-mission state
- Lifecycle-aware dragon drift, finite energy pulses, and static reduced-motion fallback
- New 4096×4096 Swurlzer launcher-icon master and Android launcher assets
- Kotlin + Jetpack Compose UI
- Room-backed persistence for nodes and missions
- Foreground service entry point
- Embedded private and local-link HTTP runtime
- Read-only CLIENT compatibility routes with authoritative-empty presence truth
- Deterministic Glitch Dragon Core launcher resources
- Basic theme, permissions, diagnostics, and mission views
- Build scripts and Android manifest

## Build status
This source archive is the `SERVER_CFv2.0.2_SWRLZ` source checkpoint. Static contract, protected-file, launcher-resource, and archive checks are recorded in `SOURCES/SERVER/SERVER_CFv2.0.2_SWRLZ.md`. Gradle compilation and APK assembly are intentionally deferred to the owner's GitHub build.

The UI checkpoint does not change protocol/schema version 1, listener exposure, discovery signatures, pairing/trust rules, mission authority, private proof handling, or offline-first routing.
