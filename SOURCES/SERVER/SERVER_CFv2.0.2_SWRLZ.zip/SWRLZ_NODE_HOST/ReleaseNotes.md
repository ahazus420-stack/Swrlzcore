## 2.0.2 — VERSION-SYNCHRONIZED-REPACKAGE

- Advanced Android identity to `versionCode 5` / `versionName 2.0.2`.
- Repackaged the valid SERVER/Swurlzer source as `SERVER_CFv2.0.2_SWRLZ.zip`.
- Regenerated the SHA-256 receipt from the final archive bytes.
- Preserved the CFv2.0.1 `NodeEntity::nodeId` compile repair.
- No architecture, protocol, database, trust, cryptographic, or UI behavior changes.
- APK compilation remains delegated to the existing GitHub workflow.

# Release Notes

## 2.0.1 — NODE-KEY-COMPILE-FIX
- Corrected two Compose LazyColumn key selectors from the nonexistent `NodeEntity::id` property to the actual Room primary key `NodeEntity::nodeId`.
- Fixed Kotlin compilation failures in `HostScreen.kt` and `SwurlzerUserScreen.kt` without changing UI behavior, trust semantics, protocol/schema versions, or SERVER transport naming.
- Added a regression guard that rejects any reintroduction of `NodeEntity::id` in the affected screens.
- Source identity advanced to `versionCode 4` / `versionName 2.0.1`.
- APK compilation remains deferred to the owner's GitHub workflow.

## 2.0.0 — GLITCH-DRAGON-SWURLZER-DUAL-MODE
- Renamed the user-facing local node host experience to **Swurlzer** while preserving SERVER archive naming and `NODE_HOST` source/protocol identities.
- Added a streamlined Glitch Dragon Glass User Mode for Core, stored Nodes, stored Missions, and visual Settings.
- Upgraded the original Overview and Diagnostics cockpit as switchable Swurlzer Dev Mode without removing legacy controls.
- Added persisted mode and reduced-motion preferences plus lifecycle-aware, bounded decorative animation.
- Added a new 4096×4096 crystalline Swurlzer icon master and density/adaptive launcher resources.
- Preserved loopback/private API, approved local-link discovery, trust/pairing, proof binding, mission, and protocol/schema version 1 semantics.
- Source identity advanced to `versionCode 3` / `versionName 2.0.0`.
- Compile and APK assembly intentionally deferred to the owner's GitHub build.

## 1.0.3
- Added truthful CLIENT compatibility routes on the local-link listener.
- Empty presence now returns authoritative zero counts and empty collections instead of `404`.
- Preserved discovery signature, durable identity, protocol/schema version 1, and trust boundaries.
- Added deterministic Glitch Dragon Core launcher icons.
- Source version advanced to `versionCode 2` / `versionName 1.0.3`.

## 1.0
- Initial Android Studio project for SWRLZ Node Host.
- Compose UI, Room persistence, foreground service, and embedded local runtime.
- Mission-first dashboard with node and mission state.
