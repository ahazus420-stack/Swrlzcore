# SWRLZ-Core 2.6 Patch Report

## Patch identity

- Version name: `0.2.6-bridge-truth`
- Version code: `12`
- Patch label: `2.6-BRIDGE-TRUTH`
- Roadmap revision: `2.6`
- Source ZIP: `SWRLZ_CORE_2.6_BRIDGE_TRUTH_SOURCE.zip`

## Files changed

- `android/app/build.gradle.kts`
- `ContextModels.kt`
- `Prefs.kt`
- `Api.kt`
- `HomeScreen.kt`
- `SetupScreen.kt`
- `CoreNodeScreen.kt`
- `CommandsScreen.kt`
- `HowToScreen.kt`
- `InfoScreen.kt`
- `README_LATEST_2.6.md`

## Completed fixes

### CLIENT-FIX-001 — Home status layout wrap bug

Replaced the tight horizontal status row with stacked bordered status cards. Long Core Node details now wrap under the label instead of squeezing `Local Core Node bridge` into vertical fragments.

### CLIENT-FIX-002 — Launch status truth model

Added persisted manual and auto Core Node check records:

- configured URL
- last manual check result
- last auto-check result
- timestamp
- summary/detail

### CLIENT-FIX-003 — Status color rules

Kept explicit color rules:

- success/reachable = green
- failed/unreachable/denied = red
- not configured/untested/testing = yellow

### CLIENT-FIX-004 — Command card state clarity

Command cards now show lifecycle status chips, creator/timestamps, ack/completion details, and disabled impossible lifecycle actions.

### CLIENT-FIX-005 — Admin password handling

Admin password fields remain masked. No password value is displayed in status cards, logs, or identity blocks.

## Acceptance checklist

1. Home loads without label-crush layout.
2. Home shows `Local Core Node bridge` as a readable label.
3. Setup shows configured/manual/auto state separately.
4. TEST CORE NODE turns green only after valid `/status` response.
5. Failed Core Node test is red.
6. Untested configured Core Node is yellow.
7. Command card pending state allows ACK/REJECT.
8. Accepted state allows COMPLETE/REJECT.
9. Completed/rejected/failed card becomes read-only.
10. How To and Info explain the bridge truth model.
