# SWRLZ-Core 2.7.6-NETWORK-DISCOVERY

Roadmap: 2.7.6

## Build identity

- versionName: `0.2.7.6-codefix3-scan-trim`
- versionCode: `25`
- Patch: `2.7.6-NETWORK-DISCOVERY`
- Build line: `Network Discovery / discovery signature / local node scan / saved server verify / Admin Registry bridge`
- Source: `SWRLZ_CORE_2.7.6_NETWORK_DISCOVERY_SOURCE.zip`

## Main change

Adds visible **Network Discovery** to the app:

- top tab: Network
- Home button: Network Discovery
- More drawer entry: Network Discovery
- `/discovery/signature` tester
- local candidate scan
- save verified node URL into Core Node config

## Law

No invisible patches. No mystery APKs. Integrate, do not overwrite.


## 2.7.6-CODEFIX3-DISCOVERY-SCAN-TRIM

- Source: `SRC_2.7.6_CF3_SCAN_TRIM.zip`
- Objective: trim discovery scan overhead by skipping `127.0.0.x` range sweeps by default, while keeping a saved debug toggle for unusual loopback testing.
- Output naming convention: `SRC_` for source, `SHA_` for hashes, `REPORT_` for patch notes, `APK_` for APKs, and `BUNDLE_` for APK download bundles.


## 2.7.6 CF4 - Signing + Reconnect

Adds Connection Memory / Last-Good Node Auto-Reconnect and stable dev signing readiness. Source: `SRC_2.7.6_CF4_SIGN_RECONNECT.zip`.
