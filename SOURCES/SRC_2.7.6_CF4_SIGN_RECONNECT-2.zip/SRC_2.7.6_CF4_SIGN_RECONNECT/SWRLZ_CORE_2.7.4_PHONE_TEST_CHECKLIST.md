# SWRLZ-Core 2.7.6 Phone Test Checklist

## Identity

- [ ] App shows `0.2.7.6-cockpit-shell`.
- [ ] App code is `17`.
- [ ] Patch is `2.7.6-NETWORK-DISCOVERY`.

## Navigation

- [ ] Top tabs show Home, Radar, Cockpit, Setup, Style, More.
- [ ] More opens Core, Permissions, Allowlist, Skills, How To, and Info.
- [ ] Opening a More item marks More as selected in the top bar.

## Theme Armor preservation

- [ ] Style screen opens.
- [ ] Original Core works.
- [ ] Glitch Neon works.
- [ ] Pharaoh Emerald works.
- [ ] Void Jester works.
- [ ] Dark/Sunlight/Inverse variants work.
- [ ] Status colors remain semantic.

## Radar / pairing

- [ ] Core Node URL saved.
- [ ] Refresh Radar works.
- [ ] Guided Pairing Ladder appears.
- [ ] Auto Register / Heartbeat works.
- [ ] Device Roster Summary appears.
- [ ] This device appears online after heartbeat.
- [ ] Second phone can appear as second online device.

## Queue

- [ ] Send PING to self.
- [ ] Pull Offline Queue.
- [ ] Packet card appears.
- [ ] DISPLAY / ACK / COMPLETE works.
- [ ] Terminal packet becomes read-only/history style.
