# SWRLZ-Core 2.4 — Latest How-To

## Build identity

- App version: `0.2.4-command-inbox`
- Code: `10`
- Patch: `2.4-COMMAND-INBOX`
- Roadmap: `2.4`

## Install/update

1. Build the APK from `SWRLZ_CORE_2.4_COMMAND_INBOX_SOURCE.zip`.
2. Install the generated APK on the Action Phone.
3. Confirm the Home screen shows `v0.2.4-command-inbox · code 10`.
4. Confirm the Build Identity card shows `2.4-COMMAND-INBOX`.

## Core Node setup

1. Run Local Node Server `0.4-command-queue` on Termux/second phone.
2. On SWRLZ-Core, open `Setup` or `Core`.
3. Enter the Core Node URL, for example:
   - Same phone: `http://127.0.0.1:8787`
   - Other phone on LAN/hotspot: `http://192.168.x.x:8787`
4. Tap `SAVE CORE`.
5. Tap `TEST STATUS` or `TEST CORE NODE`.
6. Success requires a full valid server `/status` response.

## Command inbox test loop

1. Open `Cmds`.
2. Enter admin credentials if creating a command.
3. Tap `CREATE SAFE TEST COMMAND`.
4. Tap `PULL PENDING`.
5. Copy/paste the command ID into `Command ID`.
6. Tap `ACK`, `REJECT`, or `COMPLETE`.
7. Check Termux logs and server recent events.

## Notes

- The `Cmds` tab is a safe command queue test harness.
- It does not yet run full automation actions.
- Future patches will turn command proposals into guarded action proposals with safety gates.

