# SWRLZ-CORE 1.3 — Context Viewer Self-Capture Hotfix Report

**Patch label:** 1.3-CTXVIEW-SELF-CAPTURE-HOTFIX  
**Base source:** SWRLZ_CORE_1.3_BUILD_MESH_CONTEXTCOLLECTORS_HOTFIX_SOURCE.zip  
**Status:** Source patched; Codespaces APK build and phone test required.

## Problem found during phone field test

The Context Viewer successfully generated STANDARD, MINIMAL, and DETAILED packets. During repeated refresh tests, the app began observing the previously displayed Context Viewer JSON as a visible accessibility node. This created recursive packets where a new context packet included an older context packet inside `visibleNodes`.

## Risk

This was not a crash bug and did not block the app. However, it could:

- inflate outgoing context packets,
- leak previous context previews into newer previews,
- confuse screen-delta summaries,
- trigger unnecessary redactions,
- and create a mirror-loop effect during repeated Refresh Context testing.

## Patch applied

### Modified files

- `android/app/src/main/java/sh/swurlz/core/data/ContextCollectors.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/screens/SetupScreen.kt`
- `android/app/src/main/java/sh/swurlz/core/service/MissionRunnerService.kt`

### Behavior change

Added `PrivacyRedactor.omitInternalContextPreviewOutput(...)` to remove SWRLZ internal Context Viewer JSON blobs before packets are built.

A node is treated as internal context-preview output only when the text/description looks like a SWRLZ context packet shape:

- starts with `{`,
- contains `"schemaVersion"`,
- contains `"contextLevel"`,
- contains `"visibleNodes"`,
- contains `"createdAtEpochMs"`,
- and is long enough to avoid filtering normal short text.

The Setup Context Viewer now filters nodes before:

- app context counts,
- screen delta generation,
- privacy redaction,
- and visible node export.

MissionRunner also filters internal preview output before planning packets are assembled.

## Expected test result

After building/installing this patch:

1. Open Setup.
2. Refresh STANDARD context.
3. Switch to MINIMAL and refresh.
4. Switch to DETAILED and refresh.
5. Confirm the new packet does not include a huge prior JSON packet inside `visibleNodes`.
6. Confirm buttons, settings, and Test Connection still work.

## Roadmap note

This addresses:

- `CTXVIEW-001 — Exclude internal Context Viewer output from outgoing context packets.`

Do not mark complete until phone test confirms recursive preview JSON is gone.
