#!/usr/bin/env bash
set -Eeuo pipefail

# SWRLZ-CORE Android debug APK builder for GitHub Codespaces / Linux builders.
# Goal: let a phone-only workflow run one script and download a ZIP containing
# the debug APK + SHA-256 checksum + build log + provenance report.

show_help() {
  cat <<'HELP'
SWRLZ-CORE Android Debug Bundle Builder

Usage:
  bash scripts/build_android_debug_bundle.sh

Optional environment variables:
  SWRLZ_APK_OUT_DIR   Output directory for APK bundle. Default: <project-root>/APK_DOWNLOAD
  ANDROID_HOME        Android SDK path. Usually already set in GitHub Codespaces.
  ANDROID_SDK_ROOT    Android SDK path fallback if ANDROID_HOME is not set.

What it does:
  1. Locates the project root and android/gradlew.
  2. Writes android/local.properties using ANDROID_HOME or ANDROID_SDK_ROOT.
  3. Runs ./gradlew --no-daemon --stacktrace clean assembleDebug.
  4. Copies the debug APK into APK_DOWNLOAD/ with a project/version-safe name.
  5. Creates SHA-256 checksum files.
  6. Creates BUILD_PROVENANCE_REPORT.md.
  7. Creates a downloadable ZIP containing APK + checksums + build log + provenance.

If the build fails, the script does not edit source files. It leaves a build log and provenance report in APK_DOWNLOAD/.
HELP
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  show_help
  exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PROJECT_NAME="$(basename "$PROJECT_ROOT")"
ANDROID_DIR="$PROJECT_ROOT/android"
GRADLEW="$ANDROID_DIR/gradlew"
OUT_DIR="${SWRLZ_APK_OUT_DIR:-$PROJECT_ROOT/APK_DOWNLOAD}"
LOG_FILE="$OUT_DIR/build_android_debug.log"
PROVENANCE_FILE="$OUT_DIR/BUILD_PROVENANCE_REPORT.md"
mkdir -p "$OUT_DIR"

sanitize_name() {
  printf '%s' "$1" | tr -c 'A-Za-z0-9._-' '_'
}

swrlz_output_base_from_source_zip() {
  local source_name="$1"
  local base="${source_name##*/}"
  base="${base%.zip}"
  if [[ "$base" == SRC_* ]]; then
    printf 'APK_%s' "${base#SRC_}"
  elif [[ -n "$base" ]]; then
    printf '%s' "$base"
  else
    printf '%s' "$SAFE_PROJECT_NAME"
  fi
}

swrlz_bundle_name_from_apk_base() {
  local apk_base="$1"
  if [[ "$apk_base" == APK_* ]]; then
    printf 'BUNDLE_%s.zip' "${apk_base#APK_}"
  else
    printf 'BUNDLE_%s.zip' "$apk_base"
  fi
}

run_capture() {
  local cmd="$1"
  bash -lc "$cmd" 2>&1 || true
}

source_status() {
  if command -v git >/dev/null 2>&1 && git -C "$PROJECT_ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    git -C "$PROJECT_ROOT" status --short || true
  else
    echo "git status unavailable"
  fi
}

current_commit() {
  if command -v git >/dev/null 2>&1 && git -C "$PROJECT_ROOT" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    git -C "$PROJECT_ROOT" rev-parse HEAD || true
  else
    echo "git commit unavailable"
  fi
}

swrlz_gradle_value() {
  local key="$1"
  if [[ -f "$PROJECT_ROOT/android/app/build.gradle.kts" ]]; then
    grep -E "^[[:space:]]*(versionName|versionCode)[[:space:]]*=" "$PROJECT_ROOT/android/app/build.gradle.kts" | grep "$key" | head -1 | sed -E 's/^[[:space:]]*[^=]+=[[:space:]]*//; s/"//g' || true
  fi
}

swrlz_build_config_value() {
  local key="$1"
  if [[ -f "$PROJECT_ROOT/android/app/build.gradle.kts" ]]; then
    python3 - "$PROJECT_ROOT/android/app/build.gradle.kts" "$key" <<'PYIDENT' || true
import re, sys
path, key = sys.argv[1], sys.argv[2]
text = open(path, encoding='utf-8').read().splitlines()
pat = re.compile(r'buildConfigField\("String",\s*"' + re.escape(key) + r'",\s*"\\"(.*)\\""\)')
for line in text:
    m = pat.search(line)
    if m:
        print(m.group(1))
        break
PYIDENT
  fi
}

write_provenance() {
  local status="$1"
  local stage="$2"
  local gradle_exit="${3:-not-run}"
  local apk_path="${4:-}"
  local bundle_path="${5:-}"
  local now
  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  local sdk_dir="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"

  {
    echo "# SWRLZ-CORE Build Provenance Report"
    echo
    echo "- Generated: $now"
    echo "- Status: $status"
    echo "- Stage: $stage"
    echo "- Gradle exit code: $gradle_exit"
    echo "- Project root: $PROJECT_ROOT"
    echo "- Android dir: $ANDROID_DIR"
    echo "- Output dir: $OUT_DIR"
    echo "- Build log: $LOG_FILE"
    echo "- Source commit: $(current_commit)"
    echo
    echo "## SWRLZ Build Identity"
    echo
    echo "- Android versionName: $(swrlz_gradle_value versionName)"
    echo "- Android versionCode: $(swrlz_gradle_value versionCode)"
    echo "- Patch label: $(swrlz_build_config_value PATCH_LABEL)"
    echo "- Roadmap revision: $(swrlz_build_config_value ROADMAP_REVISION)"
    echo "- Build line: $(swrlz_build_config_value BUILD_LINE)"
    echo "- Source ZIP: $(swrlz_build_config_value SOURCE_ZIP)"
    echo "- Patch notes: $(swrlz_build_config_value PATCH_NOTES)"
    echo
    echo "## Environment"
    echo
    echo "- ANDROID_HOME: ${ANDROID_HOME:-unset}"
    echo "- ANDROID_SDK_ROOT: ${ANDROID_SDK_ROOT:-unset}"
    echo "- SDK dir used: ${sdk_dir:-unset}"
    echo "- PATH Android entries:"
    printf '%s' "$PATH" | tr ':' '\n' | grep -Ei 'android|sdk|platform-tools|cmdline-tools' | sed 's/^/  - /' || echo "  - none detected"
    echo
    echo "## Java"
    echo
    echo '```text'
    java -version 2>&1 || true
    echo '```'
    echo
    echo "## Gradle"
    echo
    echo '```text'
    if [[ -x "$GRADLEW" ]]; then
      (cd "$ANDROID_DIR" && ./gradlew --version) 2>&1 || true
    else
      echo "Gradle wrapper not executable or missing: $GRADLEW"
    fi
    echo '```'
    echo
    echo "## Android SDK packages"
    echo
    echo '```text'
    if command -v sdkmanager >/dev/null 2>&1; then
      sdkmanager --list_installed 2>&1 || true
    elif [[ -n "${sdk_dir:-}" && -x "$sdk_dir/cmdline-tools/latest/bin/sdkmanager" ]]; then
      "$sdk_dir/cmdline-tools/latest/bin/sdkmanager" --list_installed 2>&1 || true
    else
      echo "sdkmanager unavailable"
    fi
    echo '```'
    echo
    echo "## Source modifications"
    echo
    echo '```text'
    source_status
    echo '```'
    echo
    echo "## Build command"
    echo
    echo '```bash'
    echo "cd '$ANDROID_DIR' && ./gradlew --no-daemon --stacktrace clean assembleDebug"
    echo '```'
    echo
    if [[ -n "$apk_path" ]]; then
      echo "## APK"
      echo
      echo "- APK path: $apk_path"
      if [[ -f "$apk_path" ]]; then
        echo "- APK size bytes: $(stat -c '%s' "$apk_path" 2>/dev/null || wc -c < "$apk_path")"
        echo "- APK SHA-256: $(sha256sum "$apk_path" | awk '{print $1}')"
      fi
      echo
    fi
    if [[ -n "$bundle_path" ]]; then
      echo "## Download bundle"
      echo
      echo "- Bundle path: $bundle_path"
      if [[ -f "$bundle_path" ]]; then
        echo "- Bundle size bytes: $(stat -c '%s' "$bundle_path" 2>/dev/null || wc -c < "$bundle_path")"
        echo "- Bundle SHA-256: $(sha256sum "$bundle_path" | awk '{print $1}')"
      fi
      echo
    fi
    echo "## Last 80 lines of build log"
    echo
    echo '```text'
    if [[ -f "$LOG_FILE" ]]; then
      tail -80 "$LOG_FILE" || true
    else
      echo "No build log found."
    fi
    echo '```'
  } > "$PROVENANCE_FILE"
}

fail() {
  local message="$*"
  echo "ERROR: $message" >&2
  echo "Build helper stopped. Check: $LOG_FILE" >&2
  {
    echo "SWRLZ-CORE Android Debug Bundle Build"
    echo "Started: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    echo "Project root: $PROJECT_ROOT"
    echo "Android dir: $ANDROID_DIR"
    echo "Output dir: $OUT_DIR"
    echo "Failure before Gradle: $message"
  } >> "$LOG_FILE"
  write_provenance "failed" "pre-gradle: $message" "not-run"
  exit 1
}

SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
[[ -n "$SDK_DIR" ]] || fail "ANDROID_HOME or ANDROID_SDK_ROOT is not set. In Codespaces, run: bash scripts/install_android_sdk_and_build.sh"
[[ -d "$SDK_DIR" ]] || fail "Android SDK path does not exist: $SDK_DIR"
[[ -d "$ANDROID_DIR" ]] || fail "Could not find android/ directory at: $ANDROID_DIR"
[[ -f "$GRADLEW" ]] || fail "Could not find Gradle wrapper at: $GRADLEW"

chmod +x "$GRADLEW"
printf 'sdk.dir=%s\n' "$SDK_DIR" > "$ANDROID_DIR/local.properties"

SAFE_PROJECT_NAME="$(sanitize_name "$PROJECT_NAME")"
SOURCE_ZIP_NAME="$(swrlz_build_config_value SOURCE_ZIP || true)"
OUTPUT_BASE="$(sanitize_name "$(swrlz_output_base_from_source_zip "$SOURCE_ZIP_NAME")")"
STARTED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

{
  echo "SWRLZ-CORE Android Debug Bundle Build"
  echo "Started: $STARTED_AT"
  echo "Project root: $PROJECT_ROOT"
  echo "Android dir: $ANDROID_DIR"
  echo "SDK dir: $SDK_DIR"
  echo "Output dir: $OUT_DIR"
  echo "Output base: $OUTPUT_BASE"
  echo "Gradle command: ./gradlew --no-daemon --stacktrace clean assembleDebug"
  echo
} | tee "$LOG_FILE"

pushd "$ANDROID_DIR" >/dev/null
set +e
./gradlew --no-daemon --stacktrace clean assembleDebug 2>&1 | tee -a "$LOG_FILE"
GRADLE_STATUS=${PIPESTATUS[0]}
set -e
popd >/dev/null

if [[ "$GRADLE_STATUS" -ne 0 ]]; then
  echo "Build failed with Gradle exit code: $GRADLE_STATUS" | tee -a "$LOG_FILE"
  echo "No source files were modified by this script except android/local.properties." | tee -a "$LOG_FILE"
  write_provenance "failed" "gradle" "$GRADLE_STATUS"
  exit "$GRADLE_STATUS"
fi

mapfile -t APK_CANDIDATES < <(find "$ANDROID_DIR/app/build/outputs/apk/debug" -type f -name '*.apk' 2>/dev/null | sort)
[[ "${#APK_CANDIDATES[@]}" -gt 0 ]] || fail "Gradle succeeded but no debug APK was found under android/app/build/outputs/apk/debug."

APK_SRC="${APK_CANDIDATES[-1]}"
APK_NAME="${OUTPUT_BASE}_DEBUG.apk"
APK_DST="$OUT_DIR/$APK_NAME"
cp "$APK_SRC" "$APK_DST"

pushd "$OUT_DIR" >/dev/null
sha256sum "$APK_NAME" > "${APK_NAME}.sha256"
sha256sum "$LOG_FILE" > "build_android_debug.log.sha256"
popd >/dev/null

FINISHED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
{
  echo
  echo "Build succeeded."
  echo "Finished: $FINISHED_AT"
  echo "APK: $APK_DST"
} | tee -a "$LOG_FILE"

write_provenance "succeeded" "apk-created" "0" "$APK_DST"

pushd "$OUT_DIR" >/dev/null
sha256sum "BUILD_PROVENANCE_REPORT.md" > "BUILD_PROVENANCE_REPORT.md.sha256"
BUNDLE_NAME="$(swrlz_bundle_name_from_apk_base "$OUTPUT_BASE")"
rm -f "$BUNDLE_NAME"
if command -v zip >/dev/null 2>&1; then
  zip -9 "$BUNDLE_NAME" \
    "$APK_NAME" \
    "${APK_NAME}.sha256" \
    "build_android_debug.log" \
    "build_android_debug.log.sha256" \
    "BUILD_PROVENANCE_REPORT.md" \
    "BUILD_PROVENANCE_REPORT.md.sha256" >/dev/null
else
  python3 - <<PY
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
out = Path('$BUNDLE_NAME')
files = [Path('$APK_NAME'), Path('${APK_NAME}.sha256'), Path('build_android_debug.log'), Path('build_android_debug.log.sha256'), Path('BUILD_PROVENANCE_REPORT.md'), Path('BUILD_PROVENANCE_REPORT.md.sha256')]
with ZipFile(out, 'w', ZIP_DEFLATED) as z:
    for p in files:
        z.write(p, p.name)
PY
fi
sha256sum "$BUNDLE_NAME" > "${BUNDLE_NAME}.sha256"
popd >/dev/null

# Refresh provenance with bundle details included.
write_provenance "succeeded" "bundle-created" "0" "$APK_DST" "$OUT_DIR/$BUNDLE_NAME"
sha256sum "$PROVENANCE_FILE" > "$OUT_DIR/BUILD_PROVENANCE_REPORT.md.sha256"

{
  echo "Bundle: $OUT_DIR/$BUNDLE_NAME"
  echo "Bundle checksum: $OUT_DIR/${BUNDLE_NAME}.sha256"
  echo "Provenance report: $PROVENANCE_FILE"
} | tee -a "$LOG_FILE"
