#!/usr/bin/env bash
set -Eeuo pipefail

# Generates a stable SWRLZ dev signing key locally and prints the GitHub Secrets values.
# Do NOT commit the generated .jks file. Store it in GitHub Secrets only.

OUT_DIR="${1:-$PWD/build/swrlz-dev-signing}"
KEYSTORE="$OUT_DIR/swrlz-dev-signing.jks"
ALIAS="swrlz-dev"
STORE_PASS="${SWRLZ_DEV_KEYSTORE_PASSWORD:-swrlz-dev-change-me-2026}"
KEY_PASS="${SWRLZ_DEV_KEY_PASSWORD:-$STORE_PASS}"
mkdir -p "$OUT_DIR"

if [[ -f "$KEYSTORE" ]]; then
  echo "Keystore already exists: $KEYSTORE"
else
  keytool -genkeypair     -v     -keystore "$KEYSTORE"     -storepass "$STORE_PASS"     -keypass "$KEY_PASS"     -alias "$ALIAS"     -keyalg RSA     -keysize 2048     -validity 10000     -dname "CN=SWRLZ Dev,O=SWRLZ,C=US"
fi

BASE64_FILE="$OUT_DIR/SWRLZ_DEV_KEYSTORE_BASE64.txt"
base64 -w 0 "$KEYSTORE" > "$BASE64_FILE" 2>/dev/null || base64 "$KEYSTORE" | tr -d '
' > "$BASE64_FILE"

cat <<EOF
SWRLZ dev signing key generated.

Add these GitHub repository secrets:

SWRLZ_DEV_KEYSTORE_BASE64 = $(cat "$BASE64_FILE")
SWRLZ_DEV_KEYSTORE_PASSWORD = $STORE_PASS
SWRLZ_DEV_KEY_ALIAS = $ALIAS
SWRLZ_DEV_KEY_PASSWORD = $KEY_PASS

Keystore path, keep private:
$KEYSTORE

Base64 file:
$BASE64_FILE
EOF
