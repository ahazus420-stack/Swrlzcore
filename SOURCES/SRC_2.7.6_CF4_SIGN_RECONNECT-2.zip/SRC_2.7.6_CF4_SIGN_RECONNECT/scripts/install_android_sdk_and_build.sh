#!/usr/bin/env bash
set -Eeuo pipefail

# SWRLZ-CORE Codespaces Android SDK bootstrap + debug APK builder.
# Purpose: make phone-first cloud builds closer to one command from a fresh Codespace.
# This script installs/verifies Android SDK command-line tools, platform 34, and build-tools 34.0.0,
# then calls scripts/build_android_debug_bundle.sh.

show_help() {
  cat <<'HELP'
SWRLZ-CORE Android SDK Bootstrap + Build

Usage:
  bash scripts/install_android_sdk_and_build.sh

Environment variables:
  ANDROID_HOME / ANDROID_SDK_ROOT  Optional SDK root. Default: $HOME/android-sdk
  SWRLZ_ANDROID_API               Android platform API. Default: 34
  SWRLZ_BUILD_TOOLS               Build tools version. Default: 34.0.0

What it does:
  1. Locates the project root from this script path, not the terminal's current directory.
  2. Installs Android command-line tools if sdkmanager is missing.
  3. Exports ANDROID_HOME, ANDROID_SDK_ROOT, and Android PATH entries for this run.
  4. Accepts Android SDK licenses.
  5. Installs platform-tools, platforms;android-34, and build-tools;34.0.0 by default.
  6. Runs scripts/build_android_debug_bundle.sh.

It does not edit SWRLZ source files. It may create android/local.properties through the build script.
HELP
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
  show_help
  exit 0
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
OUT_DIR="${SWRLZ_APK_OUT_DIR:-$PROJECT_ROOT/APK_DOWNLOAD}"
LOG_FILE="$OUT_DIR/install_android_sdk_and_build.log"
mkdir -p "$OUT_DIR"

ANDROID_API="${SWRLZ_ANDROID_API:-34}"
BUILD_TOOLS="${SWRLZ_BUILD_TOOLS:-34.0.0}"
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$HOME/android-sdk}}"
CMDLINE_ZIP_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
CMDLINE_DIR="$SDK_ROOT/cmdline-tools/latest"
SDKMANAGER="$CMDLINE_DIR/bin/sdkmanager"

log() { echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "$LOG_FILE"; }
fail() { log "ERROR: $*"; exit 1; }
need_cmd() { command -v "$1" >/dev/null 2>&1 || fail "Required command not found: $1"; }

{
  echo "SWRLZ-CORE Android SDK Bootstrap + Build"
  echo "Started: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "Project root: $PROJECT_ROOT"
  echo "Requested SDK root: $SDK_ROOT"
  echo "Android API: $ANDROID_API"
  echo "Build tools: $BUILD_TOOLS"
  echo
} | tee "$LOG_FILE"

need_cmd java
need_cmd curl
need_cmd unzip

cd "$PROJECT_ROOT"

if [[ ! -x "$SDKMANAGER" ]]; then
  log "sdkmanager not found. Installing Android command-line tools."
  tmpdir="$(mktemp -d)"
  trap 'rm -rf "$tmpdir"' EXIT
  mkdir -p "$SDK_ROOT/cmdline-tools"
  curl -L -o "$tmpdir/commandlinetools-linux.zip" "$CMDLINE_ZIP_URL" 2>&1 | tee -a "$LOG_FILE"
  rm -rf "$SDK_ROOT/cmdline-tools/latest" "$SDK_ROOT/cmdline-tools/cmdline-tools"
  unzip -q -o "$tmpdir/commandlinetools-linux.zip" -d "$SDK_ROOT/cmdline-tools"
  mv "$SDK_ROOT/cmdline-tools/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
else
  log "sdkmanager already exists: $SDKMANAGER"
fi

[[ -x "$SDKMANAGER" ]] || fail "sdkmanager still missing after install attempt: $SDKMANAGER"

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

log "ANDROID_HOME=$ANDROID_HOME"
log "ANDROID_SDK_ROOT=$ANDROID_SDK_ROOT"
log "sdkmanager=$(command -v sdkmanager || true)"

# Persist for future terminals in this Codespace if possible, without duplicating endlessly.
BASHRC="$HOME/.bashrc"
if [[ -w "$HOME" ]]; then
  touch "$BASHRC" || true
  if ! grep -q "SWRLZ Android SDK bootstrap" "$BASHRC" 2>/dev/null; then
    cat >> "$BASHRC" <<PERSIST

# SWRLZ Android SDK bootstrap
export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$PATH"
PERSIST
    log "Persisted Android SDK environment to $BASHRC"
  fi
fi

log "Accepting Android SDK licenses."
yes | sdkmanager --licenses 2>&1 | tee -a "$LOG_FILE" || log "License command returned non-zero; continuing to package install check."

log "Installing required Android SDK packages."
sdkmanager \
  "platform-tools" \
  "platforms;android-$ANDROID_API" \
  "build-tools;$BUILD_TOOLS" 2>&1 | tee -a "$LOG_FILE"

log "Installed SDK packages summary:"
sdkmanager --list_installed 2>&1 | tee -a "$LOG_FILE" || true

log "Running SWRLZ APK build helper."
bash "$PROJECT_ROOT/scripts/build_android_debug_bundle.sh" 2>&1 | tee -a "$LOG_FILE"

log "Bootstrap + build finished. Check $OUT_DIR for APK bundle and provenance report."
