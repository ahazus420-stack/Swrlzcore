# SWRLZ Combined Roadmap Index

This index points to the two current roadmaps:

1. `SWRLZ_CORE_ANDROID_CLIENT_ROADMAP_2.6.md`
2. `SWRLZ_LOCAL_NODE_SERVER_ROADMAP_0.6.md`

## Current prepared status

### Android Client
- Current prepared client: `v0.2.6-bridge-truth`
- Version code: `12`
- Patch: `2.6-BRIDGE-TRUTH`
- Implemented: bridge truth model, Home layout fix, status color hardening, command-card lifecycle guards, How To / Info update.
- Build note: APK build could not be verified inside this offline sandbox because Gradle wrapper needed to download Gradle. Build in Codespaces/GitHub as usual.

### Local Node Server
- Current verified server: `local-node-server-0.6-process-control`
- Patch line: `LNS-0.6-PROCESS-CONTROL`
- Verified: Python compile, `/status`, `/admin/update/settings`, PID file, stop script PID cleanup.

## Next coordinated update

### Client 2.7
- Action Phone Safe Executor.
- Safe commands: PING, SHOW_MESSAGE, REFRESH_CONTEXT, REPORT_STATUS.
- User approval required before every action.

### Server 0.7
- Server-hosted command execution policies.
- Risk levels and command expiration.
- Allowed command type policy.
- Device identity ownership for commands.
