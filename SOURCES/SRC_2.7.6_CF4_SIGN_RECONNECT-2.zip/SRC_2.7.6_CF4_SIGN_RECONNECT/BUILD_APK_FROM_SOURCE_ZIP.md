# SWRLZ-CORE Phone-Friendly APK Build Flow

This source package includes a phone-first Codespaces builder for the Android debug APK.

## Intended workflow

1. Upload or pull the full SWRLZ-CORE source into GitHub Codespaces.
2. Open a terminal at the project root.
3. Run the bootstrap builder:

```bash
bash scripts/install_android_sdk_and_build.sh
```

The bootstrap builder installs/verifies Android command-line tools, sets `ANDROID_HOME` and `ANDROID_SDK_ROOT`, installs Android platform 34/build-tools 34.0.0, and then calls the APK bundle builder.

If Android SDK is already configured, the lower-level builder can be run directly:

```bash
bash scripts/build_android_debug_bundle.sh
```

4. Download the ZIP created in:

```text
APK_DOWNLOAD/
```

The output ZIP contains:

- debug APK
- APK SHA-256 checksum
- build log
- build log SHA-256 checksum
- `BUILD_PROVENANCE_REPORT.md`
- provenance report SHA-256 checksum

## Codespaces AI prompt

Paste this into Codespaces AI after uploading/extracting the source ZIP or after opening the repo Codespace:

```text
Run the SWRLZ Android bootstrap build from the project root:

bash scripts/install_android_sdk_and_build.sh

If the build succeeds, zip APK_DOWNLOAD if it is not already zipped and show me the path to the APK download bundle so I can download it to my phone.

After the build, summarize docs/BUILD_PROVENANCE_REPORT.md or APK_DOWNLOAD/BUILD_PROVENANCE_REPORT.md, including Android SDK path, installed SDK packages, Java/Gradle versions, APK path, APK size, APK SHA-256, source commit SHA, and whether any source files were edited.

If the build fails, do not randomly edit source files. Show the failure stage, exact Gradle task if any, exact error, file path/line if shown, and last 80 lines of APK_DOWNLOAD/build_android_debug.log.
```

## Notes

- `scripts/install_android_sdk_and_build.sh` can be used from a fresh Codespace.
- `scripts/build_android_debug_bundle.sh` requires `ANDROID_HOME` or `ANDROID_SDK_ROOT` to already be set.
- The scripts do not modify app source code. The APK builder writes `android/local.properties` only.
- If Gradle fails, the scripts stop and leave logs/provenance in `APK_DOWNLOAD/`.
- Do not put API keys or private tokens into this source package.
