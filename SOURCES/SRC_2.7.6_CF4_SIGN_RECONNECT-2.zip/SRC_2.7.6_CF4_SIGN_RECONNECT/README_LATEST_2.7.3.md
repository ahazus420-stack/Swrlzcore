# SWRLZ-Core 2.7.3 — Theme Armor

Theme Armor adds a token-driven cockpit skin system while preserving the status-color truth model.

## App identity

- Version: `0.2.7.3-theme-armor`
- Code: `16`
- Patch: `2.7.3-THEME-ARMOR`
- Roadmap: `2.7.3`
- Source ZIP: `SWRLZ_CORE_2.7.3_THEME_ARMOR_SOURCE.zip`

## What changed

- Added token-driven theme model in `ui/theme/Theme.kt`.
- Added theme families:
  - Original Core
  - Glitch Neon
  - Pharaoh Emerald
  - Void Jester
- Added variants:
  - Dark
  - Sunlight
  - Inverse
- Added live preview cards in Style screen.
- Added semantic border policy controls.
- Added high contrast toggle.
- Added glow strength setting.
- Preserved animation, text size, card density, and Node Heartbeat settings.
- Applied theme tokens to the app shell, top bar, selected tab styling, and Style/Appearance screen.

## Design law

Themes may change armor, glow, text, surfaces, cards, tabs, and buttons.
Themes may not lie about status.

- Green stays ready/online/success.
- Yellow stays queued/waiting/caution.
- Red stays failed/blocked/danger.
- Cyan stays info/neutral action.
- Purple stays admin/advanced/special.

## Phone test checklist

1. Install APK built from `SWRLZ_CORE_2.7.3_THEME_ARMOR_SOURCE.zip`.
2. Confirm Home/Core identity shows `0.2.7.3-theme-armor · code 16`.
3. Open Style tab.
4. Select each theme family.
5. Select Dark, Sunlight, and Inverse variants.
6. Confirm app shell/top tabs respond to theme tokens.
7. Confirm live preview cards update colors and remain readable.
8. Toggle High Contrast.
9. Toggle Semantic Borders Only.
10. Toggle Solid Buttons in Sunlight.
11. Confirm Node Heartbeat controls still show device identity.
12. Confirm Radar still connects to Core Node 0.7.1.
13. Confirm group/device/queue flow still works.

## Build note

Use Java 17 in Codespaces/GitHub builds.

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"
java -version
bash scripts/install_android_sdk_and_build.sh
```
