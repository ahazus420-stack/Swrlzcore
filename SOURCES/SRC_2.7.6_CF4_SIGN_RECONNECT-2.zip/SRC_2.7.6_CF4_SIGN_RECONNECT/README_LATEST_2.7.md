# SWRLZ-Core 2.7 — Two-Phone Sigil

Two-Phone Sigil is the client-side relay UI upgrade for SWRLZ-Core. It turns the command screen into a clean action bridge for same-device, device-to-device, and group relay packets.

## Main flow

1. Configure the Local Core Node URL in Setup/Core.
2. Activate Admin once if you need to create groups or view all devices.
3. Create a group from the app or server admin endpoint.
4. Join devices to the group with Group ID + Group Key.
5. Each device receives/saves a Device Key.
6. Send safe packets to self, one device, or group.
7. Offline devices receive queued packets when they reconnect and pull their queue.
8. User approves/rejects/completes packet cards manually.

## UI concepts

- **Admin Mode ON/OFF**: controls whether saved admin powers are used.
- **Forget Admin**: revokes/deletes the saved admin session token.
- **Group ID**: shared room/relay identifier.
- **Group Key**: shared secret for group membership.
- **Device ID**: stable node name.
- **Device Key**: per-device secret returned during join.
- **Packet Inbox**: offline queue cards delivered from the server.

## Safe command types

- PING
- SHOW_MESSAGE
- REPORT_STATUS
- REFRESH_CONTEXT
- ECHO_TEST

No destructive actions are included in this release.
