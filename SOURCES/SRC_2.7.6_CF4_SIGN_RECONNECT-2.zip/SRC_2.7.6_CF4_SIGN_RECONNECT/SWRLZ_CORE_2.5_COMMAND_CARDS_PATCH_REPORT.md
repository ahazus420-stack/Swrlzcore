# SWRLZ-Core 0.2.5 / Patch 2.5 — Command Cards

## Patch identity

- App version: `0.2.5-command-cards`
- Version code: `11`
- Patch label: `2.5-COMMAND-CARDS`
- Roadmap revision: `2.5`
- Source ZIP: `SWRLZ_CORE_2.5_COMMAND_CARDS_SOURCE.zip`

## Purpose

This patch upgrades the command bridge from raw JSON/manual command IDs into a clearer command-card workflow.

## Added

- Command cards parsed from Core Node JSON responses.
- Auto-fill of the latest command ID after create/pull/list responses.
- One-tap command lifecycle controls on each card:
  - `ACK`
  - `REJECT`
  - `COMPLETE`
- Manual response fallback kept for raw command ID testing.
- Clearer command-card status tones:
  - pending = yellow
  - accepted = cyan
  - completed = green
  - rejected/failed/blocked = red
- Home status row layout tightened so long Core Node versions do not crush the label into vertical letters.

## Preserved

- Existing Mentor setup.
- Existing Core Node setup.
- Existing admin settings/log/event controls.
- Existing command queue endpoints.
- Existing safety rule: no invisible patches / no mystery APKs.

## Field-test target

1. Install the APK.
2. Open `Core` and confirm the Local Core Node is reachable.
3. Open `Cmds`.
4. Tap `CREATE SAFE TEST COMMAND`.
5. Confirm a command card appears and auto-fills the command ID.
6. Tap `ACK` on the card.
7. Tap `COMPLETE` on the card.
8. Confirm Termux server logs show create / accepted / completed events.

## Known next improvements

- Add automatic polling interval toggle.
- Add command card filters: pending / active / completed / failed.
- Add command payload preview formatting.
- Add copy-to-clipboard buttons for command IDs.
