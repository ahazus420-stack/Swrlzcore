# Dual-Phone Core Node Plan

## Concept

Run SWRLZ-CORE as a two-device local-first mesh:

- **Core Phone / Brain Node:** another Moto 5G running the local node server, memory/log store, Skill Capsule library, patch manifest logic, learning-delta inbox, and optional online Mentor bridge.
- **Action Phone / Hands Node:** the main Android phone running the accessibility service, overlay, app allowlist, safety confirmations, screen/context capture, and approved action execution.

## Safety law

Core Phone proposes. Action Phone verifies. User approves risky actions. Action Phone executes. Both sides log.

## First implementation target

1. Add a Core Node URL field separate from the Mentor backend URL.
2. Add shared token pairing.
3. Add `/status` check from Action Phone to Core Phone.
4. Add local IP same-network connection mode.
5. Send `/teach` packets from Action Phone to Core Phone.
6. Send `/logs` and status reports back to Core Phone.
7. Add read-only Core Node dashboard before action routing.

## Later implementation target

- Termux/Python prototype on the Core Phone.
- Native Android foreground service if the prototype proves stable.
- Optional private VPN/Tailscale-style bridge for remote pairing.
- Multi-node capability manifests and emergency stop.

## No-paid-runtime rule

The Core Phone must remain useful for storage, rules, logs, skills, patch sync, and command routing even without OpenAI/API credits.
