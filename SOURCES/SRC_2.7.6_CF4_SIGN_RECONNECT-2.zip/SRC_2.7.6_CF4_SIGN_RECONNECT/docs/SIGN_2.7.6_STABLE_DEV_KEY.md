# SIGN_2.7.6_STABLE_DEV_KEY

## Purpose

Fix Android install-over-old continuity for SWRLZ debug/test APKs.

Android will not update an installed app when the new APK is signed by a different certificate. Uninstall/reinstall works because Android no longer has an old signer to compare against, but that resets app permissions and slows field testing.

## Rule

All future SWRLZ test APKs should be signed with the same stable SWRLZ dev certificate.

## GitHub Actions secrets

Configure these repository secrets once:

```text
SWRLZ_DEV_KEYSTORE_BASE64
SWRLZ_DEV_KEYSTORE_PASSWORD
SWRLZ_DEV_KEY_ALIAS
SWRLZ_DEV_KEY_PASSWORD
```

The repo workflow already checks for these secrets. When present, the build summary should show:

```text
stable-dev-signing-active
```

If secrets are missing, the summary will show debug/runner signing and Android may still require uninstall before reinstall.

## Helper script

Run from the source project root on a machine with `keytool`:

```bash
bash scripts/generate_swrlz_dev_signing_key.sh
```

Then paste the printed values into GitHub repository secrets.

## Safety

Do not commit the generated `.jks` file. Keep it in secrets only.
