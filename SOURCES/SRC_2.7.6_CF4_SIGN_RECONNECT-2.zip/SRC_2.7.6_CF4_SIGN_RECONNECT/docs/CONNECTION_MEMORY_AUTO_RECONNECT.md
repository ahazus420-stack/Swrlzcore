# Connection Memory / Last-Good Node Auto-Reconnect

## Purpose

Make SWRLZ recover the working local node without retyping the IP every time.

## Behavior

- Saves a last-good node only after `/discovery/signature` verifies a valid `swrlz-local-node`.
- On Network Discovery screen open, Auto Reconnect checks the saved Core Node URL first.
- If the saved Core Node fails, Auto Reconnect tries the last-good fallback.
- Successful auto reconnect refreshes the last-good timestamp and updates the current node field.
- Auto Reconnect can be toggled ON/OFF and is saved.
- Last-good memory can be cleared without deleting the saved Core Node config.

## Why

Hotspot and router IPs can change, but the last verified node should stay available as a fast path before a full subnet scan.
