# SWRLZ-Core Roadmap Update 2.2 — Admin + How-To + Info Legend

## Patch

`2.2-ADMIN-HOWTO-INFO`

## Android identity

```text
versionName = 0.2.2-admin-howto-info
versionCode = 9
```

## Completed

- [x] Core Node Admin tab.
- [x] In-app How-To tab.
- [x] In-app Info/Legend tab.
- [x] Core Node admin settings request helper.
- [x] Core Node recent events request helper.
- [x] Core Node session log request helper.
- [x] Core Node update URL save helper.
- [x] Updated source ZIP/provenance identity.
- [x] Updated latest app README.

## Next app target: 2.3

- [ ] Dedicated small-screen layout fixes for long labels.
- [ ] Core Node update staging button.
- [ ] Admin password change UI.
- [ ] Pairing workflow UI.
- [ ] Server logs viewer formatting.
- [ ] Loopback/LAN mode badge.
