# SWRLZ-Core Latest App Patch — 0.2.5 Command Cards

## What this build is

`0.2.5-command-cards` is the first app build where the command bridge becomes card-based instead of raw JSON/manual copying only.

## How to build in a fresh GitHub repo or Codespace

1. Upload `SWRLZ_CORE_2.5_COMMAND_CARDS_SOURCE.zip`.
2. Extract it into a clean nested folder.
3. Open the folder that contains `android/`, `backend/`, `core/`, `docs/`, and `scripts/`.
4. Run:

```bash
bash scripts/install_android_sdk_and_build.sh
```

5. Download the ZIP created in `APK_DOWNLOAD`.

## How to test

1. Install the APK.
2. Start the local node server on the other phone or same phone.
3. In SWRLZ-Core, open `Core` and test the Core Node URL.
4. Open `Cmds`.
5. Create a safe test command.
6. Use the card buttons to ACK and COMPLETE it.

## Important

A new repo can be used as a clean project workspace. The source ZIP is repo-portable. Platform account or AI usage limits may still apply to the account/plan, so keep each build script-driven and avoid unnecessary AI edits.
