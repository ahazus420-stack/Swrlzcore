# SWRLZ-Core 2.7.3 — Theme Armor Patch Report

## Summary

Theme Armor adds the first real token-driven UI skin system for SWRLZ-Core. It keeps semantic status meanings stable while allowing theme families and variants to control the cockpit's surfaces, panels, cards, tabs, buttons, text, and glow style.

## Preserved laws

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Visible build identity required.
- Mentor backend and Local Core Node remain separate.
- Status colors remain semantic.

## Added

- `SwurlzThemeTokens` model.
- Surface/text/border/accent/button/tab/card/input/effect token groups.
- Semantic `SwurlzStatusColors`.
- Original Core, Glitch Neon, Pharaoh Emerald, and Void Jester theme families.
- Dark, Sunlight, and Inverse variants.
- Token resolver and `LocalSwurlzTokens` composition local.
- Style/Appearance screen with live preview cards.
- High Contrast setting.
- Semantic Borders Only setting.
- Solid Buttons in Sunlight setting.
- Glow Strength setting.

## Updated files

- `android/app/build.gradle.kts`
- `android/app/src/main/java/sh/swurlz/core/ui/theme/Theme.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/screens/StyleScreen.kt`
- `android/app/src/main/java/sh/swurlz/core/MainActivity.kt`
- `android/app/src/main/java/sh/swurlz/core/model/Models.kt`
- `android/app/src/main/java/sh/swurlz/core/data/Prefs.kt`
- `core/version.json`
- `core/patch_manifest.json`

## Not changed

Local Node Server remains `0.7.1 Presence Index`.

## Verification performed in this packaging environment

- Source patched and packaged.
- Build identity updated in Gradle config.
- Version metadata updated.
- SHA-256 files generated.

## Not verified here

- APK compile/build. This sandbox has no internet access for Gradle distribution/dependency downloads.
