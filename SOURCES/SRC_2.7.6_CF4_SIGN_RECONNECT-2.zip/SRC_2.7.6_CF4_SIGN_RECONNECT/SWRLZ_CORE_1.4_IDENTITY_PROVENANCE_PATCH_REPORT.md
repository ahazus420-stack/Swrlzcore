# SWRLZ-CORE 1.4 Identity + Provenance Patch Report

**Patch label:** 1.4-IDENTITY-PROVENANCE  
**Android versionName:** 0.1.6-identity-provenance  
**Android versionCode:** 6  
**Source ZIP:** SWRLZ_CORE_1.4_IDENTITY_PROVENANCE_SOURCE.zip  
**Baseline:** SWRLZ_CORE_1.3_CTXVIEW_SELF_CAPTURE_HOTFIX_SOURCE.zip

## Purpose

This patch makes every SWRLZ APK visibly identifiable from inside the running app. It prevents mystery builds where the source ZIP changed but the Home screen still showed the same old version number.

## Project law added

```text
No invisible patches.
No mystery APKs.
Every build carries its nameplate.
```

## Modified files

```text
android/app/build.gradle.kts
android/app/src/main/java/sh/swurlz/core/model/ContextModels.kt
android/app/src/main/java/sh/swurlz/core/data/ContextCollectors.kt
android/app/src/main/java/sh/swurlz/core/ui/screens/HomeScreen.kt
scripts/build_android_debug_bundle.sh
core/version.json
core/patch_manifest.json
SWRLZ_CORE_MASTER_ROADMAP.md
docs/SWRLZ_CORE_ROADMAP_UPDATE_1.4_IDENTITY_PROVENANCE.md
```

## What changed

- Bumped Android app identity to `0.1.6-identity-provenance · code 6`.
- Added BuildConfig identity fields: patch label, roadmap revision, build line, source ZIP, and patch notes.
- Added a Home-screen BUILD IDENTITY panel.
- Added optional `BuildIdentityContext` to SWRLZ app context packets.
- Populated build identity when SWRLZ observes its own package.
- Updated build provenance script to print SWRLZ Build Identity fields.
- Updated roadmap revision to 1.4 with new identity acceptance tests.

## Expected phone tests

1. Build with `bash scripts/install_android_sdk_and_build.sh`.
2. Install the APK over the CTXVIEW hotfix.
3. Confirm Home shows `v0.1.6-identity-provenance · code 6`.
4. Confirm Home shows `Patch: 1.4-IDENTITY-PROVENANCE`.
5. Refresh STANDARD context and confirm `buildIdentity` appears.
6. Refresh DETAILED context and confirm bounds still appear.
7. Refresh MINIMAL context and confirm detailed app identity is still reduced.
8. Confirm the old giant context-preview self-capture blob does not return.
9. Confirm `BUILD_PROVENANCE_REPORT.md` includes the SWRLZ Build Identity section.

## Rollback

Keep the previous CTXVIEW hotfix source/APK until this identity patch builds and installs. If this patch fails, return to `SWRLZ_CORE_1.3_CTXVIEW_SELF_CAPTURE_HOTFIX_SOURCE.zip`.
