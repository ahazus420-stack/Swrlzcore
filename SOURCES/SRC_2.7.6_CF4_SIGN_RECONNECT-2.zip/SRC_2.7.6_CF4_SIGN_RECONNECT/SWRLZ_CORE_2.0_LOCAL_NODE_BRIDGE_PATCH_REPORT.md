# SWRLZ-CORE 2.0 Local Node Bridge Patch Report

## Patch identity

- Android versionName: `0.2.0-local-node-bridge`
- Android versionCode: `7`
- Patch label: `2.0-LOCAL-NODE-BRIDGE`
- Roadmap revision: `2.0`
- Source ZIP: `SWRLZ_CORE_2.0_LOCAL_NODE_BRIDGE_SOURCE.zip`

## Purpose

This patch begins the multi-device/local-first bridge layer. It keeps the online Mentor optional and separate from a local Core Node.

## Android changes

- Added Core Node URL field.
- Added Core Node pairing token field using encrypted preferences.
- Added `SAVE CORE` and `TEST CORE NODE` controls.
- Added Core Node `/status` client.
- Added Home status row for `Local Core Node bridge`.
- Added Home readiness card when Core Node is not configured.
- Preserved context-sharing modes, CTXVIEW self-capture fix, and build identity panel.

## Backend/local-node prototype changes

- Local node prototype version updated to `0.2.0-local-node-bridge`.
- `/status` now returns `node_type`, `version`, `bridge_ready`, and the Core/Action phone law message.
- Added `/pair` endpoint with optional `SWRLZ_PAIRING_TOKEN` enforcement.

## Safety / privacy

- Core Node token is stored separately from Mentor API token.
- Core Node URL does not replace Mentor backend URL.
- A failed Core Node status check should never crash the app.
- No paid AI dependency is introduced.

## Expected result

The app should now visibly identify itself as `v0.2.0-local-node-bridge · code 7`, show the Core Node bridge controls in Setup, and report Core Node status cleanly on Home.
