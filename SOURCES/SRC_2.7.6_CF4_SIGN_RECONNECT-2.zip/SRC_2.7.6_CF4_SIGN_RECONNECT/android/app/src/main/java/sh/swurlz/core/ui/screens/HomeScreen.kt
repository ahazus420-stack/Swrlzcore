package sh.swurlz.core.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.PermissionHelper
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeCheckRecord
import sh.swurlz.core.net.Api
import sh.swurlz.core.net.CoreNodeApi
import sh.swurlz.core.ui.theme.SwurlzColors

private data class MentorStatus(val online: Boolean, val label: String)
private data class CoreBridgeStatus(val tone: StatusTone, val label: String, val detail: String? = null)
private enum class StatusTone { GREEN, YELLOW, RED }

@Composable
fun HomeScreen(
    onOpenCockpit: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenPerms: () -> Unit,
    onOpenDiscovery: () -> Unit,
) {
    val ctx = LocalContext.current
    var mentor by remember { mutableStateOf(MentorStatus(false, "CHECKING…")) }
    var configured by remember { mutableStateOf(false) }
    var coreConfigured by remember { mutableStateOf(false) }
    var coreBridge by remember { mutableStateOf(CoreBridgeStatus(StatusTone.YELLOW, "CHECKING SAVED NODE…")) }
    var coreManualLine by remember { mutableStateOf("Last manual test: not run") }
    var coreAutoLine by remember { mutableStateOf("Last auto-check: not run") }
    var serverIdentity by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val mentorCfg = Prefs.mentorConfig(ctx)
        configured = mentorCfg.configured
        mentor = if (!mentorCfg.configured) {
            MentorStatus(false, "OFFLINE MODE · NOT CONFIGURED")
        } else {
            runCatching { withContext(Dispatchers.IO) { Api.ping(ctx) } }
                .fold(
                    onSuccess = { MentorStatus(true, "ONLINE · HEALTH OK") },
                    onFailure = { MentorStatus(false, "UNREACHABLE · ${Api.userMessage(it)}") },
                )
        }

        val truth = Prefs.coreNodeTruthState(ctx)
        val coreConfig = truth.config
        coreConfigured = coreConfig.configured
        coreManualLine = checkLine("Last manual test", truth.manual)
        coreAutoLine = checkLine("Last auto-check", truth.auto)

        coreBridge = if (!coreConfig.configured) {
            serverIdentity = null
            CoreBridgeStatus(StatusTone.YELLOW, "NOT CONFIGURED", "Set a Core Node URL in Setup or Core.")
        } else {
            coreBridge = CoreBridgeStatus(StatusTone.YELLOW, "AUTO-CHECKING", coreConfig.nodeUrl)
            runCatching { withContext(Dispatchers.IO) { CoreNodeApi.status(ctx) } }
                .fold(
                    onSuccess = { core ->
                        val node = core.nodeName ?: "SWRLZ Local Core Node"
                        val version = core.coreVersion ?: core.version ?: "unknown"
                        val summary = "$node · $version"
                        val identity = buildString {
                            append("Server: $node\n")
                            append("Version: $version\n")
                            if (!core.patchLabel.isNullOrBlank()) append("Patch: ${core.patchLabel}\n")
                            if (!core.roadmap.isNullOrBlank()) append("Roadmap: ${core.roadmap}\n")
                            if (!core.localUrl.isNullOrBlank()) append("Local: ${core.localUrl}\n")
                            if (core.lanUrls.isNotEmpty()) append("LAN: ${core.lanUrls.joinToString()}\n")
                            append("Paid AI required: ${core.paidAiRequired ?: false}")
                        }
                        Prefs.setCoreNodeAutoCheck(ctx, true, summary, identity)
                        coreAutoLine = "Last auto-check: successful · just now"
                        serverIdentity = identity
                        CoreBridgeStatus(StatusTone.GREEN, "REACHABLE", summary)
                    },
                    onFailure = { err ->
                        val msg = CoreNodeApi.userMessage(err)
                        Prefs.setCoreNodeAutoCheck(ctx, false, msg, err.message.orEmpty())
                        coreAutoLine = "Last auto-check: failed · $msg"
                        serverIdentity = null
                        CoreBridgeStatus(StatusTone.RED, "UNREACHABLE", msg)
                    },
                )
        }
    }

    val accessibilityOk = PermissionHelper.isAccessibilityEnabled(ctx)
    val overlayOk = PermissionHelper.isOverlayGranted(ctx)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Column(
            Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Border)
                .background(Color(0xFF0A0A0B)).padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(SwurlzColors.Phosphor))
                Spacer(Modifier.width(8.dp))
                Text("LOCAL OPERATOR · STANDING BY", color = SwurlzColors.Phosphor, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            }
            Spacer(Modifier.height(14.dp))
            Text("SWURLZ · CORE", color = SwurlzColors.Bone, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 32.sp, letterSpacing = 4.sp)
            Text("context-aware offline-first action ai", color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
            Text("v${BuildConfig.VERSION_NAME} · code ${BuildConfig.VERSION_CODE}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
            Spacer(Modifier.height(8.dp))
            BuildIdentityPanel()
            Spacer(Modifier.height(14.dp))
            Text(
                "Local skills, allowlist controls, device context, and safety features remain usable without a server. " +
                    "When an optional Mentor is configured, SWRLZ can send a redacted device/app/screen context packet for stronger planning.",
                color = SwurlzColors.Ash,
                fontSize = 13.sp,
                lineHeight = 19.sp,
            )
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("OPEN COCKPIT →", SwurlzColors.Phosphor, onClick = onOpenCockpit)
                PrimaryButton("SETUP", SwurlzColors.Cyan, onClick = onOpenSetup)
                PrimaryButton("PERMISSIONS", SwurlzColors.Runic, onClick = onOpenPerms)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("NETWORK DISCOVERY →", SwurlzColors.Cyan, onClick = onOpenDiscovery)
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("▸ SYSTEM STATUS", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        StatusRow("Accessibility service", if (accessibilityOk) StatusTone.GREEN else StatusTone.RED, if (accessibilityOk) "READY" else "MISSING")
        StatusRow("Overlay permission", if (overlayOk) StatusTone.GREEN else StatusTone.RED, if (overlayOk) "READY" else "MISSING")
        StatusRow("Local Skill Library", StatusTone.GREEN, "READY")
        StatusRow("Device Context Capsule", StatusTone.GREEN, "READY")
        StatusRow("Optional Mentor backend", if (mentor.online) StatusTone.GREEN else StatusTone.YELLOW, mentor.label)
        StatusRow("Local Core Node bridge", coreBridge.tone, coreBridge.label, coreBridge.detail)

        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, statusColor(coreBridge.tone)).padding(12.dp)) {
            Text("▸ CORE NODE TRUTH", color = statusColor(coreBridge.tone), fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(5.dp))
            Text("Configured: ${if (coreConfigured) "yes" else "no"}", color = SwurlzColors.Bone, fontFamily = FontFamily.Monospace, fontSize = 9.sp)
            Text(coreManualLine, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 13.sp)
            Text(coreAutoLine, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 13.sp)
        }

        serverIdentity?.let { identity ->
            Spacer(Modifier.height(8.dp))
            Column(Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Cyan).padding(12.dp)) {
                Text("▸ SERVER IDENTITY", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(5.dp))
                Text(identity, color = SwurlzColors.Bone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 13.sp)
            }
        }

        if (!coreConfigured) {
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Cyan).padding(12.dp)) {
                Text("LOCAL CORE NODE READY TO PAIR", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(5.dp))
                Text(
                    "Set a Core Node URL in Setup when another phone, Termux server, or PC is ready. This is separate from the online Mentor and does not require paid AI.",
                    color = SwurlzColors.Bone,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
            }
        }

        if (!configured) {
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().border(1.dp, SwurlzColors.RiskYellow).padding(12.dp)) {
                Text("GRACEFUL OFFLINE MODE", color = SwurlzColors.RiskYellow, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(5.dp))
                Text(
                    "This means no Mentor server is configured, but the app stays open and local features continue working. " +
                        "Instead of crashing or showing a raw network exception, SWRLZ clearly reports which online features are unavailable.",
                    color = SwurlzColors.Bone,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Pillar("∆", "Context Intelligence", "Collects device, foreground app, and meaningful screen-change information so a Mentor does not plan blindly.")
        Pillar("Ω", "On-device Action", "AccessibilityService taps, scrolls, reads, and types while the allowlist limits where actions may occur.")
        Pillar("Ψ", "Privacy Redaction", "Passwords, possible one-time codes, account numbers, and token-like text are removed before online sharing.")
        Pillar("∑", "Local Skill Library", "Learned Skill Capsules remain stored and viewable on this phone during network or backend outages.")
        Pillar("⌁", "Core Node Bridge", "A separate local Core Node can pair through a URL and token, answer /status, and later receive teach packets and action proposals.")
    }
}

@Composable
private fun StatusRow(label: String, tone: StatusTone, detail: String, subdetail: String? = null) {
    val color = statusColor(tone)
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).border(1.dp, SwurlzColors.Border).padding(10.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Box(Modifier.padding(top = 5.dp).size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(label, color = SwurlzColors.Bone, fontSize = 13.sp, lineHeight = 17.sp)
                Spacer(Modifier.height(2.dp))
                Text(detail, color = color, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.1.sp, lineHeight = 12.sp)
            }
        }
        if (!subdetail.isNullOrBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(subdetail, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 11.sp, modifier = Modifier.padding(start = 18.dp))
        }
    }
}

private fun statusColor(tone: StatusTone): Color = when (tone) {
    StatusTone.GREEN -> SwurlzColors.Phosphor
    StatusTone.YELLOW -> SwurlzColors.RiskYellow
    StatusTone.RED -> SwurlzColors.RiskRed
}

private fun checkLine(prefix: String, record: CoreNodeCheckRecord): String {
    if (!record.checked) return "$prefix: not run"
    val result = if (record.success) "successful" else "failed"
    val whenText = record.checkedAt.ifBlank { "time not saved" }
    val summary = record.summary.ifBlank { "no detail" }
    return "$prefix: $result · $summary · $whenText"
}

@Composable
private fun Pillar(sigil: String, title: String, body: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).border(1.dp, SwurlzColors.Border).padding(12.dp)) {
        Text(sigil, color = SwurlzColors.Runic, fontFamily = FontFamily.Serif, fontSize = 24.sp, modifier = Modifier.padding(end = 14.dp))
        Column {
            Text(title, color = SwurlzColors.Bone, fontWeight = FontWeight.SemiBold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(4.dp))
            Text(body, color = SwurlzColors.Ash, fontSize = 12.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
fun PrimaryButton(text: String, color: Color, onClick: () -> Unit) {
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = color),
        border = androidx.compose.foundation.BorderStroke(1.dp, color),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp),
    ) {
        Text(text, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BuildIdentityPanel() {
    Column(
        Modifier.fillMaxWidth()
            .border(1.dp, SwurlzColors.Cyan)
            .background(Color(0xFF05080A))
            .padding(10.dp)
    ) {
        Text("▸ BUILD IDENTITY", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        IdentityLine("Patch", BuildConfig.PATCH_LABEL)
        IdentityLine("Roadmap", BuildConfig.ROADMAP_REVISION)
        IdentityLine("Build line", BuildConfig.BUILD_LINE)
        IdentityLine("Source", BuildConfig.SOURCE_ZIP)
        IdentityLine("Law", "No invisible patches · No mystery APKs")
    }
}

@Composable
private fun IdentityLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
        Text("$label:", color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 8.sp, modifier = Modifier.width(70.dp))
        Text(value, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 11.sp, modifier = Modifier.weight(1f))
    }
}
