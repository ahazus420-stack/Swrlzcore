package sh.swurlz.core.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

private data class MoreItem(
    val title: String,
    val route: String,
    val summary: String,
    val tone: MoreTone = MoreTone.Neutral,
)

private enum class MoreTone { Neutral, Admin, Safety, Library, Help }

@Composable
fun MoreScreen(nav: NavController) {
    val tokens = LocalSwurlzTokens.current
    val items = listOf(
        MoreItem("Network Discovery", "discovery", "Find, verify, save, and reuse a local SWRLZ node with /discovery/signature.", MoreTone.Admin),
        MoreItem("Core Admin", "core", "Local Core Node status, admin session, logs, events, and update info.", MoreTone.Admin),
        MoreItem("Permissions", "perms", "Accessibility and overlay readiness plus restricted-setting guide.", MoreTone.Safety),
        MoreItem("Allowlist", "allow", "Control which apps SWRLZ may observe or act inside.", MoreTone.Safety),
        MoreItem("Skills", "skills", "Local skill library and reusable learned capsules.", MoreTone.Library),
        MoreItem("How To", "howto", "Same-phone mode, two-phone bridge, update process, and command tests.", MoreTone.Help),
        MoreItem("Info", "info", "App vocabulary, status colors, core terms, and build legend.", MoreTone.Help),
    )

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
    ) {
        Text("▸ MORE / ADVANCED DRAWER", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "The main cockpit keeps Home, Radar, Network, Cockpit, Setup, and Style up front. Advanced tools live here so the top bar stays clean.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(14.dp))
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items.forEach { item ->
                MoreNavCard(item = item, onOpen = { nav.navigate(item.route) })
            }
        }
        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
            Text("NETWORK DISCOVERY LAW", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Primary mission flow stays visible. Node discovery stays one tap away. Debug stays available, but no longer owns the cockpit.",
                color = tokens.text.secondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
        }
    }
}

@Composable
private fun MoreNavCard(item: MoreItem, onOpen: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    val tone = when (item.tone) {
        MoreTone.Admin -> tokens.status.admin
        MoreTone.Safety -> tokens.status.warning
        MoreTone.Library -> tokens.status.success
        MoreTone.Help -> tokens.status.info
        MoreTone.Neutral -> tokens.borders.selected
    }
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(tokens.cards.bg).padding(12.dp)) {
        Text(item.title.uppercase(), color = tone, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(item.summary, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = onOpen,
            colors = ButtonDefaults.outlinedButtonColors(contentColor = tone, containerColor = tokens.buttons.ghostBg),
            border = BorderStroke(1.dp, tone),
            shape = RoundedCornerShape(0),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 9.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("OPEN ${item.title.uppercase()}", fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
        }
    }
}
