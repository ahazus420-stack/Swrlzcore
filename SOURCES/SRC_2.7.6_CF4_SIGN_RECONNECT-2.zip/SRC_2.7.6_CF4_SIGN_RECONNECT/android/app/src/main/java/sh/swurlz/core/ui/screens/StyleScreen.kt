package sh.swurlz.core.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.SwurlzThemeTokens

@Composable
fun StyleScreen() {
    val ctx = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    var settings by remember { mutableStateOf(UiStyleSettings()) }
    var deviceIdentity by remember { mutableStateOf("loading device identity…") }

    LaunchedEffect(Unit) {
        Prefs.ensureRelayIdentity(ctx)
        deviceIdentity = Prefs.relayConfig(ctx).let { "${it.deviceLabel} · ${it.deviceId}" }
    }
    LaunchedEffect(Unit) { Prefs.uiStyleFlow(ctx).collectLatest { settings = it } }

    fun save(next: UiStyleSettings) {
        settings = next
        scope.launch { Prefs.setUiStyle(ctx, next) }
    }

    Column(
        Modifier.fillMaxSize().background(tokens.surfaces.bgApp).verticalScroll(rememberScrollState()).padding(14.dp),
    ) {
        Text("▸ APPEARANCE / THEME ARMOR", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Theme Armor controls full cockpit skins, dark/sunlight/inverse variants, glow, density, contrast, and status-safe borders. Themes change armor; status colors keep truth.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(12.dp))

        StyleCard("CURRENT ARMOR", "Theme: ${settings.themePack}\nVariant: ${settings.displayMode}\nAnimation: ${settings.animationLevel}\nGlow: ${settings.glowStrength}\nText: ${settings.textSize}\nCards: ${settings.cardDensity}", tokens.accents.primary, tokens)

        Spacer(Modifier.height(14.dp))
        StyleTitle("THEME FAMILY", tokens)
        OptionRow(listOf("Original Core", "Glitch Neon", "Pharaoh Emerald", "Void Jester"), settings.themePack, tokens) { save(settings.copy(themePack = it)) }

        Spacer(Modifier.height(12.dp))
        StyleTitle("VARIANT", tokens)
        OptionRow(listOf("Dark", "Sunlight", "Inverse"), settings.displayMode, tokens) { save(settings.copy(displayMode = it)) }
        Text(
            when (settings.displayMode) {
                "Sunlight" -> "Sunlight mode raises contrast, thickens surfaces, and uses more solid button fills for outdoor readability."
                "Inverse" -> "Inverse is a designed contrast flip, not a raw filter. Semantic status colors stay meaningful."
                else -> "Dark mode keeps the night cockpit glow and original field-forged feel."
            },
            color = tokens.text.muted,
            fontSize = 11.sp,
            lineHeight = 16.sp,
        )

        Spacer(Modifier.height(16.dp))
        StyleTitle("LIVE PREVIEW", tokens)
        ThemePreview(tokens)

        Spacer(Modifier.height(16.dp))
        StyleTitle("READABILITY", tokens)
        OptionRow(listOf("Compact", "Standard", "Large"), settings.textSize, tokens) { save(settings.copy(textSize = it)) }
        Spacer(Modifier.height(10.dp))
        ToggleRow("High Contrast", "Boosts primary text and neutral border strength for harsher light.", settings.highContrast, tokens) { save(settings.copy(highContrast = it)) }
        ToggleRow("Semantic Borders Only", "Normal cards use theme borders. Only real status states use green/yellow/red/cyan/purple borders.", settings.semanticBordersOnly, tokens) { save(settings.copy(semanticBordersOnly = it)) }
        ToggleRow("Solid Buttons in Sunlight", "Sunlight variant uses stronger button fills instead of faint outlines.", settings.solidButtonsInSunlight, tokens) { save(settings.copy(solidButtonsInSunlight = it)) }

        Spacer(Modifier.height(16.dp))
        StyleTitle("MOTION + DENSITY", tokens)
        OptionRow(listOf("Off", "Low", "Standard", "Pulse"), settings.animationLevel, tokens) { save(settings.copy(animationLevel = it)) }
        Spacer(Modifier.height(10.dp))
        OptionRow(listOf("Off", "Low", "Medium", "High"), settings.glowStrength, tokens) { save(settings.copy(glowStrength = it)) }
        Spacer(Modifier.height(10.dp))
        OptionRow(listOf("Compact", "Comfortable", "Spacious"), settings.cardDensity, tokens) { save(settings.copy(cardDensity = it)) }

        Spacer(Modifier.height(16.dp))
        StyleTitle("NODE HEARTBEAT", tokens)
        ToggleRow("Auto Presence", "When ON, SWRLZ auto-generates/stores a device identity and checks in with the configured Core Node while the app/Radar is active.", settings.autoPresenceEnabled, tokens) { save(settings.copy(autoPresenceEnabled = it)) }
        Spacer(Modifier.height(8.dp))
        StyleCard("THIS DEVICE", deviceIdentity, tokens.status.success, tokens)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StyleButton("ROTATE ID", tokens.status.warning, tokens, Modifier.weight(1f)) {
                scope.launch {
                    val next = Prefs.rotateRelayDeviceIdentity(ctx)
                    deviceIdentity = "${next.deviceLabel} · ${next.deviceId}"
                }
            }
            StyleButton("FORGET ID", tokens.status.danger, tokens, Modifier.weight(1f)) {
                scope.launch {
                    Prefs.forgetRelayDeviceIdentity(ctx)
                    val next = Prefs.ensureRelayIdentity(ctx)
                    deviceIdentity = "${next.deviceLabel} · ${next.deviceId}"
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        StyleCard(
            "THEME ARMOR LAW",
            "Themes may change the armor, glow, text, cards, tabs, and button fills. Themes may not lie about status. Success stays green. Waiting stays yellow. Danger stays red. Info stays cyan. Admin stays purple.",
            tokens.accents.secondary,
            tokens,
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StyleTitle(label: String, tokens: SwurlzThemeTokens) {
    Text("▸ $label", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
    Spacer(Modifier.height(7.dp))
}

@Composable
private fun OptionRow(options: List<String>, selected: String, tokens: SwurlzThemeTokens, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        options.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { item ->
                    val isSelected = item == selected
                    StyleButton(item.uppercase(), if (isSelected) tokens.tabs.selectedBorder else tokens.accents.primary, tokens, Modifier.weight(1f), selected = isSelected) { onSelect(item) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, body: String, checked: Boolean, tokens: SwurlzThemeTokens, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).border(1.dp, if (checked) tokens.status.success else tokens.borders.neutral).background(tokens.cards.bg).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(body, color = tokens.text.muted, fontSize = 11.sp, lineHeight = 16.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StyleButton(label: String, tone: Color, tokens: SwurlzThemeTokens, modifier: Modifier = Modifier, selected: Boolean = false, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(46.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (selected) tokens.tabs.selectedText else tone, containerColor = if (selected) tokens.tabs.selectedBg else tokens.buttons.ghostBg),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, tone),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(0),
    ) { Text(label, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.5.sp) }
}

@Composable
private fun StyleCard(title: String, body: String, tone: Color, tokens: SwurlzThemeTokens) {
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(tokens.cards.bg).padding(12.dp)) {
        Text(title, color = tone, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(7.dp))
        Text(body, color = tokens.text.primary, fontSize = 13.sp, lineHeight = 19.sp)
    }
}

@Composable
private fun ThemePreview(tokens: SwurlzThemeTokens) {
    Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
        Text("SELECTED TAB", color = tokens.tabs.selectedText, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PreviewChip("ONLINE", tokens.status.success, tokens)
            PreviewChip("QUEUED", tokens.status.warning, tokens)
            PreviewChip("ADMIN", tokens.status.admin, tokens)
        }
        Spacer(Modifier.height(10.dp))
        StyleCard("ONLINE DEVICE", "Action Phone · group kami-lab · heartbeat active", tokens.status.success, tokens)
        Spacer(Modifier.height(8.dp))
        StyleCard("QUEUED PACKET", "PING packet waiting for display / ACK / COMPLETE lifecycle.", tokens.status.warning, tokens)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PreviewButton("PRIMARY", tokens.buttons.primaryBg, tokens.buttons.primaryText, tokens.buttons.primaryBorder, Modifier.weight(1f))
            PreviewButton("DANGER", tokens.buttons.dangerBg, tokens.buttons.dangerText, tokens.buttons.dangerBorder, Modifier.weight(1f))
        }
    }
}

@Composable
private fun PreviewChip(label: String, tone: Color, tokens: SwurlzThemeTokens) {
    Box(Modifier.border(1.dp, tone).background(tokens.cards.chipBg).padding(horizontal = 9.dp, vertical = 6.dp)) {
        Text(label, color = tone, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun PreviewButton(label: String, bg: Color, text: Color, border: Color, modifier: Modifier = Modifier) {
    Box(modifier.height(42.dp).border(1.dp, border).background(bg), contentAlignment = Alignment.Center) {
        Text(label, color = text, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.4.sp)
    }
}
