package sh.swurlz.core.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.ui.theme.SwurlzColors

@Composable
fun InfoScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("▸ APP LEGEND", color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text("Everything in SWRLZ-Core, what it is, and what it does. Current patch: ${BuildConfig.PATCH_LABEL}", color = SwurlzColors.Ash, fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(12.dp))
        Legend("Home", "Main status dashboard. Shows build identity, accessibility, overlay, skill library, context capsule, Mentor status, and the bridge truth card.")
        Legend("Cockpit", "Mission control panel for entering tasks, starting missions, pausing, taking over, and reviewing the action timeline.")
        Legend("Skills", "Local Skill Library. Shows learned or cached skill capsules that should remain available offline.")
        Legend("Allow", "App allowlist. SWRLZ refuses actions in apps that are not allowed. Bulk controls apply only to visible filtered apps.")
        Legend("Setup", "Mentor backend, private token, Core Node URL, pairing token, context sharing level, and context preview controls.")
        Legend("Perms", "Permission Center. Confirms Accessibility Service and System Overlay permission and explains Android restricted settings.")
        Legend("Core", "Local Core Node Admin. Tests /status, views admin settings/events/logs/update info, and saves server/client update URLs.")
        Legend("Cmds", "Command Cards. Pulls pending Core Node commands, creates safe test commands, and gives lifecycle-gated ACK/REJECT/COMPLETE controls.")
        Legend("How To", "Step-by-step setup/update instructions for same-phone mode, two-phone bridge mode, server process control, and command-card testing.")
        Legend("Info", "This legend screen. Explains the app vocabulary and status colors.")
        Spacer(Modifier.height(8.dp))
        Text("▸ STATUS COLORS", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Legend("Green", "Ready, connected, granted, reachable, or successful. Core Node green requires valid ok=true /status plus node identity and server version.")
        Legend("Yellow", "Offline mode, not configured, waiting, testing, untested, or needs more information.")
        Legend("Red", "Failed, blocked, missing, unreachable, rejected, denied, or unsafe.")
        Spacer(Modifier.height(8.dp))
        Text("▸ CORE TERMS", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Legend("Mentor backend", "Optional online planning server. Separate from the local Core Node. May need an API provider later.")
        Legend("Local Core Node", "Local server running on Termux, another phone, or PC. Does not require paid AI to answer /status and manage local settings.")
        Legend("Configured", "A Core Node URL is saved. This does not prove the server is reachable.")
        Legend("Last manual test", "The most recent result from pressing TEST CORE NODE.")
        Legend("Last auto-check", "The most recent saved-server /status check done by the app on launch or screen load.")
        Legend("Reachable", "The server answered with ok=true, node identity, and server version. Anything less stays yellow/red.")
        Legend("Loopback", "Same-device mode using http://127.0.0.1:8787.")
        Legend("LAN bridge", "Phone-to-phone or phone-to-PC mode using http://192.168.x.x:8787.")
        Legend("Core Node URL", "The local server address saved in SWRLZ-Core. Use loopback only on the same device; use LAN URL across devices.")
        Legend("Pairing token", "Optional local bridge token. Keep it masked; do not paste secrets into public repos.")
        Legend("Admin password", "Server admin credential for settings/logs/update info. The app masks it and should never display the real value.")
        Legend("Command Cards", "Safe command proposals from the Core Node. Current actions are test/lifecycle only; no hidden autonomous behavior.")
        Legend("ACK", "Action Phone accepts a pending command for testing.")
        Legend("REJECT", "Action Phone rejects a pending/accepted command.")
        Legend("COMPLETE", "Action Phone reports an accepted command completed. Completed/rejected/failed cards become read-only.")
        Legend("Context preview", "Local JSON packet showing what SWRLZ would share before online missions.")
        Legend("Build identity", "Visible patch/version card. Rule: no invisible patches, no mystery APKs.")
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Legend(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp).border(1.dp, SwurlzColors.Border).padding(10.dp)) {
        Text(title, color = SwurlzColors.Bone, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(4.dp))
        Text(body, color = SwurlzColors.Ash, fontSize = 11.sp, lineHeight = 16.sp)
    }
}
