package sh.swurlz.core.net

import android.content.Context
import android.util.Base64
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.websocket.WebSockets
import io.ktor.client.request.delete
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.DeviceContextCollector
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.model.*
import java.net.URLEncoder

class BackendNotConfiguredException : IllegalStateException("Online Mentor is not configured")
class BackendHttpException(val statusCode: Int, message: String) : IllegalStateException(message)
class BackendProtocolException(message: String) : IllegalStateException(message)

object Api {
    private data class Connection(val base: String, val token: String)

    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
        prettyPrint = false
    }

    val http = HttpClient(OkHttp) {
        install(WebSockets)
        install(HttpTimeout) {
            requestTimeoutMillis = 60_000
            connectTimeoutMillis = 15_000
            socketTimeoutMillis = 60_000
        }
    }

    suspend fun isConfigured(ctx: Context): Boolean = Prefs.mentorConfig(ctx).configured

    suspend fun ping(ctx: Context): String {
        val c = connection(ctx)
        val response = http.get("${c.base}/health") { applyAuth(c.token) }
        return decodeText(response)
    }

    suspend fun createMission(ctx: Context, req: MissionCreate): Mission {
        val c = connection(ctx)
        return decodeJson(http.post("${c.base}/missions") {
            applyAuth(c.token)
            contentType(ContentType.Application.Json)
            setBody(json.encodeToString(MissionCreate.serializer(), req))
        })
    }

    suspend fun listMissions(ctx: Context): List<Mission> {
        val c = connection(ctx)
        return decodeJson(http.get("${c.base}/missions") { applyAuth(c.token) })
    }

    suspend fun setMissionState(
        ctx: Context,
        missionId: String,
        state: String,
        step: Int? = null,
        total: Int? = null,
    ) {
        val c = connection(ctx)
        val body = buildMap<String, JsonElement> {
            put("state", kotlinx.serialization.json.JsonPrimitive(state))
            step?.let { put("step", kotlinx.serialization.json.JsonPrimitive(it)) }
            total?.let { put("total", kotlinx.serialization.json.JsonPrimitive(it)) }
        }
        decodeText(http.post("${c.base}/missions/$missionId/state") {
            applyAuth(c.token)
            contentType(ContentType.Application.Json)
            setBody(json.encodeToString(body))
        })
    }

    suspend fun plan(ctx: Context, req: PlanRequest): PlanResponse {
        val c = connection(ctx)
        return decodeJson(http.post("${c.base}/plan") {
            applyAuth(c.token)
            contentType(ContentType.Application.Json)
            setBody(json.encodeToString(PlanRequest.serializer(), req))
        })
    }

    suspend fun logEvent(
        ctx: Context,
        missionId: String,
        phase: String,
        action: JsonElement,
        observed: String? = null,
    ) {
        val c = connection(ctx)
        val body = buildMap<String, JsonElement> {
            put("phase", kotlinx.serialization.json.JsonPrimitive(phase))
            put("action", action)
            observed?.let { put("observed", kotlinx.serialization.json.JsonPrimitive(it)) }
        }
        decodeText(http.post("${c.base}/missions/$missionId/events") {
            applyAuth(c.token)
            contentType(ContentType.Application.Json)
            setBody(json.encodeToString(body))
        })
    }

    suspend fun listSkills(ctx: Context): List<SkillCapsule> {
        val c = connection(ctx)
        return decodeJson(http.get("${c.base}/skills") { applyAuth(c.token) })
    }

    suspend fun createSkill(ctx: Context, skill: SkillCapsule): SkillCapsule {
        val c = connection(ctx)
        return decodeJson(http.post("${c.base}/skills") {
            applyAuth(c.token)
            contentType(ContentType.Application.Json)
            setBody(json.encodeToString(SkillCapsule.serializer(), skill))
        })
    }

    suspend fun deleteSkill(ctx: Context, id: String) {
        val c = connection(ctx)
        decodeText(http.delete("${c.base}/skills/$id") { applyAuth(c.token) })
    }

    suspend fun suggestSkill(ctx: Context, missionId: String): JsonElement {
        val c = connection(ctx)
        return decodeJson(http.post("${c.base}/skills/suggest") {
            applyAuth(c.token)
            contentType(ContentType.Application.Json)
            setBody(json.encodeToString(mapOf("mission_id" to missionId)))
        })
    }


    fun userMessage(t: Throwable): String = when (t) {
        is BackendNotConfiguredException -> "mentor not configured"
        is BackendHttpException -> when (t.statusCode) {
            401, 403 -> "mentor authentication rejected"
            404 -> "mentor route unavailable"
            429 -> "mentor rate limit reached"
            in 500..599 -> "mentor service error"
            else -> "mentor returned HTTP ${t.statusCode}"
        }
        is BackendProtocolException -> "mentor returned an invalid response"
        else -> when {
            t.message?.contains("timeout", ignoreCase = true) == true -> "mentor timed out"
            t.message?.contains("Unable to resolve host", ignoreCase = true) == true -> "no network connection"
            t.message?.contains("Failed to connect", ignoreCase = true) == true -> "mentor unreachable"
            else -> "mentor unreachable"
        }
    }

    private suspend fun connection(ctx: Context): Connection {
        val config = Prefs.mentorConfig(ctx)
        val url = config.backendUrl.trim().trimEnd('/')
        if (url.isBlank()) throw BackendNotConfiguredException()
        return Connection(base = "$url/api", token = config.apiToken)
    }

    private fun io.ktor.client.request.HttpRequestBuilder.applyAuth(token: String) {
        header(HttpHeaders.Accept, ContentType.Application.Json)
        if (token.isNotBlank()) header("X-Swurlz-Token", token)
    }

    private suspend inline fun <reified T> decodeJson(response: HttpResponse): T {
        val text = response.bodyAsText()
        validate(response, text, requireJson = true)
        return try {
            json.decodeFromString<T>(text)
        } catch (t: Throwable) {
            throw BackendProtocolException("Could not decode Mentor JSON: ${t.message}")
        }
    }

    private suspend fun decodeText(response: HttpResponse): String {
        val text = response.bodyAsText()
        validate(response, text, requireJson = false)
        return text
    }

    private fun validate(response: HttpResponse, body: String, requireJson: Boolean) {
        if (!response.status.isSuccess()) {
            val detail = body.take(240).ifBlank { response.status.description }
            throw BackendHttpException(response.status.value, detail)
        }
        if (requireJson) {
            val type = response.headers[HttpHeaders.ContentType].orEmpty().lowercase()
            if (!type.contains("application/json")) {
                throw BackendProtocolException("Expected JSON but received ${type.ifBlank { "unknown content type" }}")
            }
        }
    }
}


class CoreNodeNotConfiguredException : IllegalStateException("Local Core Node is not configured")
class CoreNodeHttpException(val statusCode: Int, message: String) : IllegalStateException(message)
class CoreNodeProtocolException(message: String) : IllegalStateException(message)

object CoreNodeApi {
    private data class Connection(val base: String, val token: String)

    suspend fun isConfigured(ctx: Context): Boolean = Prefs.coreNodeConfig(ctx).configured

    suspend fun status(ctx: Context): CoreNodeStatus {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/status") { applyCoreAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        val obj = try {
            Api.json.decodeFromString<JsonObject>(body)
        } catch (t: Throwable) {
            throw CoreNodeProtocolException("Could not decode Core Node JSON: ${t.message}")
        }
        val ok = obj.booleanAny("ok")
        val nodeName = obj.stringAny("node_name", "nodeName", "node", "name")
        val version = obj.stringAny("server_version", "version", "core_version", "coreVersion")
        if (ok != true || nodeName.isNullOrBlank() || version.isNullOrBlank()) {
            throw CoreNodeProtocolException("/status did not include ok=true, node identity, and server version")
        }
        val connection = obj["connection"] as? JsonObject
        val lanUrls = connection?.get("lan_urls")?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
        return CoreNodeStatus(
            reachable = true,
            label = "REACHABLE",
            nodeName = nodeName,
            nodeType = obj.stringAny("node_type", "nodeType", "type"),
            coreVersion = version,
            version = version,
            patchLabel = obj.stringAny("patch_label", "patchLabel"),
            roadmap = obj.stringAny("roadmap", "roadmap_revision", "roadmapRevision"),
            localUrl = connection?.get("local_url")?.jsonPrimitive?.contentOrNull,
            lanUrls = lanUrls,
            paidAiRequired = obj.booleanAny("paid_ai_required", "paidAiRequired"),
            message = obj.stringAny("message", "status", "detail"),
        )
    }


    suspend fun adminSettings(ctx: Context, username: String, password: String): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/settings") { applyCoreAdminAuth(ctx, username, password, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun recentEvents(ctx: Context, username: String, password: String): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/events/recent") { applyCoreAdminAuth(ctx, username, password, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun sessionLog(ctx: Context, username: String, password: String): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/logs/session") { applyCoreAdminAuth(ctx, username, password, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun updateInfo(ctx: Context, username: String, password: String): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/update/info") { applyCoreAdminAuth(ctx, username, password, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun updateAdminSettings(
        ctx: Context,
        username: String,
        password: String,
        serverUpdateUrl: String,
        clientUpdateUrl: String,
    ): String {
        val c = connection(ctx)
        val bodyMap = mapOf(
            "server_update_url" to serverUpdateUrl.trim(),
            "client_update_url" to clientUpdateUrl.trim(),
        )
        val response = Api.http.post("${c.base}/admin/settings") {
            applyCoreAdminAuth(ctx, username, password, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(bodyMap))
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }



    suspend fun pendingCommands(ctx: Context): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/commands/pending") { applyCoreAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun allCommands(ctx: Context, username: String, password: String): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/commands/all") { applyCoreAdminAuth(ctx, username, password, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun createTestCommand(ctx: Context, username: String, password: String, title: String, commandType: String): String {
        val c = connection(ctx)
        val bodyMap = mapOf(
            "type" to commandType.trim().ifBlank { "PING" },
            "title" to title.trim().ifBlank { "SWRLZ ping test" },
            "risk" to "low",
            "description" to "First safe command queue test from SWRLZ-Core app.",
        )
        val response = Api.http.post("${c.base}/admin/commands/create") {
            applyCoreAdminAuth(ctx, username, password, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(bodyMap))
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun ackCommand(ctx: Context, commandId: String, decision: String): String {
        val c = connection(ctx)
        val bodyMap = mapOf("decision" to decision)
        val response = Api.http.post("${c.base}/commands/${commandId.trim()}/ack") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(bodyMap))
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun completeCommand(ctx: Context, commandId: String, result: String, detail: String): String {
        val c = connection(ctx)
        val bodyMap = mapOf(
            "result" to result,
            "detail" to detail,
        )
        val response = Api.http.post("${c.base}/commands/${commandId.trim()}/result") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(bodyMap))
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }


    suspend fun adminSessionLogin(ctx: Context, username: String, password: String): String {
        val c = connection(ctx)
        val deviceId = Prefs.relayConfig(ctx).deviceId.ifBlank { DeviceContextCollector.collect(ctx).deviceNodeId }
        val bodyJson = buildJsonObject {
            put("username", username.trim().ifBlank { "admin" })
            put("password", password)
            put("device_id", deviceId)
        }
        val response = Api.http.post("${c.base}/admin/session/login") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(bodyJson.toString())
        }
        val body = response.bodyAsText()
        validate(response, body)
        val obj = Api.json.parseToJsonElement(body).jsonObject
        val token = obj["admin_session_token"]?.jsonPrimitive?.contentOrNull.orEmpty()
        val sessionId = obj["session_id"]?.jsonPrimitive?.contentOrNull.orEmpty()
        if (token.isNotBlank()) Prefs.saveAdminSession(ctx, username, token, sessionId)
        return body
    }

    suspend fun adminSessionStatus(ctx: Context): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/session/status") { applyCoreSavedAdminAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        Prefs.touchAdminVerified(ctx)
        return body
    }

    suspend fun revokeSavedAdminSession(ctx: Context): String {
        val c = connection(ctx)
        val token = SecretStore.adminSessionToken(ctx)
        val response = Api.http.post("${c.base}/admin/session/revoke") {
            applyCoreSavedAdminAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(mapOf("admin_session_token" to token)))
        }
        val body = response.bodyAsText()
        validate(response, body)
        Prefs.forgetAdminSession(ctx)
        return body
    }

    suspend fun createGroup(ctx: Context, groupId: String, groupKey: String, label: String): String {
        val c = connection(ctx)
        val bodyMap = mapOf("group_id" to groupId.trim(), "group_key" to groupKey.trim(), "label" to label.trim())
        val response = Api.http.post("${c.base}/groups/create") {
            applyCoreSavedAdminAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(bodyMap))
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun joinGroup(ctx: Context, config: RelayConfig): String {
        val c = connection(ctx)
        val bodyJson = buildJsonObject {
            put("group_id", config.groupId)
            put("group_key", config.groupKey)
            put("device_id", config.deviceId)
            put("device_key", config.deviceKey)
            put("device_label", config.deviceLabel)
            put("role", config.role)
        }
        val response = Api.http.post("${c.base}/groups/join") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(bodyJson.toString())
        }
        val body = response.bodyAsText()
        validate(response, body)
        val obj = Api.json.parseToJsonElement(body).jsonObject
        val device = obj["device"] as? JsonObject
        val returnedKey = device?.get("device_key")?.jsonPrimitive?.contentOrNull.orEmpty()
        if (returnedKey.isNotBlank() && returnedKey != "saved-on-device") {
            Prefs.setRelayConfig(ctx, config.copy(deviceKey = returnedKey))
        }
        return body
    }

    suspend fun checkInDevice(ctx: Context): String {
        val c = connection(ctx)
        val r = Prefs.relayConfig(ctx)
        val bodyMap = mapOf(
            "group_id" to r.groupId,
            "device_id" to r.deviceId,
            "device_key" to r.deviceKey,
        )
        val response = Api.http.post("${c.base}/devices/checkin") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(Api.json.encodeToString(bodyMap))
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun autoPresence(ctx: Context): String {
        val style = Prefs.uiStyle(ctx)
        val core = Prefs.coreNodeConfig(ctx)
        val relay = Prefs.ensureRelayIdentity(ctx)
        if (!style.autoPresenceEnabled) {
            return buildJsonObject {
                put("ok", true)
                put("skipped", true)
                put("reason", "auto presence disabled")
            }.toString()
        }
        if (core.nodeUrl.isBlank()) {
            return buildJsonObject {
                put("ok", true)
                put("skipped", true)
                put("reason", "core node not configured")
                put("device_id", relay.deviceId)
            }.toString()
        }
        if (relay.groupId.isBlank() || relay.groupKey.isBlank()) {
            return buildJsonObject {
                put("ok", true)
                put("skipped", true)
                put("reason", "group id/key not configured")
                put("device_id", relay.deviceId)
            }.toString()
        }
        val joined = runCatching { joinGroup(ctx, relay) }.getOrNull().orEmpty()
        val checked = checkInDevice(ctx)
        return buildJsonObject {
            put("ok", true)
            put("auto_presence", true)
            put("device_id", Prefs.relayConfig(ctx).deviceId)
            put("group_id", Prefs.relayConfig(ctx).groupId)
            put("join_result", joined.ifBlank { "already joined or join skipped" })
            put("checkin_result", checked)
        }.toString()
    }


    suspend fun presenceSummary(ctx: Context): String {
        val c = connection(ctx)
        val r = Prefs.relayConfig(ctx)
        val admin = Prefs.adminSession(ctx)
        val url = "${c.base}/presence/summary?group_id=${enc(r.groupId)}&group_key=${enc(r.groupKey)}"
        val response = Api.http.get(url) {
            if (admin.modeEnabled && admin.sessionTokenSaved) applyCoreSavedAdminAuth(ctx, c.token) else applyCoreAuth(ctx, c.token)
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun devicesOnline(ctx: Context): String {
        val c = connection(ctx)
        val r = Prefs.relayConfig(ctx)
        val url = "${c.base}/devices/online?group_id=${enc(r.groupId)}&group_key=${enc(r.groupKey)}"
        val response = Api.http.get(url) { applyCoreAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun adminDevices(ctx: Context): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/devices") { applyCoreSavedAdminAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun adminLedger(ctx: Context): String {
        val c = connection(ctx)
        val response = Api.http.get("${c.base}/admin/ledger") { applyCoreSavedAdminAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun createPacket(ctx: Context, targetMode: String, targetDeviceId: String, commandType: String, title: String, message: String): String {
        val c = connection(ctx)
        val r = Prefs.relayConfig(ctx)
        val bodyJson = buildJsonObject {
            put("group_id", r.groupId)
            put("group_key", r.groupKey)
            put("from_device_id", r.deviceId)
            put("target_mode", targetMode)
            put("target_device_id", targetDeviceId)
            put("packet_type", "COMMAND")
            put("command_type", commandType.trim().ifBlank { "PING" }.uppercase())
            put("title", title.trim().ifBlank { "SWRLZ relay packet" })
            put("ttl_minutes", "1440")
            put("payload", buildJsonObject { put("message", message) })
        }
        val response = Api.http.post("${c.base}/packets/create") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(bodyJson.toString())
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun pendingPackets(ctx: Context): String {
        val c = connection(ctx)
        val r = Prefs.relayConfig(ctx)
        val url = "${c.base}/packets/pending?group_id=${enc(r.groupId)}&device_id=${enc(r.deviceId)}&device_key=${enc(r.deviceKey)}"
        val response = Api.http.get(url) { applyCoreAuth(ctx, c.token) }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    suspend fun updatePacket(ctx: Context, packetId: String, status: String, detail: String): String {
        val c = connection(ctx)
        val r = Prefs.relayConfig(ctx)
        val bodyJson = buildJsonObject {
            put("group_id", r.groupId)
            put("device_id", r.deviceId)
            put("device_key", r.deviceKey)
            put("status", status.uppercase())
            put("detail", detail)
        }
        val response = Api.http.post("${c.base}/packets/${packetId.trim()}") {
            applyCoreAuth(ctx, c.token)
            contentType(ContentType.Application.Json)
            setBody(bodyJson.toString())
        }
        val body = response.bodyAsText()
        validate(response, body)
        return body
    }

    fun userMessage(t: Throwable): String = when (t) {
        is CoreNodeNotConfiguredException -> "core node not configured"
        is CoreNodeHttpException -> when (t.statusCode) {
            401, 403 -> "core node pairing rejected"
            404 -> "core node /status route unavailable"
            in 500..599 -> "core node service error"
            else -> "core node returned HTTP ${t.statusCode}"
        }
        is CoreNodeProtocolException -> "core node returned an invalid response"
        else -> when {
            t.message?.contains("CLEARTEXT", ignoreCase = true) == true -> "cleartext HTTP blocked by Android policy"
            t.message?.contains("timeout", ignoreCase = true) == true -> "core node timed out"
            t.message?.contains("Unable to resolve host", ignoreCase = true) == true -> "no local network connection"
            t.message?.contains("Failed to connect", ignoreCase = true) == true -> "core node unreachable"
            t.message?.contains("Connection refused", ignoreCase = true) == true -> "core node refused connection"
            else -> "core node unreachable: ${t.message?.take(80) ?: "unknown error"}"
        }
    }

    fun cleanFailure(t: Throwable): String = when (t) {
        is CoreNodeHttpException -> "${userMessage(t)} · HTTP ${t.statusCode}"
        is CoreNodeProtocolException -> userMessage(t)
        else -> userMessage(t)
    }

    private suspend fun connection(ctx: Context): Connection {
        val config = Prefs.coreNodeConfig(ctx)
        val url = config.nodeUrl.trim().trimEnd('/')
        if (url.isBlank()) throw CoreNodeNotConfiguredException()
        return Connection(base = url, token = config.pairingToken)
    }

    private fun io.ktor.client.request.HttpRequestBuilder.applyCoreAuth(ctx: Context, token: String) {
        header(HttpHeaders.Accept, ContentType.Application.Json)
        header("X-SWRLZ-Client-Role", "action-phone")
        header("X-SWRLZ-App-Version", BuildConfig.VERSION_NAME)
        header("X-SWRLZ-App-Version-Code", BuildConfig.VERSION_CODE.toString())
        header("X-SWRLZ-Patch-Label", BuildConfig.PATCH_LABEL)
        header("X-SWRLZ-Roadmap-Revision", BuildConfig.ROADMAP_REVISION)
        runCatching { DeviceContextCollector.collect(ctx).deviceNodeId }.getOrNull()?.let { nodeId ->
            header("X-SWRLZ-Device-Node-Id", nodeId)
        }
        if (token.isNotBlank()) header("X-Swurlz-Pairing-Token", token)
    }



    private fun io.ktor.client.request.HttpRequestBuilder.applyCoreAdminAuth(ctx: Context, username: String, password: String, token: String) {
        applyCoreAuth(ctx, token)
        val raw = "$username:$password"
        val encoded = Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        header(HttpHeaders.Authorization, "Basic $encoded")
    }

    private fun io.ktor.client.request.HttpRequestBuilder.applyCoreSavedAdminAuth(ctx: Context, token: String) {
        applyCoreAuth(ctx, token)
        val adminToken = SecretStore.adminSessionToken(ctx)
        if (adminToken.isNotBlank()) header(HttpHeaders.Authorization, "Bearer $adminToken")
    }

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun validate(response: HttpResponse, body: String) {
        if (!response.status.isSuccess()) {
            val detail = body.take(240).ifBlank { response.status.description }
            throw CoreNodeHttpException(response.status.value, detail)
        }
        val type = response.headers[HttpHeaders.ContentType].orEmpty().lowercase()
        if (type.isNotBlank() && !type.contains("application/json")) {
            throw CoreNodeProtocolException("Expected JSON but received $type")
        }
    }

    private fun JsonObject.stringAny(vararg keys: String): String? = keys.firstNotNullOfOrNull { key ->
        get(key)?.jsonPrimitive?.contentOrNull
    }

    private fun JsonObject.booleanAny(vararg keys: String): Boolean? = keys.firstNotNullOfOrNull { key ->
        get(key)?.jsonPrimitive?.booleanOrNull
    }
}
