package sh.swurlz.core.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.ui.theme.SwurlzColors

@Composable
fun HowToScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("▸ HOW TO", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text("Current app: v${BuildConfig.VERSION_NAME} · code ${BuildConfig.VERSION_CODE} · ${BuildConfig.PATCH_LABEL}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        Spacer(Modifier.height(12.dp))
        HowBlock("1 · SAME-PHONE LOCAL NODE", "Run Termux server on the same phone as SWRLZ-Core. Use http://127.0.0.1:8787 as the Core Node URL. Save Core, then Test Core Node. Reachable only means /status returned ok=true plus node identity.")
        HowBlock("2 · TWO-PHONE LAN BRIDGE", "Run Termux server on the Core Phone. Copy the printed LAN URL, like http://192.168.1.177:8787, into SWRLZ-Core on the Action Phone. Do not use 127.0.0.1 across two phones.")
        HowBlock("3 · STATUS TRUTH", "Configured means a URL is saved. Last manual test means you pressed TEST CORE NODE. Last auto-check means the app checked saved /status on launch. Green only appears after a valid server response.")
        HowBlock("4 · SERVER STOP / RESTART", "For Local Node Server 0.6, use bash stop_local_node.sh to clear an old ghost process, bash run_local_node.sh to start, and bash restart_local_node.sh to restart while preserving swrlz_node_data.")
        HowBlock("5 · UPDATE SERVER ZIP", "Download the latest SWRLZ_LOCAL_NODE_SERVER zip. Preserve swrlz_node_data. Stage/verify ZIPs before replacing source. The server's update folders are incoming, staged, and rollback.")
        HowBlock("6 · UPDATE APP APK", "Build the newest SWRLZ-Core source ZIP in Codespaces. Download the APK bundle, install/update, then confirm Home shows the expected versionName, code, patch label, and source ZIP.")
        HowBlock("7 · COMMAND CARD TEST", "Open Cmds. Create a safe PING command with admin credentials, Pull Pending, ACK the card, then COMPLETE it. Completed/rejected/failed cards become read-only in the card UI.")
        Spacer(Modifier.height(10.dp))
        SelectionContainer {
            Text(
                "Termux quick commands:\n\n" +
                    "deactivate 2>/dev/null || true\n" +
                    "cd ~/swurlz/SWRLZ_LOCAL_NODE_SERVER_0.6_PROCESS_CONTROL_SOURCE\n" +
                    "bash run_local_node.sh\n\n" +
                    "Stop server:\n" +
                    "bash stop_local_node.sh\n\n" +
                    "Restart server:\n" +
                    "bash restart_local_node.sh\n\n" +
                    "Fallback ghost-process check:\n" +
                    "python - <<'PY'\nimport socket\ns=socket.socket(); print(s.connect_ex(('127.0.0.1',8787)))\ns.close()\nPY",
                modifier = Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Border).padding(10.dp),
                color = SwurlzColors.Ash,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                lineHeight = 13.sp,
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun HowBlock(title: String, body: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).border(1.dp, SwurlzColors.Border).padding(12.dp)) {
        Text(title, color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(5.dp))
        Text(body, color = SwurlzColors.Bone, fontSize = 12.sp, lineHeight = 17.sp)
    }
}
