package sh.swurlz.core.data

import android.content.Context
import android.content.pm.PackageManager
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.model.ContextSharingLevel
import sh.swurlz.core.model.CoreNodeCheckRecord
import sh.swurlz.core.model.CoreNodeConfig
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.MentorConfig
import sh.swurlz.core.model.RelayConfig
import sh.swurlz.core.model.AdminSessionState
import sh.swurlz.core.model.UiStyleSettings
import java.util.UUID
import java.time.Instant

private val Context.dataStore by preferencesDataStore(name = "swurlz_prefs")

object Prefs {
    private val KEY_PREFLIGHT_OK = booleanPreferencesKey("preflight_acknowledged")
    private val KEY_ALLOWLIST = stringSetPreferencesKey("app_allowlist")
    private val KEY_ALLOWLIST_INIT = booleanPreferencesKey("allowlist_initialized")
    private val KEY_OVR_X = intPreferencesKey("overlay_x")
    private val KEY_OVR_Y = intPreferencesKey("overlay_y")
    private val KEY_OVR_COLLAPSED = booleanPreferencesKey("overlay_collapsed")
    private val KEY_BACKEND_URL = stringPreferencesKey("mentor_backend_url")
    private val KEY_CONTEXT_LEVEL = stringPreferencesKey("context_sharing_level")
    private val KEY_CONTEXT_PREVIEW_REQUIRED = booleanPreferencesKey("context_preview_required")
    private val KEY_CONTEXT_PREVIEW_APPROVED = booleanPreferencesKey("context_preview_approved_once")
    private val KEY_CORE_NODE_URL = stringPreferencesKey("core_node_url")
    private val KEY_CORE_MANUAL_CHECKED = booleanPreferencesKey("core_manual_checked")
    private val KEY_CORE_MANUAL_SUCCESS = booleanPreferencesKey("core_manual_success")
    private val KEY_CORE_MANUAL_SUMMARY = stringPreferencesKey("core_manual_summary")
    private val KEY_CORE_MANUAL_DETAIL = stringPreferencesKey("core_manual_detail")
    private val KEY_CORE_MANUAL_AT = stringPreferencesKey("core_manual_at")
    private val KEY_CORE_AUTO_CHECKED = booleanPreferencesKey("core_auto_checked")
    private val KEY_CORE_AUTO_SUCCESS = booleanPreferencesKey("core_auto_success")
    private val KEY_CORE_AUTO_SUMMARY = stringPreferencesKey("core_auto_summary")
    private val KEY_CORE_AUTO_DETAIL = stringPreferencesKey("core_auto_detail")
    private val KEY_CORE_AUTO_AT = stringPreferencesKey("core_auto_at")
    private val KEY_RELAY_GROUP_ID = stringPreferencesKey("relay_group_id")
    private val KEY_RELAY_DEVICE_ID = stringPreferencesKey("relay_device_id")
    private val KEY_RELAY_DEVICE_LABEL = stringPreferencesKey("relay_device_label")
    private val KEY_RELAY_ROLE = stringPreferencesKey("relay_role")
    private val KEY_ADMIN_USERNAME = stringPreferencesKey("admin_username")
    private val KEY_ADMIN_MODE_ENABLED = booleanPreferencesKey("admin_mode_enabled")
    private val KEY_ADMIN_SESSION_ID = stringPreferencesKey("admin_session_id")
    private val KEY_ADMIN_LAST_VERIFIED_AT = stringPreferencesKey("admin_last_verified_at")
    private val KEY_ADMIN_ALL_DEVICES_VISIBLE = booleanPreferencesKey("admin_all_devices_visible")
    private val KEY_UI_THEME_PACK = stringPreferencesKey("ui_theme_pack")
    private val KEY_UI_DISPLAY_MODE = stringPreferencesKey("ui_display_mode")
    private val KEY_UI_ANIMATION_LEVEL = stringPreferencesKey("ui_animation_level")
    private val KEY_UI_TEXT_SIZE = stringPreferencesKey("ui_text_size")
    private val KEY_UI_CARD_DENSITY = stringPreferencesKey("ui_card_density")
    private val KEY_AUTO_PRESENCE_ENABLED = booleanPreferencesKey("auto_presence_enabled")
    private val KEY_UI_GLOW_STRENGTH = stringPreferencesKey("ui_glow_strength")
    private val KEY_UI_HIGH_CONTRAST = booleanPreferencesKey("ui_high_contrast")
    private val KEY_UI_SEMANTIC_BORDERS_ONLY = booleanPreferencesKey("ui_semantic_borders_only")
    private val KEY_UI_SOLID_BUTTONS_SUNLIGHT = booleanPreferencesKey("ui_solid_buttons_sunlight")

    /** Safe initial set used until the user intentionally changes the allowlist. */
    val DEFAULT_ALLOWLIST = setOf(
        "com.android.settings",
        "com.android.calculator2",
        "com.google.android.calculator",
        "com.android.deskclock",
        "com.google.android.deskclock",
        "com.android.chrome",
        "com.android.calendar",
        "com.google.android.calendar",
        "com.google.android.apps.messaging",
        "com.android.contacts",
        "com.google.android.contacts",
        "sh.swurlz.core",
    )

    /** Packages skipped by bulk ALLOW SHOWN. They may still be enabled manually. */
    val BULK_ALLOW_EXCLUSIONS = setOf(
        "com.android.systemui",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
    )

    fun preflightFlow(ctx: Context): Flow<Boolean> =
        ctx.dataStore.data.map { it[KEY_PREFLIGHT_OK] ?: false }

    suspend fun isPreflightAck(ctx: Context): Boolean =
        ctx.dataStore.data.first()[KEY_PREFLIGHT_OK] ?: false

    suspend fun setPreflightAck(ctx: Context, value: Boolean) {
        ctx.dataStore.edit { it[KEY_PREFLIGHT_OK] = value }
    }

    fun allowlistFlow(ctx: Context): Flow<Set<String>> =
        ctx.dataStore.data.map { prefs ->
            if (prefs[KEY_ALLOWLIST_INIT] == true) prefs[KEY_ALLOWLIST] ?: emptySet()
            else DEFAULT_ALLOWLIST
        }

    suspend fun currentAllowlist(ctx: Context): Set<String> =
        ctx.dataStore.data.first().let { prefs ->
            if (prefs[KEY_ALLOWLIST_INIT] == true) prefs[KEY_ALLOWLIST] ?: emptySet()
            else DEFAULT_ALLOWLIST
        }

    suspend fun setAllowlist(ctx: Context, value: Set<String>) {
        ctx.dataStore.edit {
            it[KEY_ALLOWLIST] = value
            it[KEY_ALLOWLIST_INIT] = true
        }
    }

    suspend fun toggle(ctx: Context, pkg: String) {
        val cur = currentAllowlist(ctx).toMutableSet()
        if (!cur.remove(pkg)) cur.add(pkg)
        setAllowlist(ctx, cur)
    }

    suspend fun allowPackages(ctx: Context, packages: Set<String>) {
        val next = currentAllowlist(ctx) + packages
        setAllowlist(ctx, next)
    }

    suspend fun blockPackages(ctx: Context, packages: Set<String>) {
        val next = currentAllowlist(ctx) - packages
        // SWRLZ must always be allowed to observe its own UI safely.
        setAllowlist(ctx, next + ctx.packageName)
    }

    suspend fun resetAllowlist(ctx: Context) = setAllowlist(ctx, DEFAULT_ALLOWLIST)

    fun uiStyleFlow(ctx: Context): Flow<UiStyleSettings> = ctx.dataStore.data.map { prefs ->
        UiStyleSettings(
            themePack = prefs[KEY_UI_THEME_PACK] ?: "Original Core",
            displayMode = prefs[KEY_UI_DISPLAY_MODE] ?: "Dark",
            animationLevel = prefs[KEY_UI_ANIMATION_LEVEL] ?: "Standard",
            textSize = prefs[KEY_UI_TEXT_SIZE] ?: "Standard",
            cardDensity = prefs[KEY_UI_CARD_DENSITY] ?: "Comfortable",
            autoPresenceEnabled = prefs[KEY_AUTO_PRESENCE_ENABLED] ?: true,
            glowStrength = prefs[KEY_UI_GLOW_STRENGTH] ?: "Medium",
            highContrast = prefs[KEY_UI_HIGH_CONTRAST] ?: false,
            semanticBordersOnly = prefs[KEY_UI_SEMANTIC_BORDERS_ONLY] ?: true,
            solidButtonsInSunlight = prefs[KEY_UI_SOLID_BUTTONS_SUNLIGHT] ?: true,
        )
    }

    suspend fun uiStyle(ctx: Context): UiStyleSettings = uiStyleFlow(ctx).first()

    suspend fun setUiStyle(ctx: Context, settings: UiStyleSettings) {
        ctx.dataStore.edit { prefs ->
            prefs[KEY_UI_THEME_PACK] = settings.themePack
            prefs[KEY_UI_DISPLAY_MODE] = settings.displayMode
            prefs[KEY_UI_ANIMATION_LEVEL] = settings.animationLevel
            prefs[KEY_UI_TEXT_SIZE] = settings.textSize
            prefs[KEY_UI_CARD_DENSITY] = settings.cardDensity
            prefs[KEY_AUTO_PRESENCE_ENABLED] = settings.autoPresenceEnabled
            prefs[KEY_UI_GLOW_STRENGTH] = settings.glowStrength
            prefs[KEY_UI_HIGH_CONTRAST] = settings.highContrast
            prefs[KEY_UI_SEMANTIC_BORDERS_ONLY] = settings.semanticBordersOnly
            prefs[KEY_UI_SOLID_BUTTONS_SUNLIGHT] = settings.solidButtonsInSunlight
        }
    }

    suspend fun setAutoPresenceEnabled(ctx: Context, enabled: Boolean) {
        ctx.dataStore.edit { it[KEY_AUTO_PRESENCE_ENABLED] = enabled }
    }

    fun relayConfigFlow(ctx: Context): Flow<RelayConfig> = ctx.dataStore.data.map { prefs ->
        RelayConfig(
            groupId = (prefs[KEY_RELAY_GROUP_ID] ?: "").trim(),
            groupKey = SecretStore.relayGroupKey(ctx).trim(),
            deviceId = (prefs[KEY_RELAY_DEVICE_ID] ?: DeviceContextCollector.collect(ctx).deviceNodeId).trim(),
            deviceKey = SecretStore.relayDeviceKey(ctx).trim(),
            deviceLabel = (prefs[KEY_RELAY_DEVICE_LABEL] ?: "Action Phone").trim(),
            role = (prefs[KEY_RELAY_ROLE] ?: "Action Phone").trim(),
        )
    }

    suspend fun relayConfig(ctx: Context): RelayConfig = relayConfigFlow(ctx).first()

    suspend fun setRelayConfig(ctx: Context, config: RelayConfig) {
        SecretStore.setRelayGroupKey(ctx, config.groupKey)
        SecretStore.setRelayDeviceKey(ctx, config.deviceKey)
        ctx.dataStore.edit { prefs ->
            prefs[KEY_RELAY_GROUP_ID] = config.groupId.trim()
            prefs[KEY_RELAY_DEVICE_ID] = config.deviceId.trim()
            prefs[KEY_RELAY_DEVICE_LABEL] = config.deviceLabel.trim()
            prefs[KEY_RELAY_ROLE] = config.role.trim()
        }
    }

    suspend fun ensureRelayIdentity(ctx: Context): RelayConfig {
        val prefs = ctx.dataStore.data.first()
        val generatedId = DeviceContextCollector.collect(ctx).deviceNodeId.trim().ifBlank {
            "swrlz-node-${UUID.randomUUID().toString().replace("-", "").take(10)}"
        }
        val existingId = (prefs[KEY_RELAY_DEVICE_ID] ?: "").trim()
        val existingLabel = (prefs[KEY_RELAY_DEVICE_LABEL] ?: "").trim()
        val existingRole = (prefs[KEY_RELAY_ROLE] ?: "").trim()
        val currentKey = SecretStore.relayDeviceKey(ctx).trim()
        val nextId = existingId.ifBlank { generatedId }
        val nextKey = currentKey.ifBlank { "dk-${UUID.randomUUID().toString().replace("-", "").take(20)}" }
        val nextLabel = existingLabel.ifBlank { "Action Phone" }
        val nextRole = existingRole.ifBlank { "Action Phone" }
        if (currentKey.isBlank()) SecretStore.setRelayDeviceKey(ctx, nextKey)
        ctx.dataStore.edit { edit ->
            if (existingId.isBlank()) edit[KEY_RELAY_DEVICE_ID] = nextId
            if (existingLabel.isBlank()) edit[KEY_RELAY_DEVICE_LABEL] = nextLabel
            if (existingRole.isBlank()) edit[KEY_RELAY_ROLE] = nextRole
        }
        return relayConfig(ctx).copy(deviceId = nextId, deviceKey = nextKey, deviceLabel = nextLabel, role = nextRole)
    }

    suspend fun rotateRelayDeviceIdentity(ctx: Context): RelayConfig {
        val generatedId = "swrlz-node-${UUID.randomUUID().toString().replace("-", "").take(10)}"
        val generatedKey = "dk-${UUID.randomUUID().toString().replace("-", "").take(20)}"
        SecretStore.setRelayDeviceKey(ctx, generatedKey)
        ctx.dataStore.edit { prefs ->
            prefs[KEY_RELAY_DEVICE_ID] = generatedId
            prefs[KEY_RELAY_DEVICE_LABEL] = (prefs[KEY_RELAY_DEVICE_LABEL] ?: "Action Phone").ifBlank { "Action Phone" }
            prefs[KEY_RELAY_ROLE] = (prefs[KEY_RELAY_ROLE] ?: "Action Phone").ifBlank { "Action Phone" }
        }
        return relayConfig(ctx).copy(deviceId = generatedId, deviceKey = generatedKey)
    }

    suspend fun forgetRelayDeviceIdentity(ctx: Context) {
        SecretStore.setRelayDeviceKey(ctx, "")
        ctx.dataStore.edit { prefs ->
            prefs.remove(KEY_RELAY_DEVICE_ID)
            prefs.remove(KEY_RELAY_DEVICE_LABEL)
            prefs.remove(KEY_RELAY_ROLE)
        }
    }

    fun adminSessionFlow(ctx: Context): Flow<AdminSessionState> = ctx.dataStore.data.map { prefs ->
        AdminSessionState(
            username = (prefs[KEY_ADMIN_USERNAME] ?: "admin").trim(),
            modeEnabled = prefs[KEY_ADMIN_MODE_ENABLED] ?: false,
            sessionTokenSaved = SecretStore.adminSessionToken(ctx).isNotBlank(),
            sessionId = prefs[KEY_ADMIN_SESSION_ID] ?: "",
            lastVerifiedAt = prefs[KEY_ADMIN_LAST_VERIFIED_AT] ?: "",
            allDevicesVisible = prefs[KEY_ADMIN_ALL_DEVICES_VISIBLE] ?: false,
        )
    }

    suspend fun adminSession(ctx: Context): AdminSessionState = adminSessionFlow(ctx).first()

    suspend fun setAdminUsername(ctx: Context, username: String) {
        ctx.dataStore.edit { it[KEY_ADMIN_USERNAME] = username.trim().ifBlank { "admin" } }
    }

    suspend fun setAdminModeEnabled(ctx: Context, enabled: Boolean) {
        ctx.dataStore.edit { it[KEY_ADMIN_MODE_ENABLED] = enabled }
    }

    suspend fun setAdminAllDevicesVisible(ctx: Context, enabled: Boolean) {
        ctx.dataStore.edit { it[KEY_ADMIN_ALL_DEVICES_VISIBLE] = enabled }
    }

    suspend fun saveAdminSession(ctx: Context, username: String, token: String, sessionId: String, verifiedAt: String = Instant.now().toString()) {
        SecretStore.setAdminSessionToken(ctx, token)
        ctx.dataStore.edit { prefs ->
            prefs[KEY_ADMIN_USERNAME] = username.trim().ifBlank { "admin" }
            prefs[KEY_ADMIN_SESSION_ID] = sessionId.trim()
            prefs[KEY_ADMIN_LAST_VERIFIED_AT] = verifiedAt
            prefs[KEY_ADMIN_MODE_ENABLED] = true
        }
    }

    suspend fun touchAdminVerified(ctx: Context) {
        ctx.dataStore.edit { it[KEY_ADMIN_LAST_VERIFIED_AT] = Instant.now().toString() }
    }

    suspend fun forgetAdminSession(ctx: Context) {
        SecretStore.forgetAdminSessionToken(ctx)
        ctx.dataStore.edit { prefs ->
            prefs[KEY_ADMIN_MODE_ENABLED] = false
            prefs.remove(KEY_ADMIN_SESSION_ID)
            prefs.remove(KEY_ADMIN_LAST_VERIFIED_AT)
        }
    }

    fun mentorConfigFlow(ctx: Context): Flow<MentorConfig> = ctx.dataStore.data.map { prefs ->
        MentorConfig(
            backendUrl = (prefs[KEY_BACKEND_URL] ?: BuildConfig.BACKEND_URL).trim(),
            apiToken = SecretStore.mentorToken(ctx).ifBlank { BuildConfig.API_TOKEN }.trim(),
            contextLevel = ContextSharingLevel.fromStorage(
                prefs[KEY_CONTEXT_LEVEL] ?: ContextSharingLevel.STANDARD.name
            ),
            previewRequired = prefs[KEY_CONTEXT_PREVIEW_REQUIRED] ?: false,
        )
    }

    suspend fun mentorConfig(ctx: Context): MentorConfig = mentorConfigFlow(ctx).first()

    suspend fun setMentorConfig(ctx: Context, config: MentorConfig) {
        SecretStore.setMentorToken(ctx, config.apiToken)
        ctx.dataStore.edit {
            it[KEY_BACKEND_URL] = config.backendUrl.trim()
            it[KEY_CONTEXT_LEVEL] = config.contextLevel.name
            it[KEY_CONTEXT_PREVIEW_REQUIRED] = config.previewRequired
        }
    }

    fun coreNodeConfigFlow(ctx: Context): Flow<CoreNodeConfig> = ctx.dataStore.data.map { prefs ->
        CoreNodeConfig(
            nodeUrl = (prefs[KEY_CORE_NODE_URL] ?: "").trim(),
            pairingToken = SecretStore.coreNodeToken(ctx).trim(),
        )
    }

    suspend fun coreNodeConfig(ctx: Context): CoreNodeConfig = coreNodeConfigFlow(ctx).first()

    fun coreNodeTruthStateFlow(ctx: Context): Flow<CoreNodeTruthState> = ctx.dataStore.data.map { prefs ->
        CoreNodeTruthState(
            config = CoreNodeConfig(
                nodeUrl = (prefs[KEY_CORE_NODE_URL] ?: "").trim(),
                pairingToken = SecretStore.coreNodeToken(ctx).trim(),
            ),
            manual = CoreNodeCheckRecord(
                checked = prefs[KEY_CORE_MANUAL_CHECKED] ?: false,
                success = prefs[KEY_CORE_MANUAL_SUCCESS] ?: false,
                summary = prefs[KEY_CORE_MANUAL_SUMMARY] ?: "not run",
                detail = prefs[KEY_CORE_MANUAL_DETAIL] ?: "",
                checkedAt = prefs[KEY_CORE_MANUAL_AT] ?: "",
            ),
            auto = CoreNodeCheckRecord(
                checked = prefs[KEY_CORE_AUTO_CHECKED] ?: false,
                success = prefs[KEY_CORE_AUTO_SUCCESS] ?: false,
                summary = prefs[KEY_CORE_AUTO_SUMMARY] ?: "not run",
                detail = prefs[KEY_CORE_AUTO_DETAIL] ?: "",
                checkedAt = prefs[KEY_CORE_AUTO_AT] ?: "",
            ),
        )
    }

    suspend fun coreNodeTruthState(ctx: Context): CoreNodeTruthState = coreNodeTruthStateFlow(ctx).first()

    suspend fun setCoreNodeManualCheck(ctx: Context, success: Boolean, summary: String, detail: String = "") {
        ctx.dataStore.edit { prefs ->
            prefs[KEY_CORE_MANUAL_CHECKED] = true
            prefs[KEY_CORE_MANUAL_SUCCESS] = success
            prefs[KEY_CORE_MANUAL_SUMMARY] = summary.trim()
            prefs[KEY_CORE_MANUAL_DETAIL] = detail.trim()
            prefs[KEY_CORE_MANUAL_AT] = Instant.now().toString()
        }
    }

    suspend fun setCoreNodeAutoCheck(ctx: Context, success: Boolean, summary: String, detail: String = "") {
        ctx.dataStore.edit { prefs ->
            prefs[KEY_CORE_AUTO_CHECKED] = true
            prefs[KEY_CORE_AUTO_SUCCESS] = success
            prefs[KEY_CORE_AUTO_SUMMARY] = summary.trim()
            prefs[KEY_CORE_AUTO_DETAIL] = detail.trim()
            prefs[KEY_CORE_AUTO_AT] = Instant.now().toString()
        }
    }

    suspend fun clearCoreNodeCheckRecords(ctx: Context) {
        ctx.dataStore.edit { prefs ->
            prefs.remove(KEY_CORE_MANUAL_CHECKED)
            prefs.remove(KEY_CORE_MANUAL_SUCCESS)
            prefs.remove(KEY_CORE_MANUAL_SUMMARY)
            prefs.remove(KEY_CORE_MANUAL_DETAIL)
            prefs.remove(KEY_CORE_MANUAL_AT)
            prefs.remove(KEY_CORE_AUTO_CHECKED)
            prefs.remove(KEY_CORE_AUTO_SUCCESS)
            prefs.remove(KEY_CORE_AUTO_SUMMARY)
            prefs.remove(KEY_CORE_AUTO_DETAIL)
            prefs.remove(KEY_CORE_AUTO_AT)
        }
    }

    suspend fun setCoreNodeConfig(ctx: Context, config: CoreNodeConfig) {
        SecretStore.setCoreNodeToken(ctx, config.pairingToken)
        ctx.dataStore.edit { it[KEY_CORE_NODE_URL] = config.nodeUrl.trim() }
    }

    suspend fun approveContextPreviewOnce(ctx: Context) {
        ctx.dataStore.edit { it[KEY_CONTEXT_PREVIEW_APPROVED] = true }
    }

    suspend fun consumeContextPreviewApproval(ctx: Context): Boolean {
        val approved = ctx.dataStore.data.first()[KEY_CONTEXT_PREVIEW_APPROVED] ?: false
        if (approved) ctx.dataStore.edit { it[KEY_CONTEXT_PREVIEW_APPROVED] = false }
        return approved
    }

    suspend fun overlayPos(ctx: Context): Pair<Int, Int> {
        val p = ctx.dataStore.data.first()
        return (p[KEY_OVR_X] ?: 24) to (p[KEY_OVR_Y] ?: 96)
    }

    suspend fun setOverlayPos(ctx: Context, x: Int, y: Int) {
        ctx.dataStore.edit {
            it[KEY_OVR_X] = x
            it[KEY_OVR_Y] = y
        }
    }

    suspend fun overlayCollapsed(ctx: Context): Boolean =
        ctx.dataStore.data.first()[KEY_OVR_COLLAPSED] ?: false

    suspend fun setOverlayCollapsed(ctx: Context, value: Boolean) {
        ctx.dataStore.edit { it[KEY_OVR_COLLAPSED] = value }
    }
}

data class InstalledApp(val pkg: String, val label: String, val isSystem: Boolean)

object InstalledApps {
    fun list(ctx: Context, includeSystem: Boolean = true): List<InstalledApp> {
        val pm = ctx.packageManager
        val apps = runCatching {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        }.getOrElse { emptyList() }
        return apps
            .map {
                InstalledApp(
                    pkg = it.packageName,
                    label = pm.getApplicationLabel(it).toString(),
                    isSystem = (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0,
                )
            }
            .filter { includeSystem || !it.isSystem }
            .sortedBy { it.label.lowercase() }
    }
}
