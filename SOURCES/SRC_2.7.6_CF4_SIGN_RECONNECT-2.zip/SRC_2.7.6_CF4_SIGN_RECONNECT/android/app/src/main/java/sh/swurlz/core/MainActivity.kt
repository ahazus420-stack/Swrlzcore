package sh.swurlz.core

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.flow.collectLatest
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.ui.screens.*
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.SwurlzColors
import sh.swurlz.core.ui.theme.SwurlzTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            var uiStyle by remember { mutableStateOf(UiStyleSettings()) }
            LaunchedEffect(Unit) { Prefs.uiStyleFlow(ctx).collectLatest { uiStyle = it } }
            SwurlzTheme(uiStyle) { AppNav() }
        }
    }
}

@Composable
fun AppNav() {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    var preflightAck by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) { Prefs.preflightFlow(ctx).collectLatest { preflightAck = it } }
    if (preflightAck == null) return
    val navEntry by nav.currentBackStackEntryAsState()
    val currentRoute = navEntry?.destination?.route ?: if (preflightAck == true) "home" else "preflight"

    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxSize().background(tokens.surfaces.bgApp)) {
        if (preflightAck == true) {
            HeaderBar(
                onHome = { nav.navigate("home") { popUpTo("home") { inclusive = true } } },
                onCockpit = { nav.navigate("cockpit") },
                onSkills = { nav.navigate("skills") },
                onAllow = { nav.navigate("allow") },
                onSetup = { nav.navigate("setup") },
                onStyle = { nav.navigate("style") },
                onPerms = { nav.navigate("perms") },
                onCore = { nav.navigate("core") },
                onHowTo = { nav.navigate("howto") },
                onInfo = { nav.navigate("info") },
                onCommands = { nav.navigate("commands") },
                onDiscovery = { nav.navigate("discovery") },
                onMore = { nav.navigate("more") },
                currentRoute = currentRoute,
            )
        }
        Box(Modifier.fillMaxSize()) {
            NavHost(nav, startDestination = if (preflightAck == true) "home" else "preflight") {
                composable("preflight") {
                    PreflightScreen(onAcknowledged = {
                        nav.navigate("perms") { popUpTo("preflight") { inclusive = true } }
                    })
                }
                composable("home") {
                    HomeScreen(
                        onOpenCockpit = { nav.navigate("cockpit") },
                        onOpenPerms = { nav.navigate("perms") },
                        onOpenSetup = { nav.navigate("setup") },
                        onOpenDiscovery = { nav.navigate("discovery") },
                    )
                }
                composable("cockpit") { CockpitScreen() }
                composable("skills") { SkillsScreen() }
                composable("allow") { AllowlistScreen() }
                composable("setup") { SetupScreen() }
                composable("style") { StyleScreen() }
                composable("perms") { PermissionsScreen() }
                composable("core") { CoreNodeScreen() }
                composable("howto") { HowToScreen() }
                composable("info") { InfoScreen() }
                composable("commands") { CommandsScreen() }
                composable("discovery") { NetworkDiscoveryScreen(onOpenSetup = { nav.navigate("setup") }, onOpenCore = { nav.navigate("core") }) }
                composable("more") { MoreScreen(nav) }
            }
        }
    }
}

@Composable
private fun HeaderBar(
    onHome: () -> Unit,
    onCockpit: () -> Unit,
    onSkills: () -> Unit,
    onAllow: () -> Unit,
    onSetup: () -> Unit,
    onStyle: () -> Unit,
    onPerms: () -> Unit,
    onCore: () -> Unit,
    onHowTo: () -> Unit,
    onInfo: () -> Unit,
    onCommands: () -> Unit,
    onDiscovery: () -> Unit,
    onMore: () -> Unit,
    currentRoute: String,
) {
    val tokens = LocalSwurlzTokens.current
    Row(
        Modifier.fillMaxWidth().background(tokens.surfaces.bgTopBar).border(1.dp, tokens.borders.neutral)
            .horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("Ω SWURLZ·CORE", color = tokens.accents.secondary, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.width(12.dp))
        TabItem("Home", currentRoute == "home", onHome)
        TabItem("Radar", currentRoute == "commands", onCommands)
        TabItem("Network", currentRoute == "discovery", onDiscovery)
        TabItem("Cockpit", currentRoute == "cockpit", onCockpit)
        TabItem("Setup", currentRoute == "setup", onSetup)
        TabItem("Style", currentRoute == "style", onStyle)
        val moreSelected = currentRoute in setOf("more", "core", "perms", "allow", "skills", "howto", "info", "discovery")
        TabItem("More", moreSelected, onMore)
    }
}

@Composable
private fun TabItem(label: String, selected: Boolean, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    val borderColor by animateColorAsState(if (selected) tokens.tabs.selectedBorder else tokens.tabs.idleBorder, label = "tabBorder")
    val contentColor by animateColorAsState(if (selected) tokens.tabs.selectedText else tokens.tabs.idleText, label = "tabText")
    val bg = if (selected) tokens.tabs.selectedBg else tokens.tabs.idleBg
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = contentColor, containerColor = bg),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, borderColor),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(0),
        modifier = Modifier.padding(end = 4.dp).height(if (selected) 34.dp else 32.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.2.sp)
            if (selected) Box(Modifier.padding(top = 2.dp).height(2.dp).width(24.dp).background(tokens.tabs.underline))
        }
    }
}

object PermissionHelper {
    fun isAccessibilityEnabled(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == ctx.packageName }
    }

    fun isOverlayGranted(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun openAccessibility(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openOverlayPerm(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openAppDetails(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openSamsungAutoBlocker(ctx: Context) {
        val candidates = listOf(
            ComponentName("com.samsung.android.sm", "com.samsung.android.sm.security.ui.AutoBlockerActivity"),
            ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.security.ui.AutoBlockerActivity"),
        )
        for (cn in candidates) {
            try {
                ctx.startActivity(Intent().setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
        try {
            ctx.startActivity(Intent("android.settings.SECURITY_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            openAppDetails(ctx)
        }
    }
}
