package sh.swurlz.core.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeConfig
import sh.swurlz.core.net.CoreNodeApi
import sh.swurlz.core.ui.theme.SwurlzColors

@Composable
fun CoreNodeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var coreNodeUrl by remember { mutableStateOf("") }
    var coreNodeToken by remember { mutableStateOf("") }
    var adminUser by remember { mutableStateOf("admin") }
    var adminPassword by remember { mutableStateOf("") }
    var serverUpdateUrl by remember { mutableStateOf("") }
    var clientUpdateUrl by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Core panel ready · load or test the node") }
    var output by remember { mutableStateOf("No Core Node admin output yet.") }

    LaunchedEffect(Unit) {
        val cfg = Prefs.coreNodeConfig(ctx)
        coreNodeUrl = cfg.nodeUrl
        coreNodeToken = cfg.pairingToken
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("▸ CORE NODE ADMIN", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Manage the local Core Node bridge, view server status, inspect recent connection events, and save server/client update URLs. This is separate from the online Mentor.",
            color = SwurlzColors.Ash,
            fontSize = 12.sp,
            lineHeight = 17.sp,
        )
        Spacer(Modifier.height(12.dp))
        InfoTile("APP IDENTITY", "v${BuildConfig.VERSION_NAME} · code ${BuildConfig.VERSION_CODE}\nPatch: ${BuildConfig.PATCH_LABEL}\nRoadmap: ${BuildConfig.ROADMAP_REVISION}")
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = coreNodeUrl, onValueChange = { coreNodeUrl = it }, label = { Text("Core Node URL") }, placeholder = { Text("http://127.0.0.1:8787 or http://192.168.x.x:8787") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = coreNodeToken, onValueChange = { coreNodeToken = it }, label = { Text("Core Node pairing token") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PrimaryButton("SAVE CORE", SwurlzColors.Phosphor) {
                scope.launch {
                    Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(coreNodeUrl, coreNodeToken))
                    status = "Core URL saved"
                }
            }
            PrimaryButton("TEST STATUS", SwurlzColors.Cyan) {
                scope.launch {
                    Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(coreNodeUrl, coreNodeToken))
                    status = "Testing Core Node…"
                    output = runCatching { withContext(Dispatchers.IO) { CoreNodeApi.status(ctx) } }
                        .fold(
                            onSuccess = { core ->
                                status = "Core Node reachable"
                                "Node: ${core.nodeName ?: "unknown"}\nType: ${core.nodeType ?: "unknown"}\nVersion: ${core.coreVersion ?: core.version ?: "unknown"}\nPaid AI required: ${core.paidAiRequired ?: false}"
                            },
                            onFailure = { err ->
                                status = "Core Node failed · ${CoreNodeApi.cleanFailure(err)}"
                                "${CoreNodeApi.cleanFailure(err)}\n\nCheck the Core Node URL, Wi-Fi/hotspot connection, and whether the Termux server is still running."
                            },
                        )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(status, color = coreStatusColor(status), fontFamily = FontFamily.Monospace, fontSize = 10.sp)

        Spacer(Modifier.height(16.dp))
        Text("▸ ADMIN MODE", color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(6.dp))
        Text("Default server admin is admin / swurlz-admin for first-run testing. Keep passwords masked; use the server password endpoint or environment variable to change it.", color = SwurlzColors.Ash, fontSize = 11.sp, lineHeight = 16.sp)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = adminUser, onValueChange = { adminUser = it }, label = { Text("Admin username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = adminPassword, onValueChange = { adminPassword = it }, label = { Text("Admin password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = serverUpdateUrl, onValueChange = { serverUpdateUrl = it }, label = { Text("Server update URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = clientUpdateUrl, onValueChange = { clientUpdateUrl = it }, label = { Text("Client/app update URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PrimaryButton("GET SETTINGS", SwurlzColors.Cyan) {
                scope.launch { output = adminCall("Admin settings loaded") { CoreNodeApi.adminSettings(ctx, adminUser, adminPassword) } }
            }
            PrimaryButton("UPDATE INFO", SwurlzColors.Runic) {
                scope.launch { output = adminCall("Update info loaded") { CoreNodeApi.updateInfo(ctx, adminUser, adminPassword) } }
            }
            PrimaryButton("SAVE URLS", SwurlzColors.Phosphor) {
                scope.launch { output = adminCall("Update URLs saved") { CoreNodeApi.updateAdminSettings(ctx, adminUser, adminPassword, serverUpdateUrl, clientUpdateUrl) } }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PrimaryButton("RECENT EVENTS", SwurlzColors.Runic) {
                scope.launch { output = adminCall("Recent events loaded") { CoreNodeApi.recentEvents(ctx, adminUser, adminPassword) } }
            }
            PrimaryButton("SESSION LOG", SwurlzColors.Violet) {
                scope.launch { output = adminCall("Session log loaded") { CoreNodeApi.sessionLog(ctx, adminUser, adminPassword) } }
            }
        }
        Spacer(Modifier.height(10.dp))
        SelectionContainer {
            Text(output, modifier = Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Border).padding(10.dp), color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 13.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

private suspend fun adminCall(success: String, call: suspend () -> String): String =
    runCatching { withContext(Dispatchers.IO) { call() } }
        .fold(
            onSuccess = { "$success\n\n$it" },
            onFailure = { "Admin request failed: ${it.message}\n\n${it.stackTraceToString().take(1200)}" },
        )

@Composable
private fun InfoTile(title: String, body: String) {
    Column(Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Border).padding(12.dp)) {
        Text(title, color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(5.dp))
        Text(body, color = SwurlzColors.Bone, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

private fun coreStatusColor(text: String) = when {
    text.contains("failed", ignoreCase = true) -> SwurlzColors.RiskRed
    text.contains("unreachable", ignoreCase = true) -> SwurlzColors.RiskRed
    text.contains("Testing", ignoreCase = true) -> SwurlzColors.RiskYellow
    text.contains("reachable", ignoreCase = true) -> SwurlzColors.Phosphor
    else -> SwurlzColors.RiskYellow
}
