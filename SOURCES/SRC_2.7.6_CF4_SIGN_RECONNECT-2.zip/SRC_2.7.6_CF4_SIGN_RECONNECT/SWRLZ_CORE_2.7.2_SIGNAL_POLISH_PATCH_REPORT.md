# SWRLZ-Core 2.7.2 Signal Polish Patch Report

## Purpose

2.7.2 polishes the 2.7.1 Relay Radar field-test build before larger Cartographer/Mission layers. The goal is better readability, cleaner navigation, saved style options, and automatic device presence.

## Implemented

- Build identity bumped to `0.2.7.2-signal-polish`, code `15`.
- Added `StyleScreen.kt`.
- Added `UiStyleSettings` model.
- Added persistent style preferences in `Prefs`.
- Added saved theme pack, display mode, animation level, text size, and card density.
- Added Auto Presence preference.
- Added stable auto device identity generation and local storage.
- Added rotate/forget device identity controls.
- Added `CoreNodeApi.autoPresence(ctx)`.
- Added Node Heartbeat toggle and button to Relay Radar.
- Added active-tab animation/selected indicator in header.
- Increased global text/border contrast.

## Preserved

- Existing 2.7.1 Relay Radar flows.
- Manual setup/raw IDs as advanced fallback.
- Admin session workflow.
- Packet queue lifecycle controls.
- No mystery APK; source identity remains visible.

## Not changed

- Local Node Server remains `0.7.1 Presence Index` unless backend bugs are discovered.
- Cartographer/RouteSeed remains roadmap architecture, not active runtime in this patch.

## Verification in packaging environment

- Source files patched and packaged.
- Kotlin/Compose source brace balance checked.
- Full Android build not completed here because Gradle wrapper attempted to fetch `services.gradle.org`, which is unavailable in this environment.
