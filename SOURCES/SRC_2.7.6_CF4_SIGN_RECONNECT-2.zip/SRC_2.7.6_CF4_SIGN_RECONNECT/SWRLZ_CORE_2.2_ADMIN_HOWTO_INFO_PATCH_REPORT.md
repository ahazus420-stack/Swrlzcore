# SWRLZ-Core 2.2 Patch Report

## Patch label

`2.2-ADMIN-HOWTO-INFO`

## Source base

`SWRLZ_CORE_2.1_CORE_NODE_DIAGNOSTICS_SOURCE.zip`

## Adds

- Core Node Admin tab.
- How-To menu.
- Info/Legend menu.
- Admin settings/events/session log helpers.
- Update URL save helper.
- Roadmap update 2.2.
- Latest README guide.

## Test checklist

1. Build APK.
2. Install APK.
3. Confirm `v0.2.2-admin-howto-info · code 9`.
4. Open Core tab.
5. Test Core Node status.
6. Use GET SETTINGS with admin credentials.
7. Open How To and Info tabs.
