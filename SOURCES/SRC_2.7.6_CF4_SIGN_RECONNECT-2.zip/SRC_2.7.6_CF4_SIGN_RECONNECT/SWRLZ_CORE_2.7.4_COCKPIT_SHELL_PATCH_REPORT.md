# SWRLZ-Core 2.7.6 Network Discovery Patch Report

## Purpose

2.7.6 is a control-shell refinement after Theme Armor. It reduces top-tab clutter, adds a More drawer, guides relay setup, and makes Radar easier to operate during two-phone tests.

## Added

- More / Advanced Drawer screen.
- Main navigation cleanup.
- Radar Guided Pairing Ladder.
- Radar Device Roster Summary.
- Queue terminal read-only card handling.
- Clearer step language for Core URL, group, device identity, register/heartbeat, and radar verification.

## Preserved

- Theme Armor token system.
- Style screen and live preview cards.
- Node Heartbeat / Auto Presence.
- Relay Radar packet workflow.
- Group/device presence flow.
- Admin session and admin ledger flow.
- Manual setup as advanced fallback.

## Not added yet

- Full Cartographer / RouteSeed mission engine.
- Mission Preflight.
- State Graph Logger.
- Idle Route Solver.
- Teach Mode route memory.

These remain planned after Network Discovery and Mission Cards.
