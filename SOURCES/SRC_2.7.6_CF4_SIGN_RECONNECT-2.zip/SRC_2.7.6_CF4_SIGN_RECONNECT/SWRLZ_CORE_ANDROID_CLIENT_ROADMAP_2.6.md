# SWRLZ-Core Android Client Roadmap

**Roadmap revision:** 2.6 — Command Cards + Bridge Truth + UI Legend  
**Current verified client baseline:** `v0.2.6-bridge-truth` / `versionCode 12`  
**Latest verified patch label:** `2.6-BRIDGE-TRUTH`  
**Current bridge role:** Action Phone / SWRLZ-Core client  
**Core law:** No invisible patches. No mystery APKs. Integrate, do not overwrite.

---

## 1. Current Proven State

### ✅ 0.1.x — Offline-first + context foundation
- [x] App installs and launches.
- [x] Home screen loads.
- [x] Accessibility service status displays.
- [x] Overlay permission status displays.
- [x] Local Skill Library remains available offline.
- [x] Context capsule exists.
- [x] Mentor backend can remain unreachable without breaking local features.
- [x] Context sharing levels exist: MINIMAL, STANDARD, DETAILED, LOCAL ONLY.
- [x] Context preview can be refreshed locally.
- [x] Sensitive fields are redacted.
- [x] Password nodes are detected.
- [x] App version is visible in context payload.

### ✅ 0.1.6 — Identity provenance
- [x] Visible build identity on Home screen.
- [x] App shows version name and version code.
- [x] App shows patch label.
- [x] App shows roadmap revision.
- [x] App shows source ZIP identity.
- [x] Build law displayed: No invisible patches. No mystery APKs.

### ✅ 2.0 — Local Core Node Bridge foundation
- [x] Mentor backend URL and Local Core Node URL are separate.
- [x] Setup screen includes Local Core Node Bridge section.
- [x] Core Node can be configured independently of paid/online Mentor backend.
- [x] Core Node test button exists.
- [x] Core Node status displays on Home screen.

### ✅ 2.1 — Core Node diagnostics
- [x] App can reach `/status` on Local Core Node over LAN / local loopback.
- [x] App sends Ktor client requests.
- [x] App sends device/app identity headers.
- [x] Server sees Device Node ID, app version, patch label, client IP, request path.
- [x] Phone-to-phone LAN bridge verified.
- [x] Same-phone `127.0.0.1` local bridge verified.

### ✅ 2.2 — Admin / How To / Info
- [x] Core/Admin screen exists.
- [x] Admin username/password fields exist.
- [x] Server settings can be loaded with correct admin credentials.
- [x] Wrong/missing admin credentials return denied/401.
- [x] Recent events can be loaded.
- [x] Session logs can be loaded.
- [x] How To tab exists.
- [x] Info/Legend tab exists.
- [x] App explains what major functions do.

### ✅ 2.4 / 2.5 — Command Queue + Command Cards
- [x] Cmds tab exists.
- [x] App can create safe test command.
- [x] App can pull pending commands.
- [x] Server returns command JSON.
- [x] App converts command JSON into a command card.
- [x] Latest command ID auto-fills.
- [x] ACK button works.
- [x] REJECT button exists.
- [x] COMPLETE button works.
- [x] Completed command card displays completed state.
- [x] Server logs command create / view / ack / complete.
- [x] End-to-end safe PING command cycle verified.

---

## 2. Known Issues / Fix Queue

### 🔴 CLIENT-FIX-001 — Home status layout wrap bug
**Observed:** `Local Core Node bridge` label breaks vertically as `Loc / al / Cor / e / Nod / e / brid / ge`.

**Cause likely:** Long server version/status text is squeezing the left label column.

**Fix target:**
- Replace tight horizontal status row with stacked card layout, or
- Give label fixed min width and status flexible wrap, or
- Put long server version on a second line.

**Acceptance:**
- `Local Core Node bridge` displays normally on narrow phone screens.
- Long value like `local-node-server-0.3-session-logs-updater` wraps beneath, not beside, the label.

### 🟡 CLIENT-FIX-002 — Launch status truth model
**Observed:** App may auto-contact saved Core Node on launch, but Setup says configured/not tested.

**Fix target:** Separate these states:
- `configured`: URL exists.
- `lastManualTest`: result from user pressing TEST CORE NODE.
- `lastAutoCheck`: result from app launch/background status check.
- `reachable`: only true after valid server response with `ok: true`.

**Acceptance:**
- Setup can clearly say `Core Node configured · not manually tested`, `Last manual test successful`, `Last auto-check successful`, or `Last test failed`.
- Home status never shows success unless the server response is valid.

### 🔴 CLIENT-FIX-003 — Status color rules
**Fix target:**
- Success = green.
- Failure/unreachable/denied = red.
- Not configured / needs info / untested / mentor unreachable = yellow.
- Active testing/loading = cyan or yellow.

**Acceptance:**
- `Core Node failed · core node unreachable` is red.
- `Core Node configured · not tested` is yellow.
- `Core Node reachable` is green.

### 🟡 CLIENT-FIX-004 — Command card state clarity
**Fix target:**
- Add clear card status chips: Pending, Accepted, Rejected, Completed, Failed.
- Disable impossible actions:
  - Completed command should not show active COMPLETE unless re-test is allowed.
  - Rejected command should not show active COMPLETE unless reopened.

### 🟡 CLIENT-FIX-005 — Admin password handling
**Fix target:**
- Do not display real password anywhere.
- Preserve masked field.
- Add optional “show password” toggle only if user explicitly wants it.
- Consider separate pairing token vs admin password.

---

## 3. Next Major Client Patch

## ✅ 2.6 — Command Cards Hardening + Bridge Truth

### Goals
- Make the app’s bridge status honest, readable, and hard to misunderstand.
- Fix narrow-screen status layout.
- Improve command-card lifecycle display.
- Strengthen How To / Info pages around command safety.

### Planned changes
- [x] Fix Home `Local Core Node bridge` status row layout.
- [x] Add separate manual-test and auto-check state tracking.
- [x] Add last successful Core Node response timestamp.
- [x] Add server identity card with server version, patch label, roadmap, LAN URL, and last check time.
- [x] Add color-state function shared across Home, Setup, and Core screens.
- [x] Improve command cards with status chips, timestamps, created_by / acked_by / completed_by, and safer disabled states.
- [x] Add Info entries for Core Node URL, Mentor backend URL, pairing token, admin password, command cards, ACK / REJECT / COMPLETE.
- [x] Add How To steps for same-phone local server test, phone-to-phone LAN bridge, Termux server start, and command card test cycle.

### Acceptance test
1. Start server in Termux.
2. Open SWRLZ-Core.
3. Home displays readable Local Core Node status.
4. Setup shows configured/manual/auto status correctly.
5. TEST CORE NODE returns green success only on valid server response.
6. Create PING command.
7. Pull command card.
8. ACK command.
9. COMPLETE command.
10. Server logs all steps.
11. Recent events and session log remain readable.

---

## 4. Future Client Milestones

## 2.7 — Action Phone Safe Executor
- [ ] PING command executes locally.
- [ ] SHOW_MESSAGE command displays safe local message.
- [ ] REPORT_STATUS command sends device/app status response.
- [ ] REFRESH_CONTEXT command refreshes context preview.
- [ ] User approval required before every action.
- [ ] No destructive actions.

## 2.8 — Teach Packet Preview
- [ ] Create local teach packet schema.
- [ ] Preview teach packet before server upload.
- [ ] Save local taught skill draft.
- [ ] Send teach packet to Core Node only after approval.
- [ ] Server stores teach packets as append-only records.

## 2.9 — Allowlist-aware Open App command
- [ ] Add OPEN_APP command type.
- [ ] Only allow apps from allowlist.
- [ ] Require confirmation.
- [ ] Log outcome.
- [ ] Never open protected system settings without separate high-risk confirmation.

## 3.0 — Local-first Automation Loop
- [ ] Core Node proposes.
- [ ] Action Phone previews.
- [ ] User approves.
- [ ] Action Phone executes.
- [ ] Action Phone reports.
- [ ] Server records command history.
- [ ] Rollback/undo notes where possible.

---

## 5. Build / Release Requirements

Every Android client patch must include:
- [ ] Version name bump.
- [ ] Version code bump.
- [ ] Patch label update.
- [ ] Roadmap revision update.
- [ ] Source ZIP name update.
- [ ] Build identity screen update.
- [ ] SHA-256 file.
- [ ] Build provenance report.
- [ ] Test checklist.
- [ ] No hard-coded personal tokens or passwords.
- [ ] No mystery APK.


---

## 2.6 completion note

Patch `2.6-BRIDGE-TRUTH` is implemented in source folder `SWRLZ_CORE_2.6_BRIDGE_TRUTH` and prepared for source ZIP release as `SWRLZ_CORE_2.6_BRIDGE_TRUTH_SOURCE.zip`. Build verification in this environment was blocked because Gradle wrapper could not download `gradle-8.7-bin.zip` without internet; server-side tests completed separately.
