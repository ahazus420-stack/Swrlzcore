#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
api = (root / 'android/app/src/main/java/sh/swurlz/core/net/Api.kt').read_text()
network = (root / 'android/app/src/main/java/sh/swurlz/core/ui/screens/NetworkDiscoveryScreen.kt').read_text()
commands = (root / 'android/app/src/main/java/sh/swurlz/core/ui/screens/CommandsScreen.kt').read_text()
prefs = (root / 'android/app/src/main/java/sh/swurlz/core/data/Prefs.kt').read_text()
policy = (root / 'android/app/src/main/java/sh/swurlz/core/net/AdminRoutePolicy.kt').read_text()
build = (root / 'android/app/build.gradle.kts').read_text()

assert 'skipped_no_saved_token' in api
assert 'Local admin state was cleared' in api
assert 'response.request.url.encodedPath' in api
assert 'core node route unavailable: ${t.route}' in api
assert 'Prefs.forgetAdminSession(ctx)' in api
assert 'KEY_ADMIN_ALL_DEVICES_VISIBLE] = false' in prefs
assert 'lastVerifiedAt.isNotBlank()' in policy
assert 'AdminRoutePolicy.devicesPath(verifiedAdmin)' in network
assert 'SKIPPED /admin/queues' in network
assert 'adminMode && !adminTokenSaved' in network
assert 'var radarStatus' in commands
assert 'if (isRadarRead) radarStatus' in commands
assert 'versionCode = 30' in build
assert '0.2.7.6-cf8-admin-fallback' in build
print('CF8 verified-admin fallback checks: PASS')
