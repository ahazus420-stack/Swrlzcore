import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) load(f.reader())
}

fun swrlzPropOrEnv(key: String): String =
    ((localProps[key] as String?) ?: System.getenv(key)).orEmpty().trim()

val swrlzDevKeystoreFile = swrlzPropOrEnv("SWRLZ_DEV_KEYSTORE_FILE")
val swrlzDevKeystorePassword = swrlzPropOrEnv("SWRLZ_DEV_KEYSTORE_PASSWORD")
val swrlzDevKeyAlias = swrlzPropOrEnv("SWRLZ_DEV_KEY_ALIAS")
val swrlzDevKeyPassword = swrlzPropOrEnv("SWRLZ_DEV_KEY_PASSWORD")
val swrlzDevSigningReady = swrlzDevKeystoreFile.isNotBlank() &&
    swrlzDevKeystorePassword.isNotBlank() &&
    swrlzDevKeyAlias.isNotBlank() &&
    swrlzDevKeyPassword.isNotBlank()

android {
    namespace = "sh.swurlz.core"
    compileSdk = 34

    signingConfigs {
        if (swrlzDevSigningReady) {
            create("swrlzDev") {
                storeFile = rootProject.file(swrlzDevKeystoreFile)
                storePassword = swrlzDevKeystorePassword
                keyAlias = swrlzDevKeyAlias
                keyPassword = swrlzDevKeyPassword
            }
        }
    }

    defaultConfig {
        applicationId = "sh.swurlz.core"
        minSdk = 26
        targetSdk = 34
        versionCode = 30
        versionName = "0.2.7.6-cf8-admin-fallback"

        // Optional build-time defaults. Both can be changed later inside the app.
        val backend = (localProps["SWURLZ_BACKEND_URL"] as String?)
            ?: System.getenv("SWURLZ_BACKEND_URL")
            ?: ""
        val apiToken = (localProps["SWURLZ_API_TOKEN"] as String?)
            ?: System.getenv("SWURLZ_API_TOKEN")
            ?: ""
        buildConfigField("String", "BACKEND_URL", "\"${backend.replace("\"", "\\\"")}\"")
        buildConfigField("String", "API_TOKEN", "\"${apiToken.replace("\"", "\\\"")}\"")

        // SWRLZ build identity: every patch must carry a visible nameplate inside the app.
        buildConfigField("String", "PATCH_LABEL", "\"2.7.6-CF7-NETPULSE-LIVE-ADMIN\"")
        buildConfigField("String", "ROADMAP_REVISION", "\"2.7.6\"")
        buildConfigField("String", "BUILD_LINE", "\"Network pulse / persisted refresh / live admin panels / server dashboard sync / reinstall backup hints\"")
        buildConfigField("String", "SOURCE_ZIP", "\"SRC_CF7_276_NETPULSE.zip\"")
        buildConfigField("String", "PATCH_NOTES", "\"CF7: Persists network auto-refresh and interval, adds live groups/devices/online/queue panels, admin-only actions, and backup/restore guidance.\"")
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            if (swrlzDevSigningReady) signingConfig = signingConfigs.getByName("swrlzDev")
        }
        release {
            isMinifyEnabled = false
            signingConfig = if (swrlzDevSigningReady) signingConfigs.getByName("swrlzDev") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "META-INF/INDEX.LIST",
            "META-INF/io.netty.versions.properties",
        )
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.02")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.5")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.5")
    implementation("androidx.navigation:navigation-compose:2.8.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.security:security-crypto:1.0.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")

    implementation("io.ktor:ktor-client-core:2.3.12")
    implementation("io.ktor:ktor-client-okhttp:2.3.12")
    implementation("io.ktor:ktor-client-websockets:2.3.12")
}
