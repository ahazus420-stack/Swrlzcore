# SWRLZ-Core 2.7.6 — Current CLIENT line

## CF8 Verified Admin Fallback

The current candidate is `CLIENT_CFv1.0.2_SWRLZ.zip` with Android
`versionName 0.2.7.6-cf8-admin-fallback` / `versionCode 30`.

CF8 preserves CF7 Network Pulse and adds:

- verified-token gating before `/admin/*` routes;
- automatic fallback to `/presence/devices` when admin authentication is absent;
- local-first Forget Admin behavior even when remote revoke is unsupported;
- endpoint-specific HTTP error reporting;
- separate Radar read health versus heartbeat/write-operation health.

See `RPT_CF8_276_ADMIN_FALLBACK.md` for the device evidence and bounded repair.
