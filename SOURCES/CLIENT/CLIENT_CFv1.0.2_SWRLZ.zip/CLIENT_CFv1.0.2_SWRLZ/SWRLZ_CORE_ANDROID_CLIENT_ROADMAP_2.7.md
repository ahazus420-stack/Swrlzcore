# SWRLZ-Core Android Client Roadmap 2.7

## Current release
**2.7 — Two-Phone Sigil**

Client-facing mythic release for relay flow, device cards, admin session mode, and offline packet cards.

## Completed
- Saved admin token/session state UI.
- Admin Mode ON/OFF persistence.
- Group ID/Key and Device ID/Key UI.
- Device join/check-in controls.
- Online device cards.
- Packet composer for self/device/group.
- Offline queue packet inbox.
- Packet lifecycle buttons.

## Next recommended client release
**2.8 — Dragon Queue**

Focus:
- Better packet filtering/search.
- Queue badges on Home/Core screens.
- More polished motion states: pulse, ripple, slide-in, success flash.
- Per-device capability chips.
- Safer OPEN_APP prototype with allowlist + confirmation only.


## CF8 Verified Admin Fallback

- Treat an admin UI toggle as preference only, never authentication authority.
- Require token plus successful verification before selecting `/admin/*`.
- Keep Forget Admin local-first and best-effort remote.
- Preserve successful public presence reads when optional write/admin surfaces are unavailable.
- Keep Radar connection health separate from heartbeat and command-operation status.
