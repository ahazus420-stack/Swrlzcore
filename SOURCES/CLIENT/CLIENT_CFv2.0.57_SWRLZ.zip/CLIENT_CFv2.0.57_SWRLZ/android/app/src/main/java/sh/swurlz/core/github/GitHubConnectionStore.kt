package sh.swurlz.core.github

import android.app.backup.BackupManager
import android.content.Context
import org.json.JSONObject
import sh.swurlz.core.data.SecretStore

/**
 * Durable, backup-aware GitHub Forge connection profile.
 *
 * Runtime secrets remain in [SecretStore]. A custom BackupAgent serializes a tiny
 * encrypted-transport-only restore envelope and re-imports the token into the new
 * install's Android Keystore store during restore.
 */
object GitHubConnectionStore {
    private const val PREFS = "swrlz_github_connection_profile"
    private const val KEY_OAUTH_CLIENT_ID = "oauth_client_id"
    private const val KEY_OWNER = "owner"
    private const val KEY_REPOSITORY = "repository"
    private const val KEY_BRANCH = "branch"
    private const val KEY_CONNECTED_LOGIN = "connected_login"
    private const val KEY_AUTO_CONNECT = "auto_connect"
    private const val KEY_EXPLICITLY_DISCONNECTED = "explicitly_disconnected"
    private const val ENVELOPE_VERSION = 1

    data class Profile(
        val oauthClientId: String,
        val owner: String,
        val repository: String,
        val branch: String,
        val connectedLogin: String,
        val autoConnect: Boolean,
        val explicitlyDisconnected: Boolean,
    )

    fun profile(context: Context): Profile {
        migrateLegacyClientId(context)
        val prefs = prefs(context)
        return Profile(
            oauthClientId = prefs.getString(KEY_OAUTH_CLIENT_ID, "").orEmpty(),
            owner = prefs.getString(KEY_OWNER, "ahazus420-stack").orEmpty().ifBlank { "ahazus420-stack" },
            repository = prefs.getString(KEY_REPOSITORY, "Swrlzcore").orEmpty().ifBlank { "Swrlzcore" },
            branch = prefs.getString(KEY_BRANCH, "main").orEmpty().ifBlank { "main" },
            connectedLogin = prefs.getString(KEY_CONNECTED_LOGIN, "").orEmpty(),
            autoConnect = prefs.getBoolean(KEY_AUTO_CONNECT, true),
            explicitlyDisconnected = prefs.getBoolean(KEY_EXPLICITLY_DISCONNECTED, false),
        )
    }

    fun setOAuthClientId(context: Context, clientId: String) {
        prefs(context).edit()
            .putString(KEY_OAUTH_CLIENT_ID, clientId.trim())
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .putBoolean(KEY_AUTO_CONNECT, true)
            .commitOrThrow("GitHub OAuth client ID")
        requestBackup(context)
    }

    fun saveTarget(context: Context, owner: String, repository: String, branch: String) {
        prefs(context).edit()
            .putString(KEY_OWNER, owner.trim())
            .putString(KEY_REPOSITORY, repository.trim())
            .putString(KEY_BRANCH, branch.trim())
            .commitOrThrow("GitHub repository target")
        requestBackup(context)
    }

    fun saveAuthorizedConnection(
        context: Context,
        token: String,
        connectedLogin: String,
        oauthClientId: String,
        owner: String,
        repository: String,
        branch: String,
    ) {
        SecretStore.setGithubToken(context, token)
        prefs(context).edit()
            .putString(KEY_OAUTH_CLIENT_ID, oauthClientId.trim())
            .putString(KEY_OWNER, owner.trim())
            .putString(KEY_REPOSITORY, repository.trim())
            .putString(KEY_BRANCH, branch.trim())
            .putString(KEY_CONNECTED_LOGIN, connectedLogin.trim())
            .putBoolean(KEY_AUTO_CONNECT, true)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .commitOrThrow("GitHub connection profile")
        requestBackup(context)
    }

    fun markValidated(context: Context, connectedLogin: String) {
        prefs(context).edit()
            .putString(KEY_CONNECTED_LOGIN, connectedLogin.trim())
            .putBoolean(KEY_AUTO_CONNECT, true)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, false)
            .commitOrThrow("GitHub validation state")
        requestBackup(context)
    }

    fun disconnect(context: Context) {
        SecretStore.forgetGithubToken(context)
        SecretStore.forgetGithubOAuthClientId(context)
        prefs(context).edit()
            .clear()
            .putBoolean(KEY_AUTO_CONNECT, false)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, true)
            .commitOrThrow("GitHub disconnect state")
        requestBackup(context)
    }

    fun shouldAutoConnect(context: Context): Boolean {
        val profile = profile(context)
        return profile.autoConnect && !profile.explicitlyDisconnected
    }

    /**
     * Payload consumed only by [sh.swurlz.core.backup.SwrlzBackupAgent].
     * The agent writes it only when the Android backup transport reports client-side
     * encryption or direct device-to-device transfer.
     */
    fun backupEnvelope(context: Context): ByteArray {
        val profile = profile(context)
        val token = SecretStore.githubToken(context)
        val payload = JSONObject()
            .put("version", ENVELOPE_VERSION)
            .put("oauthClientId", profile.oauthClientId)
            .put("owner", profile.owner)
            .put("repository", profile.repository)
            .put("branch", profile.branch)
            .put("connectedLogin", profile.connectedLogin)
            .put("autoConnect", profile.autoConnect)
            .put("explicitlyDisconnected", profile.explicitlyDisconnected)
            .put("token", if (profile.autoConnect && !profile.explicitlyDisconnected) token else "")
        return payload.toString().toByteArray(Charsets.UTF_8)
    }

    fun restoreEnvelope(context: Context, bytes: ByteArray): Boolean {
        val payload = runCatching { JSONObject(bytes.toString(Charsets.UTF_8)) }.getOrNull() ?: return false
        if (payload.optInt("version", 0) !in 1..ENVELOPE_VERSION) return false

        val disconnected = payload.optBoolean("explicitlyDisconnected", false)
        val autoConnect = payload.optBoolean("autoConnect", true) && !disconnected
        val token = payload.optString("token", "").trim()

        prefs(context).edit()
            .putString(KEY_OAUTH_CLIENT_ID, payload.optString("oauthClientId", "").trim())
            .putString(KEY_OWNER, payload.optString("owner", "ahazus420-stack").trim())
            .putString(KEY_REPOSITORY, payload.optString("repository", "Swrlzcore").trim())
            .putString(KEY_BRANCH, payload.optString("branch", "main").trim())
            .putString(KEY_CONNECTED_LOGIN, payload.optString("connectedLogin", "").trim())
            .putBoolean(KEY_AUTO_CONNECT, autoConnect)
            .putBoolean(KEY_EXPLICITLY_DISCONNECTED, disconnected)
            .commitOrThrow("restored GitHub profile")

        if (autoConnect && token.isNotBlank()) {
            SecretStore.setGithubToken(context, token)
        } else {
            SecretStore.forgetGithubToken(context)
        }
        return true
    }

    private fun migrateLegacyClientId(context: Context) {
        val prefs = prefs(context)
        if (!prefs.getString(KEY_OAUTH_CLIENT_ID, "").isNullOrBlank()) return
        val legacy = SecretStore.githubOAuthClientId(context).trim()
        if (legacy.isBlank()) return
        prefs.edit().putString(KEY_OAUTH_CLIENT_ID, legacy).commit()
        requestBackup(context)
    }

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun android.content.SharedPreferences.Editor.commitOrThrow(label: String) {
        check(commit()) { "Unable to persist $label." }
    }

    private fun requestBackup(context: Context) {
        runCatching { BackupManager(context.applicationContext).dataChanged() }
    }
}
