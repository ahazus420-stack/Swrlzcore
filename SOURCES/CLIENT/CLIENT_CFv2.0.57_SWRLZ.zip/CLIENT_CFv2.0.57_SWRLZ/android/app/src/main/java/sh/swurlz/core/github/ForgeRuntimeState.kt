package sh.swurlz.core.github

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Process-local Forge state projected into the CLIENT shell and bubble. */
object ForgeRuntimeState {
    enum class Phase(val label: String) {
        IDLE("IDLE"),
        VALIDATING("VALIDATING"),
        UPLOADING("UPLOADING"),
        BUILDING("BUILDING"),
        DOWNLOADING("DOWNLOADING"),
        ARTIFACTS_READY("ARTIFACTS READY"),
        COMPLETE("COMPLETE"),
        FAILED("FAILED"),
    }

    enum class EventTone { INFO, SUCCESS, FAILURE }

    data class Event(
        val title: String,
        val detail: String,
        val tone: EventTone,
        val timestampMillis: Long = System.currentTimeMillis(),
    )

    var phase by mutableStateOf(Phase.IDLE)
        private set

    var latestEvent by mutableStateOf<Event?>(null)
        private set

    var activeTransactionId by mutableStateOf<String?>(null)
        private set

    fun publish(next: Phase) {
        phase = next
    }

    fun beginTransaction(transactionId: String) {
        activeTransactionId = transactionId
    }

    fun endTransaction(transactionId: String) {
        if (activeTransactionId == transactionId) activeTransactionId = null
    }

    fun publishEvent(event: Event) {
        latestEvent = event
        phase = when (event.tone) {
            EventTone.SUCCESS -> Phase.COMPLETE
            EventTone.FAILURE -> Phase.FAILED
            EventTone.INFO -> phase
        }
    }
}
