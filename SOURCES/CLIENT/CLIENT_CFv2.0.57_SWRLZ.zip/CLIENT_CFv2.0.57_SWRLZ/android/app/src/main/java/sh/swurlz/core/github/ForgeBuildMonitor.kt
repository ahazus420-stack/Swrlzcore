package sh.swurlz.core.github

import android.content.Context
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.notification.ForgeEventNotifier

/** Polls only durable, verified Forge commits and emits each artifact-build outcome once. */
object ForgeBuildMonitor {
    suspend fun pollOnce(context: Context) {
        val appContext = context.applicationContext
        val token = SecretStore.githubToken(appContext)
        if (token.isBlank()) return

        val watches = ForgeBuildWatchStore.pending(appContext)
        if (watches.isEmpty()) return

        val grouped = watches.groupBy { Triple(it.owner, it.repository, it.branch) }
        for ((target, targetWatches) in grouped) {
            val (owner, repository, branch) = target
            val runs = runCatching {
                GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token)
            }.getOrNull() ?: continue

            for (watch in targetWatches) {
                val completed = runs.firstOrNull { run ->
                    run.status == "completed" &&
                        run.headSha.equals(watch.commitSha, ignoreCase = true) &&
                        isArtifactBuild(run)
                } ?: continue

                val conclusion = completed.conclusion ?: "unknown"
                if (!ForgeBuildWatchStore.markOutcomeNotified(appContext, completed.id, conclusion)) {
                    ForgeBuildWatchStore.complete(appContext, watch)
                    continue
                }

                val artifactCount = if (conclusion.equals("success", ignoreCase = true)) {
                    runCatching {
                        GitHubForgeClient.listArtifacts(owner, repository, completed.id, token)
                            .count { !it.expired }
                    }.getOrDefault(0)
                } else {
                    0
                }

                ForgeEventNotifier.workflowCompleted(
                    context = appContext,
                    runId = completed.id,
                    workflowName = completed.name,
                    conclusion = completed.conclusion,
                    artifactCount = artifactCount,
                    commitSha = watch.commitSha,
                    transactionId = watch.transactionId,
                )
                ForgeBuildWatchStore.complete(appContext, watch)
            }
        }
    }

    private fun isArtifactBuild(run: GitHubForgeClient.WorkflowRun): Boolean {
        val identity = "${run.name} ${run.displayTitle}".lowercase()
        return listOf("apk", "artifact", "build", "router", "assemble").any(identity::contains)
    }
}
