package sh.swurlz.core.github

import android.content.Context
import android.os.Build
import java.io.File
import java.time.Instant
import java.util.UUID
import sh.swurlz.core.BuildConfig

/** Append-only, redacted Forge upload diagnostics that can be exported while work is active. */
object ForgeUploadLogStore {
    private const val PREFS = "swrlz_forge_upload_log_state"
    private const val KEY_CURRENT = "current_session_id"
    private const val KEY_LATEST = "latest_session_id"
    private const val DIRECTORY = "forge_upload_logs"
    private const val MAX_LOGS = 20
    private const val MAX_BYTES = 2L * 1024L * 1024L

    @Synchronized
    fun ensureSession(context: Context, reason: String): String {
        val prefs = prefs(context)
        val current = prefs.getString(KEY_CURRENT, "").orEmpty()
        if (current.isNotBlank() && logFile(context, current).isFile) return current
        return startSession(context, reason)
    }

    @Synchronized
    fun startSession(context: Context, reason: String): String {
        val sessionId = UUID.randomUUID().toString()
        val file = logFile(context, sessionId)
        file.parentFile?.mkdirs()
        file.writeText(
            buildString {
                appendLine("SWRLZ FORGE UPLOAD DIAGNOSTIC LOG")
                appendLine("session_id=$sessionId")
                appendLine("started_at=${Instant.now()}")
                appendLine("reason=${sanitize(reason)}")
                appendLine("client_version=${BuildConfig.VERSION_NAME}")
                appendLine("client_version_code=${BuildConfig.VERSION_CODE}")
                appendLine("android_sdk=${Build.VERSION.SDK_INT}")
                appendLine("device=${sanitize(Build.MANUFACTURER)} ${sanitize(Build.MODEL)}")
                appendLine("security=GitHub tokens, Authorization headers, OAuth device codes, and token-like values are redacted")
                appendLine("---")
            },
            Charsets.UTF_8,
        )
        prefs.edit().putString(KEY_CURRENT, sessionId).putString(KEY_LATEST, sessionId).commit()
        prune(context)
        append(context, sessionId, "SESSION", "Upload diagnostic session opened")
        return sessionId
    }

    @Synchronized
    fun append(
        context: Context,
        sessionId: String,
        phase: String,
        message: String,
        fields: Map<String, Any?> = emptyMap(),
    ) {
        if (sessionId.isBlank()) return
        val file = logFile(context, sessionId)
        if (!file.exists()) return
        if (file.length() >= MAX_BYTES) return
        val fieldText = fields.entries.joinToString(" ") { (key, value) ->
            "${sanitize(key)}=${sanitize(value?.toString().orEmpty())}"
        }
        val line = buildString {
            append(Instant.now())
            append(" | ")
            append(sanitize(phase.uppercase()))
            append(" | ")
            append(sanitize(message))
            if (fieldText.isNotBlank()) {
                append(" | ")
                append(fieldText)
            }
            appendLine()
        }
        file.appendText(line, Charsets.UTF_8)
        prefs(context).edit().putString(KEY_LATEST, sessionId).apply()
    }

    @Synchronized
    fun appendFailure(context: Context, sessionId: String, phase: String, failure: Throwable) {
        append(
            context,
            sessionId,
            phase,
            "${failure::class.java.simpleName}: ${failure.message.orEmpty()}",
        )
    }

    @Synchronized
    fun finish(context: Context, sessionId: String, outcome: String) {
        append(context, sessionId, "SESSION_END", outcome)
        val prefs = prefs(context)
        if (prefs.getString(KEY_CURRENT, "") == sessionId) {
            prefs.edit().remove(KEY_CURRENT).putString(KEY_LATEST, sessionId).commit()
        }
    }

    fun hasLog(context: Context): Boolean = latestFile(context)?.isFile == true

    fun latestBytes(context: Context): ByteArray? = latestFile(context)?.takeIf { it.isFile }?.readBytes()

    fun latestSuggestedName(context: Context): String {
        val id = prefs(context).getString(KEY_LATEST, "").orEmpty().take(8).ifBlank { "latest" }
        return "swrlz_forge_upload_${id}.log.txt"
    }

    fun currentSessionId(context: Context): String =
        prefs(context).getString(KEY_CURRENT, "").orEmpty()

    private fun latestFile(context: Context): File? {
        val latest = prefs(context).getString(KEY_LATEST, "").orEmpty()
        return latest.takeIf { it.isNotBlank() }?.let { logFile(context, it) }
    }

    private fun logFile(context: Context, sessionId: String): File =
        File(File(context.applicationContext.filesDir, DIRECTORY), "forge_upload_$sessionId.log")

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    private fun prune(context: Context) {
        val directory = File(context.applicationContext.filesDir, DIRECTORY)
        val files = directory.listFiles().orEmpty().sortedByDescending { it.lastModified() }
        files.drop(MAX_LOGS).forEach { it.delete() }
    }

    private fun sanitize(raw: String): String {
        var value = raw.replace('\n', ' ').replace('\r', ' ').trim()
        val patterns = listOf(
            Regex("(?i)(authorization\\s*[:=]\\s*)(bearer|token)\\s+[^\\s,;]+"),
            Regex("(?i)(bearer|token)\\s+[A-Za-z0-9._-]{12,}"),
            Regex("(?i)github_pat_[A-Za-z0-9_]+"),
            Regex("(?i)gh[pousr]_[A-Za-z0-9_]+"),
            Regex("(?i)(access[_-]?token|refresh[_-]?token|device[_-]?code)\\s*[:=]\\s*[^\\s,;]+"),
        )
        patterns.forEach { pattern -> value = value.replace(pattern, "[REDACTED]") }
        return value.take(4000)
    }
}
