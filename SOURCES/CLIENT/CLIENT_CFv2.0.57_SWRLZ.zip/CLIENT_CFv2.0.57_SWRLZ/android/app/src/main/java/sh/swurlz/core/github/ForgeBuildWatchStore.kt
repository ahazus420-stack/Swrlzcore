package sh.swurlz.core.github

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Durable correlation between a verified Forge commit and its later GitHub artifact build.
 *
 * Multiple watches are retained so a CLIENT upload followed by a SERVER upload does not
 * silently replace the first pending build notification.
 */
data class ForgeBuildWatch(
    val owner: String,
    val repository: String,
    val branch: String,
    val commitSha: String,
    val transactionId: String,
    val createdAtMillis: Long,
)

object ForgeBuildWatchStore {
    private const val PREFS = "swrlz_forge_build_watch_v1"
    private const val KEY_WATCHES = "pending_watches_json"
    private const val KEY_NOTIFIED = "notified_outcomes"
    private const val MAX_WATCHES = 12
    const val MAX_WATCH_AGE_MS = 24L * 60L * 60L * 1000L

    @Synchronized
    fun add(context: Context, watch: ForgeBuildWatch) {
        val now = System.currentTimeMillis()
        val next = load(context)
            .filter { now - it.createdAtMillis <= MAX_WATCH_AGE_MS }
            .filterNot { it.commitSha.equals(watch.commitSha, ignoreCase = true) }
            .plus(watch)
            .sortedByDescending { it.createdAtMillis }
            .take(MAX_WATCHES)
        save(context, next)
    }

    @Synchronized
    fun pending(context: Context): List<ForgeBuildWatch> {
        val now = System.currentTimeMillis()
        val current = load(context)
        val valid = current.filter { now - it.createdAtMillis <= MAX_WATCH_AGE_MS }
        if (valid.size != current.size) save(context, valid)
        return valid
    }

    @Synchronized
    fun complete(context: Context, watch: ForgeBuildWatch) {
        save(
            context,
            load(context).filterNot {
                it.commitSha.equals(watch.commitSha, ignoreCase = true) &&
                    it.owner == watch.owner &&
                    it.repository == watch.repository
            },
        )
    }

    @Synchronized
    fun markOutcomeNotified(context: Context, runId: Long, conclusion: String): Boolean {
        val key = "$runId:${conclusion.lowercase()}"
        val preferences = preferences(context)
        val outcomes = preferences.getStringSet(KEY_NOTIFIED, emptySet())
            .orEmpty()
            .toMutableSet()
        if (!outcomes.add(key)) return false
        preferences.edit()
            .putStringSet(KEY_NOTIFIED, outcomes.toList().takeLast(80).toSet())
            .apply()
        return true
    }

    fun hasPending(context: Context): Boolean = pending(context).isNotEmpty()

    private fun load(context: Context): List<ForgeBuildWatch> {
        val raw = preferences(context).getString(KEY_WATCHES, "[]").orEmpty()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val sha = item.optString("commitSha")
                    if (sha.isBlank()) continue
                    add(
                        ForgeBuildWatch(
                            owner = item.optString("owner"),
                            repository = item.optString("repository"),
                            branch = item.optString("branch", "main"),
                            commitSha = sha,
                            transactionId = item.optString("transactionId"),
                            createdAtMillis = item.optLong("createdAtMillis", 0L),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun save(context: Context, watches: List<ForgeBuildWatch>) {
        val array = JSONArray()
        watches.forEach { watch ->
            array.put(
                JSONObject()
                    .put("owner", watch.owner)
                    .put("repository", watch.repository)
                    .put("branch", watch.branch)
                    .put("commitSha", watch.commitSha)
                    .put("transactionId", watch.transactionId)
                    .put("createdAtMillis", watch.createdAtMillis),
            )
        }
        preferences(context).edit().putString(KEY_WATCHES, array.toString()).apply()
    }

    private fun preferences(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
