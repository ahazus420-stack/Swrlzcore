package sh.swurlz.core.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.Instant
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.github.ForgeBuildMonitor
import sh.swurlz.core.github.ForgeBuildWatch
import sh.swurlz.core.github.ForgeBuildWatchStore
import sh.swurlz.core.github.ForgeRuntimeState
import sh.swurlz.core.github.ForgeUploadLogStore
import sh.swurlz.core.github.GitHubConnectionStore
import sh.swurlz.core.github.OpenSiblingDocumentContract
import sh.swurlz.core.github.SiblingDocumentRequest
import sh.swurlz.core.notification.ForgeEventNotifier
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
fun GitHubForgeScreen() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val forgePreferences = remember {
        context.getSharedPreferences("swrlz_forge_preferences", Context.MODE_PRIVATE)
    }
    val restoredConnectionProfile = remember { GitHubConnectionStore.profile(context) }

    var owner by remember { mutableStateOf(restoredConnectionProfile.owner) }
    var repository by remember { mutableStateOf(restoredConnectionProfile.repository) }
    var branch by remember { mutableStateOf(restoredConnectionProfile.branch) }
    var destination by remember { mutableStateOf("SOURCES/INBOX") }
    var message by remember { mutableStateOf("Upload CLIENT and SERVER source packages through SWRLZ Forge") }
    var token by remember {
        mutableStateOf(
            if (GitHubConnectionStore.shouldAutoConnect(context)) SecretStore.githubToken(context) else "",
        )
    }
    var oauthClientId by remember { mutableStateOf(restoredConnectionProfile.oauthClientId) }
    var connectedLogin by remember { mutableStateOf("") }
    var deviceAuth by remember { mutableStateOf<GitHubForgeClient.DeviceAuthorization?>(null) }
    var workflowId by remember { mutableStateOf("") }
    var dispatch by remember { mutableStateOf(false) }
    var autoRefresh by remember { mutableStateOf(true) }
    var autoRoute by remember { mutableStateOf(true) }
    var autoMatchChecksum by remember {
        mutableStateOf(forgePreferences.getBoolean("auto_match_source_checksum", true))
    }
    var sourceZipGuard by remember {
        mutableStateOf(forgePreferences.getBoolean("source_zip_content_guard", true))
    }
    var workflowHistoryDepth by remember {
        mutableIntStateOf(forgePreferences.getInt("workflow_history_depth", 4).coerceIn(2, 20))
    }
    var files by remember { mutableStateOf(emptyList<GitHubForgeClient.LocalFile>()) }
    var pendingChecksumZip by remember { mutableStateOf<GitHubForgeClient.LocalFile?>(null) }
    var runs by remember { mutableStateOf(emptyList<GitHubForgeClient.WorkflowRun>()) }
    var artifacts by remember { mutableStateOf(emptyList<GitHubForgeClient.Artifact>()) }
    var jobsByRun by remember { mutableStateOf<Map<Long, List<GitHubForgeClient.WorkflowJob>>>(emptyMap()) }
    var selectedRunId by remember { mutableStateOf<Long?>(null) }
    var pendingArtifactBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingArtifactName by remember { mutableStateOf("artifact.zip") }
    var pendingWorkflowLogBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingWorkflowLogName by remember { mutableStateOf("workflow-logs.zip") }
    var pendingUploadLogBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingUploadLogName by remember { mutableStateOf("swrlz-forge-upload.log.txt") }
    var busy by remember { mutableStateOf(false) }
    var forgeProgress by remember { mutableIntStateOf(0) }
    var signingIn by remember { mutableStateOf(false) }
    var showManualToken by remember { mutableStateOf(false) }
    var showDisconnectApproval by remember { mutableStateOf(false) }
    var uploadLogSessionId by remember { mutableStateOf(ForgeUploadLogStore.currentSessionId(context)) }
    var status by remember { mutableStateOf("Connect GitHub, stage CLIENT and SERVER packages, then forge one atomic commit.") }

    fun ensureUploadLog(reason: String): String {
        val id = ForgeUploadLogStore.ensureSession(context, reason)
        uploadLogSessionId = id
        return id
    }
    val visibleRuns by remember(runs, workflowHistoryDepth) {
        derivedStateOf {
            val deduplicated = runs.distinctBy { "${it.name}|${it.headSha}|${it.event}" }
            deduplicated.filter { it.status != "completed" } +
                deduplicated.filter { it.status == "completed" }.take(workflowHistoryDepth)
        }
    }

    fun refreshRuns() {
        if (token.isBlank()) return
        busy = true
        status = "Refreshing workflow runs…"
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token) } }
                .onSuccess { refreshed ->
                    runs = refreshed
                    status = "Loaded ${refreshed.size} recent workflow run(s)."
                    withContext(Dispatchers.IO) { ForgeBuildMonitor.pollOnce(context) }
                }
                .onFailure { status = "Workflow refresh failed: ${it.message}" }
            busy = false
        }
    }

    LaunchedEffect(autoRefresh, token, owner, repository, branch) {
        while (autoRefresh && token.isNotBlank()) {
            delay(if (runs.any { it.status != "completed" }) 2_000 else 5_000)
            runCatching {
                withContext(Dispatchers.IO) {
                    GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token)
                }
            }.onSuccess { refreshed ->
                runs = refreshed
                val active = refreshed.filter { it.status != "completed" }.take(3)
                active.forEach { run ->
                    runCatching {
                        withContext(Dispatchers.IO) {
                            GitHubForgeClient.listWorkflowJobs(owner, repository, run.id, token)
                        }
                    }.onSuccess { jobs ->
                        jobsByRun = jobsByRun + (run.id to jobs)
                    }
                }
                withContext(Dispatchers.IO) { ForgeBuildMonitor.pollOnce(context) }
            }
        }
    }

    LaunchedEffect(token) {
        if (token.isNotBlank() && connectedLogin.isBlank() && GitHubConnectionStore.shouldAutoConnect(context)) {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) } }
                .onSuccess {
                    connectedLogin = it.login
                    GitHubConnectionStore.markValidated(context, it.login)
                    status = "Connected to GitHub as ${it.login}. Auto-connect is armed for restart, update, and Android-backed restore."
                }
                .onFailure {
                    status = "Saved GitHub credential could not be verified right now: ${it.message}. It was retained; reconnect only if GitHub rejects it."
                }
        } else if (token.isBlank() && restoredConnectionProfile.connectedLogin.isNotBlank() && restoredConnectionProfile.autoConnect) {
            status = "GitHub connection identity was restored for ${restoredConnectionProfile.connectedLogin}, but Android did not restore an authorization token. Reconnect once to re-arm automatic sign-in."
        }
    }

    LaunchedEffect(busy, forgeProgress, runs, artifacts, status) {
        val latest = runs.firstOrNull()
        val next = when {
            status.contains("failed", ignoreCase = true) || latest?.conclusion in setOf("failure", "cancelled", "timed_out", "action_required") -> ForgeRuntimeState.Phase.FAILED
            busy && status.contains("Validat", ignoreCase = true) -> ForgeRuntimeState.Phase.VALIDATING
            busy && status.contains("Downloading", ignoreCase = true) -> ForgeRuntimeState.Phase.DOWNLOADING
            busy && forgeProgress in 1..99 -> ForgeRuntimeState.Phase.UPLOADING
            runs.any { it.status != "completed" } -> ForgeRuntimeState.Phase.BUILDING
            status.startsWith("Artifact received") || artifacts.any { !it.expired } -> ForgeRuntimeState.Phase.ARTIFACTS_READY
            latest?.status == "completed" && latest.conclusion == "success" -> ForgeRuntimeState.Phase.COMPLETE
            else -> ForgeRuntimeState.Phase.IDLE
        }
        ForgeRuntimeState.publish(next)
    }

    LaunchedEffect(Unit) {
        // Retire the old directory-grant model. Companion lookup now starts from the
        // selected ZIP and falls back to a picker opened at that document location.
        forgePreferences.edit().remove("source_package_tree_uri").apply()
    }

    val checksumPicker = rememberLauncherForActivityResult(OpenSiblingDocumentContract()) { uri ->
        val zip = pendingChecksumZip
        pendingChecksumZip = null
        if (zip == null) return@rememberLauncherForActivityResult
        val logId = ensureUploadLog("checksum companion selection")

        if (uri == null) {
            ForgeUploadLogStore.append(context, logId, "CHECKSUM_PICKER", "Checksum selection cancelled", mapOf("zip" to zip.displayName))
            status = "Checksum selection cancelled. ${zip.displayName} remains staged, but commit is blocked until its exact SHA-256 sibling is added."
            return@rememberLauncherForActivityResult
        }

        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val checksum = GitHubForgeClient.describe(context, uri)
        val expectedName = zip.displayName.dropLast(4) + ".sha256"
        if (!checksum.displayName.equals(expectedName, ignoreCase = true)) {
            ForgeUploadLogStore.append(
                context,
                logId,
                "CHECKSUM_PICKER",
                "Wrong checksum companion selected",
                mapOf("zip" to zip.displayName, "expected" to expectedName, "selected" to checksum.displayName),
            )
            status = "Expected $expectedName beside ${zip.displayName}, but selected ${checksum.displayName}. The ZIP remains staged."
            return@rememberLauncherForActivityResult
        }
        val additions = listOf(zip, checksum)
        val additionsByName = additions.associateBy { it.displayName.lowercase() }
        files = (files.filterNot { additionsByName.containsKey(it.displayName.lowercase()) } + additions)
            .distinctBy { it.displayName.lowercase() }
        status = "Same-folder pair staged: ${zip.displayName} + ${checksum.displayName}."
        ForgeUploadLogStore.append(
            context,
            logId,
            "CHECKSUM_MATCH",
            "Exact same-location checksum companion staged",
            mapOf("zip" to zip.displayName, "checksum" to checksum.displayName, "checksum_size_bytes" to checksum.sizeBytes),
        )
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val logId = ensureUploadLog("source document selection")
        val selected = uris.distinct().map { uri ->
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            GitHubForgeClient.describe(context, uri)
        }
        scope.launch {
            if (selected.isEmpty()) {
                ForgeUploadLogStore.append(context, logId, "SOURCE_PICKER", "No source documents selected")
                status = "No new files selected."
                return@launch
            }

            selected.forEach { file ->
                ForgeUploadLogStore.append(
                    context,
                    logId,
                    "SOURCE_SELECTED",
                    "Source document selected",
                    mapOf("name" to file.displayName, "size_bytes" to file.sizeBytes, "provider" to file.uri.authority.orEmpty()),
                )
            }
            val explicitNames = selected.map { it.displayName.lowercase() }.toSet()
            val additions = withContext(Dispatchers.IO) {
                if (!autoMatchChecksum) {
                    selected
                } else {
                    selected.flatMap { file ->
                        if (!file.displayName.endsWith(".zip", ignoreCase = true)) {
                            listOf(file)
                        } else {
                            val expected = (file.displayName.dropLast(4) + ".sha256").lowercase()
                            if (expected in explicitNames) {
                                listOf(file)
                            } else {
                                val checksum = runCatching {
                                    GitHubForgeClient.findMatchingChecksumBesideDocument(context, file)
                                }.getOrNull()
                                if (checksum == null) listOf(file) else listOf(file, checksum)
                            }
                        }
                    }
                }
            }

            val additionsByName = additions.associateBy { it.displayName.lowercase() }
            files = (files.filterNot { additionsByName.containsKey(it.displayName.lowercase()) } + additions)
                .distinctBy { it.displayName.lowercase() }

            val unmatchedZips = selected.filter { zip ->
                zip.displayName.endsWith(".zip", true) &&
                    additions.none { it.displayName.equals(zip.displayName.dropLast(4) + ".sha256", true) } &&
                    selected.none { it.displayName.equals(zip.displayName.dropLast(4) + ".sha256", true) }
            }
            val autoMatchedCount = additions.count { it.displayName.endsWith(".sha256", true) } -
                selected.count { it.displayName.endsWith(".sha256", true) }

            ForgeUploadLogStore.append(
                context,
                logId,
                "STAGING_UPDATE",
                "Source staging updated",
                mapOf(
                    "selected_count" to selected.size,
                    "staged_count" to files.size,
                    "auto_matched_checksum_count" to autoMatchedCount,
                    "unmatched_zip_count" to unmatchedZips.size,
                ),
            )
            when {
                autoMatchChecksum && unmatchedZips.size == 1 -> {
                    val zip = unmatchedZips.single()
                    val expected = zip.displayName.dropLast(4) + ".sha256"
                    pendingChecksumZip = zip
                    status = "Android blocked direct sibling access. Select $expected from the same folder; no separate folder grant is required."
                    ForgeUploadLogStore.append(context, logId, "CHECKSUM_MATCH", "Direct sibling enumeration unavailable; opening exact companion picker", mapOf("zip" to zip.displayName, "expected" to expected))
                    checksumPicker.launch(SiblingDocumentRequest(zip.uri, expected))
                }
                autoMatchChecksum && unmatchedZips.size > 1 -> {
                    status = "${selected.size} file(s) staged. ${unmatchedZips.size} ZIPs still need their exact sibling SHA files; use ADD MORE FILES to select those checksums together."
                }
                autoMatchedCount > 0 -> {
                    status = "${selected.size} selection(s) added with $autoMatchedCount same-folder SHA-256 match(es); ${files.size} physical files staged."
                }
                else -> {
                    status = "${selected.size} file(s) added; ${files.size} total staged."
                }
            }
        }
    }

    val artifactSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val bytes = pendingArtifactBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingArtifactName successfully." }
                .onFailure { status = "Artifact save failed: ${it.message}" }
        }
        pendingArtifactBytes = null
    }

    val workflowLogSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val bytes = pendingWorkflowLogBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingWorkflowLogName successfully." }
                .onFailure { status = "Workflow log save failed: ${it.message}" }
        }
        pendingWorkflowLogBytes = null
    }

    val uploadLogSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val bytes = pendingUploadLogBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingUploadLogName successfully." }
                .onFailure { status = "Forge upload log save failed: ${it.message}" }
        }
        pendingUploadLogBytes = null
    }

    if (showDisconnectApproval) {
        AlertDialog(
            onDismissRequest = { showDisconnectApproval = false },
            title = { Text("Disconnect GitHub?") },
            text = {
                Text(
                    "This removes the active token, saved OAuth client ID, restored account identity, and automatic reconnect backup. Repository files and existing GitHub workflow history are not changed.",
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        GitHubConnectionStore.disconnect(context)
                        token = ""
                        oauthClientId = ""
                        connectedLogin = ""
                        deviceAuth = null
                        signingIn = false
                        showDisconnectApproval = false
                        status = "GitHub disconnected after approval. Automatic reconnect and restore were disabled."
                    },
                ) { Text("DISCONNECT") }
            },
            dismissButton = {
                TextButton(onClick = { showDisconnectApproval = false }) { Text("KEEP CONNECTED") }
            },
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("▸ GITHUB FORGE", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Text("Mass-upload CLIENT and SERVER source ZIPs to their authoritative repository locations, dispatch builds, observe workflow state, and download resulting APK/ZIP artifacts.", color = tokens.text.secondary, fontSize = 13.sp, lineHeight = 19.sp)

        ForgePanel("GITHUB ACCOUNT") {
            if (connectedLogin.isNotBlank()) {
                Text("Connected as $connectedLogin", color = tokens.text.primary, fontWeight = FontWeight.Bold)
                Text("Runtime token secured by Android Keystore. Connection identity is backup-aware; automatic restore requires Android encrypted backup or device transfer.", color = tokens.text.secondary, fontSize = 11.sp)
                TextButton(onClick = { showDisconnectApproval = true }) { Text("DISCONNECT GITHUB") }
            } else {
                ForgeField("GITHUB OAUTH APP CLIENT ID", oauthClientId, {
                    oauthClientId = it
                    GitHubConnectionStore.setOAuthClientId(context, it)
                })
                Button(
                    enabled = !signingIn && oauthClientId.isNotBlank(),
                    onClick = {
                        signingIn = true
                        GitHubConnectionStore.setOAuthClientId(context, oauthClientId)
                        status = "Requesting a GitHub device authorization code…"
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.beginDeviceAuthorization(oauthClientId) } }
                                .onSuccess { auth ->
                                    deviceAuth = auth
                                    status = "Enter ${auth.userCode} on GitHub and approve SWRLZ."
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(auth.verificationUri))) }
                                    val deadline = System.currentTimeMillis() + auth.expiresInSeconds * 1000L
                                    var interval = auth.pollingIntervalSeconds
                                    while (signingIn && System.currentTimeMillis() < deadline) {
                                        delay(interval * 1000L)
                                        when (val result = withContext(Dispatchers.IO) { GitHubForgeClient.pollDeviceAuthorization(oauthClientId, auth.deviceCode, interval) }) {
                                            is GitHubForgeClient.DeviceTokenPoll.Authorized -> {
                                                token = result.token
                                                connectedLogin = withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token).login }
                                                GitHubConnectionStore.saveAuthorizedConnection(
                                                    context = context,
                                                    token = token,
                                                    connectedLogin = connectedLogin,
                                                    oauthClientId = oauthClientId,
                                                    owner = owner,
                                                    repository = repository,
                                                    branch = branch,
                                                )
                                                status = "Connected to GitHub as $connectedLogin. Automatic reconnect backup is armed."; signingIn = false
                                            }
                                            is GitHubForgeClient.DeviceTokenPoll.Pending -> interval = result.retryAfterSeconds
                                            is GitHubForgeClient.DeviceTokenPoll.Failed -> { status = "GitHub sign-in failed: ${result.message}"; signingIn = false }
                                        }
                                    }
                                    if (signingIn) { status = "GitHub sign-in code expired."; signingIn = false }
                                }
                                .onFailure { status = "Unable to start sign-in: ${it.message}"; signingIn = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0),
                ) { Text(if (signingIn) "WAITING FOR GITHUB…" else "CONNECT GITHUB") }
                deviceAuth?.let { auth ->
                    Text("Device code: ${auth.userCode}", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { showManualToken = !showManualToken }) { Text(if (showManualToken) "HIDE TOKEN FALLBACK" else "USE FINE-GRAINED TOKEN") }
                if (showManualToken) {
                    ForgeField("FINE-GRAINED TOKEN", token, { token = it }, secret = true)
                    OutlinedButton(enabled = token.isNotBlank(), onClick = {
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) } }
                                .onSuccess {
                                    connectedLogin = it.login
                                    GitHubConnectionStore.saveAuthorizedConnection(
                                        context = context,
                                        token = token,
                                        connectedLogin = it.login,
                                        oauthClientId = oauthClientId,
                                        owner = owner,
                                        repository = repository,
                                        branch = branch,
                                    )
                                    status = "Connected as ${it.login}. Automatic reconnect backup is armed."
                                }
                                .onFailure { status = "Token validation failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("VALIDATE TOKEN") }
                }
            }
        }

        ForgePanel("REPOSITORY TARGET") {
            ForgeField("OWNER", owner, {
                owner = it
                GitHubConnectionStore.saveTarget(context, it, repository, branch)
            })
            ForgeField("REPOSITORY", repository, {
                repository = it
                GitHubConnectionStore.saveTarget(context, owner, it, branch)
            })
            ForgeField("BRANCH", branch, {
                branch = it
                GitHubConnectionStore.saveTarget(context, owner, repository, it)
            })
            ForgeField("FALLBACK DESTINATION", destination, { destination = it })
            ForgeField("COMMIT MESSAGE", message, { message = it }, singleLine = false)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("AUTO-ROUTE SOURCE PACKAGES", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("CLIENT_* → SOURCES/CLIENT   |   SERVER_* → SOURCES/SERVER", color = tokens.text.secondary, fontSize = 11.sp)
                }
                Switch(checked = autoRoute, onCheckedChange = { autoRoute = it })
            }
        }

        ForgePanel("SOURCE PACKAGE MATCHING") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("AUTO-MATCH ZIP + SHA-256", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        "Select a source ZIP. Forge resolves the exact .sha256 beside that ZIP; when Android blocks direct sibling access, it opens the same location for one-tap checksum selection.",
                        color = tokens.text.secondary,
                        fontSize = 11.sp,
                    )
                }
                Switch(
                    checked = autoMatchChecksum,
                    onCheckedChange = {
                        autoMatchChecksum = it
                        forgePreferences.edit().putBoolean("auto_match_source_checksum", it).apply()
                    },
                )
            }
            HorizontalDivider(color = tokens.borders.neutral.copy(alpha = 0.55f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("SOURCE ZIP CONTENT GUARD", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(
                        "Inspect ZIP structure locally before upload. Blocks obvious APK/artifact bundles and archives without recognizable source files.",
                        color = tokens.text.secondary,
                        fontSize = 11.sp,
                    )
                }
                Switch(
                    checked = sourceZipGuard,
                    onCheckedChange = {
                        sourceZipGuard = it
                        forgePreferences.edit().putBoolean("source_zip_content_guard", it).apply()
                    },
                )
            }
            Text(
                if (sourceZipGuard) "Guard: ARMED · validation occurs before network upload" else "Guard: BYPASSED · checksum validation still applies",
                color = if (sourceZipGuard) tokens.status.success else tokens.status.warning,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
            )

            Text(
                "Directory grant: NOT REQUIRED · selected ZIP location drives checksum matching",
                color = tokens.accents.primary,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
            )
        }

        OutlinedButton(
            enabled = connectedLogin.isNotBlank(),
            onClick = {
                val logId = ensureUploadLog(if (files.isEmpty()) "source picker opened" else "additional source picker opened")
                ForgeUploadLogStore.append(context, logId, "SOURCE_PICKER", "Opening Android source document picker", mapOf("existing_staged_count" to files.size))
                picker.launch(arrayOf("*/*"))
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(0),
            border = BorderStroke(1.dp, tokens.accents.primary),
        ) {
            Text(if (files.isEmpty()) "SELECT SOURCE ZIP OR FILES" else "ADD MORE FILES TO STAGING")
        }

        if (files.isNotEmpty()) ForgePanel("STAGED MASS UPLOAD") {
            files.forEach { file ->
                val path = GitHubForgeClient.destinationPath(file.displayName, destination, autoRoute)
                Text("• ${file.displayName}${formatSize(file.sizeBytes)}", color = tokens.text.primary, fontSize = 12.sp)
                Text("  ↳ $path", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
            TextButton(onClick = {
                val logId = ensureUploadLog("staging cleared")
                ForgeUploadLogStore.append(context, logId, "STAGING_CLEAR", "User cleared staged source files", mapOf("cleared_file_count" to files.size))
                files = emptyList()
                status = "Staging cleared."
            }) { Text("CLEAR STAGING") }
        }

        ForgePanel("BUILD DISPATCH") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("DISPATCH AFTER COMMIT", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Start a workflow_dispatch build immediately after upload.", color = tokens.text.secondary, fontSize = 11.sp)
                }
                Switch(checked = dispatch, onCheckedChange = { dispatch = it })
            }
            if (dispatch) ForgeField("WORKFLOW FILE OR ID", workflowId, { workflowId = it })
        }

        Button(
            enabled = !busy && files.isNotEmpty() && token.isNotBlank() && connectedLogin.isNotBlank(),
            onClick = {
                val stagedFiles = files.toList()
                val logId = if (uploadLogSessionId.isBlank()) {
                    ForgeUploadLogStore.startSession(context, "upload submitted from existing staging")
                } else {
                    uploadLogSessionId
                }
                uploadLogSessionId = logId
                val uploadRequest = GitHubForgeClient.UploadRequest(
                    owner = owner,
                    repository = repository,
                    branch = branch,
                    destinationDirectory = destination,
                    commitMessage = message,
                    token = token,
                    files = stagedFiles,
                    workflowId = workflowId,
                    dispatchWorkflow = dispatch,
                    autoRouteSourcePackages = autoRoute,
                    logSessionId = logId,
                    onProgress = { percent, detail ->
                        forgeProgress = percent
                        status = detail
                    },
                )
                val transactionId = uploadRequest.transactionId
                busy = true
                forgeProgress = 1
                status = "Starting Forge transaction ${transactionId.take(8)} for ${stagedFiles.size} staged files…"
                ForgeRuntimeState.beginTransaction(transactionId)
                ForgeUploadLogStore.append(
                    context,
                    logId,
                    "TRANSACTION_START",
                    "Forge upload transaction submitted",
                    mapOf(
                        "transaction_id" to transactionId,
                        "owner" to owner.trim(),
                        "repository" to repository.trim(),
                        "branch" to branch.trim(),
                        "staged_file_count" to stagedFiles.size,
                        "source_zip_guard" to sourceZipGuard,
                        "auto_route" to autoRoute,
                        "dispatch_requested" to dispatch,
                    ),
                )
                scope.launch {
                    try {
                        if (sourceZipGuard) {
                            status = "Validating staged ZIP content · TX ${transactionId.take(8)}…"
                            ForgeRuntimeState.publish(ForgeRuntimeState.Phase.VALIDATING)
                            val zipInspection = withContext(Dispatchers.IO) {
                                stagedFiles.filter { it.displayName.endsWith(".zip", true) }
                                    .map { GitHubForgeClient.inspectSourceZip(context, it) }
                                    .firstOrNull { !it.valid }
                                    ?: GitHubForgeClient.StageValidation(true, "Source ZIP Guard accepted all staged archives.")
                            }
                            ForgeUploadLogStore.append(context, logId, "ZIP_GUARD", zipInspection.message, mapOf("valid" to zipInspection.valid))
                            if (!zipInspection.valid) {
                                status = zipInspection.message
                                forgeProgress = 0
                                ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                                ForgeEventNotifier.uploadFailed(context, transactionId, status)
                                ForgeUploadLogStore.finish(context, logId, "FAILED · source ZIP content guard")
                                uploadLogSessionId = ""
                                return@launch
                            }
                            status = zipInspection.message
                        }

                        val validation = withContext(Dispatchers.IO) {
                            GitHubForgeClient.validateSourcePairs(context, stagedFiles)
                        }
                        ForgeUploadLogStore.append(context, logId, "PAIR_VALIDATION", validation.message, mapOf("valid" to validation.valid))
                        if (!validation.valid) {
                            status = validation.message
                            forgeProgress = 0
                            ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                            ForgeEventNotifier.uploadFailed(context, transactionId, status)
                            ForgeUploadLogStore.finish(context, logId, "FAILED · ZIP/SHA pair validation")
                            uploadLogSessionId = ""
                            return@launch
                        }
                        status = validation.message

                        val result = runCatching {
                            withContext(Dispatchers.IO) {
                                GitHubForgeClient.upload(context, uploadRequest)
                            }
                        }.getOrElse { failure ->
                            ForgeUploadLogStore.appendFailure(context, logId, "UPLOAD_FAILURE", failure)
                            status = "Upload failed before repository verification: ${failure.message ?: failure::class.simpleName}"
                            forgeProgress = 0
                            ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                            ForgeEventNotifier.uploadFailed(context, transactionId, status)
                            ForgeUploadLogStore.finish(context, logId, "FAILED · repository upload or confirmation")
                            uploadLogSessionId = ""
                            return@launch
                        }

                        files = emptyList()
                        forgeProgress = 100
                        val dispatchSummary = when {
                            result.dispatchWarning != null -> " Repository upload succeeded; build dispatch failed."
                            result.workflowDispatched -> " Build dispatched."
                            else -> " Build watch armed."
                        }
                        status = "Upload verified on ${branch.trim()} at ${result.commitSha.take(12)} · TX ${result.transactionId.take(8)}; staging cleared.$dispatchSummary"
                        ForgeBuildWatchStore.add(
                            context,
                            ForgeBuildWatch(
                                owner = owner.trim(),
                                repository = repository.trim(),
                                branch = branch.trim(),
                                commitSha = result.commitSha,
                                transactionId = result.transactionId,
                                createdAtMillis = System.currentTimeMillis(),
                            ),
                        )
                        ForgeEventNotifier.uploadSucceeded(
                            context = context,
                            commitSha = result.commitSha,
                            uploadedPaths = result.uploadedPaths,
                            transactionId = result.transactionId,
                        )
                        result.dispatchWarning?.let { warning ->
                            ForgeEventNotifier.workflowDispatchFailed(
                                context = context,
                                transactionId = result.transactionId,
                                commitSha = result.commitSha,
                                detail = warning,
                            )
                        }
                        var observedCommitRun = false
                        ForgeUploadLogStore.append(context, logId, "WORKFLOW_DISCOVERY", "Polling for workflow run associated with uploaded commit", mapOf("commit_sha" to result.commitSha))
                        for (attempt in 0 until 8) {
                            if (attempt > 0) delay(1_000)
                            val refreshed = withContext(Dispatchers.IO) {
                                GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token)
                            }
                            runs = refreshed
                            observedCommitRun = refreshed.any { it.headSha.equals(result.commitSha, ignoreCase = true) }
                            ForgeUploadLogStore.append(
                                context,
                                logId,
                                "WORKFLOW_DISCOVERY",
                                if (observedCommitRun) "Matching workflow run detected" else "Matching workflow run not visible yet",
                                mapOf("attempt" to attempt + 1, "returned_run_count" to refreshed.size, "commit_sha" to result.commitSha),
                            )
                            if (observedCommitRun) break
                        }
                        status = if (observedCommitRun) {
                            "$status Workflow run detected for ${result.commitSha.take(12)}."
                        } else {
                            "$status GitHub has not exposed the new run yet; auto-refresh remains armed."
                        }
                        withContext(Dispatchers.IO) { ForgeBuildMonitor.pollOnce(context) }
                        ForgeUploadLogStore.finish(context, logId, "SUCCESS · commit ${result.commitSha}")
                        uploadLogSessionId = ""
                    } catch (failure: Throwable) {
                        ForgeUploadLogStore.appendFailure(context, logId, "UNHANDLED_UPLOAD_FAILURE", failure)
                        ForgeUploadLogStore.finish(context, logId, "FAILED · unhandled upload exception")
                        uploadLogSessionId = ""
                        forgeProgress = 0
                        ForgeRuntimeState.publish(ForgeRuntimeState.Phase.FAILED)
                        status = "Forge transaction failed unexpectedly: ${failure.message ?: failure::class.simpleName}. Download the upload log for diagnostics."
                        ForgeEventNotifier.uploadFailed(context, transactionId, status)
                    } finally {
                        busy = false
                        ForgeRuntimeState.endTransaction(transactionId)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0),
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accents.primary, contentColor = tokens.surfaces.bgApp),
        ) { Text(if (busy) "FORGING… $forgeProgress%" else "COMMIT MASS UPLOAD", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) }

        if (busy || forgeProgress > 0) {
            LinearProgressIndicator(progress = { forgeProgress / 100f }, modifier = Modifier.fillMaxWidth())
            Text("$forgeProgress% · $status", color = tokens.text.secondary, fontSize = 11.sp)
        }

        ForgePanel("UPLOAD DIAGNOSTICS") {
            Text(
                "The latest redacted Forge session log is exportable during staging, transfer, failure, retry, or completion. GitHub tokens, authorization headers, OAuth device codes, and token-like values are removed.",
                color = tokens.text.secondary,
                fontSize = 11.sp,
                lineHeight = 16.sp,
            )
            OutlinedButton(
                enabled = uploadLogSessionId.isNotBlank() || ForgeUploadLogStore.hasLog(context),
                onClick = {
                    val bytes = ForgeUploadLogStore.latestBytes(context)
                    if (bytes == null) {
                        status = "No Forge upload diagnostic log exists yet. Select source files to start one."
                    } else {
                        pendingUploadLogBytes = bytes
                        pendingUploadLogName = ForgeUploadLogStore.latestSuggestedName(context)
                        status = "Forge upload log snapshot ready. Choose where to save it."
                        uploadLogSaver.launch(pendingUploadLogName)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (busy) "DOWNLOAD LIVE UPLOAD LOG" else "DOWNLOAD LATEST UPLOAD LOG") }
        }

        ForgePanel("WORKFLOW OBSERVER") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("AUTO REFRESH · 2s ACTIVE / 5s IDLE", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("Workflow state updates automatically while Forge is open.", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
            }
            OutlinedButton(enabled = connectedLogin.isNotBlank() && !busy, onClick = { refreshRuns() }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH NOW") }
            Text("PAST WORKFLOWS · $workflowHistoryDepth", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Slider(
                value = workflowHistoryDepth.toFloat(),
                onValueChange = { workflowHistoryDepth = it.toInt().coerceIn(2, 20) },
                onValueChangeFinished = {
                    forgePreferences.edit().putInt("workflow_history_depth", workflowHistoryDepth).apply()
                },
                valueRange = 2f..20f,
                steps = 17,
            )
            Text("All active runs stay visible. Completed history is limited to keep Forge clean.", color = tokens.text.secondary, fontSize = 10.sp)
            visibleRuns.forEach { run ->
                val stateTone = when {
                    run.status != "completed" -> tokens.status.warning
                    run.conclusion == "success" -> tokens.status.success
                    run.conclusion in setOf("failure", "cancelled", "timed_out", "action_required") -> tokens.status.danger
                    else -> tokens.status.info
                }
                Column(
                    Modifier.fillMaxWidth().border(1.dp, stateTone).background(stateTone.copy(alpha = 0.08f)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                Text(run.name, color = stateTone, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                val runAge = relativeTime(run.runStartedAt ?: run.createdAt)
                val runDuration = elapsedBetween(run.runStartedAt ?: run.createdAt, if (run.status == "completed") run.updatedAt else null)
                Text("${run.status}${run.conclusion?.let { " / $it" } ?: ""} · ${run.branch} · ${run.event}", color = tokens.text.secondary, fontSize = 11.sp)
                Text("Started $runAge · $runDuration", color = tokens.text.secondary, fontSize = 11.sp)
                if (run.status == "completed") {
                    LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("Build is cooking — GitHub reports phases, not an exact compile percentage.", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Text(run.displayTitle, color = tokens.text.secondary, fontSize = 11.sp)
                val jobs = jobsByRun[run.id].orEmpty()
                jobs.forEach { job ->
                    Text("${job.name}: ${job.status}${job.conclusion?.let { " / $it" } ?: ""}", color = tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    job.steps.forEach { step ->
                        val marker = when {
                            step.status == "in_progress" -> "▶"
                            step.conclusion == "success" -> "✓"
                            step.conclusion != null -> "✕"
                            else -> "○"
                        }
                        Text("$marker ${step.name}", color = tokens.text.secondary, fontSize = 10.sp)
                    }
                }
                if (run.status != "completed" && jobs.isEmpty()) {
                    Text("Waiting for GitHub job and step details…", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        selectedRunId = run.id; busy = true; status = "Loading artifacts for ${run.name}…"
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listArtifacts(owner, repository, run.id, token) } }
                                .onSuccess { found ->
                                    artifacts = found
                                    status = "Loaded ${found.size} artifact(s) for run ${run.id}."
                                    val single = found.singleOrNull { !it.expired }
                                    if (single != null) {
                                        status = "Downloading ${single.name} from GitHub Actions…"
                                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadArtifact(owner, repository, single.id, token) } }
                                            .onSuccess { bytes ->
                                                pendingArtifactBytes = bytes
                                                pendingArtifactName = if (single.name.endsWith(".zip", true)) single.name else "${single.name}.zip"
                                                status = "Artifact received. Choose where to save it."
                                                artifactSaver.launch(pendingArtifactName)
                                            }
                                            .onFailure { status = "Artifact download failed: ${it.message}" }
                                    }
                                }
                                .onFailure { status = "Artifact lookup failed: ${it.message}" }
                            busy = false
                        }
                    }) { Text("ARTIFACTS") }
                    TextButton(
                        enabled = !busy,
                        onClick = {
                            busy = true
                            status = "Downloading logs for ${run.name}…"
                            scope.launch {
                                runCatching {
                                    withContext(Dispatchers.IO) {
                                        GitHubForgeClient.downloadWorkflowLogs(owner, repository, run.id, token)
                                    }
                                }.onSuccess { bytes ->
                                    pendingWorkflowLogBytes = bytes
                                    pendingWorkflowLogName = "workflow_${run.id}_${run.name.replace(Regex("[^A-Za-z0-9._-]+"), "_")}_logs.zip"
                                    status = "Workflow logs received. Choose where to save them."
                                    workflowLogSaver.launch(pendingWorkflowLogName)
                                }.onFailure {
                                    status = "Workflow log download failed: ${it.message}"
                                }
                                busy = false
                            }
                        },
                    ) { Text("LOGS") }
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(run.htmlUrl))) }) { Text("OPEN") }
                }
                }
            }
        }

        if (selectedRunId != null) ForgePanel("RUN ARTIFACTS") {
            if (artifacts.isEmpty()) Text("No downloadable artifacts found for the selected run.", color = tokens.text.secondary, fontSize = 11.sp)
            artifacts.forEach { artifact ->
                Text("${artifact.name}${formatSize(artifact.sizeBytes)} · ${relativeTime(artifact.createdAt)}${if (artifact.expired) " · EXPIRED" else ""}", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                OutlinedButton(enabled = !artifact.expired && !busy, onClick = {
                    busy = true; status = "Downloading ${artifact.name} from GitHub Actions…"
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadArtifact(owner, repository, artifact.id, token) } }
                            .onSuccess { bytes ->
                                pendingArtifactBytes = bytes
                                pendingArtifactName = if (artifact.name.endsWith(".zip", true)) artifact.name else "${artifact.name}.zip"
                                status = "Artifact received. Choose where to save it."
                                artifactSaver.launch(pendingArtifactName)
                            }
                            .onFailure { status = "Artifact download failed: ${it.message}" }
                        busy = false
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("DOWNLOAD ${artifact.name.uppercase()}") }
            }
        }

        ForgePanel("FORGE STATUS") { Text(status, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp) }
        Text("Fine-grained token setup for this personal build: select only Swrlzcore; grant Contents read/write and Actions read/write. Pull requests read/write is optional for a later PR-first mode.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun ForgePanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
        content()
    }
}

@Composable
private fun ForgeField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean = true, secret: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }, modifier = Modifier.fillMaxWidth(), singleLine = singleLine, visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None)
}

private fun formatSize(bytes: Long): String = when {
    bytes < 0 -> ""
    bytes < 1024 -> " · $bytes B"
    bytes < 1024 * 1024 -> " · ${bytes / 1024} KiB"
    else -> " · ${"%.1f".format(bytes / 1024.0 / 1024.0)} MiB"
}


private fun relativeTime(iso: String): String = runCatching {
    val seconds = Duration.between(Instant.parse(iso), Instant.now()).seconds.coerceAtLeast(0)
    when {
        seconds < 60 -> "${seconds}s ago"
        seconds < 3600 -> "${seconds / 60}m ago"
        seconds < 86400 -> "${seconds / 3600}h ago"
        else -> "${seconds / 86400}d ago"
    }
}.getOrDefault("time unavailable")

private fun elapsedBetween(startIso: String, endIso: String?): String = runCatching {
    val start = Instant.parse(startIso)
    val end = endIso?.takeIf { it.isNotBlank() }?.let(Instant::parse) ?: Instant.now()
    val seconds = Duration.between(start, end).seconds.coerceAtLeast(0)
    when {
        seconds < 60 -> "${seconds}s elapsed"
        seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s elapsed"
        else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m elapsed"
    }
}.getOrDefault("duration unavailable")
