package sh.swurlz.core.service

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.github.ForgeBuildMonitor
import sh.swurlz.core.github.ForgeBuildWatchStore
import sh.swurlz.core.notification.ClientStatusNotification

class ClientStatusService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var observerJob: Job? = null
    private var forgeMonitorJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        if (!ClientStatusNotification.canPost(this)) {
            stopSelf()
            return
        }

        startForeground(
            ClientStatusNotification.NOTIFICATION_ID,
            ClientStatusNotification.build(
                context = this,
                mission = MissionBus.mission.value,
                ambient = MissionBus.ambient.value,
                truth = CoreNodeTruthState(),
                style = UiStyleSettings(),
            ),
        )

        forgeMonitorJob = serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                runCatching { ForgeBuildMonitor.pollOnce(this@ClientStatusService) }
                delay(if (ForgeBuildWatchStore.hasPending(this@ClientStatusService)) 15_000L else 60_000L)
            }
        }

        observerJob = serviceScope.launch {
            combine(
                Prefs.statusNotificationEnabledFlow(this@ClientStatusService),
                MissionBus.mission,
                MissionBus.ambient,
                Prefs.coreNodeTruthStateFlow(this@ClientStatusService),
                Prefs.uiStyleFlow(this@ClientStatusService),
            ) { enabled, mission, ambient, truth, style ->
                StatusSnapshot(enabled, mission, ambient, truth, style)
            }.collect { snapshot ->
                if (!snapshot.enabled) {
                    ClientStatusNotification.cancel(this@ClientStatusService)
                    stopSelf()
                } else {
                    ClientStatusNotification.update(
                        context = this@ClientStatusService,
                        enabled = true,
                        mission = snapshot.mission,
                        ambient = snapshot.ambient,
                        truth = snapshot.truth,
                        style = snapshot.style,
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        observerJob?.cancel()
        forgeMonitorJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private data class StatusSnapshot(
        val enabled: Boolean,
        val mission: MissionBus.MissionLive,
        val ambient: MissionBus.Ambient,
        val truth: CoreNodeTruthState,
        val style: UiStyleSettings,
    )
}
