package sh.swurlz.core.github

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.*
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.statement.HttpResponse
import io.ktor.http.*
import io.ktor.http.content.OutgoingContent
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.writeFully
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.delay
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/** GitHub repository forge: atomic mass upload, workflow observation, and artifact download. */
object GitHubForgeClient {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val client = HttpClient(OkHttp) {
        engine {
            config {
                connectTimeout(30, TimeUnit.SECONDS)
                readTimeout(5, TimeUnit.MINUTES)
                writeTimeout(5, TimeUnit.MINUTES)
                callTimeout(10, TimeUnit.MINUTES)
            }
        }
        install(ContentNegotiation) { json(json) }
        followRedirects = true
    }

    data class LocalFile(val uri: Uri, val displayName: String, val sizeBytes: Long)

    data class UploadRequest(
        val owner: String,
        val repository: String,
        val branch: String,
        val destinationDirectory: String,
        val commitMessage: String,
        val token: String,
        val files: List<LocalFile>,
        val workflowId: String = "",
        val dispatchWorkflow: Boolean = false,
        val autoRouteSourcePackages: Boolean = true,
        val transactionId: String = UUID.randomUUID().toString(),
        val logSessionId: String = "",
        val onProgress: suspend (Int, String) -> Unit = { _, _ -> },
    )

    data class UploadResult(
        val commitSha: String,
        val uploadedPaths: List<String>,
        val transactionId: String,
        val workflowDispatched: Boolean,
        val dispatchWarning: String? = null,
    )
    data class DeviceAuthorization(val deviceCode: String, val userCode: String, val verificationUri: String, val expiresInSeconds: Int, val pollingIntervalSeconds: Int)
    data class ConnectedAccount(val login: String, val avatarUrl: String = "")
    data class WorkflowRun(
        val id: Long,
        val name: String,
        val displayTitle: String,
        val status: String,
        val conclusion: String?,
        val branch: String,
        val headSha: String,
        val event: String,
        val createdAt: String,
        val updatedAt: String,
        val runStartedAt: String?,
        val htmlUrl: String,
    )
    data class WorkflowStep(val name: String, val status: String, val conclusion: String?, val number: Int)
    data class WorkflowJob(val id: Long, val name: String, val status: String, val conclusion: String?, val startedAt: String?, val completedAt: String?, val steps: List<WorkflowStep>)
    data class StageValidation(val valid: Boolean, val message: String)
    data class Artifact(val id: Long, val name: String, val sizeBytes: Long, val expired: Boolean, val createdAt: String)

    sealed interface DeviceTokenPoll {
        data class Authorized(val token: String) : DeviceTokenPoll
        data class Pending(val retryAfterSeconds: Int) : DeviceTokenPoll
        data class Failed(val message: String) : DeviceTokenPoll
    }

    suspend fun beginDeviceAuthorization(clientId: String): DeviceAuthorization {
        require(clientId.isNotBlank()) { "GitHub OAuth Client ID is required." }
        val response = client.post("https://github.com/login/device/code") {
            header(HttpHeaders.Accept, "application/json")
            setBody(FormDataContent(Parameters.build {
                append("client_id", clientId.trim())
                append("scope", "repo workflow read:user")
            }))
        }
        ensureSuccess(response)
        val body = response.body<DeviceCodeResponse>()
        return DeviceAuthorization(body.deviceCode, body.userCode, body.verificationUri, body.expiresIn, body.interval.coerceAtLeast(5))
    }

    suspend fun pollDeviceAuthorization(clientId: String, deviceCode: String, intervalSeconds: Int): DeviceTokenPoll {
        val response = client.post("https://github.com/login/oauth/access_token") {
            header(HttpHeaders.Accept, "application/json")
            setBody(FormDataContent(Parameters.build {
                append("client_id", clientId.trim())
                append("device_code", deviceCode)
                append("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
            }))
        }
        ensureSuccess(response)
        val body = response.body<DeviceTokenResponse>()
        return when {
            !body.accessToken.isNullOrBlank() -> DeviceTokenPoll.Authorized(body.accessToken)
            body.error == "authorization_pending" -> DeviceTokenPoll.Pending(intervalSeconds)
            body.error == "slow_down" -> DeviceTokenPoll.Pending(intervalSeconds + 5)
            else -> DeviceTokenPoll.Failed(body.errorDescription ?: body.error ?: "GitHub authorization failed.")
        }
    }

    suspend fun connectedAccount(token: String): ConnectedAccount {
        require(token.isNotBlank()) { "GitHub token is required." }
        val profile = getJson<UserProfileResponse>("https://api.github.com/user", auth(token))
        return ConnectedAccount(profile.login, profile.avatarUrl.orEmpty())
    }

    suspend fun upload(context: Context, request: UploadRequest): UploadResult {
        require(request.files.isNotEmpty()) { "Select at least one file." }
        require(request.owner.isNotBlank() && request.repository.isNotBlank()) { "Repository owner and name are required." }
        require(request.branch.isNotBlank()) { "Branch is required." }
        require(request.token.isNotBlank()) { "GitHub token is required." }

        val transactionId = request.transactionId.ifBlank { UUID.randomUUID().toString() }
        val logSessionId = request.logSessionId
        fun log(phase: String, message: String, fields: Map<String, Any?> = emptyMap()) {
            ForgeUploadLogStore.append(context, logSessionId, phase, message, fields)
        }
        val uploadFiles = LinkedHashMap<String, LocalFile>().apply {
            request.files.forEach { file ->
                this[destinationPath(file.displayName, request.destinationDirectory, request.autoRouteSourcePackages).lowercase()] = file
            }
        }.values.toList()
        require(uploadFiles.isNotEmpty()) { "Select at least one unique destination file." }
        log(
            "UPLOAD_REQUEST",
            "Prepared unique repository destinations",
            mapOf(
                "transaction_id" to transactionId,
                "owner" to request.owner.trim(),
                "repository" to request.repository.trim(),
                "branch" to request.branch.trim(),
                "file_count" to uploadFiles.size,
                "dispatch_requested" to request.dispatchWorkflow,
                "workflow_id" to request.workflowId.trim(),
            ),
        )
        uploadFiles.forEach { file ->
            log(
                "STAGED_FILE",
                "Upload snapshot",
                mapOf(
                    "name" to file.displayName,
                    "size_bytes" to file.sizeBytes,
                    "destination" to destinationPath(file.displayName, request.destinationDirectory, request.autoRouteSourcePackages),
                    "provider" to file.uri.authority.orEmpty(),
                ),
            )
        }

        request.onProgress(2, "Checking repository and token access · TX ${transactionId.take(8)}…")
        log("ACCESS_CHECK", "Checking repository branch and credential access")
        val repoBase = repoBase(request.owner, request.repository)
        val authorization = auth(request.token)
        // Access check only. The branch head is deliberately fetched again after blob upload,
        // because large mobile transfers can outlive the branch head they started from.
        getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", authorization)
        log("ACCESS_CHECK", "Repository access confirmed")
        request.onProgress(5, "Repository access confirmed. Preparing transaction ${transactionId.take(8)}…")

        val entries = mutableListOf<TreeEntry>()
        val expectedBlobByPath = linkedMapOf<String, String>()
        val uploadedPaths = mutableListOf<String>()

        uploadFiles.forEachIndexed { index, file ->
            val fileStart = 8 + (index * 62 / uploadFiles.size.coerceAtLeast(1))
            require(file.sizeBytes <= 100L * 1024L * 1024L || file.sizeBytes < 0L) {
                "${file.displayName} exceeds GitHub's 100 MiB single-blob limit."
            }
            request.onProgress(fileStart, "Streaming ${file.displayName} to GitHub · TX ${transactionId.take(8)}…")
            log(
                "BLOB_UPLOAD",
                "Starting streamed blob upload",
                mapOf("name" to file.displayName, "size_bytes" to file.sizeBytes, "index" to index + 1, "total" to uploadFiles.size),
            )
            val uploadSpan = (62 / uploadFiles.size.coerceAtLeast(1)).coerceAtLeast(12)
            var lastLoggedTransferPercent = -10
            val blob = postBlobStream(
                url = "$repoBase/git/blobs",
                authorization = authorization,
                context = context,
                file = file,
            ) { sent, total ->
                val ratio = if (total > 0L) sent.toDouble() / total.toDouble() else 0.0
                val local = (ratio * (uploadSpan - 3)).toInt().coerceIn(0, uploadSpan - 3)
                val percent = (fileStart + local).coerceAtMost(76)
                val sentMiB = sent / 1024.0 / 1024.0
                val totalMiB = if (total > 0L) total / 1024.0 / 1024.0 else 0.0
                val detail = if (total > 0L) {
                    "Streaming ${file.displayName}: %.1f / %.1f MiB · TX %s".format(sentMiB, totalMiB, transactionId.take(8))
                } else {
                    "Streaming ${file.displayName}: %.1f MiB · TX %s".format(sentMiB, transactionId.take(8))
                }
                request.onProgress(percent, detail)
                val transferPercent = if (total > 0L) ((sent * 100L) / total).toInt().coerceIn(0, 100) else -1
                if (transferPercent == 100 || transferPercent >= lastLoggedTransferPercent + 10) {
                    lastLoggedTransferPercent = transferPercent
                    log(
                        "TRANSFER_PROGRESS",
                        "Streamed source bytes",
                        mapOf(
                            "name" to file.displayName,
                            "bytes_sent" to sent,
                            "total_bytes" to total,
                            "percent" to transferPercent,
                        ),
                    )
                }
            }
            val path = destinationPath(file.displayName, request.destinationDirectory, request.autoRouteSourcePackages)
            entries += TreeEntry(path, "100644", "blob", blob.sha)
            expectedBlobByPath[path] = blob.sha
            uploadedPaths += path
            log(
                "BLOB_UPLOAD",
                "GitHub blob created",
                mapOf("name" to file.displayName, "destination" to path, "blob_sha" to blob.sha),
            )
        }

        var committedSha: String? = null
        var lastFailure: Throwable? = null
        for (attempt in 1..3) {
            request.onProgress(78, "Resolving latest branch head · attempt $attempt/3…")
            log("BRANCH_HEAD", "Resolving latest branch head", mapOf("attempt" to attempt))
            val latestRef = getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", authorization)
            val parentSha = latestRef.`object`.sha
            val parentCommit = getJson<CommitResponse>("$repoBase/git/commits/$parentSha", authorization)
            log("BRANCH_HEAD", "Latest branch head resolved", mapOf("parent_commit" to parentSha, "base_tree" to parentCommit.tree.sha))

            request.onProgress(82, "Creating repository tree from latest head…")
            val tree = postJson<TreeRequest, TreeResponse>(
                "$repoBase/git/trees",
                authorization,
                TreeRequest(parentCommit.tree.sha, entries),
            )
            check(tree.sha != parentCommit.tree.sha) {
                "No repository content changed. The selected files already match the current branch; choose the newly generated ZIP/SHA pair before retrying."
            }
            log("TREE_CREATE", "Candidate repository tree created", mapOf("tree_sha" to tree.sha, "entry_count" to entries.size))

            request.onProgress(87, "Creating atomic commit · TX ${transactionId.take(8)}…")
            val baseMessage = request.commitMessage.ifBlank {
                "Upload CLIENT and SERVER source packages through SWRLZ Forge"
            }.trim()
            val commit = postJson<NewCommitRequest, NewCommitResponse>(
                "$repoBase/git/commits",
                authorization,
                NewCommitRequest(
                    "$baseMessage\n\nSWRLZ-Forge-Transaction: $transactionId",
                    tree.sha,
                    listOf(parentSha),
                ),
            )
            log("COMMIT_CREATE", "Atomic commit object created", mapOf("commit_sha" to commit.sha, "parent_commit" to parentSha))

            try {
                request.onProgress(92, "Updating ${request.branch.trim()} · attempt $attempt/3…")
                log("BRANCH_UPDATE", "Updating target branch reference", mapOf("commit_sha" to commit.sha, "attempt" to attempt))
                patchJson(
                    "$repoBase/git/refs/heads/${request.branch.trim()}",
                    authorization,
                    UpdateRefRequest(commit.sha, false),
                )
            } catch (failure: GitHubRequestException) {
                lastFailure = failure
                if (failure.statusCode in setOf(409, 422) && attempt < 3) {
                    log("BRANCH_RACE", "Branch moved; retrying from a fresh head", mapOf("status" to failure.statusCode, "attempt" to attempt))
                    request.onProgress(92, "Branch moved during upload; rebasing transaction on the newest head…")
                    delay(850L * attempt)
                    continue
                }
                throw failure
            }

            request.onProgress(95, "Confirming branch and uploaded paths…")
            var confirmed = false
            for (confirmationAttempt in 0 until 6) {
                val updatedRef = getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", authorization)
                if (updatedRef.`object`.sha == commit.sha) {
                    confirmed = true
                    break
                }
                if (confirmationAttempt < 5) delay(750L)
            }
            check(confirmed) {
                "GitHub accepted the upload request, but ${request.branch.trim()} did not resolve to commit ${commit.sha.take(12)}. Forge will not report completion."
            }
            log("BRANCH_CONFIRM", "Target branch resolves to new commit", mapOf("commit_sha" to commit.sha))

            log("PATH_VERIFY", "Reading uploaded paths back from GitHub", mapOf("path_count" to expectedBlobByPath.size))
            verifyUploadedPaths(
                repoBase = repoBase,
                authorization = authorization,
                branch = request.branch.trim(),
                expectedBlobByPath = expectedBlobByPath,
            )
            log("PATH_VERIFY", "Every uploaded path resolved to its expected blob SHA")
            committedSha = commit.sha
            break
        }

        val finalCommitSha = committedSha ?: throw (
            lastFailure ?: IllegalStateException(
                "Forge could not commit transaction ${transactionId.take(8)}.",
            )
        )

        var workflowDispatched = false
        var dispatchWarning: String? = null
        if (request.dispatchWorkflow && request.workflowId.isNotBlank()) {
            request.onProgress(98, "Dispatching GitHub Actions workflow…")
            log("WORKFLOW_DISPATCH", "Requesting workflow_dispatch", mapOf("workflow_id" to request.workflowId.trim()))
            runCatching {
                val response = client.post("$repoBase/actions/workflows/${request.workflowId.trim()}/dispatches") {
                    githubHeaders(authorization)
                    setBody(WorkflowDispatchRequest(request.branch.trim()))
                }
                ensureSuccess(response)
            }.onSuccess {
                workflowDispatched = true
                log("WORKFLOW_DISPATCH", "GitHub accepted workflow dispatch")
            }.onFailure { failure ->
                dispatchWarning = failure.message ?: "GitHub workflow dispatch failed."
                ForgeUploadLogStore.appendFailure(context, logSessionId, "WORKFLOW_DISPATCH", failure)
            }
        }
        val completion = if (dispatchWarning == null) {
            "Forge upload and repository verification complete · TX ${transactionId.take(8)}."
        } else {
            "Repository upload verified · workflow dispatch failed · TX ${transactionId.take(8)}."
        }
        request.onProgress(100, completion)
        log(
            "UPLOAD_COMPLETE",
            completion,
            mapOf(
                "commit_sha" to finalCommitSha,
                "uploaded_path_count" to uploadedPaths.size,
                "workflow_dispatched" to workflowDispatched,
                "dispatch_warning" to dispatchWarning.orEmpty(),
            ),
        )
        return UploadResult(
            commitSha = finalCommitSha,
            uploadedPaths = uploadedPaths,
            transactionId = transactionId,
            workflowDispatched = workflowDispatched,
            dispatchWarning = dispatchWarning,
        )
    }



    /**
     * Best-effort direct lookup of an exact checksum sibling beside the selected ZIP.
     *
     * Android document providers grant access differently. Path-based providers can often
     * resolve the sibling directly; opaque providers cannot, in which case the UI opens a
     * companion document picker at the ZIP location instead of asking for a directory grant.
     */
    fun findMatchingChecksumBesideDocument(context: Context, zip: LocalFile): LocalFile? {
        if (!zip.displayName.endsWith(".zip", ignoreCase = true)) return null
        val expectedName = zip.displayName.dropLast(4) + ".sha256"
        val resolver = context.contentResolver

        if (zip.uri.scheme == "file") {
            val source = zip.uri.path?.let(::File) ?: return null
            val sibling = File(source.parentFile ?: return null, expectedName)
            if (!sibling.isFile) return null
            return LocalFile(Uri.fromFile(sibling), expectedName, sibling.length())
        }

        if (!DocumentsContract.isDocumentUri(context, zip.uri)) return null
        val documentId = runCatching { DocumentsContract.getDocumentId(zip.uri) }.getOrNull() ?: return null
        if (!documentId.endsWith(zip.displayName, ignoreCase = true)) return null
        val siblingId = documentId.dropLast(zip.displayName.length) + expectedName
        val authority = zip.uri.authority ?: return null
        val siblingUri = runCatching {
            DocumentsContract.buildDocumentUri(authority, siblingId)
        }.getOrNull() ?: return null

        return runCatching {
            val described = describe(context, siblingUri)
            if (!described.displayName.equals(expectedName, ignoreCase = true)) return@runCatching null
            resolver.openInputStream(siblingUri)?.use { it.read() }
                ?: return@runCatching null
            described
        }.getOrNull()
    }

    /**
     * Performs a bounded, streaming ZIP structure check before any network request.
     * This is intentionally heuristic: it blocks obvious APK/artifact bundles and accepts
     * Android/Gradle or documented SWRLZ source trees without extracting the archive.
     */
    fun inspectSourceZip(context: Context, file: LocalFile): StageValidation {
        if (!file.displayName.endsWith(".zip", ignoreCase = true)) {
            return StageValidation(true, "${file.displayName} is not a ZIP; source-content inspection skipped.")
        }
        val sourceMarkers = setOf(
            "settings.gradle", "settings.gradle.kts", "build.gradle", "build.gradle.kts",
            "gradlew", "gradlew.bat", "androidmanifest.xml", "package.json", "pyproject.toml",
            "requirements.txt", "cargo.toml", "go.mod", "pom.xml", "readme.md", "changelog.md",
        )
        var entriesSeen = 0
        var sourceSignals = 0
        var apkEntries = 0
        var dexEntries = 0
        var manifestEntries = 0
        var codeEntries = 0
        val suspiciousArtifactRoots = mutableSetOf<String>()
        return runCatching {
            context.contentResolver.openInputStream(file.uri)?.use { raw ->
                ZipInputStream(raw.buffered()).use { zip ->
                    while (entriesSeen < 2500) {
                        val entry = zip.nextEntry ?: break
                        if (entry.isDirectory) continue
                        entriesSeen++
                        val normalized = entry.name.replace('\\', '/').trimStart('/')
                        val lower = normalized.lowercase()
                        val base = lower.substringAfterLast('/')
                        val root = lower.substringBefore('/')
                        when {
                            lower.endsWith(".apk") -> { apkEntries++; suspiciousArtifactRoots += root }
                            lower.endsWith("classes.dex") || lower.matches(Regex(".*classes\\d*\\.dex$")) -> dexEntries++
                        }
                        if (base == "androidmanifest.xml") manifestEntries++
                        if (base in sourceMarkers || lower.endsWith("/src/main/androidmanifest.xml")) sourceSignals++
                        if (lower.endsWith(".kt") || lower.endsWith(".java") || lower.endsWith(".xml") ||
                            lower.endsWith(".py") || lower.endsWith(".js") || lower.endsWith(".ts")) {
                            codeEntries++
                        }
                    }
                }
            } ?: return StageValidation(false, "Unable to inspect ${file.displayName}.")

            if (entriesSeen == 0) return StageValidation(false, "${file.displayName} is empty or not a readable ZIP archive.")
            if (apkEntries > 0 || dexEntries > 0) {
                return StageValidation(
                    false,
                    "Blocked before upload: ${file.displayName} looks like a built APK/artifact bundle " +
                        "($apkEntries APK entr${if (apkEntries == 1) "y" else "ies"}, $dexEntries DEX entr${if (dexEntries == 1) "y" else "ies"}). Select the CLIENT or SERVER source ZIP instead.",
                )
            }
            val credibleSource = sourceSignals >= 2 || (manifestEntries > 0 && codeEntries >= 3) || codeEntries >= 12
            if (!credibleSource) {
                return StageValidation(
                    false,
                    "Blocked before upload: ${file.displayName} does not contain enough recognizable source structure " +
                        "($sourceSignals project markers, $codeEntries code/resource files). Disable Source ZIP Guard only when intentionally uploading a nonstandard source archive.",
                )
            }
            StageValidation(true, "Source ZIP Guard accepted ${file.displayName}: $sourceSignals project markers and $codeEntries code/resource files found.")
        }.getOrElse { error ->
            StageValidation(false, "Unable to inspect ${file.displayName}: ${error.message ?: error::class.simpleName}")
        }
    }

    suspend fun validateSourcePairs(context: Context, files: List<LocalFile>): StageValidation {
        val byName = files.associateBy { it.displayName }
        val sourceZips = files.filter { it.displayName.endsWith(".zip", ignoreCase = true) }
        if (sourceZips.isEmpty()) return StageValidation(false, "Stage at least one source ZIP.")
        for (zip in sourceZips) {
            val shaName = zip.displayName.removeSuffix(".zip") + ".sha256"
            val sha = byName[shaName] ?: return StageValidation(false, "Missing checksum file: $shaName")
            val expected = context.contentResolver.openInputStream(sha.uri)?.bufferedReader()?.use { it.readText() }
                ?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.lowercase()
                ?: return StageValidation(false, "Unable to read $shaName")
            if (!expected.matches(Regex("[0-9a-f]{64}"))) return StageValidation(false, "$shaName does not contain a valid SHA-256 hash.")
            val digest = MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(zip.uri)?.use { input ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    if (count > 0) digest.update(buffer, 0, count)
                }
            } ?: return StageValidation(false, "Unable to read ${zip.displayName}")
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (actual != expected) return StageValidation(false, "Checksum mismatch for ${zip.displayName}. Expected $expected, calculated $actual.")
        }
        val orphanChecksums = files.filter { it.displayName.endsWith(".sha256", true) }.filter { checksum ->
            val zipName = checksum.displayName.removeSuffix(".sha256") + ".zip"
            byName[zipName] == null
        }
        if (orphanChecksums.isNotEmpty()) return StageValidation(false, "Checksum selected without matching ZIP: ${orphanChecksums.joinToString { it.displayName }}")
        return StageValidation(true, "Verified ${sourceZips.size} source package pair(s) locally.")
    }

    suspend fun listWorkflowJobs(owner: String, repository: String, runId: Long, token: String): List<WorkflowJob> {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        val url = "https://api.github.com/repos/${owner.trim()}/${repository.trim()}/actions/runs/$runId/jobs?per_page=100"
        return getJson<WorkflowJobsResponse>(url, auth(token)).jobs.map { job ->
            WorkflowJob(
                id = job.id,
                name = job.name,
                status = job.status,
                conclusion = job.conclusion,
                startedAt = job.startedAt,
                completedAt = job.completedAt,
                steps = job.steps.map { step -> WorkflowStep(step.name, step.status, step.conclusion, step.number) },
            )
        }
    }

    suspend fun listWorkflowRuns(owner: String, repository: String, branch: String, token: String): List<WorkflowRun> {
        val url = buildString {
            append(repoBase(owner, repository)); append("/actions/runs?per_page=50")
            if (branch.isNotBlank()) append("&branch=").append(branch.trim())
        }
        return getJson<WorkflowRunsResponse>(url, auth(token)).workflowRuns.map {
            WorkflowRun(it.id, it.name, it.displayTitle, it.status, it.conclusion, it.headBranch.orEmpty(), it.headSha.orEmpty(), it.event, it.createdAt, it.updatedAt, it.runStartedAt, it.htmlUrl)
        }
    }

    suspend fun listArtifacts(owner: String, repository: String, runId: Long, token: String): List<Artifact> {
        val body = getJson<ArtifactsResponse>("${repoBase(owner, repository)}/actions/runs/$runId/artifacts?per_page=100", auth(token))
        return body.artifacts.map { Artifact(it.id, it.name, it.sizeInBytes, it.expired, it.createdAt) }
    }

    suspend fun downloadArtifact(owner: String, repository: String, artifactId: Long, token: String): ByteArray {
        val response = client.get("${repoBase(owner, repository)}/actions/artifacts/$artifactId/zip") { githubHeaders(auth(token)) }
        ensureSuccess(response)
        return response.body()
    }

    suspend fun downloadWorkflowLogs(owner: String, repository: String, runId: Long, token: String): ByteArray {
        require(owner.isNotBlank() && repository.isNotBlank()) { "Repository owner and name are required." }
        val response = client.get("${repoBase(owner, repository)}/actions/runs/$runId/logs") {
            githubHeaders(auth(token))
        }
        ensureSuccess(response)
        return response.body()
    }

    fun writeArtifact(context: Context, destination: Uri, bytes: ByteArray) {
        context.contentResolver.openOutputStream(destination, "w")?.use { it.write(bytes) }
            ?: error("Unable to open selected download destination.")
    }

    fun describe(context: Context, uri: Uri): LocalFile {
        var name = uri.lastPathSegment ?: "upload.bin"
        var size = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return LocalFile(uri, name, size)
    }

    fun destinationPath(fileName: String, fallbackDirectory: String, autoRoute: Boolean): String {
        val safe = sanitizeFileName(fileName)
        val upper = safe.uppercase()
        val directory = when {
            autoRoute && upper.startsWith("CLIENT_") -> "SOURCES/CLIENT"
            autoRoute && upper.startsWith("SERVER_") -> "SOURCES/SERVER"
            else -> fallbackDirectory.trim().trim('/')
        }
        return if (directory.isBlank()) safe else "$directory/$safe"
    }

    private fun repoBase(owner: String, repository: String) = "https://api.github.com/repos/${owner.trim()}/${repository.trim()}"
    private fun auth(token: String) = "Bearer ${token.trim()}"
    private fun sanitizeFileName(value: String) = value.replace("/", "_").replace("\\", "_").ifBlank { "upload.bin" }


    private suspend fun verifyUploadedPaths(
        repoBase: String,
        authorization: String,
        branch: String,
        expectedBlobByPath: Map<String, String>,
    ) {
        val mismatches = mutableListOf<String>()
        expectedBlobByPath.forEach { (path, expectedSha) ->
            val encodedPath = path.split('/').joinToString("/") { it.encodeURLPathPart() }
            val encodedBranch = branch.encodeURLParameter()
            val content = getJson<RepositoryContentResponse>(
                "$repoBase/contents/$encodedPath?ref=$encodedBranch",
                authorization,
            )
            if (content.sha != expectedSha) {
                mismatches += "$path expected ${expectedSha.take(12)} but repository resolved ${content.sha.take(12)}"
            }
        }
        check(mismatches.isEmpty()) {
            "Branch confirmation succeeded, but uploaded-path verification failed: ${mismatches.joinToString("; ")}"
        }
    }

    private suspend fun postBlobStream(
        url: String,
        authorization: String,
        context: Context,
        file: LocalFile,
        onBytesSent: suspend (Long, Long) -> Unit,
    ): BlobResponse {
        val prefix = "{\"content\":\"".toByteArray(Charsets.UTF_8)
        val suffix = "\",\"encoding\":\"base64\"}".toByteArray(Charsets.UTF_8)
        val rawLength = file.sizeBytes.takeIf { it >= 0L }
        val encodedLength = rawLength?.let { 4L * ((it + 2L) / 3L) }

        val response = client.post(url) {
            githubHeaders(authorization)
            setBody(object : OutgoingContent.WriteChannelContent() {
                override val contentType: ContentType = ContentType.Application.Json
                override val contentLength: Long? = encodedLength?.let { prefix.size + it + suffix.size }

                override suspend fun writeTo(channel: ByteWriteChannel) {
                    channel.writeFully(prefix)
                    val input = context.contentResolver.openInputStream(file.uri)
                        ?: error("Unable to read ${file.displayName}")
                    input.use { stream ->
                        val inputBuffer = ByteArray(192 * 1024)
                        var carry = ByteArray(0)
                        var sent = 0L
                        var lastReported = 0L
                        while (true) {
                            val read = stream.read(inputBuffer)
                            if (read < 0) break
                            if (read == 0) continue
                            sent += read
                            val combined = ByteArray(carry.size + read)
                            if (carry.isNotEmpty()) carry.copyInto(combined, 0)
                            inputBuffer.copyInto(combined, carry.size, 0, read)
                            val complete = combined.size - (combined.size % 3)
                            if (complete > 0) {
                                val encoded = java.util.Base64.getEncoder().encode(combined.copyOfRange(0, complete))
                                channel.writeFully(encoded)
                            }
                            carry = if (complete < combined.size) combined.copyOfRange(complete, combined.size) else ByteArray(0)
                            if (sent - lastReported >= 512 * 1024 || (rawLength != null && sent >= rawLength)) {
                                onBytesSent(sent, rawLength ?: -1L)
                                lastReported = sent
                            }
                        }
                        if (carry.isNotEmpty()) {
                            channel.writeFully(java.util.Base64.getEncoder().encode(carry))
                        }
                        onBytesSent(sent, rawLength ?: sent)
                    }
                    channel.writeFully(suffix)
                }
            })
        }
        ensureSuccess(response)
        return response.body()
    }

    private suspend inline fun <reified T> getJson(url: String, authorization: String): T {
        val response = client.get(url) { githubHeaders(authorization) }
        ensureSuccess(response)
        return response.body()
    }
    private suspend inline fun <reified Req : Any, reified Res> postJson(url: String, authorization: String, body: Req): Res {
        val response = client.post(url) { githubHeaders(authorization); setBody(body) }
        ensureSuccess(response)
        return response.body()
    }
    private suspend fun patchJson(url: String, authorization: String, body: UpdateRefRequest) {
        val response = client.patch(url) { githubHeaders(authorization); setBody(body) }
        ensureSuccess(response)
    }
    private fun HttpRequestBuilder.githubHeaders(authorization: String) {
        header(HttpHeaders.Authorization, authorization)
        header(HttpHeaders.Accept, "application/vnd.github+json")
        header(HttpHeaders.ContentType, ContentType.Application.Json)
        header("X-GitHub-Api-Version", "2022-11-28")
    }
    private suspend fun ensureSuccess(response: HttpResponse) {
        if (response.status.isSuccess()) return
        val body = response.body<String>().take(500)
        val message = if (response.status.value == 403 && body.contains("Resource not accessible by personal access token", ignoreCase = true)) {
            "GitHub denied repository write access. Edit or recreate the fine-grained token with Resource owner ahazus420-stack, Repository access: Only select repositories → Swrlzcore, and Contents: Read and write. Then reconnect the token in Forge."
        } else {
            "GitHub ${response.status.value}: $body"
        }
        throw GitHubRequestException(response.status.value, message)
    }
}

private class GitHubRequestException(val statusCode: Int, message: String) : IllegalStateException(message)

@Serializable private data class RepositoryContentResponse(val path: String = "", val sha: String = "")

@Serializable private data class RefResponse(@SerialName("object") val `object`: GitObject)
@Serializable private data class GitObject(val sha: String)
@Serializable private data class CommitResponse(val tree: GitTree)
@Serializable private data class GitTree(val sha: String)
@Serializable private data class BlobRequest(val content: String, val encoding: String)
@Serializable private data class BlobResponse(val sha: String)
@Serializable private data class TreeEntry(val path: String, val mode: String, val type: String, val sha: String)
@Serializable private data class TreeRequest(@SerialName("base_tree") val baseTree: String, val tree: List<TreeEntry>)
@Serializable private data class TreeResponse(val sha: String)
@Serializable private data class NewCommitRequest(val message: String, val tree: String, val parents: List<String>)
@Serializable private data class NewCommitResponse(val sha: String)
@Serializable private data class UpdateRefRequest(val sha: String, val force: Boolean)
@Serializable private data class WorkflowDispatchRequest(val ref: String)
@Serializable private data class UserProfileResponse(val login: String, @SerialName("avatar_url") val avatarUrl: String? = null)
@Serializable private data class DeviceCodeResponse(@SerialName("device_code") val deviceCode: String, @SerialName("user_code") val userCode: String, @SerialName("verification_uri") val verificationUri: String, @SerialName("expires_in") val expiresIn: Int, val interval: Int = 5)
@Serializable private data class DeviceTokenResponse(@SerialName("access_token") val accessToken: String? = null, val error: String? = null, @SerialName("error_description") val errorDescription: String? = null)
@Serializable private data class WorkflowJobsResponse(val jobs: List<WorkflowJobResponse> = emptyList())
@Serializable private data class WorkflowJobResponse(
    val id: Long,
    val name: String = "Job",
    val status: String = "unknown",
    val conclusion: String? = null,
    @SerialName("started_at") val startedAt: String? = null,
    @SerialName("completed_at") val completedAt: String? = null,
    val steps: List<WorkflowStepResponse> = emptyList(),
)
@Serializable private data class WorkflowStepResponse(
    val name: String = "Step",
    val status: String = "unknown",
    val conclusion: String? = null,
    val number: Int = 0,
)
@Serializable private data class WorkflowRunsResponse(@SerialName("workflow_runs") val workflowRuns: List<WorkflowRunResponse> = emptyList())
@Serializable private data class WorkflowRunResponse(
    val id: Long,
    val name: String = "Workflow",
    @SerialName("display_title") val displayTitle: String = "",
    val status: String = "unknown",
    val conclusion: String? = null,
    @SerialName("head_branch") val headBranch: String? = null,
    @SerialName("head_sha") val headSha: String? = null,
    val event: String = "",
    @SerialName("created_at") val createdAt: String = "",
    @SerialName("updated_at") val updatedAt: String = "",
    @SerialName("run_started_at") val runStartedAt: String? = null,
    @SerialName("html_url") val htmlUrl: String = "",
)
@Serializable private data class ArtifactsResponse(val artifacts: List<ArtifactResponse> = emptyList())
@Serializable private data class ArtifactResponse(val id: Long, val name: String, @SerialName("size_in_bytes") val sizeInBytes: Long = 0, val expired: Boolean = false, @SerialName("created_at") val createdAt: String = "")
