# CLIENT CFv2.0.57 Forge Live Log and Connector Restore Checkpoint

**Recorded:** 2026-07-24  
**Status:** Source/static implementation complete; external ZIP/SHA receipt prepared after archive finalization; GitHub build, Android restore, and device acceptance pending.

## Scope

This bounded CLIENT pass adds two reliability capabilities requested during device testing:

1. a detailed exportable Forge upload log available before terminal completion;
2. durable GitHub connector identity and eligible reinstall restoration with explicit disconnect approval.

## Forge live upload log

The app opens an append-only diagnostic session when the source picker is opened. It records:

- source-document names, sizes, providers, and destination paths;
- exact sibling SHA matching and companion-picker fallbacks;
- staging additions and clears;
- transaction UUID and non-secret repository target;
- ZIP content-guard and ZIP/SHA pair validation;
- bounded transfer checkpoints;
- GitHub blob, tree, commit, branch update, retry, confirmation, and uploaded-path verification;
- workflow dispatch and exact-commit workflow discovery;
- failures and terminal outcome.

The latest log can be exported while staging or upload is active, after failure, or after success. Logs are capped and pruned. Sanitization removes authorization headers, bearer/token forms, GitHub token prefixes, access/refresh tokens, and OAuth device codes.

## GitHub connector persistence and restore

- OAuth client ID, owner, repository, branch, connected login, auto-connect intent, and explicit-disconnect state use synchronous backup-aware preferences.
- Runtime GitHub tokens remain in Android Keystore-backed encrypted preferences.
- The Keystore-encrypted preference file is excluded from ordinary backup because its original encryption key is not portable.
- A custom BackupAgent creates a temporary restore envelope only when Android reports client-side encrypted backup or direct device-to-device transfer.
- On restore, the token is imported into the fresh install's new Keystore store. Forge validates the token before reporting connected.
- When Android restores only the profile, the client ID and repository target remain available but one authorization is required to re-arm auto-connect.
- Disconnect requires an approval dialog and clears token, profile, auto-connect, and backed-up restore intent.

Android backup availability, transport eligibility, account/device settings, retention, and restore timing are platform-controlled; the app cannot guarantee restoration after every uninstall.

## Version identity

```text
CLIENT_CFv2.0.57_SWRLZ.zip
versionCode: 84
versionName: 2.0.57-forge-live-logs-connector-restore-v1
```

## Static evidence

- 32 bounded source/manifest/backup/logging assertions passed.
- All Android XML resources parsed successfully.
- All packaged PNG resources opened and verified successfully.
- Modified Kotlin files passed structural delimiter-balance checks.
- The final archive must be hashed only after this embedded checkpoint is finalized; the authoritative digest is therefore carried by the external sibling `.sha256` receipt and repository checkpoint.

## Acceptance gate

1. Build through GitHub APK Router.
2. Select a ZIP and export the log before upload.
3. Start a large upload and export another log snapshot while bytes are transferring.
4. Verify success and failure logs contain the expected phases and no credential values.
5. Restart/update the app and verify client ID, target, token validation, and auto-connect.
6. Trigger an eligible Android backup/device transfer, reinstall/restore, and verify restored validation/auto-connect.
7. Test a restore where the token is unavailable and verify the profile remains while reauthorization is requested.
8. Confirm disconnect requires approval and prevents subsequent automatic reconnect/restore.
