# CLIENT CFv2.0.57 — Forge Live Logs and Durable GitHub Connection

CLIENT CFv2.0.57 preserves the CFv2.0.56 compiler, observer, identity, bubble-theme, and version-footer work and adds:

- an append-only redacted Forge upload diagnostic log that begins with source selection and remains downloadable during staging, upload, retry, failure, or success;
- detailed source selection, SHA matching, validation, byte transfer, blob, tree, commit, branch, path-verification, workflow-discovery, and failure events;
- persistent GitHub OAuth client ID, repository target, connected account identity, and auto-connect intent;
- Android encrypted-backup/device-transfer restoration of the authorization token when the platform provides an eligible secure transport;
- automatic credential validation after restart, update, or successful restore;
- an approval dialog before disconnecting and clearing saved connection state.

**Android identity:** versionCode `84`; versionName `2.0.57-forge-live-logs-connector-restore-v1`.

> Reinstall restoration depends on Android Backup/device-transfer availability and the user's device backup settings. When only the non-secret profile is restored, Forge keeps the client ID and target but asks for authorization once to re-arm auto-connect.

---

> Current stabilization checkpoint: **CLIENT CFv2.0.56**. See `CFv2.0.56_FORGE_OBSERVER_IDENTITY_FOOTER_BUILDFIX_CHECKPOINT.md`. CFv2.1.0 remains reserved for the coordinated Chat control plane after CFv2.0.x stabilization.

# SWRLZ-Core Android Client

Current source package: **CLIENT CFv2.0.56 — Forge observer, theme identity, main version footer, and Kotlin build repair**.

## Current app identity

- Version: `2.0.56-forge-observer-identity-footer-buildfix-v1`
- Code: `83`
- Patch: `CFv2.0.56-FORGE-OBSERVER-IDENTITY-FOOTER-BUILDFIX-V1`
- Source: `CLIENT_CFv2.0.56_SWRLZ.zip`

## Current stabilization scope

- Preserves CFv2.0.55 repeat-upload transaction verification, selected-ZIP checksum matching, and upload/build outcome notifications.
- Repairs the CFv2.0.55 Kotlin `Set.takeLast` compiler failure.
- Refreshes workflow runs every 2 seconds while active and every 5 seconds while idle.
- Shows every active workflow plus 2–20 completed runs, defaulting to 4.
- Collapses duplicate display cards sharing workflow identity, commit, and event.
- Uses the current cyan crystal-dragon artwork for the default launcher and every Theme Armor icon family.
- Makes CLIENT, selected SERVER, and fusion bubble icons follow the active interface theme.
- Shows `CLIENT · CFv2.0.56` and versionCode at the bottom of the main User and Developer interfaces.

## Interface modes

- **User Mode** is the fresh-install default: Core, Chat, Missions, Nodes, and Settings on the animated translucent Glitch Dragon Glass shell.
- **SWRLZ Dev Mode** retains the complete engineering surface: Home, Radar, Network, Cockpit, Setup, Style, Permissions, Core Admin, Skills, Allowlist, How To, Info, and More.
- The selected interface persists locally and can be switched in either direction without deleting configuration, identity, mission, trust, or style state.

## Current server pair

- Local Node Server: `0.7.1 Presence Index`

## Project law

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Preserve local data and taught skills.
- Keep Mentor backend and Local Core Node separate.
- Status colors remain semantic; themes may not lie about operational state.
- User Mode never hides Pause, Take Over, approval state, local-versus-remote identity, or Truth Firewall status.


## 2.7.6-CODEFIX3-DISCOVERY-SCAN-TRIM

- Source: `SRC_2.7.6_CF3_SCAN_TRIM.zip`
- Objective: trim discovery scan overhead by skipping `127.0.0.x` range sweeps by default, while keeping a saved debug toggle for unusual loopback testing.
- Output naming convention: `SRC_` for source, `SHA_` for hashes, `REPORT_` for patch notes, `APK_` for APKs, and `BUNDLE_` for APK download bundles.


## 2.7.6 CF4 - Signing + Reconnect

Adds Connection Memory / Last-Good Node Auto-Reconnect and stable dev signing readiness. Source: `SRC_2.7.6_CF4_SIGN_RECONNECT.zip`.


## INT-CONV-012A communication foundation
See `docs/contracts/SWRLZ_PROTOCOL_AND_DATA_CONTRACTS_V1_INTEGRATED.md` and `reports/INT-CONV-012A_IMPLEMENTATION_REPORT.md` (CLIENT) or `INT-CONV-012A_IMPLEMENTATION_REPORT.md` (SERVER). This is source-only foundation work; no live endpoint is exposed.

## CFv2.0.56 Forge transaction update

The current CLIENT build uses a fresh transaction ID for every Forge upload, rebases on the latest branch head after blob transfer, retries branch races, verifies uploaded repository paths, and reports upload/build results through both Android notifications and the CLIENT conversation bubble. ZIP checksum matching now begins from the selected ZIP location and no longer requires a separate Downloads-root folder grant. See `CFv2.0.56_FORGE_REPEAT_NOTIFICATIONS_SIBLING_CHECKPOINT.md`.
