#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ANDROID = ROOT / "android" / "app" / "src" / "main" / "java"

checks: list[tuple[str, bool]] = []

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

def require(name: str, condition: bool) -> None:
    checks.append((name, condition))

build = text("android/app/build.gradle.kts")
forge = text("android/app/src/main/java/sh/swurlz/core/github/GitHubForgeClient.kt")
screen = text("android/app/src/main/java/sh/swurlz/core/ui/screens/GitHubForgeScreen.kt")
notifier = text("android/app/src/main/java/sh/swurlz/core/notification/ForgeEventNotifier.kt")
service = text("android/app/src/main/java/sh/swurlz/core/service/ClientStatusService.kt")
bubble = text("android/app/src/main/java/sh/swurlz/core/bubble/ClientBubbleActivity.kt")
monitor = text("android/app/src/main/java/sh/swurlz/core/github/ForgeBuildMonitor.kt")
watch_store = text("android/app/src/main/java/sh/swurlz/core/github/ForgeBuildWatchStore.kt")
sibling_contract = text("android/app/src/main/java/sh/swurlz/core/github/OpenSiblingDocumentContract.kt")

require("versionCode 82", "versionCode = 82" in build)
require("versionName 2.0.55", 'versionName = "2.0.55-forge-repeat-notifications-sibling-v1"' in build)
require("source ZIP identity", 'CLIENT_CFv2.0.55_SWRLZ.zip' in build)
require("fresh transaction identity", "transactionId: String = UUID.randomUUID().toString()" in forge)
require("latest branch head after blobs", forge.find("uploadFiles.forEachIndexed") < forge.find("Resolving latest branch head"))
require("branch race retry", "Branch moved during upload" in forge and "attempt in 1..3" in forge)
require("no-op rejection", "No repository content changed" in forge)
require("uploaded path verification", "verifyUploadedPaths(" in forge and "RepositoryContentResponse" in forge)
require("dispatch separated from commit", "dispatchWarning" in forge and "Repository upload verified · workflow dispatch failed" in forge)
require("staged snapshot", "val stagedFiles = files.toList()" in screen)
result_index = screen.find("val result = runCatching")
clear_after_result = screen.find("files = emptyList()", result_index)
require("staging clears after verified result", result_index >= 0 and clear_after_result > result_index)
require("durable build watch", "ForgeBuildWatchStore.add" in screen and "MAX_WATCHES = 12" in watch_store)
require("background build monitor", "ForgeBuildMonitor.pollOnce" in service and "15_000L" in service)
require("upload outcome notifications", "Forge upload succeeded" in notifier and "Forge upload failed" in notifier)
require("build outcome notifications", "Artifact build succeeded" in notifier and "Artifact build failed" in notifier)
require("dispatch failure notification", "Build dispatch failed" in notifier)
require("bubble Forge event banner", "ForgeEventBanner" in bubble and "latestEvent" in bubble)
require("same-location sibling lookup", "findMatchingChecksumBesideDocument" in forge and "EXTRA_INITIAL_URI" in sibling_contract)
require("no folder-tree picker", "OpenDocumentTree" not in screen)
require("no explicit Compose weight import", not any("import androidx.compose.foundation.layout.weight" in p.read_text(encoding="utf-8", errors="ignore") for p in ANDROID.rglob("*.kt")))
require("single ForgeEventNotifier", len(list(ANDROID.rglob("ForgeEventNotifier.kt"))) == 1)
require("no accidental nested client55 tree", not (ROOT / "client55").exists())
require("artifact workflow correlation", "run.headSha.equals(watch.commitSha" in monitor)
require("artifact workflow filter", all(word in monitor for word in ("apk", "artifact", "build", "router", "assemble")))

# Basic package/path consistency for newly touched Kotlin files.
for relative in [
    "android/app/src/main/java/sh/swurlz/core/github/ForgeBuildMonitor.kt",
    "android/app/src/main/java/sh/swurlz/core/github/ForgeBuildWatchStore.kt",
    "android/app/src/main/java/sh/swurlz/core/github/OpenSiblingDocumentContract.kt",
    "android/app/src/main/java/sh/swurlz/core/notification/ForgeEventNotifier.kt",
]:
    source = text(relative)
    package = re.search(r"^package\s+([\w.]+)", source, re.MULTILINE)
    expected = relative.split("/java/")[1].rsplit("/", 1)[0].replace("/", ".")
    require(f"package matches path: {relative}", bool(package and package.group(1) == expected))

failed = [name for name, ok in checks if not ok]
for name, ok in checks:
    print(f"{'PASS' if ok else 'FAIL'} - {name}")

if failed:
    print(f"\n{len(failed)} verification check(s) failed.", file=sys.stderr)
    raise SystemExit(1)

print(f"\nAll {len(checks)} CLIENT CFv2.0.55 static verification checks passed.")
