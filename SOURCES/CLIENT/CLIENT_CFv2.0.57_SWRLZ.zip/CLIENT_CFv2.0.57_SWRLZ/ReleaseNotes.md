# CLIENT CFv2.0.57 Release Notes

## Forge diagnostics

A redacted upload-session log starts when source selection begins and can be downloaded while the transaction is active or after it succeeds or fails. The export records source metadata, exact SHA matching, validation, streamed byte checkpoints, Git object creation, branch confirmation, uploaded-path verification, workflow discovery, retries, and exceptions. Credentials and token-like values are redacted.

## GitHub connector continuity

The OAuth client ID, repository target, branch, connected login, and auto-connect intent are synchronously persisted. Runtime tokens remain in Android Keystore-backed encrypted preferences. On eligible client-side encrypted Android backup or direct device transfer, a custom backup agent restores the token into the fresh install's new Keystore store; Forge then validates the credential before reporting connected. If Android restores only the profile and not the token, the app preserves the client ID and target and requests one authorization. Disconnect requires confirmation and clears token, profile, auto-connect, and restore state.

## Identity

- versionCode: `84`
- versionName: `2.0.57-forge-live-logs-connector-restore-v1`
- package: `CLIENT_CFv2.0.57_SWRLZ.zip`

The source archive is finalized with an external exact-basename SHA-256 receipt. GitHub compilation and device acceptance remain pending.

---

# CLIENT CFv2.0.56 — Forge Observer, Theme Identity, Main Footer, and Build Repair

- Repaired the CFv2.0.55 Kotlin compile failure in `ForgeBuildWatchStore` by converting the notified-outcome Set to a List before applying bounded `takeLast`.
- Added immediate post-upload run discovery, 2-second active polling, and 5-second idle polling.
- Kept all active workflow runs visible while limiting completed history to a configurable 2–20 entries, default 4.
- Collapsed duplicate display cards by workflow name, commit SHA, and event.
- Rebuilt the default and Theme Armor launcher families from the current cyan crystal-dragon artwork.
- Made CLIENT, selected SERVER, and fusion bubble icons follow the selected interface theme.
- Added persistent `CLIENT · CFv2.0.56` / `VC 83` footers to User and Developer main interfaces.
- Advanced Android identity to versionCode 83 / versionName `2.0.56-forge-observer-identity-footer-buildfix-v1`.
- The source archive is finalized with an external exact-basename SHA-256 receipt. GitHub compilation and device acceptance remain pending.

