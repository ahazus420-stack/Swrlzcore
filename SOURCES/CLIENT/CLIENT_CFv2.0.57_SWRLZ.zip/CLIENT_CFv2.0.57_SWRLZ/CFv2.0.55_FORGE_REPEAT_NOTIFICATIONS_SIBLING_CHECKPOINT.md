# CLIENT CFv2.0.55 Forge Repeat Upload, Outcome Notifications, and Same-Location SHA Checkpoint

**Recorded:** 2026-07-24  
**Status:** Source implementation and package static verification complete; GitHub compilation and device acceptance pending.

## Scope

This checkpoint addresses three related CLIENT Forge requirements:

1. a second or later upload from the same installed CLIENT must create an independent repository transaction instead of replaying progress without verified mutation;
2. upload and artifact-build outcomes must reach both Android notifications and the CLIENT bubble;
3. ZIP/SHA pairing must begin from the selected ZIP location without requiring a separate public Downloads-folder tree grant.

## Evidence discipline

The user-observed symptom establishes that later uploads could appear active without producing a visible repository update. Source inspection did **not** reveal a literal one-install or one-upload boolean. The repair therefore closes the transaction hazards that previously allowed an upload to appear complete without strong postconditions.

A progress bar reaching 100 percent is never accepted as repository success by itself.

## Repeat-upload transaction repair

Every commit button press now snapshots the current staging set and creates a new UUID transaction ID before local validation.

The upload sequence is:

```text
snapshot staged files
-> assign transaction ID
-> validate ZIP structure and ZIP/SHA pairs
-> stream each Git blob
-> resolve the latest branch head after transfer
-> create tree from that latest head
-> reject an unchanged/no-op tree
-> create a commit containing the transaction ID
-> update the branch without force
-> retry a 409/422 branch race up to three times
-> confirm the branch points to the new commit
-> verify every uploaded repository path resolves to the expected blob SHA
-> clear staging
```

Important changes:

- the branch parent is no longer captured before a potentially long mobile upload;
- a new transaction cannot reuse a prior transaction identity;
- a no-op selection produces an explicit message rather than a false success state;
- staging is cleared only after commit, branch, and per-path verification;
- commit messages include `SWRLZ-Forge-Transaction: <uuid>`;
- a workflow-dispatch failure no longer converts a verified repository commit into a false upload failure.

## Upload, dispatch, and build outcome notifications

A dedicated high-importance `SWRLZ Forge Events` channel publishes:

- Forge upload succeeded;
- Forge upload failed;
- build workflow dispatch failed after a verified commit;
- artifact build succeeded;
- artifact build failed.

Each event is also published through `ClientBubbleController`. The CLIENT bubble interface displays the latest Forge event in a compact status banner.

Failure events may request bubble expansion. Successful events update the bubble without forcing it open.

## Durable artifact-build watch

A verified upload adds a durable build watch containing:

- repository owner;
- repository name;
- branch;
- verified commit SHA;
- Forge transaction ID;
- creation timestamp.

Up to twelve pending watches are retained for 24 hours. This prevents a later CLIENT or SERVER upload from silently replacing an earlier pending build notification.

The existing CLIENT foreground status service polls pending watches in the background while status notifications are enabled:

```text
pending verified commit
-> query GitHub workflow runs
-> require exact head_sha match
-> ignore non-artifact workflows such as package integrity
-> accept APK / artifact / build / router / assemble workflow identities
-> notify one completed conclusion per run
-> count non-expired artifacts on success
-> retire the completed watch
```

Repository upload, workflow dispatch, workflow conclusion, artifact availability, artifact download, and APK installation remain separate states.

## Same-location checksum matching

The prior `ACTION_OPEN_DOCUMENT_TREE` folder-grant workflow is retired because Android document providers may prohibit selecting the public Downloads root.

The new flow is:

1. select the source ZIP;
2. attempt an exact `.sha256` sibling URI beside that selected document;
3. when the document provider exposes the sibling, add it automatically;
4. when Android grants only the selected document, open a companion `ACTION_OPEN_DOCUMENT` picker at that ZIP location;
5. require the exact expected SHA filename;
6. stage ZIP and SHA as one logical package.

Android Storage Access Framework security does not guarantee that selecting one document grants silent access to every sibling. The same-location fallback therefore removes the separate folder-selection step without requesting broad all-files permission.

## Build identity

- `versionCode`: `82`
- `versionName`: `2.0.55-forge-repeat-notifications-sibling-v1`
- patch label: `CFv2.0.55-FORGE-REPEAT-NOTIFY-SIBLING-V1`
- source ZIP: `CLIENT_CFv2.0.55_SWRLZ.zip`

## Static evidence

- 28 dedicated CFv2.0.55 verification checks passed.
- Changed Kotlin files passed structural delimiter-balance checks.
- No explicit `androidx.compose.foundation.layout.weight` import remains.
- Only one `ForgeEventNotifier` implementation remains.
- The obsolete folder-tree picker is absent from the Forge screen.
- The accidental nested working-tree copy was removed before packaging.
- Local Gradle compilation remains unavailable because the isolated environment cannot download the Gradle distribution.

## Acceptance checklist

- [ ] Upload package A, then package B from the same installed CLIENT without clearing app data or reinstalling.
- [ ] Confirm two distinct transaction IDs and two distinct verified commits.
- [ ] Confirm package B repository paths resolve to package B blob SHAs.
- [ ] Confirm a same-content re-upload reports a no-op rather than success.
- [ ] Confirm upload success and upload failure each produce an Android notification and CLIENT bubble event.
- [ ] Confirm a workflow-dispatch failure reports that the commit succeeded while dispatch failed.
- [ ] Leave the Forge screen and confirm the CLIENT status service reports the matching artifact-build outcome.
- [ ] Confirm a successful build notification reports available artifact count.
- [ ] Select a ZIP from Downloads without selecting the Downloads root.
- [ ] Confirm direct sibling matching or the same-location exact-SHA picker.
- [ ] Confirm the bubble footer displays `CLIENT · CFv2.0.55`.
