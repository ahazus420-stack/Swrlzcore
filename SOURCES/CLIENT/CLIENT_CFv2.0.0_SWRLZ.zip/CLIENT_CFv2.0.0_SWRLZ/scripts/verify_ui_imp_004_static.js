#!/usr/bin/env node

const fs = require("fs");
const path = require("path");

const root = path.resolve(__dirname, "..");
const rel = (...parts) => path.join(root, ...parts);

function fail(message) {
  process.stderr.write(`UI-IMP-004 STATIC VERIFY FAIL: ${message}\n`);
  process.exit(1);
}

function read(...parts) {
  const file = rel(...parts);
  if (!fs.existsSync(file)) fail(`missing ${path.relative(root, file)}`);
  return fs.readFileSync(file, "utf8");
}

function walk(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const target = path.join(directory, entry.name);
    return entry.isDirectory() ? walk(target) : [target];
  });
}

function stripStringsAndComments(source) {
  let output = "";
  let index = 0;
  let state = "code";
  while (index < source.length) {
    const char = source[index];
    const next = source[index + 1];
    if (state === "code") {
      if (char === "/" && next === "/") {
        state = "line";
        output += "  ";
        index += 2;
        continue;
      }
      if (char === "/" && next === "*") {
        state = "block";
        output += "  ";
        index += 2;
        continue;
      }
      if (source.slice(index, index + 3) === '\"\"\"') {
        state = "triple";
        output += "   ";
        index += 3;
        continue;
      }
      if (char === '\"') {
        state = "string";
        output += " ";
        index += 1;
        continue;
      }
      if (char === "'") {
        state = "char";
        output += " ";
        index += 1;
        continue;
      }
      output += char;
      index += 1;
      continue;
    }
    if (state === "line") {
      if (char === "\n") {
        state = "code";
        output += "\n";
      } else output += " ";
      index += 1;
      continue;
    }
    if (state === "block") {
      if (char === "*" && next === "/") {
        state = "code";
        output += "  ";
        index += 2;
      } else {
        output += char === "\n" ? "\n" : " ";
        index += 1;
      }
      continue;
    }
    if (state === "triple") {
      if (source.slice(index, index + 3) === '\"\"\"') {
        state = "code";
        output += "   ";
        index += 3;
      } else {
        output += char === "\n" ? "\n" : " ";
        index += 1;
      }
      continue;
    }
    if (char === "\\") {
      output += "  ";
      index += 2;
      continue;
    }
    const terminator = state === "string" ? '\"' : "'";
    if (char === terminator) state = "code";
    output += char === "\n" ? "\n" : " ";
    index += 1;
  }
  if (state !== "code" && state !== "line") fail(`unterminated ${state} literal or comment`);
  return output;
}

function verifyBalance(file) {
  const source = stripStringsAndComments(fs.readFileSync(file, "utf8"));
  const stack = [];
  const pairs = { ")": "(", "]": "[", "}": "{" };
  for (const char of source) {
    if ("([{ ".replace(" ", "").includes(char)) stack.push(char);
    if (")]}".includes(char)) {
      const open = stack.pop();
      if (open !== pairs[char]) fail(`${path.relative(root, file)} has an unbalanced ${char}`);
    }
  }
  if (stack.length) fail(`${path.relative(root, file)} has an unclosed ${stack[stack.length - 1]}`);
}

function mustContain(name, source, required) {
  for (const value of required) {
    if (!source.includes(value)) fail(`${name} is missing ${value}`);
  }
}

const kotlinRoot = rel("android", "app", "src", "main", "java");
const kotlinFiles = walk(kotlinRoot).filter((file) => file.endsWith(".kt"));
if (kotlinFiles.length < 20) fail("unexpectedly small Kotlin source set");
kotlinFiles.forEach(verifyBalance);

const main = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "MainActivity.kt");
const client = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "ui", "client", "ClientShellScreen.kt");
const prefs = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "data", "Prefs.kt");
const models = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "model", "Models.kt");
const theme = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "ui", "theme", "Theme.kt");
const style = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "ui", "screens", "StyleScreen.kt");
const gradle = read("android", "app", "build.gradle.kts");
const api = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "net", "Api.kt");
const adminPolicy = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "net", "AdminRoutePolicy.kt");
const commands = read("android", "app", "src", "main", "java", "sh", "swurlz", "core", "ui", "screens", "CommandsScreen.kt");

mustContain("MainActivity", main, [
  "Prefs.interfaceModeFlow",
  "Prefs.setInterfaceMode",
  "ClientInterfaceMode.User",
  "ClientInterfaceMode.Developer",
  'composable("client")',
  "ClientShellScreen(",
  "DeveloperHeaderBar(",
  'Text("SWRLZ DEV MODE"',
  'Text("USER MODE"',
  "GlitchDragonBackdrop(",
  "startDestination = startRoute",
]);

mustContain("Client shell", client, [
  "ClientTab.Core",
  "ClientTab.Chat",
  "ClientTab.Missions",
  "ClientTab.Nodes",
  "ClientTab.Settings",
  "MissionRunnerService.start",
  "MissionBus.pauseRequest",
  "MissionBus.takeoverRequest",
  "MissionBus.approvalGranted",
  "Prefs.coreNodeTruthStateFlow",
  "CoreNodeAutoDiscovery.connectOnLaunch",
  "Truth Firewall",
  "Local-first core",
  "SWITCH TO SWRLZ DEV MODE",
  "artAlpha.coerceIn",
]);

mustContain("Persistent interface mode", `${prefs}\n${models}`, [
  'stringPreferencesKey("ui_interface_mode")',
  "fun interfaceModeFlow",
  "suspend fun setInterfaceMode",
  "enum class ClientInterfaceMode",
  'User("user")',
  'Developer("developer")',
]);

mustContain("Glitch Dragon theme", `${prefs}\n${models}\n${theme}\n${style}`, [
  "Glitch Dragon Glass",
  "glitchDragonGlassDark",
  'themePack = prefs[KEY_UI_THEME_PACK] ?: "Glitch Dragon Glass"',
]);

mustContain("CFv2 source identity", gradle, [
  "versionCode = 31",
  'versionName = "0.2.7.6-cfv2-dual-mode-ui"',
  "2.7.6-CFV2-GLITCH-DRAGON-DUAL-MODE",
  "CLIENT_CFv2.0.0_SWRLZ.zip",
]);

mustContain("CF8/Ktor preservation", `${prefs}\n${models}\n${api}\n${adminPolicy}\n${commands}`, [
  "lastVerifiedAt.isNotBlank()",
  "prefs[KEY_ADMIN_ALL_DEVICES_VISIBLE] = false",
  "response.call.request.url.encodedPath",
  'if (hasVerifiedSession) "/admin/devices" else "/presence/devices"',
  "var radarStatus by remember",
]);

const legacyScreens = [
  "HomeScreen.kt",
  "CockpitScreen.kt",
  "CommandsScreen.kt",
  "NetworkDiscoveryScreen.kt",
  "SetupScreen.kt",
  "StyleScreen.kt",
  "PermissionsScreen.kt",
  "CoreNodeScreen.kt",
  "SkillsScreen.kt",
  "AllowlistScreen.kt",
  "HowToScreen.kt",
  "InfoScreen.kt",
  "MoreScreen.kt",
];
for (const name of legacyScreens) {
  const file = rel("android", "app", "src", "main", "java", "sh", "swurlz", "core", "ui", "screens", name);
  if (!fs.existsSync(file)) fail(`legacy Dev Mode surface was removed: ${name}`);
}

const image = rel("android", "app", "src", "main", "res", "drawable-nodpi", "glitch_dragon_core.jpg");
if (!fs.existsSync(image)) fail("dragon artwork resource is missing");
const imageBytes = fs.readFileSync(image);
if (imageBytes.length < 100000 || imageBytes[0] !== 0xff || imageBytes[1] !== 0xd8 || imageBytes[2] !== 0xff) {
  fail("dragon artwork is not a valid retained JPEG resource");
}

let version;
try {
  version = JSON.parse(read("core", "version.json"));
} catch (error) {
  fail(`core/version.json is invalid: ${error.message}`);
}
if (version.source_zip !== "CLIENT_CFv2.0.0_SWRLZ.zip" || version.versionCode !== 31 || version.interface_default !== "user") {
  fail("core/version.json does not identify CFv2.0.0 User Mode default");
}

const forbidden = walk(root).filter((file) => {
  const relative = path.relative(root, file).replaceAll("\\", "/");
  return relative === "android/local.properties" || /\.(apk|aab|jks|keystore)$/i.test(relative);
});
if (forbidden.length) fail(`forbidden generated or secret-bearing files present: ${forbidden.map((file) => path.relative(root, file)).join(", ")}`);

process.stdout.write(`UI-IMP-004 STATIC VERIFY PASS — ${kotlinFiles.length} Kotlin files, ${legacyScreens.length} legacy Dev surfaces, dual-mode persistence, CF8/Ktor guards, CFv2 identity\n`);
