package sh.swurlz.core.net
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
object GroupClientApi {
 data class Result(val ok:Boolean,val code:String,val detail:String,val payload:String="")
 private fun request(base:String,path:String,method:String="POST",body:JSONObject?=null):Result = runCatching {
  val c=(URL(base.trimEnd('/')+path).openConnection() as HttpURLConnection).apply{requestMethod=method;connectTimeout=2500;readTimeout=2500;doOutput=body!=null;setRequestProperty("Content-Type","application/json")}
  if(body!=null)c.outputStream.use{it.write(body.toString().toByteArray())}; val text=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()}; val j=JSONObject(text); Result(j.optBoolean("ok"),j.optString("code",if(j.optBoolean("ok"))"OK" else "ERROR"),j.optString("detail",text),text)
 }.getOrElse{Result(false,"NETWORK_ERROR",it.message?:"Group action failed")}
 fun create(base:String,name:String,leaderNodeId:String)=request(base,"/v1/groups/create",body=JSONObject().put("name",name).put("leaderNodeId",leaderNodeId))
 fun join(base:String,code:String,nodeId:String,label:String)=request(base,"/v1/groups/join",body=JSONObject().put("inviteCode",code).put("nodeId",nodeId).put("nodeLabel",label).put("deviceType","android-client").put("capabilities","chat,missions,presence").put("registrationState","REGISTERED").put("trustState","UNTRUSTED").put("proofState","PENDING"))
 fun list(base:String,nodeId:String)=request(base,"/v1/groups/list",body=JSONObject().put("nodeId",nodeId))
 fun rotate(base:String,groupId:String,leaderNodeId:String)=request(base,"/v1/groups/invite/rotate","POST",JSONObject().put("groupId",groupId).put("leaderNodeId",leaderNodeId))
}