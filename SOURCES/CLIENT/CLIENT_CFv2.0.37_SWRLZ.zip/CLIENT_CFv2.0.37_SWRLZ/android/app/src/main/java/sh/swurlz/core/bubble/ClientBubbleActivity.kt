package sh.swurlz.core.bubble

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class ClientBubbleActivity : ComponentActivity() {

    companion object {
        const val EXTRA_SECTION = "bubble_section"
        const val EXTRA_SOURCE_ROLE = "bubble_source_role"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val requested = intent.getStringExtra(EXTRA_SECTION)?.let {
                runCatching { BubbleSection.valueOf(it) }.getOrNull()
            }
            var section by remember {
                mutableStateOf(
                    requested ?: if (BubbleStateStore.restoreAfterRestart(this)) {
                        BubbleStateStore.section(this)
                    } else BubbleSection.HOME
                )
            }
            var restore by remember { mutableStateOf(BubbleStateStore.restoreAfterRestart(this)) }
            var mode by remember { mutableStateOf(BubbleStateStore.mode(this)) }
            var dockEnabled by remember { mutableStateOf(BubbleStateStore.interactiveDockEnabled(this)) }
            var keepOriginals by remember { mutableStateOf(BubbleStateStore.keepOriginalsWhenFused(this)) }
            var overlayGranted by remember { mutableStateOf(InteractiveBubbleDockService.canDraw(this)) }
            val sourceRole = intent.getStringExtra(EXTRA_SOURCE_ROLE)

            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("SWRLZ · CLIENT", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                            Spacer(Modifier.weight(1f))
                            AssistChip(onClick = {}, label = { Text(mode.name.replace('_', ' ')) })
                        }
                        Text(
                            when (sourceRole) {
                                "SERVER" -> "Remote SWURLZER control surface"
                                "FUSION" -> "SWURVER unified command surface"
                                else -> "Persistent crystal command bubble"
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )

                        RadialMenu(section) { next ->
                            section = next
                            BubbleStateStore.setSection(this@ClientBubbleActivity, next)
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            tonalElevation = 4.dp,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                        ) {
                            Column(
                                Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Text(section.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(contentFor(section))

                                if (section == BubbleSection.SETTINGS || section == BubbleSection.FUSION) {
                                    HorizontalDivider()
                                    Text("Interactive Bubble Dock", fontWeight = FontWeight.Bold)

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = dockEnabled,
                                            onCheckedChange = { enabled ->
                                                dockEnabled = enabled
                                                BubbleStateStore.setInteractiveDockEnabled(this@ClientBubbleActivity, enabled)
                                                if (enabled && overlayGranted) {
                                                    InteractiveBubbleDockService.start(this@ClientBubbleActivity, mode)
                                                } else if (!enabled) {
                                                    InteractiveBubbleDockService.stop(this@ClientBubbleActivity)
                                                }
                                            },
                                        )
                                        Text(" Enable Client-owned fusion bubbles", modifier = Modifier.padding(start = 8.dp))
                                    }

                                    if (!overlayGranted) {
                                        Text("Display over other apps is required for drag-to-fuse bubbles.")
                                        Button(onClick = {
                                            startActivity(
                                                Intent(
                                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                    Uri.parse("package:$packageName"),
                                                )
                                            )
                                        }) { Text("Grant overlay permission") }
                                    } else {
                                        Text("Overlay permission granted", color = MaterialTheme.colorScheme.primary)
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = keepOriginals,
                                            onCheckedChange = {
                                                keepOriginals = it
                                                BubbleStateStore.setKeepOriginalsWhenFused(this@ClientBubbleActivity, it)
                                            },
                                        )
                                        Text(" Keep Client and SWURLZER bubbles after fusion", modifier = Modifier.padding(start = 8.dp))
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = restore,
                                            onCheckedChange = {
                                                restore = it
                                                BubbleStateStore.setRestoreAfterRestart(this@ClientBubbleActivity, it)
                                            },
                                        )
                                        Text(" Restore last bubble page", modifier = Modifier.padding(start = 8.dp))
                                    }

                                    Text("Bubble layout")
                                    BubbleLayoutMode.entries.forEach { candidate ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(
                                                selected = mode == candidate,
                                                onClick = {
                                                    mode = candidate
                                                    BubbleStateStore.setMode(this@ClientBubbleActivity, candidate)
                                                    if (dockEnabled && overlayGranted) {
                                                        InteractiveBubbleDockService.start(this@ClientBubbleActivity, candidate)
                                                    }
                                                },
                                            )
                                            Text(candidate.name.replace('_', ' '))
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            enabled = overlayGranted,
                                            onClick = {
                                                dockEnabled = true
                                                BubbleStateStore.setInteractiveDockEnabled(this@ClientBubbleActivity, true)
                                                InteractiveBubbleDockService.start(this@ClientBubbleActivity, mode)
                                            },
                                        ) { Text("Launch dock") }
                                        OutlinedButton(onClick = {
                                            dockEnabled = false
                                            BubbleStateStore.setInteractiveDockEnabled(this@ClientBubbleActivity, false)
                                            InteractiveBubbleDockService.stop(this@ClientBubbleActivity)
                                        }) { Text("Stop dock") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (BubbleStateStore.interactiveDockEnabled(this) && InteractiveBubbleDockService.canDraw(this)) {
            InteractiveBubbleDockService.start(this, BubbleStateStore.mode(this))
        }
    }

    @Composable
    private fun RadialMenu(selected: BubbleSection, onSelect: (BubbleSection) -> Unit) {
        val items = listOf(
            BubbleSection.CHAT,
            BubbleSection.MISSIONS,
            BubbleSection.NODES,
            BubbleSection.LOGS,
            BubbleSection.ASSISTANTS,
            BubbleSection.FUSION,
            BubbleSection.SETTINGS,
            BubbleSection.HOME,
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            items.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { item ->
                        OutlinedButton(
                            onClick = { onSelect(item) },
                            shape = CircleShape,
                            border = BorderStroke(
                                if (selected == item) 2.dp else 1.dp,
                                MaterialTheme.colorScheme.primary,
                            ),
                            contentPadding = PaddingValues(8.dp),
                            modifier = Modifier.size(72.dp),
                        ) {
                            Text(item.name.take(4), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    private fun contentFor(section: BubbleSection): String = when (section) {
        BubbleSection.HOME -> "Quick access ring. Your last page is remembered when enabled."
        BubbleSection.CHAT -> "Conversation surface and message controls."
        BubbleSection.MISSIONS -> "Mission status, pause/resume, approvals, and takeover."
        BubbleSection.NODES -> "Authenticated remote SWURLZER status and permitted server actions, presented by the Client."
        BubbleSection.LOGS -> "Recent events, notifications, and communication history."
        BubbleSection.ASSISTANTS -> "Assistant packs and swarm controls."
        BubbleSection.SETTINGS -> "Persistence, relaunch behavior, and interactive bubble layout."
        BubbleSection.FUSION -> "Drag the Client and remote SWURLZER bubbles together. The Client creates a SWURVER fusion bubble and preserves or hides the originals according to your setting."
    }
}
