# CLIENT CFv2.0.53

- Added the first separate SWRLZ CLIENT bubble interface overhaul.
- Replaced the default light Material panel with the saved SWRLZ theme and a compact crystal cockpit.
- Added full navigation labels, icons, responsive crystal tiles, truthful CLIENT/SERVER-link status, and an Open Full Client action.
- Kept CLIENT identity independent instead of visually morphing into SWURVER when a SERVER session exists.
- Added an always-visible `CLIENT · CFv2.0.53` footer derived from `BuildConfig.VERSION_NAME`.
- Corrected stale Android/source identity fields inherited by the CFv2.0.52 archive.
- Reserved the fusion interface for a later pass after CLIENT and SERVER surfaces are accepted.
- Advanced Android identity to versionCode 80 / versionName `2.0.53-client-bubble-interface-v1`.

# CLIENT CFv2.0.52

- Added authoritative Forge phase projection in the CLIENT top bar.
- Added persisted Source ZIP Content Guard with pre-network APK/artifact rejection and source-structure heuristics.
- Preserved exact ZIP/SHA-256 validation and truthful phase-based workflow reporting.

# CLIENT CFv2.0.41 — Native Bubble Admin Morph

## CFv2.0.52
- Removed six unused CLIENT launcher/fusion resource artifacts.
- Preserved all launcher identity resources still referenced by aliases and ThemeIdentityManager.
- Added a conservative resource audit utility and checkpoint documentation.
- Advanced CLIENT build identity to versionCode 79.


- Replaced the experimental three-overlay dock with one Android-managed conversation bubble.
- Corrected identity mapping: SWRLZ Client = cyan/blue; SWURLZER Server = purple; authenticated fusion = SWURVER.
- Added verified-admin-driven bubble identity morphing.
- Prevented bubble taps from spawning separate CLIENT/SERVER/FUSION activity windows.
- Removed excess light padding from bubble avatar resources.

# CLIENT CFv2.0.40

- Added GitHub Forge mass routing for CLIENT and SERVER source packages.
- Added workflow-run observation and Actions artifact download/save support.
- Preserved encrypted GitHub authentication and atomic multi-file commits.

# Changelog

## CFv2.0.32 — Bubble build correction
- Corrected `LocusId` to use the public `android.content.LocusId` API.
- Removed the incompatible explicit Compose `weight` import from the Client bubble activity.
- Advanced Android `versionCode` to 61.
- Added `docs/implementation/INT_CHAT_032D_BUBBLE_BUILD_CORRECTION.md`.

## CFv2.0.31 — Persistent Client notification surface

- Added `ClientStatusService` so Client status remains available outside `MainActivity`.
- Added live notification updates for server connection, endpoint, mission, session evidence, and theme.
- Added a notification-permission guard before foreground startup.
- Introduced a fresh status channel ID to recover from retained legacy channel configuration.
- Kept the Client status notification separate from the Floating Dragon conversation bubble.
- Added `docs/implementation/INT_NOTIFY_034B_PERSISTENT_CLIENT_STATUS_SERVICE.md`.

## CFv2.0.30 — Client status notification recovery

- Requests Android 13+ notification permission on first launch when missing.
- Adds notification permission state and recovery controls to the Permission Centre.
- Republishes the persistent Client status notification after permission approval.
- Keeps server connection, endpoint, mission, and theme details in the expanded notification.
- Documents notification-channel and user-controlled permission limitations.

## CLIENT CFv2.0.30 — Client notification status recovery

- Restored the persistent Client status notification using a fresh Android notification channel.
- Raised the status channel from low to default importance while retaining update-only alert behavior.
- Added an Android 13+ notification permission guard.
- Decoupled the Client status widget from the Floating Dragon bubble lifecycle.
- Added `INT_NOTIFY_034A_CLIENT_STATUS_NOTIFICATION_RECOVERY.md`.

## Unreleased

- Added themed Floating Dragon bubble UI and hardened Android conversation registration.
- Bubble settings now register the conversation before opening system settings.

## Permission priority, live node status, and explicit bubble controls

- Moved the sideloaded-app restricted-settings guide to the top of the Client Permission Centre.
- Added authoritative online/offline/registered node totals to the Server notification.
- Added explicit Client server-connection evidence to its notification.
- Added manual Floating Dragon launch and Android bubble-settings controls.
- Connected the Client telemetry side puck and strip to Floating Dragon.
- Corrected the Server bubble namespace and connected it to live runtime/node state.
- Documented the release in ADR-0022 and INT-UX-033A.

## Floating Dragon bubble release

## Floating Dragon build correction

- Corrected AndroidX conversation Person and IconCompat usage.
- Corrected client permission-route compilation.
- Removed fragile server generated-class dependencies from the bubble feature.


- Added Android-native conversation bubbles for compact SWRLZ chat and mission/server status.
- Added dedicated resizeable bubble activities and long-lived conversation shortcuts.
- Preserved full-app authority for sensitive actions.
- Documented phased chat transport boundaries in ADR-0021.

# Changelog

## INT-UX-031A

- Moved Accept All to the client first-mission acknowledgement screen.
- Restored the Android permission centre workflow.
- Added default-on, theme-aware client/server notification status widgets.
- Preserved Android's mandatory server foreground-service notification.

# CLIENT CFv2.0.23 (2026-07-23)

- Protocol v2 device continuity registration.
- Raw ANDROID_ID removed from registration payload.
- Canonical SERVER node ID retained for subsequent presence calls.

# CLIENT CFv2.0.22 — INT-UI-028D

- Added a SERVER-authoritative group overview to the Core session card.
- Shows group role plus online-versus-active device counts.
- Supports zero, one, and multiple group memberships with truthful unavailable states.
- Added tap-through navigation to the dedicated Groups workspace.
- Advanced Android identity to versionCode 51 and versionName `0.2.7.26-cfv2.0.22-int-ui-028d`.
- Source-only package; no build or runtime verification performed.

# CLIENT CFv2.0.18 — INT-FIX-026E

- Replaced the invalid `tokens.status.error` reference with canonical `tokens.status.danger`.
- Advanced Android identity to `versionCode` 47 and `versionName` `0.2.7.22-cfv2.0.18-int-fix-026e`.
- Recorded the CLIENT CFv2.0.17 GitHub compilation failure and the user-reported SERVER CFv2.0.17 build success.
- Preserved all group, heartbeat, trust, identity, offline-first, lineage, and Truth Firewall behavior.
- Source-only package; compilation and runtime verification were not run.

# CLIENT CFv2.0.17 — INT-FIX-026C

- Repaired SERVER group-list dispatch.
- Added canonical role, membership-state, leader, and member-count data.
- Added live roster retrieval and readable CLIENT synchronization errors.
- Prevented failed group requests from being labeled synchronized.

# INT-UX-026A — Navigation and Groups Workspace

- Added horizontally swipeable bottom navigation.
- Added a dedicated Groups destination.
- Added richer group creation, join, inspection, synchronization, and assignment UI while preserving SERVER authority.
- Advanced package identity to CFv2.0.16.
- No APK build or runtime verification was performed.

# CLIENT CFv2.0.15

- Completed visible group-management dialogs, lists, assignment controls, and immediate post-mutation refresh.
- Corrected prior foundation-only UI claims.

# Changelog

## CLIENT CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.

## CLIENT CFv2.0.19 — INT-FIX-027D

- Sanitized nested SERVER discovery errors in the Groups workspace.
- Preserved raw response payloads for developer diagnostics while removing raw JSON from user-facing status text.
- Classified unsupported Groups routes as a CLIENT/SERVER compatibility condition.
- Disabled group creation and join submission until authoritative group synchronization succeeds.
- Confirmed SERVER CFv2.0.17 already exposes the canonical `/v1/groups/*` route set; no SERVER source change was required.
## CFv2.0.24
- Installable-update version bump, permission onboarding, and guided Accept All flow.
## CLIENT CFv2.0.38 — GitHub Forge
- Added More → GitHub Forge for multi-file Android document selection.
- Added atomic Git Data API commits that bypass the 25 MiB website uploader.
- Added encrypted fine-grained GitHub token storage.
- Added optional workflow_dispatch after a successful commit.


## CLIENT CFv2.0.39 — GitHub Device Authorization

- Added GitHub browser sign-in through the OAuth Device Authorization Flow.
- Added encrypted OAuth Client ID and access-token persistence.
- Added connected-account verification through `GET /user`.
- Added disconnect and manual fine-grained-token fallback controls.
- GitHub Forge upload controls remain locked until authentication succeeds.
- Multi-file atomic commit and optional workflow dispatch remain preserved.