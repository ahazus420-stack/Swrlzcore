package sh.swurlz.core.bubble

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Article
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.MainActivity
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.net.AdminRoutePolicy
import sh.swurlz.core.ui.theme.SwurlzTheme

/**
 * Separate SWRLZ CLIENT bubble surface.
 *
 * This activity always presents CLIENT identity. A verified SERVER session is shown
 * as linked state, but it never visually converts the CLIENT into SWURVER. The fused
 * interface remains a separate later-stage surface.
 */
class ClientBubbleActivity : ComponentActivity() {

    companion object {
        const val EXTRA_SECTION = "bubble_section"
        const val EXTRA_SOURCE_ROLE = "bubble_source_role"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val style by Prefs.uiStyleFlow(this@ClientBubbleActivity)
                .collectAsState(initial = UiStyleSettings())
            val requested = intent.getStringExtra(EXTRA_SECTION)?.let {
                runCatching { BubbleSection.valueOf(it) }.getOrNull()
            }
            var section by remember {
                mutableStateOf(
                    requested ?: if (BubbleStateStore.restoreAfterRestart(this)) {
                        BubbleStateStore.section(this)
                    } else {
                        BubbleSection.HOME
                    },
                )
            }
            var restore by remember { mutableStateOf(BubbleStateStore.restoreAfterRestart(this)) }
            var verifiedAdmin by remember { mutableStateOf(false) }
            var adminUser by remember { mutableStateOf("") }

            LaunchedEffect(Unit) {
                val admin = withContext(Dispatchers.IO) {
                    Prefs.adminSession(this@ClientBubbleActivity)
                }
                val token = withContext(Dispatchers.IO) {
                    SecretStore.adminSessionToken(this@ClientBubbleActivity)
                }
                verifiedAdmin = AdminRoutePolicy.hasVerifiedSession(
                    modeEnabled = admin.modeEnabled,
                    savedToken = token,
                    lastVerifiedAt = admin.lastVerifiedAt,
                )
                adminUser = admin.username
            }

            SwurlzTheme(style) {
                ClientBubbleScreen(
                    section = section,
                    restore = restore,
                    verifiedAdmin = verifiedAdmin,
                    adminUser = adminUser,
                    onSection = { next ->
                        section = next
                        BubbleStateStore.setSection(this@ClientBubbleActivity, next)
                    },
                    onRestore = { enabled ->
                        restore = enabled
                        BubbleStateStore.setRestoreAfterRestart(this@ClientBubbleActivity, enabled)
                    },
                    onOpenFullApp = {
                        startActivity(Intent(this@ClientBubbleActivity, MainActivity::class.java))
                    },
                )
            }
        }
    }
}

private data class ClientDestination(
    val section: BubbleSection,
    val label: String,
    val icon: ImageVector,
)

private val clientDestinations = listOf(
    ClientDestination(BubbleSection.HOME, "HOME", Icons.Default.Home),
    ClientDestination(BubbleSection.CHAT, "CHAT", Icons.Default.Chat),
    ClientDestination(BubbleSection.MISSIONS, "MISSIONS", Icons.Default.Flag),
    ClientDestination(BubbleSection.NODES, "NODES", Icons.Default.Devices),
    ClientDestination(BubbleSection.LOGS, "LOGS", Icons.Default.Article),
    ClientDestination(BubbleSection.ASSISTANTS, "AI CREW", Icons.Default.SmartToy),
    ClientDestination(BubbleSection.SETTINGS, "SETTINGS", Icons.Default.Settings),
    ClientDestination(BubbleSection.FUSION, "FUSION", Icons.Default.MergeType),
)

@Composable
private fun ClientBubbleScreen(
    section: BubbleSection,
    restore: Boolean,
    verifiedAdmin: Boolean,
    adminUser: String,
    onSection: (BubbleSection) -> Unit,
    onRestore: (Boolean) -> Unit,
    onOpenFullApp: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = colors.background,
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            colors.background,
                            colors.primary.copy(alpha = 0.10f),
                            colors.background,
                        ),
                    ),
                ),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ClientHeader(verifiedAdmin = verifiedAdmin, adminUser = adminUser)
                DestinationGrid(selected = section, onSelect = onSection)
                ClientSectionPanel(
                    section = section,
                    restore = restore,
                    verifiedAdmin = verifiedAdmin,
                    onRestore = onRestore,
                    onOpenFullApp = onOpenFullApp,
                    modifier = Modifier.weight(1f),
                )
                BuildFooter(
                    role = "CLIENT",
                    displayVersion = cfVersion(BuildConfig.VERSION_NAME),
                    versionName = BuildConfig.VERSION_NAME,
                    versionCode = BuildConfig.VERSION_CODE,
                )
            }
        }
    }
}

@Composable
private fun ClientHeader(verifiedAdmin: Boolean, adminUser: String) {
    val colors = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = colors.surface.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, colors.primary.copy(alpha = 0.48f)),
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(colors.primary, colors.tertiary),
                            ),
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("S", fontWeight = FontWeight.Black, color = colors.onPrimary)
                }
                Spacer(Modifier.size(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "SWRLZ · CLIENT",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        "Local conversation and command cockpit",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.onSurface.copy(alpha = 0.72f),
                    )
                }
                AssistChip(
                    onClick = {},
                    label = {
                        Text(
                            if (verifiedAdmin) "SERVER LINKED" else "LOCAL",
                            maxLines = 1,
                        )
                    },
                )
            }
            if (verifiedAdmin && adminUser.isNotBlank()) {
                Text(
                    text = "Authenticated SERVER context · $adminUser",
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.secondary,
                )
            }
        }
    }
}

@Composable
private fun DestinationGrid(
    selected: BubbleSection,
    onSelect: (BubbleSection) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        clientDestinations.chunked(4).forEach { rowItems ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                rowItems.forEach { item ->
                    DestinationTile(
                        item = item,
                        selected = selected == item.section,
                        onClick = { onSelect(item.section) },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                    )
                }
            }
        }
    }
}

@Composable
private fun DestinationTile(
    item: ClientDestination,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    val accent = if (selected) colors.primary else colors.outline
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = if (selected) colors.primary.copy(alpha = 0.18f) else colors.surface.copy(alpha = 0.78f),
        border = BorderStroke(if (selected) 2.dp else 1.dp, accent.copy(alpha = 0.78f)),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .clickable(role = Role.Button, onClick = onClick)
                .padding(PaddingValues(horizontal = 5.dp, vertical = 8.dp)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                imageVector = item.icon,
                contentDescription = item.label,
                tint = if (selected) colors.primary else colors.onSurface.copy(alpha = 0.78f),
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.height(5.dp))
            Text(
                item.label,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = if (selected) FontWeight.Black else FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ClientSectionPanel(
    section: BubbleSection,
    restore: Boolean,
    verifiedAdmin: Boolean,
    onRestore: (Boolean) -> Unit,
    onOpenFullApp: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = MaterialTheme.colorScheme
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = colors.surface.copy(alpha = 0.90f),
        border = BorderStroke(1.dp, colors.primary.copy(alpha = 0.28f)),
        tonalElevation = 4.dp,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                titleFor(section),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = colors.primary,
            )
            Text(
                descriptionFor(section, verifiedAdmin),
                style = MaterialTheme.typography.bodyMedium,
            )

            when (section) {
                BubbleSection.HOME -> {
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.28f))
                    StatusLine("LOCAL CONTROL", "READY", colors.primary)
                    StatusLine("SERVER LINK", if (verifiedAdmin) "AUTHENTICATED" else "NOT LINKED", if (verifiedAdmin) colors.secondary else colors.outline)
                    StatusLine("RESTORE PAGE", if (restore) "ON" else "OFF", colors.tertiary)
                }

                BubbleSection.SETTINGS -> {
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.28f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = restore, onCheckedChange = onRestore)
                        Text(
                            "Restore the last CLIENT bubble page",
                            modifier = Modifier.padding(start = 10.dp),
                        )
                    }
                }

                BubbleSection.FUSION -> {
                    HorizontalDivider(color = colors.outline.copy(alpha = 0.28f))
                    Text(
                        "Fusion UI is intentionally deferred until the separate CLIENT and SERVER bubble surfaces pass visual and authority testing.",
                        color = colors.secondary,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }

                else -> Unit
            }

            Button(onClick = onOpenFullApp) {
                Icon(Icons.Default.OpenInNew, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("OPEN FULL CLIENT")
            }
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String, accent: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(RoundedCornerShape(50))
                .background(accent),
        )
        Text(
            label,
            modifier = Modifier.padding(start = 8.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.72f),
        )
        Spacer(Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun BuildFooter(
    role: String,
    displayVersion: String,
    versionName: String,
    versionCode: Int,
) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(colors.surface.copy(alpha = 0.82f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "$role · $displayVersion",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Black,
            color = colors.primary,
        )
        Spacer(Modifier.weight(1f))
        Text(
            "$versionName · VC $versionCode",
            style = MaterialTheme.typography.labelSmall,
            color = colors.onSurface.copy(alpha = 0.54f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private fun cfVersion(versionName: String): String = "CFv${versionName.substringBefore('-')}"

private fun titleFor(section: BubbleSection): String = when (section) {
    BubbleSection.HOME -> "CLIENT OVERVIEW"
    BubbleSection.CHAT -> "CLIENT CHAT"
    BubbleSection.MISSIONS -> "CLIENT MISSIONS"
    BubbleSection.NODES -> "CLIENT NODES"
    BubbleSection.LOGS -> "CLIENT LOGS"
    BubbleSection.ASSISTANTS -> "AI CREW"
    BubbleSection.SETTINGS -> "CLIENT SETTINGS"
    BubbleSection.FUSION -> "FUSION STAGING"
}

private fun descriptionFor(section: BubbleSection, verifiedAdmin: Boolean): String = when (section) {
    BubbleSection.HOME -> "Quick local status and trusted entry points. CLIENT identity remains independent from SERVER and fusion state."
    BubbleSection.CHAT -> "Conversation surface for local-first messages, capability results, and future approval-aware commands."
    BubbleSection.MISSIONS -> "Mission progress, pause and resume, approvals, takeover, and emergency-stop entry points."
    BubbleSection.NODES -> if (verifiedAdmin) {
        "A verified SERVER session is available. Administrative actions still require command-level authorization."
    } else {
        "Local node visibility remains available. Authenticate a SERVER session before administrative controls are projected."
    }
    BubbleSection.LOGS -> "Recent CLIENT events, notifications, communication history, Forge activity, and exported diagnostics."
    BubbleSection.ASSISTANTS -> "Assistant packs, local models, swarm status, and future specialist controls."
    BubbleSection.SETTINGS -> "CLIENT bubble persistence and compact-surface preferences. Visual state never grants authority."
    BubbleSection.FUSION -> "Reserved for the later SWURVER interface pass after the separate CLIENT and SERVER designs are accepted."
}
