package sh.swurlz.core.github

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Lightweight process-local Forge state used by the CLIENT shell header. */
object ForgeRuntimeState {
    enum class Phase(val label: String) {
        IDLE("IDLE"),
        VALIDATING("VALIDATING"),
        UPLOADING("UPLOADING"),
        BUILDING("BUILDING"),
        DOWNLOADING("DOWNLOADING"),
        ARTIFACTS_READY("ARTIFACTS READY"),
        COMPLETE("COMPLETE"),
        FAILED("FAILED"),
    }

    var phase by mutableStateOf(Phase.IDLE)
        private set

    fun publish(next: Phase) {
        phase = next
    }
}
