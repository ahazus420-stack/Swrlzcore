# CLIENT CFv2.0.54 Build Repair

**Date:** 2026-07-24  
**Baseline:** CLIENT CFv2.0.53  
**Change class:** bounded Kotlin compilation repair

## Trigger evidence

The GitHub APK Router reached `:app:compileDebugKotlin` and failed at:

```text
ClientBubbleActivity.kt:22:43 Cannot access
'val RowColumnParentData?.weight: Float': it is internal in file.
```

## Root cause

`ClientBubbleActivity.kt` explicitly imported:

```kotlin
import androidx.compose.foundation.layout.weight
```

In this Compose/Kotlin toolchain, the import resolved to an internal row/column parent-data property instead of the contextual `ColumnScope.weight` / `RowScope.weight` modifier API. Existing project screens use `Modifier.weight(...)` from Row/Column scope without that explicit import.

## Repair

- Removed the invalid explicit `foundation.layout.weight` import.
- Preserved every contextual `Modifier.weight(...)` call inside its Row or Column receiver scope.
- Advanced Android identity to `versionCode 81` and `versionName 2.0.54-client-bubble-build-repair-v1`.
- Preserved the CLIENT bubble overhaul and visible build footer.

## Evidence status

- Source repair: complete.
- Source ZIP integrity: compressed-data verification passed.
- SHA companion: generated from the final immutable ZIP bytes.
- GitHub build: pending upload and workflow execution.
- Device/runtime acceptance: pending.
