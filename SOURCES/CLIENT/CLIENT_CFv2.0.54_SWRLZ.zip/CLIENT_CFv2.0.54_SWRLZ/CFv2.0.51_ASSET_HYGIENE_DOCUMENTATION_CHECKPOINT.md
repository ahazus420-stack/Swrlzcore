# CLIENT CFv2.0.51 — Asset Hygiene and Documentation Checkpoint

## Scope

This checkpoint performs a conservative Android resource cleanup without removing
the selectable launcher identities implemented by `ThemeIdentityManager`.

## Removed unused CLIENT resources

- `android/app/src/main/res/drawable/ic_launcher_monochrome.xml`
- `android/app/src/main/res/drawable/ic_launcher_foreground.xml`
- `android/app/src/main/res/drawable-nodpi/swrlz_glitch_dragon_launcher_foreground.png`
- `android/app/src/main/res/drawable-nodpi/swurver_fusion_alt.png`
- `android/app/src/main/res/drawable-nodpi/swrlz_glitch_dragon_launcher_foreground_safe.png`
- `android/app/src/main/res/drawable-nodpi/ic_launcher_glitch_dragon_foreground.png`

Each removed file had no direct Kotlin, Java, manifest, adaptive-icon, or XML
resource reference in the packaged source.

## Intentionally retained

The `GlitchDragon`, `OriginalCore`, `GlitchNeon`, `PharaohEmerald`, and
`VoidJester` mipmap families remain because they are referenced by launcher
activity aliases and `ThemeIdentityManager`. They are not dead assets even when
the current default identity is SWRLZ.

The active bubble artwork remains:

- `swrlz_client_named`
- `swurlzer_server_named`
- `swurver_fusion_named`

## Documentation continuity

This record continues the CFv2.0.x stabilization line. It does not declare the
CFv2.1.0 conversational control plane complete.

## Verification

- Direct resource reference scan completed.
- Manifest and adaptive-icon references preserved.
- Source version advanced to `2.0.51`.
- A conservative audit utility is available at
  `tools/verify_resource_assets.py`.
- Clean Android compilation remains required in CI/Forge.
