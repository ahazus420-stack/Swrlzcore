## Permission priority, live node status, and explicit bubble controls

- Moved the sideloaded-app restricted-settings guide to the top of the Client Permission Centre.
- Added authoritative online/offline/registered node totals to the Server notification.
- Added explicit Client server-connection evidence to its notification.
- Added manual Floating Dragon launch and Android bubble-settings controls.
- Connected the Client telemetry side puck and strip to Floating Dragon.
- Corrected the Server bubble namespace and connected it to live runtime/node state.
- Documented the release in ADR-0022 and INT-UX-033A.

## Floating Dragon bubble release

## Floating Dragon build correction

- Corrected AndroidX conversation Person and IconCompat usage.
- Corrected client permission-route compilation.
- Removed fragile server generated-class dependencies from the bubble feature.


- Added Android-native conversation bubbles for compact SWRLZ chat and mission/server status.
- Added dedicated resizeable bubble activities and long-lived conversation shortcuts.
- Preserved full-app authority for sensitive actions.
- Documented phased chat transport boundaries in ADR-0021.

# Changelog

## INT-UX-031A

- Moved Accept All to the client first-mission acknowledgement screen.
- Restored the Android permission centre workflow.
- Added default-on, theme-aware client/server notification status widgets.
- Preserved Android's mandatory server foreground-service notification.

# CLIENT CFv2.0.23 (2026-07-23)

- Protocol v2 device continuity registration.
- Raw ANDROID_ID removed from registration payload.
- Canonical SERVER node ID retained for subsequent presence calls.

# CLIENT CFv2.0.22 — INT-UI-028D

- Added a SERVER-authoritative group overview to the Core session card.
- Shows group role plus online-versus-active device counts.
- Supports zero, one, and multiple group memberships with truthful unavailable states.
- Added tap-through navigation to the dedicated Groups workspace.
- Advanced Android identity to versionCode 51 and versionName `0.2.7.26-cfv2.0.22-int-ui-028d`.
- Source-only package; no build or runtime verification performed.

# CLIENT CFv2.0.18 — INT-FIX-026E

- Replaced the invalid `tokens.status.error` reference with canonical `tokens.status.danger`.
- Advanced Android identity to `versionCode` 47 and `versionName` `0.2.7.22-cfv2.0.18-int-fix-026e`.
- Recorded the CLIENT CFv2.0.17 GitHub compilation failure and the user-reported SERVER CFv2.0.17 build success.
- Preserved all group, heartbeat, trust, identity, offline-first, lineage, and Truth Firewall behavior.
- Source-only package; compilation and runtime verification were not run.

# CLIENT CFv2.0.17 — INT-FIX-026C

- Repaired SERVER group-list dispatch.
- Added canonical role, membership-state, leader, and member-count data.
- Added live roster retrieval and readable CLIENT synchronization errors.
- Prevented failed group requests from being labeled synchronized.

# INT-UX-026A — Navigation and Groups Workspace

- Added horizontally swipeable bottom navigation.
- Added a dedicated Groups destination.
- Added richer group creation, join, inspection, synchronization, and assignment UI while preserving SERVER authority.
- Advanced package identity to CFv2.0.16.
- No APK build or runtime verification was performed.

# CLIENT CFv2.0.15

- Completed visible group-management dialogs, lists, assignment controls, and immediate post-mutation refresh.
- Corrected prior foundation-only UI claims.

# Changelog

## CLIENT CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.

## CLIENT CFv2.0.19 — INT-FIX-027D

- Sanitized nested SERVER discovery errors in the Groups workspace.
- Preserved raw response payloads for developer diagnostics while removing raw JSON from user-facing status text.
- Classified unsupported Groups routes as a CLIENT/SERVER compatibility condition.
- Disabled group creation and join submission until authoritative group synchronization succeeds.
- Confirmed SERVER CFv2.0.17 already exposes the canonical `/v1/groups/*` route set; no SERVER source change was required.
## CFv2.0.24
- Installable-update version bump, permission onboarding, and guided Accept All flow.