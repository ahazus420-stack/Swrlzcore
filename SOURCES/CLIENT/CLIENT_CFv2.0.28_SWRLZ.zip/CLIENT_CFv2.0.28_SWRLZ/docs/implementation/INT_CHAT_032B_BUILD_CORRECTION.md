# INT-CHAT-032B — Floating Dragon build correction

## Status
Verified by static source inspection against the failing GitHub Actions compiler logs.

## Failure analysis
The first Floating Dragon release mixed platform notification types with AndroidX compatibility types:

- `android.app.Person` was passed to `NotificationCompat.MessagingStyle`.
- `android.graphics.drawable.Icon` was passed to `NotificationCompat.BubbleMetadata`.
- The client startup route referenced a nonexistent `ClientPermissionState`.
- The server bubble directly imported generated `R` and `MainActivity`, producing unresolved references in the routed source build.

## Resolution
- Use `androidx.core.app.Person` with `NotificationCompat.MessagingStyle`.
- Use `IconCompat` for AndroidX person and bubble metadata APIs.
- Retain a platform `Icon` only for `ShortcutInfo`.
- Resolve the notification icon from `applicationInfo.icon`.
- Reuse the existing `PermissionHelper` for client onboarding routing.
- Open the server through its package launch intent instead of a direct activity dependency.
- Preserve mutable bubble `PendingIntent` behavior required by the platform bubble API.

## Compatibility
No database, protocol, registration identity, trust, or mission-state migration is required.

## Verification gate
GitHub Actions must run `assembleDebug` for both Android components. The correction specifically targets every Kotlin compiler error captured in workflow logs `81381558693` and `81381815881`.
