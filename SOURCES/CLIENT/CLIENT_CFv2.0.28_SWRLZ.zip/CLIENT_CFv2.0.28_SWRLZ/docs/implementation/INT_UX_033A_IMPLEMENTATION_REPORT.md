# INT-UX-033A Implementation Report

## Scope
Permission-centre priority correction, authoritative status-notification summaries, and explicit Floating Dragon controls.

## Client
- Moved the restricted-settings guide above permission grant cards.
- Added explicit connected/offline server wording and endpoint evidence to the status notification.
- Added `OPEN` and `BUBBLE SETTINGS` controls in Client Settings.
- Added `CHAT` to the expanded telemetry overlay.
- Changed the collapsed side puck so tap requests Floating Dragon and long-press expands telemetry.
- Added manual bubble publication with auto-expand requested.

## Server
- Added authoritative online/offline/registered node counts at the top of the foreground notification.
- Connected server conversation updates to live runtime and Room node flows.
- Added `OPEN DRAGON` and `BUBBLE SETTINGS` controls in Server Settings.
- Corrected the bubble package namespace to match `sh.swrlz.nodehost`.

## Versions
- Client: CFv2.0.28, Android `versionCode 57`
- Server: CFv2.0.25, Android `versionCode 27`

## Test status
Static verification passed. Gradle compilation was attempted for both components but could not start because the required Gradle wrapper distributions were not cached and the sandbox could not resolve `services.gradle.org`.
