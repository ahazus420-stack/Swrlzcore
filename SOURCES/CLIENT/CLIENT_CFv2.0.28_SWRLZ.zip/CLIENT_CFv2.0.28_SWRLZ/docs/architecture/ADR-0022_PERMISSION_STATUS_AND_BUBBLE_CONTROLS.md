# ADR-0022 — Permission Priority, Live Status Notifications, and Explicit Bubble Controls

## Status
Accepted

## Context
Sideloaded Android builds can have Accessibility restricted until the user enables **Allow restricted settings** from the app-info overflow menu. The previous permission screen placed this recovery path below the two permission cards, making the first blocking action difficult to discover.

The first Floating Dragon release created valid Android conversation notifications, but publication alone does not guarantee that a launcher will display a floating bubble. Android and the user retain control over whether a conversation may bubble. The apps therefore need an explicit user action that republishes the conversation with auto-expand requested, plus a direct route to Android bubble settings.

The server status notification also lacked the registered/online node summary users need most often. The client status notification did not clearly identify its server connection state.

## Decision
1. Move the restricted-settings unlock guide to the top of the Client Permission Centre, before Accessibility and overlay controls.
2. Show server node totals first in the expanded server foreground notification:
   - authoritative online nodes (`CONNECTED` or `BUSY`)
   - offline nodes
   - total registered nodes
3. Show explicit `Server: CONNECTED` or `Server: OFFLINE` status in the Client notification and include the configured/discovered server endpoint evidence.
4. Add **Open Dragon** and **Bubble settings** controls to Client and Server settings.
5. Publishing from **Open Dragon** requests bubble auto-expansion. This is a request, not a bypass of Android/user policy.
6. Connect the Client telemetry overlay to Floating Dragon:
   - expanded overlay exposes a `CHAT` control;
   - tapping the collapsed side puck requests the chat bubble;
   - long-pressing the collapsed puck expands telemetry.
7. Correct the Server bubble package namespace to `sh.swrlz.nodehost.bubble`, matching the application namespace and manifest.
8. Publish/update the Server conversation from the live runtime/node flow while the enhanced status notification is enabled.

## Security
- No permission is silently granted.
- Bubble settings remain under Android user control.
- Bubble controls expose status/chat shell behavior only; sensitive operations stay in the trusted full application.
- Server online counts come from authoritative registered node state, not discovery sightings.

## Performance
The server combines existing Room and runtime flows. Notification updates occur only when one of those state flows changes. No polling loop was added.

## Compatibility
Android may still render the conversation as a normal notification when bubbling is disabled globally, disabled for the app, or unsupported by the launcher. The explicit settings route lets the user correct that state.

## Verification
Static source checks verified namespace consistency, manual bubble controls, overlay routing, notification count derivation, and version increments. Full Gradle compilation could not run in the sandbox because the Gradle distributions were not cached and outbound access to `services.gradle.org` was unavailable.
