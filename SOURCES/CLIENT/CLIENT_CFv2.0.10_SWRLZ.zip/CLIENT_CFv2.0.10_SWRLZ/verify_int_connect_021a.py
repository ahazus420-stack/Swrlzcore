from pathlib import Path
r=Path(__file__).resolve().parent
shell=(r/'android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt').read_text()
pres=(r/'android/app/src/main/java/sh/swurlz/core/net/ClientPresenceRegistration.kt').read_text()
icon=(r/'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml').read_text()
gradle=(r/'android/app/build.gradle.kts').read_text()
wf=(r/'.github/workflows/build-apk.yml').read_text()
checks={
 'modern launch auto-connect':'LaunchedEffect(autoConnect, connected)' in shell and 'includeLoopbackRange = true' in shell,
 'disconnect retaining registration':'ClientPresenceRegistration.disconnect' in shell and '/nodes/disconnect' in pres,
 'responsive control':'maxLines = 1' in shell,
 'device binding':'deviceBindingFingerprint' in pres and 'client-"+binding.take(24)' in pres,
 'adaptive full-color path':'<monochrome' not in icon,
 'one-apk embedded workflow':'path: dist/CLIENT_CFv2.0.10_SWRLZ_DEBUG.apk' in wf,
 'version':'versionCode = 41' in gradle and 'cfv2.0.10-int-connect-021a' in gradle,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'), k)
raise SystemExit(0 if all(checks.values()) else 1)
