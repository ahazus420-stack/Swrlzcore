# CLIENT CFv2.0.10 Release Notes

Checkpoint: INT-CONNECT-021A

## Added
- Modern Core-shell launch auto-connect execution.
- Explicit disconnect while retaining durable SERVER registration and saved SERVER configuration.
- Privacy-preserving device-binding fingerprint based on Android-scoped identity and app namespace.

## Changed
- Device node identity is derived from the stable binding rather than installation UUID.
- Connecting state uses a full-width, single-line control.
- Connected state presents DISCONNECT and SERVER DETAILS.
- Adaptive icon metadata omits the broken monochrome layer so launchers use the full-color dragon path.

## Evidence
- SOURCE IMPLEMENTED
- STATIC VERIFICATION PASS
- BUILD NOT RUN
- RUNTIME NOT TESTED
