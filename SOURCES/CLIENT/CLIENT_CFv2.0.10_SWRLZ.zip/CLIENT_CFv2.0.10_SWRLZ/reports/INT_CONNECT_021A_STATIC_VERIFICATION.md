# INT-CONNECT-021A CLIENT Static Verification

PASS:
- modern Core panel contains launch-time auto-connect LaunchedEffect;
- explicit disconnect calls presence disconnect contract;
- stable device-binding fingerprint is submitted;
- connection labels are single-line and responsive;
- adaptive icon XML no longer advertises the broken monochrome layer;
- versionCode 41 / CFv2.0.10 identity present.
