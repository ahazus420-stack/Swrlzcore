package sh.swurlz.core.bubble

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.SwurlzTheme

class ClientBubbleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val style by Prefs.uiStyleFlow(this).collectAsState(initial = UiStyleSettings())
            SwurlzTheme(style) {
                val tokens = LocalSwurlzTokens.current
                val mission = MissionBus.mission.value
                var draft by remember { mutableStateOf("") }
                var transcript by remember { mutableStateOf("Dragon link ready.") }
                val paused = MissionBus.pauseRequest.value

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = tokens.surfaces.bgApp,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(tokens.surfaces.bgApp)
                            .padding(14.dp),
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(
                                color = tokens.surfaces.bgPanel,
                                shape = RoundedCornerShape(22.dp),
                                border = BorderStroke(1.dp, tokens.accents.primary),
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        Text(
                                            text = "Ω",
                                            color = tokens.accents.primary,
                                            style = MaterialTheme.typography.headlineMedium,
                                            fontWeight = FontWeight.Black,
                                        )
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(start = 10.dp),
                                        ) {
                                            Text(
                                                "SWRLZ · CLIENT",
                                                color = tokens.text.primary,
                                                fontWeight = FontWeight.Black,
                                                fontFamily = FontFamily.Monospace,
                                            )
                                            Text(
                                                if (mission.goal.isBlank()) "DRAGON LINK READY" else "MISSION ACTIVE",
                                                color = if (mission.goal.isBlank()) tokens.status.info else tokens.status.success,
                                                fontFamily = FontFamily.Monospace,
                                            )
                                        }
                                        Text(
                                            if (paused) "PAUSED" else "LIVE",
                                            color = if (paused) tokens.status.warning else tokens.status.success,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                        )
                                    }

                                    Surface(
                                        color = tokens.cards.bgAlt,
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, tokens.cards.border),
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp),
                                        ) {
                                            Text(
                                                "CURRENT MISSION",
                                                color = tokens.accents.secondary,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            Text(
                                                mission.goal.ifBlank { "No active mission. Chat link remains available." }.take(180),
                                                color = tokens.text.secondary,
                                            )
                                        }
                                    }

                                    Surface(
                                        color = tokens.cards.bg,
                                        shape = RoundedCornerShape(16.dp),
                                        border = BorderStroke(1.dp, tokens.borders.soft),
                                    ) {
                                        Text(
                                            transcript,
                                            modifier = Modifier.padding(12.dp),
                                            color = tokens.text.primary,
                                        )
                                    }

                                    OutlinedTextField(
                                        value = draft,
                                        onValueChange = { draft = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Message Swurlz") },
                                        maxLines = 3,
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    ) {
                                        Button(
                                            onClick = {
                                                val text = draft.trim()
                                                if (text.isNotEmpty()) {
                                                    transcript = "You: $text"
                                                    draft = ""
                                                }
                                            },
                                            enabled = draft.isNotBlank(),
                                            modifier = Modifier.weight(1f),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = tokens.buttons.primaryBg,
                                                contentColor = tokens.buttons.primaryText,
                                            ),
                                            border = BorderStroke(1.dp, tokens.buttons.primaryBorder),
                                        ) {
                                            Text("SEND", fontWeight = FontWeight.Black)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                                            },
                                            modifier = Modifier.weight(1f),
                                            border = BorderStroke(
                                                1.dp,
                                                if (paused) tokens.status.success else tokens.status.warning,
                                            ),
                                        ) {
                                            Text(if (paused) "RESUME" else "PAUSE")
                                        }
                                    }
                                }
                            }

                            Spacer(Modifier.height(2.dp))
                            Text(
                                "Floating Dragon · ${style.themePack} · ${style.displayMode}",
                                color = tokens.text.muted,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.align(Alignment.CenterHorizontally),
                            )
                        }
                    }
                }
            }
        }
    }
}
