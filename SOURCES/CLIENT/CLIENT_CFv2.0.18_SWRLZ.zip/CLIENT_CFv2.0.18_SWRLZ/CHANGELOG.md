# CLIENT CFv2.0.18 — INT-FIX-026E

- Replaced the invalid `tokens.status.error` reference with canonical `tokens.status.danger`.
- Advanced Android identity to `versionCode` 47 and `versionName` `0.2.7.22-cfv2.0.18-int-fix-026e`.
- Recorded the CLIENT CFv2.0.17 GitHub compilation failure and the user-reported SERVER CFv2.0.17 build success.
- Preserved all group, heartbeat, trust, identity, offline-first, lineage, and Truth Firewall behavior.
- Source-only package; compilation and runtime verification were not run.

# CLIENT CFv2.0.17 — INT-FIX-026C

- Repaired SERVER group-list dispatch.
- Added canonical role, membership-state, leader, and member-count data.
- Added live roster retrieval and readable CLIENT synchronization errors.
- Prevented failed group requests from being labeled synchronized.

# INT-UX-026A — Navigation and Groups Workspace

- Added horizontally swipeable bottom navigation.
- Added a dedicated Groups destination.
- Added richer group creation, join, inspection, synchronization, and assignment UI while preserving SERVER authority.
- Advanced package identity to CFv2.0.16.
- No APK build or runtime verification was performed.

# CLIENT CFv2.0.15

- Completed visible group-management dialogs, lists, assignment controls, and immediate post-mutation refresh.
- Corrected prior foundation-only UI claims.

# Changelog

## CLIENT CFv2.0.14
### Added
- SERVER-authoritative heartbeat lease metadata and tolerant liveness states.
- Repository checkpoint, ADR, and protocol-history documentation.
- Visible group controls on CLIENT / node detail and Mission Council foundations on SERVER as applicable.

### Changed
- Administrative disconnect now prevents silent immediate reconnection.
- Connection status progresses through delayed and unavailable states before inferred disconnection.

### Preserved
- Offline-first behavior, Truth Firewall, identity lineage, trust gates, SERVER canonical group ownership, and protocol v1 compatibility.
