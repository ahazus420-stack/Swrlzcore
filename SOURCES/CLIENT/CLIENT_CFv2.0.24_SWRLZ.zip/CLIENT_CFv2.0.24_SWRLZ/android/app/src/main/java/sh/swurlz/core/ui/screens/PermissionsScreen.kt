package sh.swurlz.core.ui.screens

import android.Manifest
import android.os.Build
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.PermissionHelper
import sh.swurlz.core.ui.theme.SwurlzColors

object ClientPermissionState {
    fun notificationGranted(context: android.content.Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun allRequiredGranted(context: android.content.Context): Boolean =
        notificationGranted(context) &&
            PermissionHelper.isAccessibilityEnabled(context) &&
            PermissionHelper.isOverlayGranted(context)
}

@Composable
fun PermissionsScreen(onComplete: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }

    fun openNextMissingPermission() {
        when {
            !ClientPermissionState.notificationGranted(ctx) -> Unit
            !PermissionHelper.isAccessibilityEnabled(ctx) -> PermissionHelper.openAccessibility(ctx)
            !PermissionHelper.isOverlayGranted(ctx) -> PermissionHelper.openOverlayPerm(ctx)
        }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        tick++
        openNextMissingPermission()
    }

    fun acceptAll() {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                !ClientPermissionState.notificationGranted(ctx) ->
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            !PermissionHelper.isAccessibilityEnabled(ctx) -> PermissionHelper.openAccessibility(ctx)
            !PermissionHelper.isOverlayGranted(ctx) -> PermissionHelper.openOverlayPerm(ctx)
            else -> onComplete?.invoke()
        }
    }

    DisposableEffect(lifecycleOwner) {
        fun burstRefresh() {
            tick++
            scope.launch {
                repeat(6) {
                    delay(300)
                    tick++
                }
            }
        }
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) burstRefresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        burstRefresh()
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val notification = remember(tick) { ClientPermissionState.notificationGranted(ctx) }
    val accessibility = remember(tick) { PermissionHelper.isAccessibilityEnabled(ctx) }
    val overlay = remember(tick) { PermissionHelper.isOverlayGranted(ctx) }
    val allGranted = notification && accessibility && overlay
    val isSamsung = Build.MANUFACTURER.equals("samsung", ignoreCase = true)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text("▸ PERMISSION CENTRE", color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace,
            fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "Complete setup once. ACCEPT ALL requests Android permissions in sequence; Android still requires you to confirm each protected system screen.",
            color = SwurlzColors.Ash, fontSize = 12.sp,
        )
        Spacer(Modifier.height(12.dp))

        PrimaryButton(
            if (allGranted) "CONTINUE" else "ACCEPT ALL",
            if (allGranted) SwurlzColors.Phosphor else SwurlzColors.Cyan,
        ) {
            if (allGranted) onComplete?.invoke() else acceptAll()
        }

        Spacer(Modifier.height(12.dp))
        PermissionCard(
            "1 · Notifications",
            "Shows connection, mission, and foreground-operation status while SWRLZ is active.",
            notification,
            if (notification) "GRANTED" else "REQUEST NOTIFICATIONS",
        ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        Spacer(Modifier.height(10.dp))
        PermissionCard(
            "2 · Accessibility Service",
            "Allows approved local automation to inspect accessibility nodes and dispatch gestures.",
            accessibility,
            "OPEN ACCESSIBILITY SETTINGS",
        ) { PermissionHelper.openAccessibility(ctx) }

        Spacer(Modifier.height(10.dp))
        PermissionCard(
            "3 · System Overlay",
            "Allows the visible telemetry and emergency-control overlay above other apps.",
            overlay,
            "GRANT OVERLAY PERMISSION",
        ) { PermissionHelper.openOverlayPerm(ctx) }

        Spacer(Modifier.height(20.dp))
        Column(
            Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Runic)
                .background(SwurlzColors.Void).padding(14.dp)
        ) {
            Text("◊  TOGGLE GREYED OUT?  ◊", color = SwurlzColors.Runic,
                fontFamily = FontFamily.Serif, fontSize = 16.sp, letterSpacing = 3.sp,
                fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Some sideloaded builds require Android's Allow restricted settings action before Accessibility can be enabled.",
                color = SwurlzColors.Bone, fontSize = 13.sp, lineHeight = 19.sp,
            )
            Spacer(Modifier.height(14.dp))
            Step("STEP A · Android Restricted Settings",
                "Open app info → tap the top-right menu → Allow restricted settings → return here.")
            PrimaryButton("OPEN APP INFO", SwurlzColors.Phosphor) {
                PermissionHelper.openAppDetails(ctx)
            }
            if (isSamsung) {
                Spacer(Modifier.height(14.dp))
                Step("STEP B · Samsung Auto Blocker",
                    "Auto Blocker can restrict sideloaded-app permissions. Review Security and privacy settings.")
                PrimaryButton("OPEN AUTO BLOCKER", SwurlzColors.Cyan) {
                    PermissionHelper.openSamsungAutoBlocker(ctx)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "SWRLZ re-checks states whenever this screen resumes. No app can silently grant Accessibility or overlay access.",
            color = SwurlzColors.Ash, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
        )
    }
}

@Composable
private fun Step(title: String, body: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title, color = SwurlzColors.Bone, fontFamily = FontFamily.Monospace,
            fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        Text(body, color = SwurlzColors.Ash, fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun PermissionCard(
    title: String,
    body: String,
    granted: Boolean,
    cta: String,
    onClick: () -> Unit,
) {
    Column(
        Modifier.fillMaxWidth()
            .border(1.dp, if (granted) SwurlzColors.Phosphor else SwurlzColors.Border)
            .background(SwurlzColors.Void).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape)
                .background(if (granted) SwurlzColors.Phosphor else SwurlzColors.RiskYellow))
            Spacer(Modifier.width(8.dp))
            Text(title, color = SwurlzColors.Bone, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            Text(if (granted) "GRANTED" else "MISSING",
                color = if (granted) SwurlzColors.Phosphor else SwurlzColors.RiskYellow,
                fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(body, color = SwurlzColors.Ash, fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(10.dp))
        PrimaryButton(cta, if (granted) SwurlzColors.Phosphor else SwurlzColors.Runic, onClick)
    }
}
