package sh.swurlz.core.net
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
object GroupClientApi {
 data class Result(val ok:Boolean,val code:String,val detail:String,val payload:String="")
 private fun post(base:String,path:String,body:JSONObject):Result = runCatching {
  val c=(URL(base.trimEnd('/')+path).openConnection() as HttpURLConnection).apply{requestMethod="POST";connectTimeout=2500;readTimeout=2500;doOutput=true;setRequestProperty("Content-Type","application/json")}
  c.outputStream.use{it.write(body.toString().toByteArray())}; val text=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()}; val j=JSONObject(text); Result(j.optBoolean("ok"),j.optString("code",if(j.optBoolean("ok"))"OK" else "ERROR"),j.optString("detail",text),text)
 }.getOrElse{Result(false,"NETWORK_ERROR",it.message?:"Group action failed")}
 fun create(base:String,name:String,leaderNodeId:String)=post(base,"/v1/groups/create",JSONObject().put("name",name).put("leaderNodeId",leaderNodeId))
 fun join(base:String,code:String,nodeId:String,label:String)=post(base,"/v1/groups/join",JSONObject().put("inviteCode",code).put("nodeId",nodeId).put("nodeLabel",label).put("deviceType","android-client").put("capabilities","chat,missions,presence").put("registrationState","REGISTERED").put("trustState","UNTRUSTED").put("proofState","PENDING"))
}