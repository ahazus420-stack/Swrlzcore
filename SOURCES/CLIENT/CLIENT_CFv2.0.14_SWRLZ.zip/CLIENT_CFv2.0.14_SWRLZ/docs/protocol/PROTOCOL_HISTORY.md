# SWRLZ Protocol History

## Protocol v1 — INT-UX-025B-REV1 extension
- SERVER heartbeat authority metadata added to successful registration/heartbeat responses.
- Fields: authority, sequence, serverTimeEpochMs, intervalMs, delayedAfterMs, unavailableAfterMs, disconnectedAfterMs.
- Administrative disconnect state: DISCONNECTED_ADMIN / ADMIN_DISCONNECTED.
- Compatibility: additive JSON fields; existing v1 clients may ignore unknown fields.
- No trust, proof, identity, or mission-authorization bypass introduced.
