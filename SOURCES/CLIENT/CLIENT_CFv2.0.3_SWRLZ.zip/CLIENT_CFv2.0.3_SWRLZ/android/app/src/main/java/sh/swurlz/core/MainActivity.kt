package sh.swurlz.core

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.ClientInterfaceMode
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.ui.client.ClientShellScreen
import sh.swurlz.core.ui.client.GlitchDragonBackdrop
import sh.swurlz.core.ui.screens.*
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.SwurlzTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            var uiStyle by remember { mutableStateOf(UiStyleSettings()) }
            LaunchedEffect(Unit) { Prefs.uiStyleFlow(ctx).collectLatest { uiStyle = it } }
            SwurlzTheme(uiStyle) { AppNav(uiStyle) }
        }
    }
}

@Composable
fun AppNav(uiStyle: UiStyleSettings) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    var preflightAck by remember { mutableStateOf<Boolean?>(null) }
    var interfaceMode by remember { mutableStateOf<ClientInterfaceMode?>(null) }

    LaunchedEffect(Unit) { Prefs.preflightFlow(ctx).collectLatest { preflightAck = it } }
    LaunchedEffect(Unit) { Prefs.interfaceModeFlow(ctx).collectLatest { interfaceMode = it } }
    if (preflightAck == null || interfaceMode == null) return

    val acknowledged = preflightAck == true
    val selectedMode = interfaceMode ?: ClientInterfaceMode.User
    val startRoute = if (!acknowledged) {
        "preflight"
    } else if (selectedMode == ClientInterfaceMode.Developer) {
        "home"
    } else {
        "client"
    }
    val navEntry by nav.currentBackStackEntryAsState()
    val currentRoute = navEntry?.destination?.route ?: startRoute

    val tokens = LocalSwurlzTokens.current
    fun openRoute(route: String) {
        nav.navigate(route) { launchSingleTop = true }
    }
    fun switchInterface(next: ClientInterfaceMode, route: String) {
        scope.launch { Prefs.setInterfaceMode(ctx, next) }
        nav.navigate(route) {
            popUpTo(nav.graph.startDestinationId) { inclusive = true }
            launchSingleTop = true
        }
    }

    Box(Modifier.fillMaxSize().background(tokens.surfaces.bgApp)) {
        if (acknowledged && currentRoute != "client") {
            GlitchDragonBackdrop(
                motionEnabled = uiStyle.animationLevel != "Off",
                artAlpha = .18f,
            )
            Box(Modifier.fillMaxSize().background(tokens.surfaces.bgApp.copy(alpha = .72f)))
        }

        Column(Modifier.fillMaxSize()) {
            if (acknowledged && currentRoute != "client") {
                DeveloperHeaderBar(
                    onUserMode = { switchInterface(ClientInterfaceMode.User, "client") },
                    onHome = { openRoute("home") },
                    onCockpit = { openRoute("cockpit") },
                    onSkills = { openRoute("skills") },
                    onAllow = { openRoute("allow") },
                    onSetup = { openRoute("setup") },
                    onStyle = { openRoute("style") },
                    onPerms = { openRoute("perms") },
                    onCore = { openRoute("core") },
                    onHowTo = { openRoute("howto") },
                    onInfo = { openRoute("info") },
                    onCommands = { openRoute("commands") },
                    onDiscovery = { openRoute("discovery") },
                    onMore = { openRoute("more") },
                    currentRoute = currentRoute,
                )
            }
            Box(Modifier.fillMaxSize()) {
                NavHost(nav, startDestination = startRoute) {
                composable("preflight") {
                    PreflightScreen(onAcknowledged = {
                        nav.navigate("perms") { popUpTo("preflight") { inclusive = true } }
                    })
                }
                composable("client") {
                    ClientShellScreen(
                        onOpenDeveloper = { switchInterface(ClientInterfaceMode.Developer, "home") },
                        onOpenPermissions = { switchInterface(ClientInterfaceMode.Developer, "perms") },
                        onOpenDiscovery = { switchInterface(ClientInterfaceMode.Developer, "discovery") },
                        onOpenCoreAdmin = { switchInterface(ClientInterfaceMode.Developer, "core") },
                        onOpenStyle = { switchInterface(ClientInterfaceMode.Developer, "style") },
                        onOpenSetup = { switchInterface(ClientInterfaceMode.Developer, "setup") },
                    )
                }
                composable("home") {
                    HomeScreen(
                        onOpenCockpit = { openRoute("cockpit") },
                        onOpenPerms = { openRoute("perms") },
                        onOpenSetup = { openRoute("setup") },
                        onOpenDiscovery = { openRoute("discovery") },
                    )
                }
                composable("cockpit") { CockpitScreen() }
                composable("skills") { SkillsScreen() }
                composable("allow") { AllowlistScreen() }
                composable("setup") { SetupScreen() }
                composable("style") { StyleScreen() }
                composable("perms") { PermissionsScreen() }
                composable("core") { CoreNodeScreen() }
                composable("howto") { HowToScreen() }
                composable("info") { InfoScreen() }
                composable("commands") { CommandsScreen() }
                composable("discovery") { NetworkDiscoveryScreen(onOpenSetup = { openRoute("setup") }, onOpenCore = { openRoute("core") }) }
                composable("more") { MoreScreen(nav) }
                }
            }
        }
    }
}

@Composable
private fun DeveloperHeaderBar(
    onUserMode: () -> Unit,
    onHome: () -> Unit,
    onCockpit: () -> Unit,
    onSkills: () -> Unit,
    onAllow: () -> Unit,
    onSetup: () -> Unit,
    onStyle: () -> Unit,
    onPerms: () -> Unit,
    onCore: () -> Unit,
    onHowTo: () -> Unit,
    onInfo: () -> Unit,
    onCommands: () -> Unit,
    onDiscovery: () -> Unit,
    onMore: () -> Unit,
    currentRoute: String,
) {
    val tokens = LocalSwurlzTokens.current
    val shape = RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp)
    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        tokens.surfaces.bgTopBar.copy(alpha = .92f),
                        tokens.surfaces.bgPanel.copy(alpha = .76f),
                    )
                )
            )
            .border(1.dp, tokens.accents.primary.copy(alpha = .34f), shape)
            .padding(top = statusPadding + 8.dp, bottom = 9.dp),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(37.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(tokens.accents.primary.copy(alpha = .24f), tokens.accents.tertiary.copy(alpha = .30f))))
                    .border(1.dp, tokens.accents.primary.copy(alpha = .62f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                Text("Ω", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text("SWRLZ DEV MODE", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.6.sp)
                Text("FULL LEGACY TOOLSET", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 1.2.sp)
            }
            androidx.compose.material3.OutlinedButton(
                onClick = onUserMode,
                contentPadding = PaddingValues(horizontal = 11.dp, vertical = 5.dp),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                    contentColor = tokens.accents.primary,
                    containerColor = tokens.accents.primary.copy(alpha = .09f),
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, tokens.accents.primary.copy(alpha = .68f)),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text("USER MODE", fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DevTabItem("Home", currentRoute == "home", onHome)
            DevTabItem("Radar", currentRoute == "commands", onCommands)
            DevTabItem("Network", currentRoute == "discovery", onDiscovery)
            DevTabItem("Cockpit", currentRoute == "cockpit", onCockpit)
            DevTabItem("Setup", currentRoute == "setup", onSetup)
            DevTabItem("Style", currentRoute == "style", onStyle)
            val moreSelected = currentRoute in setOf("more", "core", "perms", "allow", "skills", "howto", "info")
            DevTabItem("More", moreSelected, onMore)
        }
    }
}

@Composable
private fun DevTabItem(label: String, selected: Boolean, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    val borderColor by animateColorAsState(if (selected) tokens.tabs.selectedBorder else tokens.tabs.idleBorder, label = "tabBorder")
    val contentColor by animateColorAsState(if (selected) tokens.tabs.selectedText else tokens.tabs.idleText, label = "tabText")
    val bg = if (selected) tokens.tabs.selectedBg else tokens.tabs.idleBg
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = contentColor, containerColor = bg),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, borderColor),
        shape = RoundedCornerShape(13.dp),
        modifier = Modifier.padding(end = 5.dp).height(34.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.2.sp)
            if (selected) Box(Modifier.padding(top = 2.dp).height(2.dp).width(24.dp).background(tokens.tabs.underline))
        }
    }
}

object PermissionHelper {
    fun isAccessibilityEnabled(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == ctx.packageName }
    }

    fun isOverlayGranted(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun openAccessibility(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openOverlayPerm(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openAppDetails(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openSamsungAutoBlocker(ctx: Context) {
        val candidates = listOf(
            ComponentName("com.samsung.android.sm", "com.samsung.android.sm.security.ui.AutoBlockerActivity"),
            ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.security.ui.AutoBlockerActivity"),
        )
        for (cn in candidates) {
            try {
                ctx.startActivity(Intent().setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
        try {
            ctx.startActivity(Intent("android.settings.SECURITY_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            openAppDetails(ctx)
        }
    }
}
