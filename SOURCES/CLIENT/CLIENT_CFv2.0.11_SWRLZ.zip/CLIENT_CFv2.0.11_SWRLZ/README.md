# SWRLZ-Core Android Client

Current source package: **CLIENT CFv2.0.2 — Glitch Dragon Glass Dual-Mode Interface**.

See `README_LATEST_2.7.6.md`, `SWRLZ_CORE_UI_IMP_004_CFV2_DUAL_MODE_OVERHAUL_REPORT.md`, and `RPT_CF8_276_ADMIN_FALLBACK.md`.

## Current app identity

- Version: `0.2.7.7-cfv2.0.2-verified-baseline`
- Code: `33`
- Patch: `2.7.7-CFV2.0.2-VERIFIED-BASELINE`
- Roadmap: `2.7.7`
- Source: `CLIENT_CFv2.0.2_SWRLZ.zip`

## Interface modes

- **User Mode** is the fresh-install default: Core, Chat, Missions, Nodes, and Settings on the animated translucent Glitch Dragon Glass shell.
- **SWRLZ Dev Mode** retains the complete engineering surface: Home, Radar, Network, Cockpit, Setup, Style, Permissions, Core Admin, Skills, Allowlist, How To, Info, and More.
- The selected interface persists locally and can be switched in either direction without deleting configuration, identity, mission, trust, or style state.

## Current server pair

- Local Node Server: `0.7.1 Presence Index`

## Project law

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Preserve local data and taught skills.
- Keep Mentor backend and Local Core Node separate.
- Status colors remain semantic; themes may not lie about operational state.
- User Mode never hides Pause, Take Over, approval state, local-versus-remote identity, or Truth Firewall status.


## 2.7.6-CODEFIX3-DISCOVERY-SCAN-TRIM

- Source: `SRC_2.7.6_CF3_SCAN_TRIM.zip`
- Objective: trim discovery scan overhead by skipping `127.0.0.x` range sweeps by default, while keeping a saved debug toggle for unusual loopback testing.
- Output naming convention: `SRC_` for source, `SHA_` for hashes, `REPORT_` for patch notes, `APK_` for APKs, and `BUNDLE_` for APK download bundles.


## 2.7.6 CF4 - Signing + Reconnect

Adds Connection Memory / Last-Good Node Auto-Reconnect and stable dev signing readiness. Source: `SRC_2.7.6_CF4_SIGN_RECONNECT.zip`.


## INT-CONV-012A communication foundation
See `docs/contracts/SWRLZ_PROTOCOL_AND_DATA_CONTRACTS_V1_INTEGRATED.md` and `reports/INT-CONV-012A_IMPLEMENTATION_REPORT.md` (CLIENT) or `INT-CONV-012A_IMPLEMENTATION_REPORT.md` (SERVER). This is source-only foundation work; no live endpoint is exposed.
