# SWRLZ-Core 2.7.7 — Current CLIENT line

## CFv2.0.0 Glitch Dragon Glass Dual-Mode Interface

The current source candidate is `CLIENT_CFv2.0.2_SWRLZ.zip` with Android
`versionName 0.2.7.7-cfv2.0.2-verified-baseline` / `versionCode 33`.

CFv2.0.2 preserves the GitHub-verified CFv2.0.1 compile repair and CFv2.0.0 interface:

- a default streamlined User Mode with Core, Chat, Missions, Nodes, and Settings;
- translucent Glitch Dragon Glass artwork, crystalline drift, core pulse, scanline, and directional content transitions;
- a persistent User Mode / SWRLZ Dev Mode selector;
- upgraded rounded glass navigation and dragon backdrop for the complete legacy developer toolset;
- reduced-motion behavior controlled by the existing Animation setting;
- direct visibility of Pause, Take Over, approval, Truth Firewall, and local/remote identity boundaries.

## Preserved CF8 Verified Admin Fallback

CF8 preserves CF7 Network Pulse and adds:

- verified-token gating before `/admin/*` routes;
- automatic fallback to `/presence/devices` when admin authentication is absent;
- local-first Forget Admin behavior even when remote revoke is unsupported;
- endpoint-specific HTTP error reporting;
- separate Radar read health versus heartbeat/write-operation health.

See `RPT_CF8_276_ADMIN_FALLBACK.md` for the device evidence and bounded repair.

The v1.0.2 `AdminRoutePolicy.kt`, route-specific Ktor request-path correction, public presence fallback, local-first Forget Admin behavior, and separate Radar read-health state remain unchanged in CFv2.0.0.
