# INT-RUNTIME-014A CLIENT implementation

- Advanced CLIENT to CFv2.0.5 (`versionCode 36`).
- Replaced legacy launcher density assets and adaptive foreground with the supplied crystalline Glitch Dragon artwork.
- Kept manifest launcher references canonical (`@mipmap/ic_launcher`, `@mipmap/ic_launcher_round`).
- Hardened GitHub APK staging: exactly one Gradle debug APK is accepted, exactly one renamed APK is placed in `dist`, and packaging fails on zero or multiple APKs.
- No APK/Gradle build was run here.
- No protocol, Room schema, live endpoint, trust, proof, or deployment change was made.
