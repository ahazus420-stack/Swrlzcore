# INT-UXPACK-019A — CLIENT Implementation Report

Baseline: CLIENT CFv2.0.7
Result: CLIENT CFv2.0.8 source-only

Implemented:
- Nodes removed from primary bottom navigation and integrated into Core as the Core Connection surface.
- Persistent `AUTO-CONNECT ON APP LAUNCH` preference, default enabled.
- Saved-SERVER-first startup connection remains bounded and verification-preserving.
- State-aware CONNECT / RETRY CONNECTION / RECONNECT / CONNECTED labels.
- Final artifact workflow uploads exactly one APK; checksum is a separate artifact.
- Adaptive foreground safe-zone asset, dedicated monochrome asset, round and legacy launcher resources.

Preserved:
- Registration is not trust.
- Proof and Truth Firewall gates remain authoritative.
- No protocol or Room migration.
- No APK build or workflow execution performed.
