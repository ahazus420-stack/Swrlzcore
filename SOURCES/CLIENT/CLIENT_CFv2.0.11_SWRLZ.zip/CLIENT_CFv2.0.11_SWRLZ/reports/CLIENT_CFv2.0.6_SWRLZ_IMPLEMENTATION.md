# CLIENT_CFv2.0.6_SWRLZ Implementation

- INT-PRES-015A
- Automatic registration after verified discovery
- Durable installation identity
- Heartbeat contract
- Client registration state projection

Source-only; no build, push, release, or deployment performed.
