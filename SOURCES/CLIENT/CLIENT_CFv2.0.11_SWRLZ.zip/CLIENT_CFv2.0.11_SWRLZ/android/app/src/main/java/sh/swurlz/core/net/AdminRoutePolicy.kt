package sh.swurlz.core.net

/**
 * Single source of truth for choosing authenticated admin surfaces.
 * A UI preference alone never grants admin routing authority.
 */
object AdminRoutePolicy {
    fun hasVerifiedSession(
        modeEnabled: Boolean,
        savedToken: String,
        lastVerifiedAt: String,
    ): Boolean = modeEnabled && savedToken.isNotBlank() && lastVerifiedAt.isNotBlank()

    fun devicesPath(hasVerifiedSession: Boolean): String =
        if (hasVerifiedSession) "/admin/devices" else "/presence/devices"

    fun queuePath(hasVerifiedSession: Boolean): String? =
        if (hasVerifiedSession) "/admin/queues" else null
}
