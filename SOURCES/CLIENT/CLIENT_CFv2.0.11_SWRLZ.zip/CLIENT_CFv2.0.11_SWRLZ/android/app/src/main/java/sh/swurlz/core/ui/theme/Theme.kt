package sh.swurlz.core.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.model.UiStyleSettings

object SwurlzColors {
    val ObsidianBase = Color(0xFF03030B)
    val TapeAsh = Color(0xFF081020)
    val Void = Color(0xD9040713)
    val Bone = Color(0xFFF7FBFF)
    val Ash = Color(0xFF91A9C0)
    val Phosphor = Color(0xFF4DFFB4)
    val Runic = Color(0xFF9A55FF)
    val Cyan = Color(0xFF38E8FF)
    val Violet = Color(0xFFC45DFF)
    val RiskGreen = Color(0xFF4ADE80)
    val RiskYellow = Color(0xFFEAB308)
    val RiskRed = Color(0xFFEF4444)
    val Border = Color(0xFF29445F)

    fun themeAccent(themePack: String): Color = when (themePack) {
        "Pharaoh Gold", "Pharaoh Emerald" -> Runic
        "Glitch Teal", "Glitch Neon", "Glitch Dragon Glass" -> Cyan
        "Void Jester" -> Violet
        else -> Phosphor
    }

    fun sunlightSurface(enabled: Boolean): Color = if (enabled) Color(0xFF000000) else TapeAsh
}

data class SwurlzStatusColors(
    val success: Color,
    val warning: Color,
    val danger: Color,
    val info: Color,
    val admin: Color,
)

data class SurfaceTokens(
    val bgApp: Color,
    val bgTopBar: Color,
    val bgPanel: Color,
    val bgPanelAlt: Color,
    val bgElevated: Color,
    val bgOverlay: Color,
    val bgScrim: Color,
)

data class TextTokens(
    val primary: Color,
    val secondary: Color,
    val muted: Color,
    val disabled: Color,
    val heading: Color,
    val label: Color,
    val onAccent: Color,
    val inverse: Color,
)

data class BorderTokens(
    val neutral: Color,
    val soft: Color,
    val strong: Color,
    val focus: Color,
    val selected: Color,
)

data class AccentTokens(
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val glow: Color,
    val ornament: Color,
    val highlight: Color,
)

data class ButtonTokens(
    val primaryBg: Color,
    val primaryText: Color,
    val primaryBorder: Color,
    val secondaryBg: Color,
    val secondaryText: Color,
    val secondaryBorder: Color,
    val ghostBg: Color,
    val ghostText: Color,
    val ghostBorder: Color,
    val dangerBg: Color,
    val dangerText: Color,
    val dangerBorder: Color,
)

data class TabTokens(
    val idleBg: Color,
    val idleText: Color,
    val idleBorder: Color,
    val selectedBg: Color,
    val selectedText: Color,
    val selectedBorder: Color,
    val selectedGlow: Color,
    val underline: Color,
)

data class CardTokens(
    val bg: Color,
    val bgAlt: Color,
    val border: Color,
    val selectedBg: Color,
    val selectedBorder: Color,
    val headerBg: Color,
    val chipBg: Color,
    val chipText: Color,
)

data class InputTokens(
    val bg: Color,
    val text: Color,
    val label: Color,
    val placeholder: Color,
    val border: Color,
    val focusedBorder: Color,
    val cursor: Color,
)

data class EffectTokens(
    val shadowSoft: Color,
    val shadowStrong: Color,
    val glowLow: Color,
    val glowMedium: Color,
    val glowHigh: Color,
    val scanline: Color,
)

data class SwurlzThemeTokens(
    val id: String,
    val displayName: String,
    val family: String,
    val variant: String,
    val surfaces: SurfaceTokens,
    val text: TextTokens,
    val borders: BorderTokens,
    val accents: AccentTokens,
    val buttons: ButtonTokens,
    val tabs: TabTokens,
    val cards: CardTokens,
    val inputs: InputTokens,
    val effects: EffectTokens,
    val status: SwurlzStatusColors,
)

private val DefaultStatusColors = SwurlzStatusColors(
    success = Color(0xFF4DFF7A),
    warning = Color(0xFFFFD75A),
    danger = Color(0xFFFF4D5E),
    info = Color(0xFF40EFFF),
    admin = Color(0xFFC95DFF),
)

private val OriginalCoreDark = SwurlzThemeTokens(
    id = "original_core_dark",
    displayName = "Original Core / Dark",
    family = "Original Core",
    variant = "Dark",
    surfaces = SurfaceTokens(Color(0xFF050607), Color(0xFF07090B), Color(0xFF090D10), Color(0xFF0D1216), Color(0xFF11181D), Color(0xEE050607), Color(0xCC000000)),
    text = TextTokens(Color(0xFFF5F7FA), Color(0xFFD5DDE5), Color(0xFF8A969F), Color(0xFF555E66), Color(0xFFFFD75A), Color(0xFF40EFFF), Color(0xFF020304), Color(0xFF050607)),
    borders = BorderTokens(Color(0xFF2A3138), Color(0xFF171D22), Color(0xFF4E5B66), Color(0xFF40EFFF), Color(0xFF4DFF7A)),
    accents = AccentTokens(Color(0xFF40EFFF), Color(0xFFFFD75A), Color(0xFFC95DFF), Color(0xFF40EFFF), Color(0xFFFFD75A), Color(0xFF4DFF7A)),
    buttons = ButtonTokens(Color(0xFF071A0D), Color(0xFF4DFF7A), Color(0xFF4DFF7A), Color(0xFF07171C), Color(0xFF40EFFF), Color(0xFF40EFFF), Color.Transparent, Color(0xFFD5DDE5), Color(0xFF2A3138), Color(0xFF21070A), Color(0xFFFF4D5E), Color(0xFFFF4D5E)),
    tabs = TabTokens(Color(0xFF07090B), Color(0xFFD5DDE5), Color(0xFF252B31), Color(0xFF0B171A), Color(0xFF40EFFF), Color(0xFF40EFFF), Color(0xFF40EFFF), Color(0xFFFFD75A)),
    cards = CardTokens(Color(0xFF080C0F), Color(0xFF0D1216), Color(0xFF2A3138), Color(0xFF07171C), Color(0xFF40EFFF), Color(0xFF050607), Color(0xFF020304), Color(0xFFF5F7FA)),
    inputs = InputTokens(Color(0xFF06090B), Color(0xFFF5F7FA), Color(0xFFD5DDE5), Color(0xFF8A969F), Color(0xFF2A3138), Color(0xFF4DFF7A), Color(0xFF40EFFF)),
    effects = EffectTokens(Color(0x66000000), Color(0xCC000000), Color(0x3340EFFF), Color(0x6640EFFF), Color(0x9940EFFF), Color(0x3340EFFF)),
    status = DefaultStatusColors,
)

private fun glitchNeonDark(): SwurlzThemeTokens = OriginalCoreDark.copy(
    id = "glitch_neon_dark",
    displayName = "Glitch Neon / Dark",
    family = "Glitch Neon",
    surfaces = OriginalCoreDark.surfaces.copy(bgApp = Color(0xFF03020A), bgTopBar = Color(0xFF05030D), bgPanel = Color(0xFF090718), bgPanelAlt = Color(0xFF120B27), bgElevated = Color(0xFF171033)),
    text = OriginalCoreDark.text.copy(primary = Color(0xFFF8F6FF), secondary = Color(0xFFD7D2FF), muted = Color(0xFF8A7DAD), heading = Color(0xFFFF2DFF), label = Color(0xFF00EFFF)),
    borders = OriginalCoreDark.borders.copy(neutral = Color(0xFF352B58), focus = Color(0xFF00EFFF), selected = Color(0xFFFF2DFF)),
    accents = OriginalCoreDark.accents.copy(primary = Color(0xFF00EFFF), secondary = Color(0xFFFF2DFF), tertiary = Color(0xFF7B3CFF), glow = Color(0xFF00EFFF), ornament = Color(0xFFFF2DFF), highlight = Color(0xFF7B3CFF)),
    buttons = OriginalCoreDark.buttons.copy(primaryBg = Color(0xFF071B2A), primaryText = Color(0xFF00EFFF), primaryBorder = Color(0xFF00EFFF), secondaryBg = Color(0xFF210728), secondaryText = Color(0xFFFF2DFF), secondaryBorder = Color(0xFFFF2DFF)),
    tabs = OriginalCoreDark.tabs.copy(selectedBg = Color(0xFF071B2A), selectedText = Color(0xFF00EFFF), selectedBorder = Color(0xFFFF2DFF), selectedGlow = Color(0xFFFF2DFF), underline = Color(0xFF00EFFF)),
    cards = OriginalCoreDark.cards.copy(bg = Color(0xFF070513), bgAlt = Color(0xFF100A24), selectedBg = Color(0xFF0A1930), selectedBorder = Color(0xFF00EFFF)),
    inputs = OriginalCoreDark.inputs.copy(bg = Color(0xFF060412), focusedBorder = Color(0xFFFF2DFF), cursor = Color(0xFF00EFFF)),
    status = SwurlzStatusColors(Color(0xFF44FF88), Color(0xFFFFD84D), Color(0xFFFF3B72), Color(0xFF00EFFF), Color(0xFFD35DFF)),
)

private fun glitchDragonGlassDark(): SwurlzThemeTokens = glitchNeonDark().copy(
    id = "glitch_dragon_glass_dark",
    displayName = "Glitch Dragon Glass / Dark",
    family = "Glitch Dragon Glass",
    surfaces = SurfaceTokens(
        bgApp = Color(0xFF03030B),
        bgTopBar = Color(0xFF070817),
        bgPanel = Color(0xFF0A1020),
        bgPanelAlt = Color(0xFF10152A),
        bgElevated = Color(0xFF151C36),
        bgOverlay = Color(0xF0070A17),
        bgScrim = Color(0xB8000208),
    ),
    text = glitchNeonDark().text.copy(
        primary = Color(0xFFF7FBFF),
        secondary = Color(0xFFD7E7F5),
        muted = Color(0xFF91A9C0),
        heading = Color(0xFF63EFFF),
        label = Color(0xFF8E6BFF),
    ),
    borders = glitchNeonDark().borders.copy(
        neutral = Color(0xFF263B55),
        soft = Color(0xFF15243A),
        strong = Color(0xFF63EFFF),
        focus = Color(0xFF63EFFF),
        selected = Color(0xFF9B62FF),
    ),
    accents = AccentTokens(
        primary = Color(0xFF38E8FF),
        secondary = Color(0xFF5CA8FF),
        tertiary = Color(0xFF9A55FF),
        glow = Color(0xFF38E8FF),
        ornament = Color(0xFFC45DFF),
        highlight = Color(0xFF4DFFCF),
    ),
    buttons = glitchNeonDark().buttons.copy(
        primaryBg = Color(0xFF0A2134),
        primaryText = Color(0xFF63EFFF),
        primaryBorder = Color(0xFF38E8FF),
        secondaryBg = Color(0xFF20123A),
        secondaryText = Color(0xFFC49BFF),
        secondaryBorder = Color(0xFF9A55FF),
    ),
    tabs = glitchNeonDark().tabs.copy(
        idleBg = Color(0x00000000),
        idleText = Color(0xFF91A9C0),
        idleBorder = Color(0xFF263B55),
        selectedBg = Color(0xFF0A2134),
        selectedText = Color(0xFF63EFFF),
        selectedBorder = Color(0xFF38E8FF),
        selectedGlow = Color(0xFF38E8FF),
        underline = Color(0xFF9A55FF),
    ),
    cards = glitchNeonDark().cards.copy(
        bg = Color(0xCC09111F),
        bgAlt = Color(0xB3111830),
        border = Color(0xFF29445F),
        selectedBg = Color(0xCC0B1F35),
        selectedBorder = Color(0xFF38E8FF),
    ),
    inputs = glitchNeonDark().inputs.copy(
        bg = Color(0xB3080D1A),
        border = Color(0xFF29445F),
        focusedBorder = Color(0xFF63EFFF),
        cursor = Color(0xFF63EFFF),
    ),
    effects = EffectTokens(
        shadowSoft = Color(0x55000000),
        shadowStrong = Color(0xAA000000),
        glowLow = Color(0x2238E8FF),
        glowMedium = Color(0x5538E8FF),
        glowHigh = Color(0x8838E8FF),
        scanline = Color(0x2238E8FF),
    ),
    status = SwurlzStatusColors(
        success = Color(0xFF4DFFB4),
        warning = Color(0xFFFFD45A),
        danger = Color(0xFFFF4D68),
        info = Color(0xFF38E8FF),
        admin = Color(0xFFB468FF),
    ),
)

private fun pharaohEmeraldDark(): SwurlzThemeTokens = OriginalCoreDark.copy(
    id = "pharaoh_emerald_dark",
    displayName = "Pharaoh Emerald / Dark",
    family = "Pharaoh Emerald",
    surfaces = OriginalCoreDark.surfaces.copy(bgApp = Color(0xFF030807), bgTopBar = Color(0xFF050B08), bgPanel = Color(0xFF07110E), bgPanelAlt = Color(0xFF0C1A14), bgElevated = Color(0xFF12271E)),
    text = OriginalCoreDark.text.copy(primary = Color(0xFFFFF7E0), secondary = Color(0xFFE8DDBF), muted = Color(0xFF9E9274), heading = Color(0xFFFFD166), label = Color(0xFF00E6B0)),
    borders = OriginalCoreDark.borders.copy(neutral = Color(0xFF34463A), focus = Color(0xFF00E6B0), selected = Color(0xFFFFD166)),
    accents = OriginalCoreDark.accents.copy(primary = Color(0xFF00E6B0), secondary = Color(0xFFFFD166), tertiary = Color(0xFF0E8F72), glow = Color(0xFF00E6B0), ornament = Color(0xFFFFD166), highlight = Color(0xFF00E6B0)),
    buttons = OriginalCoreDark.buttons.copy(primaryBg = Color(0xFF061B14), primaryText = Color(0xFF00E6B0), primaryBorder = Color(0xFF00E6B0), secondaryBg = Color(0xFF1D1605), secondaryText = Color(0xFFFFD166), secondaryBorder = Color(0xFFFFD166)),
    tabs = OriginalCoreDark.tabs.copy(selectedBg = Color(0xFF092218), selectedText = Color(0xFFFFD166), selectedBorder = Color(0xFF00E6B0), selectedGlow = Color(0xFF00E6B0), underline = Color(0xFFFFD166)),
    cards = OriginalCoreDark.cards.copy(bg = Color(0xFF06100D), bgAlt = Color(0xFF0C1A14), selectedBg = Color(0xFF092218), selectedBorder = Color(0xFFFFD166)),
    inputs = OriginalCoreDark.inputs.copy(bg = Color(0xFF050C09), focusedBorder = Color(0xFFFFD166), cursor = Color(0xFF00E6B0)),
    status = SwurlzStatusColors(Color(0xFF4DFF7A), Color(0xFFFFD166), Color(0xFFFF4D5E), Color(0xFF00E6B0), Color(0xFFB66DFF)),
)

private fun voidJesterDark(): SwurlzThemeTokens = OriginalCoreDark.copy(
    id = "void_jester_dark",
    displayName = "Void Jester / Dark",
    family = "Void Jester",
    surfaces = OriginalCoreDark.surfaces.copy(bgApp = Color(0xFF05000B), bgTopBar = Color(0xFF080012), bgPanel = Color(0xFF10051C), bgPanelAlt = Color(0xFF190A2A), bgElevated = Color(0xFF24103C)),
    text = OriginalCoreDark.text.copy(primary = Color(0xFFFFF8FF), secondary = Color(0xFFE6D7FF), muted = Color(0xFF9C86B8), heading = Color(0xFFFFC857), label = Color(0xFFB98CFF)),
    borders = OriginalCoreDark.borders.copy(neutral = Color(0xFF3A2754), focus = Color(0xFFB98CFF), selected = Color(0xFFFFC857)),
    accents = OriginalCoreDark.accents.copy(primary = Color(0xFF9B5CFF), secondary = Color(0xFFFFC857), tertiary = Color(0xFFFF3DDA), glow = Color(0xFF9B5CFF), ornament = Color(0xFFFFC857), highlight = Color(0xFFFF3DDA)),
    buttons = OriginalCoreDark.buttons.copy(primaryBg = Color(0xFF190A2A), primaryText = Color(0xFFB98CFF), primaryBorder = Color(0xFFB98CFF), secondaryBg = Color(0xFF241503), secondaryText = Color(0xFFFFC857), secondaryBorder = Color(0xFFFFC857)),
    tabs = OriginalCoreDark.tabs.copy(selectedBg = Color(0xFF190A2A), selectedText = Color(0xFFFFC857), selectedBorder = Color(0xFFB98CFF), selectedGlow = Color(0xFFB98CFF), underline = Color(0xFFFF3DDA)),
    cards = OriginalCoreDark.cards.copy(bg = Color(0xFF0D0418), bgAlt = Color(0xFF190A2A), selectedBg = Color(0xFF211035), selectedBorder = Color(0xFFB98CFF)),
    inputs = OriginalCoreDark.inputs.copy(bg = Color(0xFF090313), focusedBorder = Color(0xFFFFC857), cursor = Color(0xFFB98CFF)),
    status = SwurlzStatusColors(Color(0xFF4DFF7A), Color(0xFFFFC857), Color(0xFFFF4D6D), Color(0xFF40EFFF), Color(0xFFB98CFF)),
)

private fun normalizeFamily(family: String): String = when (family) {
    "Pharaoh Gold" -> "Pharaoh Emerald"
    "Glitch Teal" -> "Glitch Neon"
    else -> family
}

private fun baseTokens(family: String): SwurlzThemeTokens = when (normalizeFamily(family)) {
    "Glitch Dragon Glass" -> glitchDragonGlassDark()
    "Glitch Neon" -> glitchNeonDark()
    "Pharaoh Emerald" -> pharaohEmeraldDark()
    "Void Jester" -> voidJesterDark()
    else -> OriginalCoreDark
}

private fun toSunlightVariant(tokens: SwurlzThemeTokens): SwurlzThemeTokens {
    return tokens.copy(
        id = tokens.id.replace("_dark", "_sunlight"),
        displayName = "${tokens.family} / Sunlight",
        variant = "Sunlight",
        surfaces = tokens.surfaces.copy(
            bgApp = Color(0xFF000000),
            bgTopBar = Color(0xFF000000),
            bgPanel = Color(0xFF050607),
            bgPanelAlt = Color(0xFF0A0D10),
            bgElevated = Color(0xFF10151A),
            bgOverlay = Color(0xFA000000),
        ),
        text = tokens.text.copy(
            primary = Color.White,
            secondary = Color(0xFFF0F3F5),
            muted = Color(0xFFC9D0D6),
            disabled = Color(0xFF777F87),
        ),
        borders = tokens.borders.copy(
            neutral = tokens.borders.strong,
            soft = tokens.borders.neutral,
            strong = tokens.accents.primary,
        ),
        cards = tokens.cards.copy(
            bg = Color(0xFF040506),
            bgAlt = Color(0xFF090C0F),
            border = tokens.borders.strong,
        ),
        buttons = tokens.buttons.copy(
            primaryBg = tokens.accents.primary,
            primaryText = tokens.text.onAccent,
            secondaryBg = tokens.accents.secondary,
            secondaryText = tokens.text.inverse,
        ),
    )
}

private fun toInverseVariant(tokens: SwurlzThemeTokens): SwurlzThemeTokens {
    val status = SwurlzStatusColors(
        success = Color(0xFF008F3A),
        warning = Color(0xFF9A6B00),
        danger = Color(0xFFD42132),
        info = Color(0xFF007D91),
        admin = Color(0xFF7B2CBF),
    )
    return tokens.copy(
        id = tokens.id.replace("_dark", "_inverse"),
        displayName = "${tokens.family} / Inverse",
        variant = "Inverse",
        surfaces = SurfaceTokens(Color(0xFFEAF3F5), Color(0xFFF7FCFD), Color(0xFFF7FCFD), Color(0xFFE6EEF1), Color(0xFFFFFFFF), Color(0xEEFFFFFF), Color(0x99FFFFFF)),
        text = TextTokens(Color(0xFF061014), Color(0xFF17252B), Color(0xFF53646E), Color(0xFF8FA0AA), Color(0xFF9A6B00), Color(0xFF007D91), Color.White, Color(0xFF050607)),
        borders = BorderTokens(Color(0xFF9BAAB3), Color(0xFFD0D9DE), Color(0xFF53646E), Color(0xFF007D91), Color(0xFF7B2CBF)),
        accents = tokens.accents.copy(primary = Color(0xFF007D91), secondary = Color(0xFF9A6B00), tertiary = Color(0xFF7B2CBF), glow = Color(0xFF007D91), ornament = Color(0xFF9A6B00), highlight = Color(0xFF008F3A)),
        buttons = ButtonTokens(Color(0xFF007D91), Color.White, Color(0xFF007D91), Color(0xFF9A6B00), Color.White, Color(0xFF9A6B00), Color.Transparent, Color(0xFF061014), Color(0xFF9BAAB3), Color(0xFFD42132), Color.White, Color(0xFFD42132)),
        tabs = TabTokens(Color(0xFFF7FCFD), Color(0xFF17252B), Color(0xFF9BAAB3), Color(0xFFE1F4F7), Color(0xFF007D91), Color(0xFF007D91), Color(0xFF007D91), Color(0xFF9A6B00)),
        cards = CardTokens(Color(0xFFFFFFFF), Color(0xFFE6EEF1), Color(0xFF9BAAB3), Color(0xFFE1F4F7), Color(0xFF007D91), Color(0xFFE6EEF1), Color(0xFFE6EEF1), Color(0xFF061014)),
        inputs = InputTokens(Color(0xFFFFFFFF), Color(0xFF061014), Color(0xFF17252B), Color(0xFF53646E), Color(0xFF9BAAB3), Color(0xFF007D91), Color(0xFF007D91)),
        effects = EffectTokens(Color(0x22000000), Color(0x44000000), Color(0x33007D91), Color(0x55007D91), Color(0x77007D91), Color(0x22007D91)),
        status = status,
    )
}

fun resolveSwurlzThemeTokens(settings: UiStyleSettings): SwurlzThemeTokens {
    val base = baseTokens(settings.themePack)
    val variant = when (settings.displayMode) {
        "Sunlight" -> toSunlightVariant(base)
        "Inverse" -> toInverseVariant(base)
        else -> base
    }
    val highContrast = if (settings.highContrast) {
        variant.copy(
            text = variant.text.copy(primary = if (variant.variant == "Inverse") Color(0xFF000000) else Color.White, secondary = if (variant.variant == "Inverse") Color(0xFF101820) else Color(0xFFF2F2F2)),
            borders = variant.borders.copy(neutral = variant.borders.strong),
        )
    } else variant
    return highContrast
}

val LocalSwurlzTokens = staticCompositionLocalOf { OriginalCoreDark }

private val MonoFamily = FontFamily.Monospace
private val Body = FontFamily.SansSerif
private val Display = FontFamily.Serif

val SwurlzTypography = Typography(
    displayLarge = TextStyle(fontFamily = Display, fontWeight = FontWeight.Bold, fontSize = 32.sp, letterSpacing = 2.sp),
    titleLarge = TextStyle(fontFamily = Display, fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 1.6.sp),
    titleMedium = TextStyle(fontFamily = MonoFamily, fontWeight = FontWeight.Medium, fontSize = 14.sp, letterSpacing = 2.sp),
    bodyMedium = TextStyle(fontFamily = Body, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = MonoFamily, fontSize = 11.sp, letterSpacing = 1.4.sp),
    labelSmall = TextStyle(fontFamily = MonoFamily, fontSize = 10.sp, letterSpacing = 2.sp),
)

val SwurlzShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
)

@Composable
fun SwurlzTheme(settings: UiStyleSettings = UiStyleSettings(), content: @Composable () -> Unit) {
    val tokens = resolveSwurlzThemeTokens(settings)
    val scheme = if (tokens.variant == "Inverse") {
        lightColorScheme(
            primary = tokens.accents.primary,
            onPrimary = tokens.text.onAccent,
            secondary = tokens.accents.secondary,
            onSecondary = tokens.text.onAccent,
            background = tokens.surfaces.bgApp,
            onBackground = tokens.text.primary,
            surface = tokens.surfaces.bgPanel,
            onSurface = tokens.text.primary,
            error = tokens.status.danger,
            onError = tokens.text.onAccent,
            outline = tokens.borders.neutral,
        )
    } else {
        darkColorScheme(
            primary = tokens.accents.primary,
            onPrimary = tokens.text.onAccent,
            secondary = tokens.accents.secondary,
            onSecondary = tokens.text.onAccent,
            background = tokens.surfaces.bgApp,
            onBackground = tokens.text.primary,
            surface = tokens.surfaces.bgPanel,
            onSurface = tokens.text.primary,
            error = tokens.status.danger,
            onError = tokens.text.primary,
            outline = tokens.borders.neutral,
        )
    }
    CompositionLocalProvider(LocalSwurlzTokens provides tokens) {
        MaterialTheme(
            colorScheme = scheme,
            typography = SwurlzTypography,
            shapes = SwurlzShapes,
            content = content,
        )
    }
}
