package sh.swurlz.core.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.RelayConfig
import sh.swurlz.core.net.Api
import sh.swurlz.core.net.CoreNodeApi
import sh.swurlz.core.ui.theme.SwurlzColors

private data class PacketCardModel(
    val packetId: String,
    val commandId: String,
    val title: String,
    val commandType: String,
    val status: String,
    val fromDevice: String,
    val targetDevice: String,
    val groupId: String,
    val createdAt: String,
    val expiresAt: String,
    val message: String,
)

private data class DeviceCardModel(
    val deviceId: String,
    val label: String,
    val role: String,
    val groupId: String,
    val online: Boolean,
    val onlineState: String,
    val lastSeen: String,
    val queuedPackets: Int,
)

private data class GroupCardModel(
    val groupId: String,
    val label: String,
    val memberCount: Int,
    val onlineCount: Int,
    val queuedCount: Int,
    val status: String,
    val updatedAt: String,
)

@Composable
fun CommandsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var coreNodeUrl by remember { mutableStateOf("") }
    var groupId by remember { mutableStateOf("kami-lab") }
    var groupKey by remember { mutableStateOf("") }
    var deviceId by remember { mutableStateOf("") }
    var deviceKey by remember { mutableStateOf("") }
    var deviceLabel by remember { mutableStateOf("Action Phone") }
    var role by remember { mutableStateOf("Action Phone") }

    var adminUser by remember { mutableStateOf("admin") }
    var adminPassword by remember { mutableStateOf("") }
    var adminModeEnabled by remember { mutableStateOf(false) }
    var adminTokenSaved by remember { mutableStateOf(false) }
    var allDevicesVisible by remember { mutableStateOf(false) }
    var lastVerified by remember { mutableStateOf("") }

    var targetMode by remember { mutableStateOf("self") }
    var targetDeviceId by remember { mutableStateOf("") }
    var commandType by remember { mutableStateOf("PING") }
    var packetTitle by remember { mutableStateOf("Relay Radar test") }
    var packetMessage by remember { mutableStateOf("SWRLZ packet sent from the cleaned Relay Radar cockpit.") }

    var autoRefresh by remember { mutableStateOf(false) }
    var autoPresenceEnabled by remember { mutableStateOf(true) }
    var showManual by remember { mutableStateOf(false) }
    var showDebug by remember { mutableStateOf(false) }
    var showAdminManual by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Relay Radar ready") }
    var radarStatus by remember { mutableStateOf("Relay Radar ready") }
    var output by remember { mutableStateOf("No debug output yet. Use Refresh Radar to pull server groups/devices, then tap a device card to select a target.") }
    var groups by remember { mutableStateOf<List<GroupCardModel>>(emptyList()) }
    var devices by remember { mutableStateOf<List<DeviceCardModel>>(emptyList()) }
    var packets by remember { mutableStateOf<List<PacketCardModel>>(emptyList()) }
    var lastRadarRefresh by remember { mutableStateOf("") }

    suspend fun refreshLocalState() {
        val core = Prefs.coreNodeConfig(ctx)
        val relay = Prefs.relayConfig(ctx)
        val admin = Prefs.adminSession(ctx)
        val style = Prefs.uiStyle(ctx)
        autoPresenceEnabled = style.autoPresenceEnabled
        coreNodeUrl = core.nodeUrl
        groupId = relay.groupId.ifBlank { groupId }
        groupKey = relay.groupKey
        deviceId = relay.deviceId
        deviceKey = relay.deviceKey
        deviceLabel = relay.deviceLabel.ifBlank { "Action Phone" }
        role = relay.role.ifBlank { "Action Phone" }
        targetDeviceId = targetDeviceId.ifBlank { relay.deviceId }
        adminUser = admin.username.ifBlank { "admin" }
        adminModeEnabled = admin.modeEnabled
        adminTokenSaved = admin.sessionTokenSaved
        allDevicesVisible = admin.allDevicesVisible
        lastVerified = admin.lastVerifiedAt
    }

    suspend fun saveRelayFields() {
        Prefs.setRelayConfig(
            ctx,
            RelayConfig(
                groupId = groupId.trim(),
                groupKey = groupKey.trim(),
                deviceId = deviceId.trim(),
                deviceKey = deviceKey.trim(),
                deviceLabel = deviceLabel.trim().ifBlank { "Action Phone" },
                role = role.trim().ifBlank { "Action Phone" },
            ),
        )
    }

    fun absorbPayload(raw: String) {
        packetCardsFromPayload(raw).takeIf { it.isNotEmpty() }?.let { packets = it }
        deviceCardsFromPayload(raw).takeIf { it.isNotEmpty() }?.let { devices = it }
        groupCardsFromPayload(raw).takeIf { it.isNotEmpty() }?.let { groups = it }
    }

    suspend fun runRaw(label: String, block: suspend () -> String) {
        saveRelayFields()
        val isRadarRead = label.contains("Radar", ignoreCase = true)
        status = "$label…"
        if (isRadarRead) radarStatus = "$label…"
        output = runCatching { withContext(Dispatchers.IO) { block() } }.fold(
            onSuccess = { raw ->
                absorbPayload(raw)
                lastRadarRefresh = if (isRadarRead) "just now" else lastRadarRefresh
                status = "$label complete"
                if (isRadarRead) radarStatus = "$label complete"
                raw
            },
            onFailure = { err ->
                status = "$label failed"
                if (isRadarRead) radarStatus = "$label failed"
                "${humanRelayFailure(err)}\n\n${err.message ?: "no extra detail"}"
            },
        )
        refreshLocalState()
    }

    fun launchRaw(label: String, block: suspend () -> String) {
        scope.launch { runRaw(label, block) }
    }

    LaunchedEffect(Unit) {
        Prefs.ensureRelayIdentity(ctx)
        refreshLocalState()
        if (Prefs.coreNodeConfig(ctx).nodeUrl.isNotBlank()) {
            if (Prefs.uiStyle(ctx).autoPresenceEnabled) {
                runCatching { runRaw("Node Heartbeat") { CoreNodeApi.autoPresence(ctx) } }
            }
            runCatching { runRaw("Refresh Radar") { CoreNodeApi.presenceSummary(ctx) } }
        }
    }

    LaunchedEffect(autoRefresh, coreNodeUrl, groupId, groupKey, adminModeEnabled) {
        while (autoRefresh) {
            delay(10000)
            if (coreNodeUrl.isNotBlank()) {
                runCatching { runRaw("Auto Radar") { CoreNodeApi.presenceSummary(ctx) } }
            }
        }
    }

    LaunchedEffect(autoPresenceEnabled, coreNodeUrl, groupId, groupKey, deviceId, deviceKey) {
        while (autoPresenceEnabled) {
            delay(30000)
            if (coreNodeUrl.isNotBlank()) {
                runCatching { runRaw("Node Heartbeat") { CoreNodeApi.autoPresence(ctx) } }
            }
        }
    }

    val onlineCount = devices.count { it.online }
    val queuedCount = devices.sumOf { it.queuedPackets } + packets.size
    val selectedGroup = groupId.ifBlank { "none" }
    val selectedTarget = when (targetMode.lowercase()) {
        "self" -> deviceId.ifBlank { "this device" }
        "group" -> selectedGroup
        else -> targetDeviceId.ifBlank { "no device selected" }
    }
    val needsPairing = groupId.isBlank() || groupKey.isBlank() || deviceId.isBlank() || deviceKey.isBlank()
    val readyToSend = coreNodeUrl.isNotBlank() && groupId.isNotBlank() && groupKey.isNotBlank() && deviceId.isNotBlank() &&
        (targetMode.lowercase() != "device" || targetDeviceId.isNotBlank())

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
    ) {
        Text("▸ RELAY RADAR", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Clean command cockpit: server-pulled groups/devices, live status lights, tap-to-select targets, offline packet inbox, and manual/debug controls folded away until needed.",
            color = SwurlzColors.Ash,
            fontSize = 12.sp,
            lineHeight = 17.sp,
        )
        Spacer(Modifier.height(10.dp))

        RadarHero(
            serverUrl = coreNodeUrl.ifBlank { "Core URL not configured" },
            groups = groups.size,
            devices = devices.size,
            online = onlineCount,
            queued = queuedCount,
            status = radarStatus,
        )

        Spacer(Modifier.height(10.dp))
        ToggleLine("Auto-refresh radar while this screen is open", autoRefresh) { autoRefresh = it }
        ToggleLine("Node Heartbeat / auto presence", autoPresenceEnabled) { enabled ->
            autoPresenceEnabled = enabled
            scope.launch { Prefs.setAutoPresenceEnabled(ctx, enabled); refreshLocalState() }
        }
        RadarButton("REFRESH RADAR", SwurlzColors.Cyan) { launchRaw("Refresh Radar") { CoreNodeApi.presenceSummary(ctx) } }
        Spacer(Modifier.height(6.dp))
        RadarButton("AUTO REGISTER / HEARTBEAT", SwurlzColors.Phosphor) { launchRaw("Node Heartbeat") { CoreNodeApi.autoPresence(ctx) } }
        Spacer(Modifier.height(6.dp))
        RadarButton("CHECK-IN THIS DEVICE", SwurlzColors.Phosphor) { launchRaw("Device check-in") { CoreNodeApi.checkInDevice(ctx) } }
        Spacer(Modifier.height(6.dp))
        RadarButton("PULL OFFLINE QUEUE", SwurlzColors.Runic) { launchRaw("Pull offline queue") { CoreNodeApi.pendingPackets(ctx) } }

        Spacer(Modifier.height(14.dp))
        SectionTitle("PAIRING WIZARD")
        PairingWizardSection(
            coreReady = coreNodeUrl.isNotBlank(),
            groupReady = groupId.isNotBlank() && groupKey.isNotBlank(),
            deviceIdentityReady = deviceId.isNotBlank() && deviceKey.isNotBlank(),
            deviceVisible = devices.any { it.deviceId == deviceId },
            deviceOnline = devices.any { it.deviceId == deviceId && it.online },
            onAutoRegister = { launchRaw("Auto register / heartbeat") { CoreNodeApi.autoPresence(ctx) } },
            onJoin = { launchRaw("Join group") { CoreNodeApi.joinGroup(ctx, Prefs.relayConfig(ctx)) } },
            onRefresh = { launchRaw("Refresh Radar") { CoreNodeApi.presenceSummary(ctx) } },
            onOpenManual = { showManual = true },
        )

        Spacer(Modifier.height(14.dp))
        SectionTitle("SELECTED PATH")
        CompactTile(
            title = "GROUP",
            body = selectedGroup,
            tone = if (groupId.isNotBlank() && groupKey.isNotBlank()) SwurlzColors.Phosphor else SwurlzColors.RiskYellow,
        )
        Spacer(Modifier.height(7.dp))
        CompactTile(
            title = "THIS DEVICE",
            body = "${deviceLabel.ifBlank { "unnamed" }} · ${deviceId.ifBlank { "no device id" }} · $role",
            tone = if (deviceId.isNotBlank() && deviceKey.isNotBlank()) SwurlzColors.Phosphor else SwurlzColors.RiskYellow,
        )
        Spacer(Modifier.height(7.dp))
        CompactTile(
            title = "TARGET",
            body = "${targetMode.uppercase()} → $selectedTarget",
            tone = if (readyToSend) SwurlzColors.Cyan else SwurlzColors.RiskYellow,
        )

        Spacer(Modifier.height(14.dp))
        SectionTitle("READY CHECK")
        ReadyLine("Core Node URL saved", coreNodeUrl.isNotBlank(), "Set this in Setup/Core if red.")
        ReadyLine("Group ID + key present", groupId.isNotBlank() && groupKey.isNotBlank(), "Create/join a group in Manual Setup if yellow/red.")
        ReadyLine("This device ID + key present", deviceId.isNotBlank() && deviceKey.isNotBlank(), "Join group once to receive/save the device key.")
        ReadyLine("Node Heartbeat enabled", autoPresenceEnabled, "Turn this on in Style or Radar so this device checks in automatically.")
        ReadyLine("Target selected", targetMode.lowercase() != "device" || targetDeviceId.isNotBlank(), "Tap a device card or use self/group mode.")
        ReadyLine("Ready to send", readyToSend, if (readyToSend) "Packet can be sent safely." else "Finish the missing step before sending.")

        Spacer(Modifier.height(14.dp))
        SectionTitle("GROUPS")
        if (groups.isEmpty()) {
            CompactTile("NO GROUPS DISPLAYED", "Refresh Radar. Admin mode can show every group; group mode shows the joined group when authorized.", SwurlzColors.RiskYellow)
        }
        groups.forEach { group ->
            GroupCard(group) {
                groupId = group.groupId
                status = "Selected group ${group.groupId}"
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(10.dp))
        SectionTitle("DEVICE ROSTER")
        RosterSummary(
            thisDeviceId = deviceId,
            devices = devices,
            queued = queuedCount,
        )
        Spacer(Modifier.height(8.dp))
        if (devices.isEmpty()) {
            CompactTile("NO DEVICES DISPLAYED", "Refresh Radar, join/check-in this device, or enable admin mode to view all registered devices.", SwurlzColors.RiskYellow)
        }
        devices.forEach { device ->
            DeviceCard(
                device = device,
                onSelect = {
                    targetMode = "device"
                    targetDeviceId = device.deviceId
                    status = "Selected target ${device.deviceId}"
                },
                onPing = {
                    targetMode = "device"
                    targetDeviceId = device.deviceId
                    commandType = "PING"
                    packetTitle = "Ping ${device.label.ifBlank { device.deviceId }}"
                    launchRaw("Send PING") { CoreNodeApi.createPacket(ctx, targetMode, targetDeviceId, commandType, packetTitle, packetMessage) }
                },
            )
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("SEND SAFE COMMAND")
        CompactTile("COMMAND", "$commandType · $targetMode → $selectedTarget", if (readyToSend) SwurlzColors.Phosphor else SwurlzColors.RiskYellow)
        Spacer(Modifier.height(7.dp))
        QuickModeButtons(
            onSelf = { targetMode = "self"; targetDeviceId = deviceId },
            onGroup = { targetMode = "group" },
            onDevice = { targetMode = "device" },
        )
        Spacer(Modifier.height(7.dp))
        QuickCommandButtons(
            onPing = { commandType = "PING"; packetTitle = "Relay Radar PING" },
            onMessage = { commandType = "SHOW_MESSAGE"; packetTitle = "Relay Radar message" },
            onStatus = { commandType = "REPORT_STATUS"; packetTitle = "Relay Radar status request" },
        )
        Spacer(Modifier.height(7.dp))
        RadarButton("SEND COMMAND PACKET", if (readyToSend) SwurlzColors.Phosphor else SwurlzColors.RiskYellow) {
            launchRaw("Send packet") { CoreNodeApi.createPacket(ctx, targetMode, targetDeviceId, commandType, packetTitle, packetMessage) }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("PACKET INBOX")
        if (packets.isEmpty()) {
            CompactTile("NO PACKET CARDS", "Queued offline packets appear here after Pull Queue. Nothing executes invisibly.", SwurlzColors.Border)
        }
        packets.forEach { packet ->
            PacketCard(
                packet = packet,
                onDisplayed = { launchRaw("Mark displayed") { CoreNodeApi.updatePacket(ctx, packet.packetId, "DISPLAYED", "Displayed on Relay Radar UI.") } },
                onAck = { launchRaw("Acknowledge packet") { CoreNodeApi.updatePacket(ctx, packet.packetId, "ACKNOWLEDGED", "User approved from Relay Radar UI.") } },
                onReject = { launchRaw("Reject packet") { CoreNodeApi.updatePacket(ctx, packet.packetId, "REJECTED", "User rejected from Relay Radar UI.") } },
                onComplete = { launchRaw("Complete packet") { CoreNodeApi.updatePacket(ctx, packet.packetId, "COMPLETED", "Safe packet completed from Relay Radar UI.") } },
            )
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(14.dp))
        ToggleLine("Manual setup / raw IDs", showManual || needsPairing) { showManual = it }
        if (showManual || needsPairing) {
            ManualSetupSection(
                groupId = groupId,
                onGroupId = { groupId = it },
                groupKey = groupKey,
                onGroupKey = { groupKey = it },
                deviceId = deviceId,
                onDeviceId = { deviceId = it },
                deviceKey = deviceKey,
                onDeviceKey = { deviceKey = it },
                deviceLabel = deviceLabel,
                onDeviceLabel = { deviceLabel = it },
                role = role,
                onRole = { role = it },
                targetDeviceId = targetDeviceId,
                onTarget = { targetDeviceId = it },
                commandType = commandType,
                onCommand = { commandType = it.uppercase() },
                title = packetTitle,
                onTitle = { packetTitle = it },
                message = packetMessage,
                onMessage = { packetMessage = it },
                onSave = { scope.launch { saveRelayFields(); refreshLocalState(); status = "Manual relay fields saved" } },
                onCreateGroup = { launchRaw("Create group") { CoreNodeApi.createGroup(ctx, groupId, groupKey, groupId) } },
                onJoinGroup = { launchRaw("Join group") { CoreNodeApi.joinGroup(ctx, Prefs.relayConfig(ctx)) } },
            )
        }

        Spacer(Modifier.height(10.dp))
        ToggleLine("Admin controls", showAdminManual) { showAdminManual = it }
        if (showAdminManual) {
            AdminSection(
                adminUser = adminUser,
                onAdminUser = { adminUser = it },
                adminPassword = adminPassword,
                onAdminPassword = { adminPassword = it },
                adminModeEnabled = adminModeEnabled,
                onAdminMode = {
                    adminModeEnabled = it
                    scope.launch { Prefs.setAdminModeEnabled(ctx, it); refreshLocalState() }
                },
                allDevicesVisible = allDevicesVisible,
                onAllDevices = {
                    allDevicesVisible = it
                    scope.launch { Prefs.setAdminAllDevicesVisible(ctx, it); refreshLocalState() }
                },
                adminTokenSaved = adminTokenSaved,
                lastVerified = lastVerified,
                onActivate = {
                    scope.launch {
                        Prefs.setAdminUsername(ctx, adminUser)
                        Prefs.setAdminModeEnabled(ctx, adminModeEnabled)
                        Prefs.setAdminAllDevicesVisible(ctx, allDevicesVisible)
                        runRaw("Admin activate") { CoreNodeApi.adminSessionLogin(ctx, adminUser, adminPassword) }
                    }
                },
                onVerify = { launchRaw("Admin verify") { CoreNodeApi.adminSessionStatus(ctx) } },
                onForget = { launchRaw("Admin forget") { CoreNodeApi.revokeSavedAdminSession(ctx) } },
                onLedger = { launchRaw("Admin ledger") { CoreNodeApi.adminLedger(ctx) } },
            )
        }

        Spacer(Modifier.height(10.dp))
        ToggleLine("Debug output", showDebug) { showDebug = it }
        if (showDebug) {
            SelectionContainer {
                Text(
                    output,
                    modifier = Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Border).background(Color(0xFF050507)).padding(10.dp),
                    color = SwurlzColors.Ash,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    lineHeight = 13.sp,
                )
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}


@Composable
private fun PairingWizardSection(
    coreReady: Boolean,
    groupReady: Boolean,
    deviceIdentityReady: Boolean,
    deviceVisible: Boolean,
    deviceOnline: Boolean,
    onAutoRegister: () -> Unit,
    onJoin: () -> Unit,
    onRefresh: () -> Unit,
    onOpenManual: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().border(1.dp, SwurlzColors.Cyan).background(Color(0xFF050A0C)).padding(12.dp)) {
        Text("GUIDED PAIRING LADDER", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(
            "Use this ladder when a phone does not appear online. It keeps the setup order visible: server, group, identity, heartbeat, radar verify.",
            color = SwurlzColors.Ash,
            fontSize = 11.sp,
            lineHeight = 16.sp,
        )
        Spacer(Modifier.height(8.dp))
        WizardStep("1", "Core Node URL", coreReady, if (coreReady) "server URL saved" else "save/test Core Node in Setup or Core")
        WizardStep("2", "Group selected", groupReady, if (groupReady) "group id + key saved" else "create/select group, then join")
        WizardStep("3", "Device identity", deviceIdentityReady, if (deviceIdentityReady) "device id + key ready" else "auto identity can create this node")
        WizardStep("4", "This device visible", deviceVisible, if (deviceVisible) "server lists this node" else "tap auto register / heartbeat")
        WizardStep("5", "This device online", deviceOnline, if (deviceOnline) "heartbeat is active" else "check in and refresh radar")
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallRadarButton("AUTO", SwurlzColors.Phosphor, onAutoRegister, Modifier.weight(1f))
            SmallRadarButton("JOIN", SwurlzColors.Runic, onJoin, Modifier.weight(1f))
            SmallRadarButton("REFRESH", SwurlzColors.Cyan, onRefresh, Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        SmallRadarButton("OPEN ADVANCED MANUAL SETUP", SwurlzColors.RiskYellow, onOpenManual, Modifier.fillMaxWidth())
    }
}

@Composable
private fun WizardStep(number: String, title: String, ok: Boolean, detail: String) {
    val tone = if (ok) SwurlzColors.Phosphor else SwurlzColors.RiskYellow
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text("$number.", color = tone, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(24.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = SwurlzColors.Bone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(detail, color = SwurlzColors.Ash, fontSize = 9.sp, lineHeight = 13.sp)
        }
        Text(if (ok) "OK" else "WAIT", color = tone, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 1.1.sp)
    }
}

@Composable
private fun RosterSummary(thisDeviceId: String, devices: List<DeviceCardModel>, queued: Int) {
    val thisDeviceVisible = devices.any { it.deviceId == thisDeviceId }
    val online = devices.count { it.online }
    val offline = devices.count { !it.online }
    val tone = if (thisDeviceVisible && online > 0) SwurlzColors.Phosphor else SwurlzColors.RiskYellow
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(Color(0xFF050707)).padding(11.dp)) {
        Text("ROSTER SUMMARY", color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.7.sp)
        Spacer(Modifier.height(5.dp))
        Text(
            "this device visible: ${if (thisDeviceVisible) "yes" else "no"} · devices ${devices.size} · online $online · offline $offline · queued $queued",
            color = SwurlzColors.Bone,
            fontSize = 11.sp,
            lineHeight = 16.sp,
        )
        Text(
            if (devices.size >= 2) "Two-node relay roster is visible." else "Bring the second phone online with Auto Register / Heartbeat, then Refresh Radar.",
            color = SwurlzColors.Ash,
            fontSize = 10.sp,
            lineHeight = 14.sp,
        )
    }
}

@Composable
private fun RadarHero(serverUrl: String, groups: Int, devices: Int, online: Int, queued: Int, status: String) {
    Column(
        Modifier.fillMaxWidth()
            .border(1.dp, SwurlzColors.Cyan)
            .background(Color(0xFF050A0C))
            .padding(12.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("SERVER RADAR", color = SwurlzColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Text(statusBadge(status), color = relayStatusColor(status), fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.4.sp)
        }
        Spacer(Modifier.height(7.dp))
        Text(serverUrl, color = SwurlzColors.Bone, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            MiniStat("GROUPS", groups.toString(), SwurlzColors.Runic)
            MiniStat("DEVICES", devices.toString(), SwurlzColors.Cyan)
            MiniStat("ONLINE", online.toString(), SwurlzColors.Phosphor)
            MiniStat("QUEUE", queued.toString(), if (queued > 0) SwurlzColors.RiskYellow else SwurlzColors.Ash)
        }
    }
}

@Composable
private fun MiniStat(label: String, value: String, color: Color) {
    Column(Modifier.widthIn(min = 62.dp).border(1.dp, color).padding(horizontal = 8.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontFamily = FontFamily.Monospace, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(label, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 7.sp, letterSpacing = 1.2.sp)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text("▸ $text", color = SwurlzColors.Runic, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun ToggleLine(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = SwurlzColors.Bone, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun ReadyLine(label: String, ok: Boolean, detail: String) {
    val tone = if (ok) SwurlzColors.Phosphor else SwurlzColors.RiskYellow
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).border(1.dp, SwurlzColors.Border).padding(9.dp), verticalAlignment = Alignment.Top) {
        Text(if (ok) "●" else "●", color = tone, fontSize = 13.sp, modifier = Modifier.padding(end = 8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, color = SwurlzColors.Bone, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = SwurlzColors.Ash, fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun CompactTile(title: String, body: String, tone: Color) {
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(Color(0xFF070709)).padding(11.dp)) {
        Text(title, color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.7.sp)
        Spacer(Modifier.height(5.dp))
        Text(body, color = SwurlzColors.Bone, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun RadarButton(text: String, color: Color, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
        border = BorderStroke(1.dp, color),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(text, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SmallRadarButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
        border = BorderStroke(1.dp, color),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 7.dp),
        modifier = modifier,
    ) {
        Text(text, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickModeButtons(onSelf: () -> Unit, onGroup: () -> Unit, onDevice: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        SmallRadarButton("SELF", SwurlzColors.Cyan, onSelf, Modifier.weight(1f))
        SmallRadarButton("DEVICE", SwurlzColors.Phosphor, onDevice, Modifier.weight(1f))
        SmallRadarButton("GROUP", SwurlzColors.Runic, onGroup, Modifier.weight(1f))
    }
}

@Composable
private fun QuickCommandButtons(onPing: () -> Unit, onMessage: () -> Unit, onStatus: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        SmallRadarButton("PING", SwurlzColors.Cyan, onPing, Modifier.weight(1f))
        SmallRadarButton("MESSAGE", SwurlzColors.Phosphor, onMessage, Modifier.weight(1f))
        SmallRadarButton("STATUS", SwurlzColors.Runic, onStatus, Modifier.weight(1f))
    }
}

@Composable
private fun GroupCard(group: GroupCardModel, onSelect: () -> Unit) {
    val tone = if (group.onlineCount > 0) SwurlzColors.Phosphor else SwurlzColors.RiskYellow
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(Color(0xFF060808)).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(group.label.ifBlank { group.groupId }, color = SwurlzColors.Bone, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(if (group.onlineCount > 0) "ACTIVE" else "IDLE", color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.3.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(group.groupId, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        Text("members ${group.memberCount} · online ${group.onlineCount} · queued ${group.queuedCount}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        Spacer(Modifier.height(8.dp))
        SmallRadarButton("SELECT GROUP", tone, onSelect, Modifier.fillMaxWidth())
    }
}

@Composable
private fun DeviceCard(device: DeviceCardModel, onSelect: () -> Unit, onPing: () -> Unit) {
    val tone = when {
        device.online -> SwurlzColors.Phosphor
        device.onlineState.equals("idle", ignoreCase = true) -> SwurlzColors.RiskYellow
        else -> SwurlzColors.RiskRed
    }
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(Color(0xFF060808)).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(device.label.ifBlank { device.deviceId }, color = SwurlzColors.Bone, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(device.onlineState.ifBlank { if (device.online) "ONLINE" else "OFFLINE" }.uppercase(), color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.3.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(device.deviceId, color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        Text("${device.role} · group ${device.groupId} · queued ${device.queuedPackets}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        Text("last seen: ${device.lastSeen.ifBlank { "unknown" }}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallRadarButton("SELECT", tone, onSelect, Modifier.weight(1f))
            SmallRadarButton("PING", SwurlzColors.Cyan, onPing, Modifier.weight(1f))
        }
    }
}

@Composable
private fun PacketCard(
    packet: PacketCardModel,
    onDisplayed: () -> Unit,
    onAck: () -> Unit,
    onReject: () -> Unit,
    onComplete: () -> Unit,
) {
    val normalized = packet.status.uppercase()
    val tone = packetTone(normalized)
    val terminal = normalized in setOf("COMPLETED", "REJECTED", "FAILED", "EXPIRED", "BLOCKED")
    Column(Modifier.fillMaxWidth().border(1.dp, tone).background(Color(0xFF060608)).padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(packet.title.ifBlank { packet.commandType }, color = SwurlzColors.Bone, fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 17.sp, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Text(normalized.ifBlank { "UNKNOWN" }, color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text("${packet.packetId} · ${packet.commandType} · group ${packet.groupId}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        Text("from ${packet.fromDevice} → ${packet.targetDevice}", color = SwurlzColors.Ash, fontFamily = FontFamily.Monospace, fontSize = 8.sp, lineHeight = 12.sp)
        if (packet.message.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(packet.message, color = SwurlzColors.Bone, fontSize = 12.sp, lineHeight = 17.sp)
        }
        Spacer(Modifier.height(8.dp))
        if (terminal) {
            CompactTile("PACKET HISTORY", "This packet is terminal/read-only. Pull queue or refresh radar to continue active work.", tone)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                SmallRadarButton("DISPLAY", SwurlzColors.Cyan, onDisplayed, Modifier.weight(1f))
                SmallRadarButton("ACK", SwurlzColors.Phosphor, onAck, Modifier.weight(1f))
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                SmallRadarButton("REJECT", SwurlzColors.RiskRed, onReject, Modifier.weight(1f))
                SmallRadarButton("COMPLETE", SwurlzColors.Runic, onComplete, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ManualSetupSection(
    groupId: String,
    onGroupId: (String) -> Unit,
    groupKey: String,
    onGroupKey: (String) -> Unit,
    deviceId: String,
    onDeviceId: (String) -> Unit,
    deviceKey: String,
    onDeviceKey: (String) -> Unit,
    deviceLabel: String,
    onDeviceLabel: (String) -> Unit,
    role: String,
    onRole: (String) -> Unit,
    targetDeviceId: String,
    onTarget: (String) -> Unit,
    commandType: String,
    onCommand: (String) -> Unit,
    title: String,
    onTitle: (String) -> Unit,
    message: String,
    onMessage: (String) -> Unit,
    onSave: () -> Unit,
    onCreateGroup: () -> Unit,
    onJoinGroup: () -> Unit,
) {
    CompactTile("MANUAL MODE", "Raw fields stay here for setup, recovery, custom IDs, and edge-case testing. Main workflow should use radar cards and Node Heartbeat whenever possible.", SwurlzColors.RiskYellow)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = groupId, onValueChange = onGroupId, label = { Text("Group ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = groupKey, onValueChange = onGroupKey, label = { Text("Group Key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = deviceId, onValueChange = onDeviceId, label = { Text("Device ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = deviceKey, onValueChange = onDeviceKey, label = { Text("Device Key") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = deviceLabel, onValueChange = onDeviceLabel, label = { Text("Device Label") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = role, onValueChange = onRole, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = targetDeviceId, onValueChange = onTarget, label = { Text("Manual Target Device ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = commandType, onValueChange = onCommand, label = { Text("Command Type") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = title, onValueChange = onTitle, label = { Text("Packet Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = message, onValueChange = onMessage, label = { Text("Payload Message") }, minLines = 2, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(8.dp))
    RadarButton("SAVE MANUAL FIELDS", SwurlzColors.Cyan, onSave)
    Spacer(Modifier.height(6.dp))
    RadarButton("CREATE GROUP", SwurlzColors.Runic, onCreateGroup)
    Spacer(Modifier.height(6.dp))
    RadarButton("JOIN GROUP / REGISTER DEVICE", SwurlzColors.Phosphor, onJoinGroup)
}

@Composable
private fun AdminSection(
    adminUser: String,
    onAdminUser: (String) -> Unit,
    adminPassword: String,
    onAdminPassword: (String) -> Unit,
    adminModeEnabled: Boolean,
    onAdminMode: (Boolean) -> Unit,
    allDevicesVisible: Boolean,
    onAllDevices: (Boolean) -> Unit,
    adminTokenSaved: Boolean,
    lastVerified: String,
    onActivate: () -> Unit,
    onVerify: () -> Unit,
    onForget: () -> Unit,
    onLedger: () -> Unit,
) {
    CompactTile(
        "ADMIN STATE",
        "Mode: ${if (adminModeEnabled) "ON" else "OFF"} · saved token: ${if (adminTokenSaved) "yes" else "no"}\nLast verified: ${lastVerified.ifBlank { "not verified" }}",
        if (adminModeEnabled && adminTokenSaved) SwurlzColors.Phosphor else SwurlzColors.RiskYellow,
    )
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = adminUser, onValueChange = onAdminUser, label = { Text("Admin username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Spacer(Modifier.height(7.dp))
    OutlinedTextField(value = adminPassword, onValueChange = onAdminPassword, label = { Text("Admin password, only needed to activate") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
    ToggleLine("Admin Mode ON/OFF", adminModeEnabled, onAdminMode)
    ToggleLine("Admin can view all devices/info", allDevicesVisible, onAllDevices)
    RadarButton("ACTIVATE ADMIN", SwurlzColors.Runic, onActivate)
    Spacer(Modifier.height(6.dp))
    RadarButton("VERIFY SAVED ADMIN", SwurlzColors.Cyan, onVerify)
    Spacer(Modifier.height(6.dp))
    RadarButton("ADMIN LEDGER", SwurlzColors.Violet, onLedger)
    Spacer(Modifier.height(6.dp))
    RadarButton("FORGET ADMIN SESSION", SwurlzColors.RiskRed, onForget)
}

private fun statusBadge(text: String) = when {
    text.contains("failed", ignoreCase = true) -> "ERROR"
    text.contains("complete", ignoreCase = true) -> "OK"
    text.contains("ready", ignoreCase = true) -> "READY"
    text.contains("Auto", ignoreCase = true) -> "SYNC"
    else -> "WAIT"
}

private fun relayStatusColor(text: String) = when {
    text.contains("failed", ignoreCase = true) -> SwurlzColors.RiskRed
    text.contains("complete", ignoreCase = true) -> SwurlzColors.Phosphor
    text.contains("ready", ignoreCase = true) -> SwurlzColors.Cyan
    else -> SwurlzColors.RiskYellow
}

private fun packetTone(status: String) = when (status.uppercase()) {
    "CREATED", "QUEUED", "DELIVERED", "DISPLAYED" -> SwurlzColors.RiskYellow
    "ACKNOWLEDGED" -> SwurlzColors.Cyan
    "COMPLETED" -> SwurlzColors.Phosphor
    "REJECTED", "FAILED", "BLOCKED" -> SwurlzColors.RiskRed
    "EXPIRED" -> SwurlzColors.Ash
    else -> SwurlzColors.Border
}

private fun humanRelayFailure(t: Throwable): String {
    val raw = (t.message ?: "").lowercase()
    val cleaned = CoreNodeApi.cleanFailure(t)
    return when {
        raw.contains("group key rejected") -> "Group key mismatch. Select the saved group or reset/create a fresh group key."
        raw.contains("group authorization failed") -> "Group authorization failed. Join/create the group before sending packets."
        raw.contains("device key rejected") -> "Device key mismatch. Rejoin/register this device or use the saved device key."
        raw.contains("device not registered") -> "Device is not registered yet. Join group first, then check in."
        raw.contains("admin authentication") -> "Admin session rejected. Activate admin again or check the admin password."
        else -> cleaned
    }
}

private fun packetCardsFromPayload(raw: String): List<PacketCardModel> = runCatching {
    val root = Api.json.parseToJsonElement(raw).jsonObject
    val packets = root["packets"]?.jsonArray?.mapNotNull { it.asObjectOrNull()?.toPacketCard() }.orEmpty()
    if (packets.isNotEmpty()) return@runCatching packets
    root["packet"]?.asObjectOrNull()?.toPacketCard()?.let { listOf(it) }.orEmpty()
}.getOrDefault(emptyList())

private fun deviceCardsFromPayload(raw: String): List<DeviceCardModel> = runCatching {
    val root = Api.json.parseToJsonElement(raw).jsonObject
    val devices = root["devices"]?.jsonArray?.mapNotNull { it.asObjectOrNull()?.toDeviceCard() }.orEmpty()
    if (devices.isNotEmpty()) return@runCatching devices
    root["device"]?.asObjectOrNull()?.toDeviceCard()?.let { listOf(it) }.orEmpty()
}.getOrDefault(emptyList())

private fun groupCardsFromPayload(raw: String): List<GroupCardModel> = runCatching {
    val root = Api.json.parseToJsonElement(raw).jsonObject
    val groups = root["groups"]?.jsonArray?.mapNotNull { it.asObjectOrNull()?.toGroupCard() }.orEmpty()
    if (groups.isNotEmpty()) return@runCatching groups
    root["group"]?.asObjectOrNull()?.toGroupCard()?.let { listOf(it) }.orEmpty()
}.getOrDefault(emptyList())

private fun JsonElement.asObjectOrNull(): JsonObject? = this as? JsonObject

private fun JsonObject.toPacketCard(): PacketCardModel = PacketCardModel(
    packetId = str("packet_id", "packetId", "id").orEmpty(),
    commandId = str("command_id", "commandId").orEmpty(),
    title = str("title").orEmpty(),
    commandType = str("command_type", "commandType", "type").orEmpty().ifBlank { "PACKET" },
    status = str("status").orEmpty().ifBlank { "UNKNOWN" },
    fromDevice = str("from_device_id", "fromDeviceId", "created_by", "createdBy").orEmpty(),
    targetDevice = str("target_device_id", "targetDeviceId").orEmpty(),
    groupId = str("group_id", "groupId").orEmpty(),
    createdAt = str("created_at", "createdAt").orEmpty(),
    expiresAt = str("expires_at", "expiresAt").orEmpty(),
    message = (get("payload") as? JsonObject)?.str("message").orEmpty(),
)

private fun JsonObject.toDeviceCard(): DeviceCardModel {
    val onlineBool = bool("online")
    val state = str("online_state", "onlineState", "status").orEmpty().ifBlank {
        if (onlineBool == true) "online" else "offline"
    }
    return DeviceCardModel(
        deviceId = str("device_id", "deviceId").orEmpty(),
        label = str("device_label", "deviceLabel", "label").orEmpty(),
        role = str("role").orEmpty(),
        groupId = str("group_id", "groupId").orEmpty(),
        online = onlineBool ?: state.equals("online", ignoreCase = true),
        onlineState = state,
        lastSeen = str("last_seen_at", "lastSeenAt", "last_checkin_at", "lastCheckinAt").orEmpty(),
        queuedPackets = intAny("queued_packets", "queuedPackets") ?: 0,
    )
}

private fun JsonObject.toGroupCard(): GroupCardModel = GroupCardModel(
    groupId = str("group_id", "groupId", "id").orEmpty(),
    label = str("label", "name").orEmpty(),
    memberCount = intAny("member_count", "memberCount", "members") ?: 0,
    onlineCount = intAny("online_count", "onlineCount", "online") ?: 0,
    queuedCount = intAny("queued_count", "queuedCount", "queued_packets", "queuedPackets") ?: 0,
    status = str("status").orEmpty(),
    updatedAt = str("updated_at", "updatedAt").orEmpty(),
)

private fun JsonObject.str(vararg keys: String): String? = keys.firstNotNullOfOrNull { key ->
    get(key)?.jsonPrimitive?.contentOrNull
}

private fun JsonObject.bool(vararg keys: String): Boolean? = keys.firstNotNullOfOrNull { key ->
    get(key)?.jsonPrimitive?.booleanOrNull
}

private fun JsonObject.intAny(vararg keys: String): Int? = keys.firstNotNullOfOrNull { key ->
    get(key)?.jsonPrimitive?.intOrNull ?: get(key)?.jsonPrimitive?.contentOrNull?.toIntOrNull()
}
