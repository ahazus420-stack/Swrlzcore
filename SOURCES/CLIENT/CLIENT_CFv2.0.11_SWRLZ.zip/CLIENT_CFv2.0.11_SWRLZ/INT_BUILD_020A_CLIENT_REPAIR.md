# INT-BUILD-020A CLIENT Repair

Baseline: CLIENT CFv2.0.8
Target: CLIENT CFv2.0.9

## Fixed

- Replaced four invalid `truth.auto.connected` references with the canonical `CoreNodeCheckRecord.success` property.
- Preserved the combined connection truth expression: automatic check success OR manual check success.
- Advanced version identity and workflow artifact naming to CFv2.0.9.

## Evidence

- Source inspection confirmed `CoreNodeCheckRecord` exposes `success`, not `connected`.
- Static guard confirms no `truth.auto.connected` reference remains.
- APK/Gradle build was not run in this packaging environment.
