# CLIENT CFv2.0.1 Compose Import Compile Fix

## Scope

This bounded source checkpoint modifies only the compile defect and the package/build identity required to distinguish the repaired source.

## Source repair

Removed these explicit imports from:

`android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt`

```kotlin
import androidx.compose.foundation.layout.calculateTopPadding
import androidx.compose.foundation.layout.weight
```

The existing `calculateTopPadding()` and `Modifier.weight()` call sites remain unchanged so Compose resolves them through their public `PaddingValues`, `RowScope`, and `ColumnScope` contexts.

## Identity

- Source ZIP: `CLIENT_CFv2.0.1_SWRLZ.zip`
- Android versionCode: `32`
- Android versionName: `0.2.7.6-cfv2.0.1-compose-import-fix`
- Patch label: `2.7.6-CFV2.0.1-COMPOSE-IMPORT-FIX`

## Preserved boundaries

No runtime feature, protocol, trust, identity, Truth Firewall, offline-first behavior, local-versus-remote distinction, CF8 fallback, or Ktor behavior was intentionally changed.

## Verification status

Static package checks passed locally. A full Android build was not claimed here; GitHub Actions remains the authoritative compile verification requested by the user.
