# SWRLZ ↔ SWURLZER Architecture — INT-CONV-012A Integration

- SWRLZ is the user-facing cockpit.
- SWURLZER is the authoritative runtime and orchestration layer.
- Every request is modeled as CLIENT → SWURLZER → CLIENT.
- Conversation Router classification is deterministic and side-effect free in this checkpoint.
- Mission promotion requires explicit confirmation.
- Truth Firewall, identity, proof, trust, and approval boundaries remain unchanged.
- CLIENT and SERVER versions advance independently with lineage receipts.
- Integrate, do not overwrite.
