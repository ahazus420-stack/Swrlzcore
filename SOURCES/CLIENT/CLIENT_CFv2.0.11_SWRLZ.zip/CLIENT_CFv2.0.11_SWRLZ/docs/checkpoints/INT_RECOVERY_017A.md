# INT-RECOVERY-017A — CLIENT

Baseline: CLIENT CFv2.0.6
Target: CLIENT CFv2.0.7

- Removed the duplicate `LocalContext.current` declaration in `ClientNodesScreen`.
- Advanced Android identity to versionCode 38 / versionName `0.2.7.12-cfv2.0.7-int-recovery-017a`.
- No protocol, trust, database, or runtime behavior changes.
- Build not run in this checkpoint.
