package sh.swurlz.core.ui.client

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import sh.swurlz.core.R
import sh.swurlz.core.data.MissionBus

internal enum class DragonEnergyTarget(val x: Float, val y: Float) {
    Core(.58f, .47f),
    Chat(.22f, .64f),
    Missions(.55f, .72f),
    Nodes(.74f, .56f),
    Settings(.24f, .82f),
    Approval(.52f, .59f),
    TakeOver(.50f, .50f),
}

internal data class DragonEnergySignal(
    val id: Int = 0,
    val target: DragonEnergyTarget = DragonEnergyTarget.Core,
)

internal data class DragonVisualState(
    val ambient: MissionBus.Ambient = MissionBus.Ambient.Idle,
    val localNodeVerified: Boolean = false,
    val remoteEnhancementConfigured: Boolean = false,
    val missionActive: Boolean = false,
    val paused: Boolean = false,
    val approvalRequired: Boolean = false,
    val takeOver: Boolean = false,
)

@Composable
internal fun LivingDragonBackdrop(
    motionEnabled: Boolean,
    artAlpha: Float,
    visualState: DragonVisualState,
    energySignal: DragonEnergySignal,
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    var foreground by remember(lifecycleOwner) {
        mutableStateOf(lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, _ ->
            foreground = lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (motionEnabled && foreground) {
        AnimatedLivingDragonScene(artAlpha, visualState, energySignal)
    } else {
        StaticLivingDragonScene(artAlpha, visualState)
    }
}

@Composable
private fun AnimatedLivingDragonScene(
    artAlpha: Float,
    visualState: DragonVisualState,
    energySignal: DragonEnergySignal,
) {
    val transition = rememberInfiniteTransition(label = "living-dragon-ambient")
    val drift by transition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(tween(18_000), RepeatMode.Reverse),
        label = "living-dragon-drift",
    )
    val breathing by transition.animateFloat(
        initialValue = .88f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(if (visualState.missionActive) 2_400 else 5_200), RepeatMode.Reverse),
        label = "living-dragon-breath",
    )
    val shimmer by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(11_000), RepeatMode.Restart),
        label = "living-dragon-shimmer",
    )
    val energy = remember { Animatable(0f) }
    LaunchedEffect(energySignal.id) {
        if (energySignal.id <= 0) return@LaunchedEffect
        energy.snapTo(0f)
        energy.animateTo(1f, tween(220))
        energy.animateTo(0f, tween(460))
    }

    DragonScene(
        artAlpha = artAlpha,
        visualState = visualState,
        drift = drift,
        breathing = breathing,
        shimmer = shimmer,
        energy = energy.value,
        target = energySignal.target,
    )
}

@Composable
private fun StaticLivingDragonScene(artAlpha: Float, visualState: DragonVisualState) {
    DragonScene(
        artAlpha = artAlpha,
        visualState = visualState,
        drift = 0f,
        breathing = .94f,
        shimmer = .38f,
        energy = 0f,
        target = DragonEnergyTarget.Core,
    )
}

@Composable
private fun DragonScene(
    artAlpha: Float,
    visualState: DragonVisualState,
    drift: Float,
    breathing: Float,
    shimmer: Float,
    energy: Float,
    target: DragonEnergyTarget,
) {
    val tone = dragonPrimaryTone(visualState)
    val secondaryTone = dragonSecondaryTone(visualState)
    val targetIntensity by animateFloatAsState(
        targetValue = when {
            visualState.takeOver -> .94f
            visualState.approvalRequired || visualState.paused -> .88f
            visualState.localNodeVerified -> 1.06f
            visualState.missionActive -> 1.02f
            else -> .86f
        },
        animationSpec = tween(320),
        label = "dragon-state-intensity",
    )
    val shardSpecs = remember {
        listOf(
            floatArrayOf(.87f, .15f, 22f, .62f),
            floatArrayOf(.78f, .31f, -30f, .42f),
            floatArrayOf(.91f, .72f, 74f, .50f),
            floatArrayOf(.16f, .84f, -18f, .34f),
        )
    }

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.glitch_dragon_core),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = drift
                    translationY = -drift * .28f
                    scaleX = 1.075f
                    scaleY = 1.075f
                    alpha = artAlpha.coerceIn(0f, 1f) * breathing * targetIntensity
                },
        )

        Canvas(Modifier.fillMaxSize()) {
            val core = Offset(size.width * .62f, size.height * .57f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(tone.copy(alpha = .12f * targetIntensity), Color.Transparent),
                    center = core,
                    radius = size.minDimension * .32f,
                ),
                radius = size.minDimension * .32f,
                center = core,
            )

            shardSpecs.forEachIndexed { index, spec ->
                val wave = kotlin.math.sin((shimmer * 6.283f) + index).toFloat()
                val x = size.width * spec[0]
                val y = size.height * spec[1] + wave * 6f
                val h = 44f * spec[3]
                val w = 13f * spec[3]
                val path = Path().apply {
                    moveTo(x, y - h / 2f)
                    lineTo(x + w / 2f, y + h * .22f)
                    lineTo(x, y + h / 2f)
                    lineTo(x - w / 2f, y + h * .22f)
                    close()
                }
                rotate(spec[2], Offset(x, y)) {
                    drawPath(
                        path = path,
                        brush = Brush.linearGradient(listOf(tone, secondaryTone), Offset(x, y - h), Offset(x, y + h)),
                        alpha = .06f + (.05f * (wave + 1f)),
                    )
                }
            }

            if (energy > 0f) {
                val center = Offset(size.width * target.x, size.height * target.y)
                drawCircle(
                    color = tone.copy(alpha = .18f * energy),
                    radius = 20f + (105f * energy),
                    center = center,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f),
                )
                drawCircle(
                    brush = Brush.radialGradient(listOf(tone.copy(alpha = .18f * energy), Color.Transparent), center, 92f),
                    radius = 92f,
                    center = center,
                )
                drawLine(
                    color = secondaryTone.copy(alpha = .28f * energy),
                    start = center,
                    end = core,
                    strokeWidth = 2f,
                )
            }
        }

        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xA6060612),
                        Color(0x82050512),
                        Color(0xE5050610),
                    )
                )
            )
        )
    }
}

private fun dragonPrimaryTone(state: DragonVisualState): Color = when {
    state.takeOver -> Color(0xFFFF4D68)
    state.approvalRequired || state.paused -> Color(0xFFFFD45A)
    state.ambient == MissionBus.Ambient.Planning || state.remoteEnhancementConfigured -> Color(0xFF9A55FF)
    state.localNodeVerified || state.missionActive -> Color(0xFF38E8FF)
    else -> Color(0xFF286B98)
}

private fun dragonSecondaryTone(state: DragonVisualState): Color = when {
    state.takeOver -> Color(0xFFFFD45A)
    state.approvalRequired || state.paused -> Color(0xFFB88A38)
    state.localNodeVerified -> Color(0xFF4DFFB4)
    state.remoteEnhancementConfigured -> Color(0xFF9A55FF)
    else -> Color(0xFF5CA8FF)
}
