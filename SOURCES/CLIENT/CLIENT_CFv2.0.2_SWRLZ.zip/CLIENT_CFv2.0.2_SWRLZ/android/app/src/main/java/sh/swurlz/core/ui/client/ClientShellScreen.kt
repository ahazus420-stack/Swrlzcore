package sh.swurlz.core.ui.client

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.PanTool
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.PermissionHelper
import sh.swurlz.core.R
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.MentorConfig
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.net.CoreNodeAutoDiscovery
import sh.swurlz.core.overlay.OverlayService
import sh.swurlz.core.service.MissionRunnerService
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

private enum class ClientTab(val label: String, val icon: ImageVector) {
    Core("Core", Icons.Outlined.Home),
    Chat("Chat", Icons.Outlined.Chat),
    Missions("Missions", Icons.Outlined.ListAlt),
    Nodes("Nodes", Icons.Outlined.Devices),
    Settings("Settings", Icons.Outlined.Settings),
}

private fun ClientTab.energyTarget(): DragonEnergyTarget = when (this) {
    ClientTab.Core -> DragonEnergyTarget.Core
    ClientTab.Chat -> DragonEnergyTarget.Chat
    ClientTab.Missions -> DragonEnergyTarget.Missions
    ClientTab.Nodes -> DragonEnergyTarget.Nodes
    ClientTab.Settings -> DragonEnergyTarget.Settings
}

private data class ClientMessage(val fromUser: Boolean, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientShellScreen(
    onOpenDeveloper: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenStyle: () -> Unit,
    onOpenSetup: () -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val mission by MissionBus.mission.collectAsState()
    val ambient by MissionBus.ambient.collectAsState()
    val timeline by MissionBus.timeline.collectAsState()
    val paused by MissionBus.pauseRequest.collectAsState()
    val takeOver by MissionBus.takeoverRequest.collectAsState()
    val needsApproval by MissionBus.needsApproval.collectAsState()
    val style by Prefs.uiStyleFlow(context).collectAsState(initial = UiStyleSettings())
    val nodeTruth by Prefs.coreNodeTruthStateFlow(context).collectAsState(initial = CoreNodeTruthState())
    val mentorConfig by Prefs.mentorConfigFlow(context).collectAsState(initial = MentorConfig())

    val motionEnabled = style.animationLevel != "Off"
    var selectedTabName by rememberSaveable { mutableStateOf(ClientTab.Core.name) }
    val selectedTab = ClientTab.entries.firstOrNull { it.name == selectedTabName } ?: ClientTab.Core
    var showSovereignty by remember { mutableStateOf(false) }
    var showApproval by remember { mutableStateOf(false) }
    var chatDraft by rememberSaveable { mutableStateOf("") }
    var energySignal by remember { mutableStateOf(DragonEnergySignal()) }
    val messages = remember {
        mutableStateListOf(
            ClientMessage(
                fromUser = false,
                text = "I’m ready. Tell me the outcome you want; I’ll keep local work local and pause before sensitive steps.",
            )
        )
    }

    fun signal(target: DragonEnergyTarget) {
        energySignal = DragonEnergySignal(energySignal.id + 1, target)
    }

    fun select(tab: ClientTab) {
        signal(tab.energyTarget())
        selectedTabName = tab.name
    }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    fun seedChat(prompt: String) {
        chatDraft = prompt
        select(ClientTab.Chat)
    }

    LaunchedEffect(needsApproval) {
        if (needsApproval) {
            signal(DragonEnergyTarget.Approval)
            showApproval = true
        }
    }

    val localNodeVerified = nodeTruth.auto.success || nodeTruth.manual.success
    LaunchedEffect(localNodeVerified) {
        if (localNodeVerified) signal(DragonEnergyTarget.Nodes)
    }
    LaunchedEffect(mission.missionId, mission.goal) {
        if (mission.goal.isNotBlank()) signal(DragonEnergyTarget.Missions)
    }

    val dragonState = DragonVisualState(
        ambient = ambient,
        localNodeVerified = localNodeVerified,
        remoteEnhancementConfigured = mentorConfig.configured,
        missionActive = mission.goal.isNotBlank() && ambient !in setOf(MissionBus.Ambient.Idle, MissionBus.Ambient.Done),
        paused = paused,
        approvalRequired = needsApproval,
        takeOver = takeOver,
    )

    Box(Modifier.fillMaxSize().background(tokens.surfaces.bgApp)) {
        GlitchDragonBackdrop(
            motionEnabled = motionEnabled,
            visualState = dragonState,
            energySignal = energySignal,
        )

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                ClientTopBar(
                    selectedTab = selectedTab,
                    ambient = ambient,
                    approvalWaiting = needsApproval,
                    onOpenSovereignty = { showSovereignty = true },
                )
            },
            bottomBar = {
                ClientBottomBar(selected = selectedTab, onSelect = ::select)
            },
        ) { innerPadding ->
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    if (!motionEnabled) {
                        fadeIn(tween(90)) togetherWith fadeOut(tween(70))
                    } else {
                        (fadeIn(tween(230)) + scaleIn(tween(260), initialScale = .985f)) togetherWith
                            (fadeOut(tween(170)) + scaleOut(tween(190), targetScale = .992f))
                    }
                },
                label = "client-tab-transition",
                modifier = Modifier.fillMaxSize().padding(innerPadding),
            ) { tab ->
                when (tab) {
                    ClientTab.Core -> ClientCoreScreen(
                        mission = mission,
                        ambient = ambient,
                        paused = paused,
                        motionEnabled = motionEnabled,
                        mentorConfigured = mentorConfig.configured,
                        onSpeak = {
                            signal(DragonEnergyTarget.Core)
                            seedChat("")
                        },
                        onCreate = { seedChat("Create ") },
                        onObserve = { seedChat("Observe this and help me ") },
                        onTeach = { seedChat("Teach and record this workflow: ") },
                        onConnect = { select(ClientTab.Nodes) },
                        onOpenMission = { select(ClientTab.Missions) },
                    )

                    ClientTab.Chat -> ClientChatScreen(
                        messages = messages,
                        draft = chatDraft,
                        mission = mission,
                        onDraftChange = { chatDraft = it },
                        onOpenPermissions = onOpenPermissions,
                        onSend = { goal ->
                            val accessibilityReady = PermissionHelper.isAccessibilityEnabled(context)
                            val overlayReady = PermissionHelper.isOverlayGranted(context)
                            messages += ClientMessage(true, goal)
                            chatDraft = ""
                            if (!accessibilityReady || !overlayReady) {
                                messages += ClientMessage(
                                    false,
                                    "I kept that intent local, but the operator permissions are incomplete. Open Permissions to finish setup before execution.",
                                )
                                notify("Mission not started: operator permissions are incomplete.")
                            } else {
                                OverlayService.start(context)
                                MissionRunnerService.start(context, goal)
                                signal(DragonEnergyTarget.Missions)
                                messages += ClientMessage(
                                    false,
                                    "Mission accepted by the local operator. I’ll expose every approval gate and stop before anything sensitive.",
                                )
                                notify("Local mission started.")
                            }
                        },
                    )

                    ClientTab.Missions -> ClientMissionsScreen(
                        mission = mission,
                        ambient = ambient,
                        timeline = timeline,
                        paused = paused,
                        needsApproval = needsApproval,
                        onPauseToggle = {
                            signal(DragonEnergyTarget.Missions)
                            MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                            notify(if (MissionBus.pauseRequest.value) "Mission paused." else "Mission resumed.")
                        },
                        onTakeOver = {
                            signal(DragonEnergyTarget.TakeOver)
                            MissionBus.takeoverRequest.value = true
                            MissionRunnerService.stop(context)
                            notify("You have control. SWRLZ is observing only.")
                        },
                        onReviewApproval = { showApproval = true },
                    )

                    ClientTab.Nodes -> ClientNodesScreen(
                        truth = nodeTruth,
                        onOpenDiscovery = onOpenDiscovery,
                        onOpenCoreAdmin = onOpenCoreAdmin,
                        onNotify = ::notify,
                    )

                    ClientTab.Settings -> ClientSettingsScreen(
                        style = style,
                        onMotionChanged = { enabled ->
                            scope.launch {
                                Prefs.setUiStyle(
                                    context,
                                    style.copy(animationLevel = if (enabled) "Standard" else "Off"),
                                )
                            }
                        },
                        onOpenStyle = onOpenStyle,
                        onOpenPermissions = onOpenPermissions,
                        onOpenSetup = onOpenSetup,
                        onOpenDeveloper = onOpenDeveloper,
                    )
                }
            }
        }

        if (showSovereignty) {
            SovereigntyDialog(
                paused = paused,
                onDismiss = { showSovereignty = false },
                onPauseToggle = {
                    signal(DragonEnergyTarget.Missions)
                    MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                    showSovereignty = false
                    notify(if (MissionBus.pauseRequest.value) "Mission paused." else "Mission resumed.")
                },
                onTakeOver = {
                    signal(DragonEnergyTarget.TakeOver)
                    MissionBus.takeoverRequest.value = true
                    MissionRunnerService.stop(context)
                    showSovereignty = false
                    notify("Take Over armed. No further automated action will run.")
                },
            )
        }

        if (showApproval && needsApproval) {
            ApprovalSheet(
                missionGoal = mission.goal,
                onApprove = {
                    MissionBus.approvalGranted.value = true
                    showApproval = false
                    notify("Approved once. The next gate will still pause.")
                },
                onRedirect = {
                    MissionBus.pauseRequest.value = true
                    chatDraft = "Redirect this mission step: "
                    select(ClientTab.Chat)
                    showApproval = false
                },
                onDecline = {
                    MissionBus.pauseRequest.value = true
                    showApproval = false
                    notify("Approval declined. Mission remains paused.")
                },
                onDismiss = { showApproval = false },
            )
        }
    }
}

@Composable
internal fun GlitchDragonBackdrop(
    motionEnabled: Boolean,
    artAlpha: Float = .29f,
    visualState: DragonVisualState = DragonVisualState(),
    energySignal: DragonEnergySignal = DragonEnergySignal(),
) {
    LivingDragonBackdrop(
        motionEnabled = motionEnabled,
        artAlpha = artAlpha,
        visualState = visualState,
        energySignal = energySignal,
    )
}

@Composable
private fun ClientTopBar(
    selectedTab: ClientTab,
    ambient: MissionBus.Ambient,
    approvalWaiting: Boolean,
    onOpenSovereignty: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(tokens.surfaces.bgTopBar.copy(alpha = .58f))
            .border(1.dp, tokens.accents.primary.copy(alpha = .18f))
            .padding(top = statusPadding + 8.dp, bottom = 10.dp, start = 16.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(tokens.accents.primary.copy(alpha = .25f), tokens.accents.tertiary.copy(alpha = .24f))))
                .border(1.dp, tokens.accents.primary.copy(alpha = .65f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text("Ω", color = tokens.text.primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SWRLZ · USER", color = tokens.text.primary, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.1.sp)
            Text(
                "${selectedTab.label.uppercase()} · ${ambient.name.uppercase()}",
                color = if (approvalWaiting) tokens.status.warning else ambientColor(ambient),
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 1.3.sp,
            )
        }
        if (approvalWaiting) {
            TinyPill("APPROVAL", tokens.status.warning)
            Spacer(Modifier.width(4.dp))
        }
        IconButton(onClick = onOpenSovereignty) {
            Icon(Icons.Outlined.Shield, contentDescription = "Open Pause and Take Over controls", tint = tokens.accents.primary)
        }
    }
}

@Composable
private fun ClientBottomBar(selected: ClientTab, onSelect: (ClientTab) -> Unit) {
    val tokens = LocalSwurlzTokens.current
    NavigationBar(
        containerColor = tokens.surfaces.bgTopBar.copy(alpha = .72f),
        tonalElevation = 0.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.border(1.dp, tokens.accents.primary.copy(alpha = .16f)),
    ) {
        ClientTab.entries.forEach { tab ->
            NavigationBarItem(
                selected = selected == tab,
                onClick = { onSelect(tab) },
                icon = { Icon(tab.icon, contentDescription = null) },
                label = { Text(tab.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = tokens.accents.primary,
                    selectedTextColor = tokens.text.primary,
                    indicatorColor = tokens.accents.primary.copy(alpha = .13f),
                    unselectedIconColor = tokens.text.muted,
                    unselectedTextColor = tokens.text.muted,
                ),
            )
        }
    }
}

@Composable
private fun ClientCoreScreen(
    mission: MissionBus.MissionLive,
    ambient: MissionBus.Ambient,
    paused: Boolean,
    motionEnabled: Boolean,
    mentorConfigured: Boolean,
    onSpeak: () -> Unit,
    onCreate: () -> Unit,
    onObserve: () -> Unit,
    onTeach: () -> Unit,
    onConnect: () -> Unit,
    onOpenMission: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("GOOD TO SEE YOU, KAMI", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
            Text(
                if (mission.goal.isBlank()) "Your core is ready." else "Your mission is in motion.",
                color = tokens.text.primary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-0.6f).sp,
            )
            Text(
                "Speak naturally. SWRLZ handles routing and exposes every sensitive gate.",
                color = tokens.text.secondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
            )
        }
        item {
            DragonCoreOrb(
                ambient = ambient,
                motionEnabled = motionEnabled,
                mentorConfigured = mentorConfigured,
                onClick = onSpeak,
            )
        }
        if (mission.goal.isNotBlank()) {
            item {
                GlassPanel(highlighted = true, modifier = Modifier.clickable(onClick = onOpenMission)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SectionLabel("ACTIVE MISSION")
                            Text(mission.goal, color = tokens.text.primary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (mission.total > 0) "Step ${mission.step} of ${mission.total}" else mission.state.replaceFirstChar { it.uppercase() },
                                color = tokens.text.muted,
                                fontSize = 11.sp,
                            )
                        }
                        TinyPill(if (paused) "PAUSED" else ambient.name.uppercase(), if (paused) tokens.status.warning else ambientColor(ambient))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("Create", Icons.Outlined.CheckCircle, Modifier.weight(1f), onCreate)
                QuickAction("Observe", Icons.Outlined.Hub, Modifier.weight(1f), onObserve)
                QuickAction("Teach", Icons.Outlined.Mic, Modifier.weight(1f), onTeach)
                QuickAction("Connect", Icons.Outlined.Radar, Modifier.weight(1f), onConnect)
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.status.success, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Truth Firewall armed · local-first routing active", color = tokens.text.secondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DragonCoreOrb(
    ambient: MissionBus.Ambient,
    motionEnabled: Boolean,
    mentorConfigured: Boolean,
    onClick: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pulse = if (motionEnabled) {
        val transition = rememberInfiniteTransition(label = "client-core-orb")
        val pulseAnimated by transition.animateFloat(
            initialValue = .96f,
            targetValue = 1.04f,
            animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse),
            label = "core-pulse",
        )
        pulseAnimated
    } else {
        1f
    }
    val pressScale by animateFloatAsState(
        targetValue = if (pressed && motionEnabled) 1.07f else pulse,
        animationSpec = tween(if (pressed) 140 else 220),
        label = "voice-core-press-scale",
    )
    val stateLabel = voiceCoreLabel(ambient, mentorConfigured)
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(218.dp)) {
            drawCircle(
                color = tokens.accents.primary.copy(alpha = if (pressed) .34f else .13f),
                radius = size.minDimension * if (pressed) .49f else .46f,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = if (pressed) 4f else 2f),
            )
        }
        Box(
            modifier = Modifier
                .size(190.dp)
                .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            tokens.accents.primary.copy(alpha = .30f),
                            tokens.accents.tertiary.copy(alpha = .18f),
                            tokens.surfaces.bgOverlay.copy(alpha = .78f),
                        )
                    )
                )
                .border(1.dp, ambientColor(ambient).copy(alpha = .85f), CircleShape)
                .semantics {
                    contentDescription = "SWRLZ voice and mission core"
                    stateDescription = stateLabel
                }
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.glitch_dragon_core),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().alpha(.28f),
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "Ω",
                    color = if (pressed) Color.White else tokens.text.primary,
                    fontSize = 50.sp,
                    fontWeight = FontWeight.Medium,
                )
                Text(
                    stateLabel,
                    color = when (ambient) {
                        MissionBus.Ambient.Paused -> tokens.status.warning
                        MissionBus.Ambient.Error -> tokens.status.danger
                        MissionBus.Ambient.Planning -> tokens.status.admin
                        else -> tokens.accents.primary
                    },
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    letterSpacing = 1.5.sp,
                    maxLines = 1,
                )
            }
        }
        TinyPill("LOCAL FIRST", tokens.accents.primary, Modifier.align(Alignment.TopEnd).padding(top = 18.dp, end = 10.dp))
        TinyPill("TRUTH FIREWALL · ON", tokens.status.success, Modifier.align(Alignment.BottomStart).padding(bottom = 18.dp, start = 4.dp))
    }
}

private fun voiceCoreLabel(ambient: MissionBus.Ambient, mentorConfigured: Boolean): String = when (ambient) {
    MissionBus.Ambient.Idle -> "TAP TO SPEAK"
    MissionBus.Ambient.Listening -> "LISTENING"
    MissionBus.Ambient.Observing -> "OBSERVING LOCALLY"
    MissionBus.Ambient.Planning -> if (mentorConfigured) "PROCESSING VIA MENTOR" else "ROUTE NOT CONFIGURED"
    MissionBus.Ambient.Acting -> "ACTING ON DEVICE"
    MissionBus.Ambient.Paused -> "PAUSED"
    MissionBus.Ambient.Error -> "ACTION NEEDED"
    MissionBus.Ambient.Done -> "COMPLETE"
}

@Composable
private fun ClientChatScreen(
    messages: List<ClientMessage>,
    draft: String,
    mission: MissionBus.MissionLive,
    onDraftChange: (String) -> Unit,
    onOpenPermissions: () -> Unit,
    onSend: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val permissionsReady = PermissionHelper.isAccessibilityEnabled(context) && PermissionHelper.isOverlayGranted(context)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("COUNCIL CHAT", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
        Text("Say it your way.", color = tokens.text.primary, fontSize = 28.sp, fontWeight = FontWeight.Medium)
        Text("No command syntax. Sensitive actions always stop for you.", color = tokens.text.secondary, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            contentPadding = PaddingValues(bottom = 10.dp),
        ) {
            items(messages) { message -> ChatBubble(message) }
            if (mission.rationale.isNotBlank()) {
                item { ChatBubble(ClientMessage(false, mission.rationale)) }
            }
        }

        if (!permissionsReady) {
            GlassPanel(modifier = Modifier.fillMaxWidth()) {
                Text("Operator permissions are incomplete. Your message can be staged, but execution will not begin.", color = tokens.status.warning, fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onOpenPermissions) { Text("OPEN PERMISSIONS") }
            }
            Spacer(Modifier.height(8.dp))
        }

        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    placeholder = { Text("Message SWRLZ…") },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = tokens.accents.primary,
                    ),
                )
                IconButton(onClick = { if (draft.isNotBlank()) onSend(draft.trim()) }) {
                    Icon(Icons.Outlined.Send, contentDescription = "Send mission intent", tint = tokens.accents.primary)
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ClientMessage) {
    val tokens = LocalSwurlzTokens.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(.86f)
                .background(
                    if (message.fromUser) {
                        Brush.linearGradient(listOf(tokens.accents.primary.copy(alpha = .74f), tokens.accents.tertiary.copy(alpha = .70f)))
                    } else {
                        Brush.linearGradient(listOf(tokens.cards.bg.copy(alpha = .72f), tokens.cards.bgAlt.copy(alpha = .60f)))
                    },
                    RoundedCornerShape(18.dp),
                )
                .border(1.dp, if (message.fromUser) tokens.accents.tertiary.copy(alpha = .55f) else tokens.accents.primary.copy(alpha = .34f), RoundedCornerShape(18.dp))
                .padding(13.dp),
        ) {
            Column {
                if (!message.fromUser) {
                    Text("SWRLZ · LOCAL", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(message.text, color = tokens.text.primary, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun ClientMissionsScreen(
    mission: MissionBus.MissionLive,
    ambient: MissionBus.Ambient,
    timeline: List<MissionBus.TimelineEntry>,
    paused: Boolean,
    needsApproval: Boolean,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
    onReviewApproval: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("MISSION CONTROL")
            Text("Outcome first. Detail on demand.", color = tokens.text.primary, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Text("Every action stays visible, pausable, and recoverable.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel(highlighted = mission.goal.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionLabel(if (mission.goal.isBlank()) "NO ACTIVE MISSION" else "ACTIVE MISSION")
                        Text(if (mission.goal.isBlank()) "Start from Core or Chat." else mission.goal, color = tokens.text.primary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        if (mission.goal.isNotBlank()) {
                            Spacer(Modifier.height(5.dp))
                            Text(
                                if (mission.total > 0) "Step ${mission.step} of ${mission.total}" else mission.state,
                                color = tokens.text.muted,
                                fontSize = 11.sp,
                            )
                        }
                    }
                    TinyPill(if (paused) "PAUSED" else ambient.name.uppercase(), if (paused) tokens.status.warning else ambientColor(ambient))
                }
                if (mission.goal.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onPauseToggle) {
                            Icon(if (paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text(if (paused) "RESUME" else "PAUSE")
                        }
                        OutlinedButton(onClick = onTakeOver, colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.status.danger)) {
                            Icon(Icons.Outlined.PanTool, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text("TAKE OVER")
                        }
                    }
                }
            }
        }
        if (needsApproval) {
            item {
                GlassPanel(highlighted = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.status.warning)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Approval required", color = tokens.status.warning, fontWeight = FontWeight.Medium)
                            Text("Review exact scope before execution continues.", color = tokens.text.secondary, fontSize = 11.sp)
                        }
                        Button(onClick = onReviewApproval) { Text("REVIEW") }
                    }
                }
            }
        }
        item { SectionLabel("ACTION TIMELINE") }
        if (timeline.isEmpty()) {
            item {
                GlassPanel { Text("No mission events yet.", color = tokens.text.muted, fontSize = 12.sp) }
            }
        } else {
            items(timeline.reversed()) { entry -> TimelineRow(entry) }
        }
    }
}

@Composable
private fun TimelineRow(entry: MissionBus.TimelineEntry) {
    val tokens = LocalSwurlzTokens.current
    val tone = phaseColor(entry.phase)
    GlassPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(tone))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.label, color = tokens.text.primary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${entry.phase.uppercase()} · ${entry.type}", color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            TinyPill(entry.risk.uppercase(), riskColor(entry.risk))
        }
    }
}

@Composable
private fun ClientNodesScreen(
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    var reconnecting by remember { mutableStateOf(false) }
    var reconnectSummary by remember { mutableStateOf("") }
    val connected = truth.auto.success || truth.manual.success

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("YOUR MESH")
            Text("Near, known, and trusted.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Local and remote identity never collapse into one label.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item { NodeMeshGraphic(connected = connected) }
        item {
            GlassPanel {
                NodeLine(
                    icon = Icons.Outlined.Devices,
                    name = "This phone",
                    detail = "CLIENT · local operator",
                    status = "READY",
                    tone = tokens.status.success,
                )
                Spacer(Modifier.height(12.dp))
                NodeLine(
                    icon = Icons.Outlined.Hub,
                    name = if (truth.config.configured) "Glitch Dragon Core" else "Core Node",
                    detail = if (truth.config.configured) "NODE_HOST · local link · ${truth.config.nodeUrl}" else "No node configured",
                    status = if (connected) "CONNECTED" else if (truth.config.configured) "OFFLINE" else "UNPAIRED",
                    tone = if (connected) tokens.status.info else tokens.status.warning,
                )
            }
        }
        if (reconnectSummary.isNotBlank()) {
            item { GlassPanel { Text(reconnectSummary, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp) } }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !reconnecting,
                    onClick = {
                        scope.launch {
                            reconnecting = true
                            val result = withContext(Dispatchers.IO) {
                                CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true)
                            }
                            reconnectSummary = result.summary
                            reconnecting = false
                            onNotify(result.summary)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Outlined.Radar, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (reconnecting) "SCANNING" else "RECONNECT")
                }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("DISCOVERY") }
            }
        }
        item {
            OutlinedButton(onClick = onOpenCoreAdmin, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Shield, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("MANAGE NODE TRUST")
            }
        }
    }
}

@Composable
private fun NodeMeshGraphic(connected: Boolean) {
    val tokens = LocalSwurlzTokens.current
    GlassPanel(modifier = Modifier.fillMaxWidth().height(185.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val left = Offset(size.width * .23f, size.height * .68f)
            val center = Offset(size.width * .50f, size.height * .48f)
            val right = Offset(size.width * .79f, size.height * .28f)
            drawLine(tokens.accents.primary.copy(alpha = .50f), left, center, 2f)
            drawLine(tokens.accents.tertiary.copy(alpha = if (connected) .55f else .18f), center, right, 2f)
            listOf(left, center, right).forEachIndexed { index, point ->
                drawCircle(
                    color = when (index) {
                        1 -> tokens.accents.primary
                        2 -> if (connected) tokens.status.info else tokens.text.disabled
                        else -> tokens.status.success
                    },
                    radius = if (index == 1) 15f else 11f,
                    center = point,
                    alpha = .88f,
                )
                drawCircle(tokens.text.primary.copy(alpha = .14f), radius = 28f, center = point)
            }
        }
    }
}

@Composable
private fun ClientSettingsScreen(
    style: UiStyleSettings,
    onMotionChanged: (Boolean) -> Unit,
    onOpenStyle: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("PERSONAL CORE")
            Text("Made to feel like yours.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Everyday controls stay simple. The complete engineering cockpit remains one switch away.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel(highlighted = true) {
                SettingLine(
                    title = style.themePack,
                    detail = if (style.themePack == "Glitch Dragon Glass") {
                        "Crystalline translucent armor · ${style.displayMode}"
                    } else {
                        "Active client armor · ${style.displayMode}"
                    },
                    trailing = {
                        IconButton(onClick = onOpenStyle) {
                            Icon(Icons.Outlined.Style, contentDescription = "Open visual style settings", tint = tokens.accents.primary)
                        }
                    },
                )
                SettingDivider()
                SettingLine(
                    title = "Motion",
                    detail = "Dragon drift, core pulse, and screen transitions",
                    trailing = {
                        Switch(checked = style.animationLevel != "Off", onCheckedChange = onMotionChanged)
                    },
                )
            }
        }
        item {
            SectionLabel("SOVEREIGNTY")
            GlassPanel {
                SettingLine(
                    title = "Truth Firewall",
                    detail = "Valid objections and uncertainty stay visible",
                    trailing = { TinyPill("ARMED", tokens.status.success) },
                )
                SettingDivider()
                SettingLine(
                    title = "Local-first core",
                    detail = "Online services enhance; they never become the leash",
                    trailing = { TinyPill("ACTIVE", tokens.status.success) },
                )
                SettingDivider()
                SettingLine(
                    title = "Sharing approvals",
                    detail = "Ask before anything leaves this device",
                    trailing = { TextButton(onClick = onOpenSetup) { Text("REVIEW") } },
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpenPermissions, modifier = Modifier.weight(1f)) { Text("PERMISSIONS") }
                OutlinedButton(onClick = onOpenStyle, modifier = Modifier.weight(1f)) { Text("STYLE") }
            }
        }
        item {
            OutlinedButton(onClick = onOpenDeveloper, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.DeveloperMode, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("SWITCH TO SWRLZ DEV MODE")
            }
        }
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val shape = RoundedCornerShape(22.dp)
    val borderBrush = Brush.linearGradient(
        if (highlighted) {
            listOf(tokens.accents.primary, tokens.accents.tertiary, tokens.accents.secondary)
        } else {
            listOf(tokens.accents.primary.copy(alpha = .38f), tokens.borders.neutral.copy(alpha = .34f), tokens.accents.tertiary.copy(alpha = .30f))
        }
    )
    Box(modifier.background(borderBrush, shape).padding(1.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(tokens.cards.bg.copy(alpha = .72f), tokens.cards.bgAlt.copy(alpha = .56f))
                    ),
                    shape,
                )
                .padding(15.dp),
            content = content,
        )
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Column(
        modifier = modifier
            .semantics { contentDescription = "$label quick action" }
            .clip(RoundedCornerShape(17.dp))
            .background(tokens.cards.bg.copy(alpha = .62f))
            .border(1.dp, tokens.accents.primary.copy(alpha = .24f), RoundedCornerShape(17.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = tokens.accents.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = tokens.text.secondary, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun NodeLine(icon: ImageVector, name: String, detail: String, status: String, tone: Color) {
    val tokens = LocalSwurlzTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(tokens.accents.primary.copy(alpha = .12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = tone)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        TinyPill(status, tone)
    }
}

@Composable
private fun SettingLine(title: String, detail: String, trailing: @Composable () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(10.dp))
        trailing()
    }
}

@Composable
private fun SettingDivider() {
    val tokens = LocalSwurlzTokens.current
    Spacer(Modifier.height(12.dp))
    Box(Modifier.fillMaxWidth().height(1.dp).background(tokens.borders.neutral.copy(alpha = .45f)))
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun SectionLabel(text: String) {
    val tokens = LocalSwurlzTokens.current
    Text(text, color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.8.sp)
}

@Composable
private fun TinyPill(text: String, tone: Color, modifier: Modifier = Modifier) {
    val tokens = LocalSwurlzTokens.current
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(tokens.surfaces.bgOverlay.copy(alpha = .60f))
            .border(1.dp, tone.copy(alpha = .55f), CircleShape)
            .padding(horizontal = 8.dp, vertical = 5.dp),
    ) {
        Text(text, color = tone, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .8.sp, maxLines = 1)
    }
}

@Composable
private fun SovereigntyDialog(
    paused: Boolean,
    onDismiss: () -> Unit,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.accents.primary) },
        title = { Text("Sovereign controls") },
        text = { Text("Pause freezes the current mission. Take Over stops automated execution and leaves SWRLZ observing only.") },
        confirmButton = {
            Button(onClick = onPauseToggle) {
                Icon(if (paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (paused) "RESUME" else "PAUSE")
            }
        },
        dismissButton = {
            TextButton(onClick = onTakeOver, colors = ButtonDefaults.textButtonColors(contentColor = tokens.status.danger)) {
                Icon(Icons.Outlined.PanTool, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("TAKE OVER")
            }
        },
        containerColor = tokens.surfaces.bgOverlay.copy(alpha = .97f),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ApprovalSheet(
    missionGoal: String,
    onApprove: () -> Unit,
    onRedirect: () -> Unit,
    onDecline: () -> Unit,
    onDismiss: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = tokens.surfaces.bgOverlay.copy(alpha = .96f),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
            TinyPill("APPROVAL REQUIRED", tokens.status.warning)
            Spacer(Modifier.height(10.dp))
            Text("Review the next mission step", color = tokens.text.primary, fontSize = 21.sp, fontWeight = FontWeight.Medium)
            Text(
                if (missionGoal.isBlank()) "SWRLZ is waiting for your decision." else missionGoal,
                color = tokens.text.secondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
            Spacer(Modifier.height(12.dp))
            GlassPanel {
                Text("Approval applies once. It does not grant future sharing, spending, deletion, messaging, account changes, or permanent actions.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onApprove, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("APPROVE ONCE")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRedirect, modifier = Modifier.weight(1f)) { Text("REDIRECT") }
                TextButton(onClick = onDecline, modifier = Modifier.weight(1f)) { Text("DECLINE") }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

private fun ambientColor(ambient: MissionBus.Ambient): Color = when (ambient) {
    MissionBus.Ambient.Idle -> Color(0xFF9AA7B2)
    MissionBus.Ambient.Listening -> Color(0xFF45F5FF)
    MissionBus.Ambient.Observing -> Color(0xFF2FEAFF)
    MissionBus.Ambient.Planning -> Color(0xFF9C5CFF)
    MissionBus.Ambient.Acting -> Color(0xFF4DFF88)
    MissionBus.Ambient.Paused -> Color(0xFFFFD45A)
    MissionBus.Ambient.Error -> Color(0xFFFF4D68)
    MissionBus.Ambient.Done -> Color(0xFF4DFF88)
}

private fun phaseColor(phase: String): Color = when (phase.lowercase()) {
    "planned" -> Color(0xFF9C5CFF)
    "executing" -> Color(0xFF2FEAFF)
    "success" -> Color(0xFF4DFF88)
    "failure" -> Color(0xFFFF4D68)
    "rolled_back" -> Color(0xFFFFD45A)
    else -> Color(0xFF9AA7B2)
}

private fun riskColor(risk: String): Color = when (risk.lowercase()) {
    "green", "low" -> Color(0xFF4DFF88)
    "yellow", "medium" -> Color(0xFFFFD45A)
    "red", "high", "locked" -> Color(0xFFFF4D68)
    else -> Color(0xFF9AA7B2)
}
