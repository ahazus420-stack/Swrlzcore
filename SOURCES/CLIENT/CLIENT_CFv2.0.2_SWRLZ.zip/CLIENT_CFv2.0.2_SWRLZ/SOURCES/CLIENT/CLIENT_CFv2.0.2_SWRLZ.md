# CLIENT CFv2.0.2 SWRLZ Lineage Receipt

**Label:** `GLITCH-DRAGON-LIVING-STATE-REFINEMENT`  
**Baseline source:** `CLIENT_CFv2.0.1_SWRLZ.zip`  
**Baseline SHA-256:** `5cee9adf5725a75b9e326cda04e145c511467ca3753644e8b90fe66b6af40a8d`  
**New source:** `CLIENT_CFv2.0.2_SWRLZ.zip`  
**Android identity:** `versionCode 33` / `0.2.7.6-cfv2.0.2-living-dragon-state`  
**Protocol change:** none

## Exact files modified or added

- `android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt`
- `android/app/src/main/java/sh/swurlz/core/ui/client/LivingDragonVisuals.kt`
- `android/app/src/main/res/drawable-nodpi/ic_launcher_client_foreground.png`
- `android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
- `android/app/build.gradle.kts`
- `branding/CLIENT_GLITCH_DRAGON_ICON_MASTER_4096.png`
- `README.md`
- `core/version.json`
- `core/patch_manifest.json`
- `scripts/test_cf8_admin_fallback.py`
- `scripts/verify_ui_imp_004_static.js`
- `scripts/verify_client_cfv202.py`
- `SOURCES/CLIENT/CLIENT_CFv2.0.2_SWRLZ.md`

No service, network, mission, trust, admin, discovery, security-store, pairing, protocol, or legacy Dev Mode screen implementation was modified.

## Visual effects and truthful runtime states

- Slow breathing luminance and five-pixel ambient drift while the app is foregrounded.
- Four low-opacity remembered shards with one low-frequency shimmer phase.
- Finite localized energy ripple and a short energy trace for Core, navigation, mission, node, approval, and Take Over interactions.
- Verified local-node availability slightly increases cyan intensity and adds green as a secondary trust-associated accent.
- Online Mentor configuration uses violet as a secondary accent; Planning is labeled `PROCESSING VIA MENTOR`, never local.
- Local observation and on-device action are explicitly labeled `OBSERVING LOCALLY` and `ACTING ON DEVICE`.
- Active mission uses a bounded rhythmic Core pulse; Pause and Approval use amber; Take Over uses the existing caution accent without implying bypass of safety gates.
- Disconnected/idle rendering remains visible with reduced luminance and no red flashing.
- A new crystalline dragon/operator launcher mark is supplied as a 4096×4096 source master and a bounded adaptive-icon foreground.

## Accessibility and reduced motion

- The central Core exposes a meaningful content description and textual state description.
- Decorative dragon art and shards have no accessibility description.
- Navigation and runtime state continue to use text labels in addition to color.
- Touch targets retain the existing Compose button/navigation sizing.
- Motion Off uses a static dragon scene, disables ambient drift/shimmer/pulse loops and finite decorative ripples, and keeps only a short opacity-only panel transition.
- Decorative animation pauses when the Activity lifecycle is not at least STARTED.

## Performance safeguards

- One cached drawable resource; no runtime bitmap allocation or decode loop.
- One shared low-frequency infinite transition only while foregrounded and motion-enabled.
- Four fixed shards, no spawning particle system, blur, or per-frame bitmap work.
- Finite `Animatable` ripple rather than a continuously running touch follower.
- Static fallback for reduced motion and background lifecycle states.
- The 4096×4096 icon is a source master only; Android loads the bounded 432×432 launcher foreground.

## CFv2.0.1 compilation repair preservation

The following imports remain absent:

```kotlin
import androidx.compose.foundation.layout.calculateTopPadding
import androidx.compose.foundation.layout.weight
```

`calculateTopPadding()` remains resolved through `WindowInsets.statusBars.asPaddingValues()`. `Modifier.weight(...)` remains used only under Row/Column receiver scopes.

## Verification evidence

- `python3 scripts/verify_client_cfv202.py`: PASS.
- `node scripts/verify_ui_imp_004_static.js`: PASS; 33 Kotlin files and all 13 legacy Dev Mode surfaces checked.
- `python3 scripts/test_cf8_admin_fallback.py .`: PASS.
- CF8/Ktor protected files (`AdminRoutePolicy.kt`, `Api.kt`, `CommandsScreen.kt`, and `NetworkDiscoveryScreen.kt`) are byte-for-byte identical to CLIENT CFv2.0.1.
- Source-wide forbidden-import scan: PASS; neither CFv2.0.1-breaking import exists in Kotlin source.
- `./gradlew :app:compileDebugKotlin`: NOT RUN — source-only delivery requested; deferred to owner GitHub build.
- `./gradlew :app:assembleDebug`: NOT RUN — source-only delivery requested; deferred to owner GitHub build.
- Archive integrity and extracted verifier: performed after this receipt is finalized and reported beside the download.
- Source-tree checksum (excluding this receipt): `a72d41237d908ecff13714bc15f77479e6f886e62a613cc8e4072c0da7bbafa3`.
- Canonical ZIP SHA-256: recorded in sibling `CLIENT_CFv2.0.2_SWRLZ.sha256` to avoid a self-referential archive checksum.

## Known limitations

- The existing Core control opens Council Chat; this UI-only checkpoint does not add microphone capture or Android audio permissions. It therefore does not claim that a microphone is listening merely because the control was pressed.
- Full large-text, compact-device, runtime connection, and on-device motion persistence checks require device verification after APK installation.
- Visual state follows the existing in-process mission bus and persisted node truth; this checkpoint does not add a new durable mission state model.

## Rollback

Restore the checksum-verified `CLIENT_CFv2.0.1_SWRLZ.zip`. The UI checkpoint has no data, schema, protocol, or security migration.

**Operating law:** Integrate, do not overwrite.
