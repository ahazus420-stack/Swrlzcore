#!/usr/bin/env python3
import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SHELL = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/client/ClientShellScreen.kt"
VISUALS = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/client/LivingDragonVisuals.kt"
MAIN = ROOT / "android/app/src/main/java/sh/swurlz/core/MainActivity.kt"
BUILD = ROOT / "android/app/build.gradle.kts"
ICON_MASTER = ROOT / "branding/CLIENT_GLITCH_DRAGON_ICON_MASTER_4096.png"
ICON_FOREGROUND = ROOT / "android/app/src/main/res/drawable-nodpi/ic_launcher_client_foreground.png"
ADAPTIVE_ICON = ROOT / "android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()[:24]
    require(data[:8] == b"\x89PNG\r\n\x1a\n", f"not a PNG: {path}")
    return struct.unpack(">II", data[16:24])


def main() -> int:
    shell = SHELL.read_text(encoding="utf-8")
    visuals = VISUALS.read_text(encoding="utf-8")
    main_activity = MAIN.read_text(encoding="utf-8")
    build = BUILD.read_text(encoding="utf-8")

    forbidden = (
        "import androidx.compose.foundation.layout.calculateTopPadding",
        "import androidx.compose.foundation.layout.weight",
    )
    for item in forbidden:
        require(item not in shell and item not in main_activity, f"forbidden Compose import returned: {item}")
    require(".asPaddingValues().calculateTopPadding()" in shell, "PaddingValues receiver usage missing")
    require("Modifier.weight(" in shell, "scoped Modifier.weight usage missing")

    for marker in (
        "DragonVisualState(",
        "localNodeVerified = localNodeVerified",
        "remoteEnhancementConfigured = mentorConfig.configured",
        "approvalRequired = needsApproval",
        "takeOver = takeOver",
        "PROCESSING VIA MENTOR",
        "OBSERVING LOCALLY",
        "ACTING ON DEVICE",
        "stateDescription = stateLabel",
    ):
        require(marker in shell, f"CLIENT living-state marker missing: {marker}")

    for marker in (
        "LifecycleEventObserver",
        "if (motionEnabled && foreground)",
        "StaticLivingDragonScene",
        "AnimatedLivingDragonScene",
        "DragonEnergySignal",
        "contentDescription = null",
    ):
        require(marker in visuals, f"living dragon safeguard missing: {marker}")

    require("versionCode = 33" in build, "CLIENT versionCode 33 missing")
    require('versionName = "0.2.7.6-cfv2.0.2-living-dragon-state"' in build, "CLIENT CFv2.0.2 versionName missing")
    require("CLIENT_CFv2.0.2_SWRLZ.zip" in build, "CLIENT source identity missing")

    legacy_routes = {
        "home", "cockpit", "skills", "allow", "setup", "style", "perms",
        "core", "howto", "info", "commands", "discovery", "more",
    }
    for route in legacy_routes:
        require(f'composable("{route}")' in main_activity, f"legacy Dev Mode route missing: {route}")
    require('composable("client")' in main_activity, "User Mode route missing")
    require("ClientInterfaceMode.Developer" in main_activity, "Developer mode switch missing")
    require("ClientInterfaceMode.User" in main_activity, "User mode switch missing")

    for path in (ROOT / "core/version.json", ROOT / "core/patch_manifest.json"):
        json.loads(path.read_text(encoding="utf-8"))

    require(png_size(ICON_MASTER) == (4096, 4096), "CLIENT 4K icon master dimensions changed")
    require(png_size(ICON_FOREGROUND) == (432, 432), "CLIENT adaptive foreground dimensions changed")
    require("@drawable/ic_launcher_client_foreground" in ADAPTIVE_ICON.read_text(encoding="utf-8"), "CLIENT adaptive icon is not wired to the new foreground")

    sensitive_log = re.compile(r"\bLog\.[A-Za-z]+\([^\n]*(token|password|secret|pairing)", re.IGNORECASE)
    for path in (SHELL, VISUALS):
        require(not sensitive_log.search(path.read_text(encoding="utf-8")), f"sensitive UI log pattern found: {path}")

    print("CLIENT CFv2.0.2 STATIC VERIFY PASS")
    print("CFv2.0.1 forbidden imports remain absent")
    print("13 legacy Dev Mode routes and User Mode route remain present")
    print("truthful routing labels, reduced-motion fallback, and lifecycle pause markers present")
    print("4096x4096 CLIENT icon master and adaptive launcher foreground present")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AssertionError as exc:
        print(f"CLIENT CFv2.0.2 STATIC VERIFY FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
