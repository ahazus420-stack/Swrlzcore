package sh.swurlz.core.net

import java.net.URI

/**
 * Canonical listener-role resolver.
 * Discovery may advertise on 8787, while authenticated/private API traffic is served on 8080.
 * Host identity is preserved; only a known discovery port is translated.
 */
object ServerEndpointRoles {
    private const val DISCOVERY_PORT = 8787
    private const val PRIVATE_API_PORT = 8080

    fun privateApiBase(configuredBase: String): String {
        val clean = configuredBase.trim().trimEnd('/')
        val uri = runCatching { URI(clean) }.getOrNull() ?: return clean
        if (uri.host.isNullOrBlank()) return clean
        val targetPort = if (uri.port == DISCOVERY_PORT) PRIVATE_API_PORT else uri.port
        val authority = buildString {
            append(uri.host)
            if (targetPort >= 0) append(':').append(targetPort)
        }
        return URI(uri.scheme ?: "http", authority, uri.path?.takeIf { it != "/" }, null, null).toString().trimEnd('/')
    }

    fun isDiscoveryBase(configuredBase: String): Boolean =
        runCatching { URI(configuredBase.trim()).port == DISCOVERY_PORT }.getOrDefault(false)
}
