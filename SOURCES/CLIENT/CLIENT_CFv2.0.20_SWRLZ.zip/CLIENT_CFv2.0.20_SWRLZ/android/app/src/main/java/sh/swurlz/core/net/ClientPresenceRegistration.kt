package sh.swurlz.core.net

import android.content.Context
import android.os.Build
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.UUID
import org.json.JSONObject
import sh.swurlz.core.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal object ClientPresenceRegistration {
    data class Result(val ok:Boolean, val state:String, val detail:String, val canonicalNodeId:String?=null)
    private const val PREFS="swrlz_presence_identity"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null
    private const val HEARTBEAT_INTERVAL_MS = 10_000L

    private fun stableDeviceBinding(context: Context): String {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
        val material = "${context.packageName}|$androidId|swrlz-device-binding-v1"
        return MessageDigest.getInstance("SHA-256").digest(material.toByteArray()).joinToString("") { "%02x".format(it) }
    }

    fun register(context:Context, baseUrl:String):Result {
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val installationId=prefs.getString("installationId",null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("installationId",it).apply() }
        val deviceId=Settings.Secure.getString(context.contentResolver,Settings.Secure.ANDROID_ID).orEmpty().ifBlank { "unknown-device" }
        val binding=stableDeviceBinding(context)
        val nodeId="client-"+binding.take(24)
        val body=JSONObject().apply {
            put("nodeId",nodeId); put("deviceId",deviceId); put("deviceBindingFingerprint",binding); put("installationId",installationId)
            put("displayName","${Build.MANUFACTURER} ${Build.MODEL} · SWRLZ CLIENT")
            put("deviceType","android-client"); put("appVersion",BuildConfig.VERSION_NAME); put("protocolVersion",1)
            put("packageName",context.packageName)
            put("capabilities",org.json.JSONArray(listOf("chat","missions","presence")))
        }.toString()
        val apiBase = ServerEndpointRoles.privateApiBase(baseUrl)
        return post("${apiBase.trimEnd('/')}/nodes/register",body).also { result ->
            val canonicalNodeId = result.canonicalNodeId ?: nodeId
            prefs.edit().putString("registrationState",result.state).putString("registrationDetail",result.detail).putString("deviceBindingFingerprint",binding).putString("nodeId",canonicalNodeId).putString("candidateNodeId",nodeId).putLong("lastServerHeartbeatAt",System.currentTimeMillis()).apply()
            if (result.ok) startHeartbeat(context.applicationContext, baseUrl)
        }
    }

    private fun startHeartbeat(context: Context, baseUrl: String) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            var missed = 0
            while (isActive) {
                delay(HEARTBEAT_INTERVAL_MS)
                val result = heartbeat(context, baseUrl)
                val prefs = context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
                if (result.ok) {
                    missed = 0
                    prefs.edit().putString("registrationState", "REGISTERED")
                        .putString("connectionHealth", "CONNECTED")
                        .putLong("lastServerHeartbeatAt", System.currentTimeMillis())
                        .putString("registrationDetail", result.detail).apply()
                } else {
                    if (result.detail.contains("ADMIN_DISCONNECTED")) {
                        prefs.edit().putString("connectionHealth", "DISCONNECTED")
                            .putBoolean("autoReconnectSuppressed", true)
                            .putString("registrationDetail", "Disconnected by SERVER; manual reconnect required.").apply()
                        break
                    }
                    missed += 1
                    val health = when {
                        missed >= 6 -> "DISCONNECTED"
                        missed >= 4 -> "UNAVAILABLE"
                        missed >= 2 -> "DELAYED"
                        else -> "CONNECTED"
                    }
                    prefs.edit().putString("connectionHealth", health)
                        .putString("registrationDetail", "SERVER heartbeat $health; missed=$missed. ${result.detail}").apply()
                }
            }
        }
    }

    fun heartbeat(context:Context, baseUrl:String, state:String="CONNECTED", missionId:String?=null):Result {
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val binding=stableDeviceBinding(context)
        val nodeId=prefs.getString("nodeId",null) ?: "client-"+binding.take(24)
        val body=JSONObject().apply { put("nodeId",nodeId); put("state",state); if(!missionId.isNullOrBlank()) put("missionId",missionId) }.toString()
        return post("${ServerEndpointRoles.privateApiBase(baseUrl).trimEnd('/')}/nodes/heartbeat",body)
    }

    fun disconnect(context: Context, baseUrl: String): Result {
        heartbeatJob?.cancel(); heartbeatJob = null
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val nodeId=prefs.getString("nodeId",null) ?: "client-"+stableDeviceBinding(context).take(24)
        val body=JSONObject().put("nodeId", nodeId).toString()
        val result=post("${ServerEndpointRoles.privateApiBase(baseUrl).trimEnd('/')}/nodes/disconnect", body)
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
            .putString("registrationState", "REGISTERED")
            .putString("registrationDetail", if(result.ok) "Disconnected; durable SERVER registration retained." else result.detail).apply()
        return result
    }

    private fun post(url:String, body:String):Result { var c:HttpURLConnection?=null; return try { c=URL(url).openConnection() as HttpURLConnection; c.requestMethod="POST"; c.connectTimeout=1500;c.readTimeout=1500;c.doOutput=true;c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toByteArray())}; val code=c.responseCode; val text=(if(code in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use{it.readText()}.orEmpty(); val canonical=runCatching{JSONObject(text).optString("nodeId").takeIf{it.isNotBlank()}}.getOrNull(); Result(code in 200..299, if(code in 200..299)"REGISTERED" else "REGISTRATION_FAILED",text.take(1200),canonical) } catch(e:Throwable){Result(false,"REGISTRATION_FAILED","${e.javaClass.simpleName}: ${e.message}")} finally {c?.disconnect()} }
}
