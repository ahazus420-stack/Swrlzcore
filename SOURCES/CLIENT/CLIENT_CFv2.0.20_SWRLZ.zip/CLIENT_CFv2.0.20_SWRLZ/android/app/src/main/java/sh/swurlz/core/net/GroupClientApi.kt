package sh.swurlz.core.net

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

object GroupClientApi {
    data class Result(
        val ok: Boolean,
        val code: String,
        val detail: String,
        val payload: String = "",
        val httpStatus: Int? = null,
    ) {
        val routeUnavailable: Boolean
            get() = code == "NOT_FOUND" && detail.contains("route", ignoreCase = true)

        fun userMessage(): String = when {
            routeUnavailable -> "Group synchronization reached a SERVER listener that does not expose the Groups route. Verify the SERVER API endpoint and retry."
            code == "GROUP_NOT_FOUND" -> "The selected group no longer exists on this SERVER."
            code == "INVITE_INVALID" -> "That invite code is invalid or has been rotated."
            code == "INVITE_EXPIRED" -> "That invite code expired or has already been used."
            code == "NETWORK_ERROR" -> "The SERVER could not be reached for group synchronization."
            code == "BAD_RESPONSE" -> "The SERVER returned an unreadable group response."
            else -> detail.ifBlank {
                code.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
            }
        }
    }

    private fun request(
        base: String,
        path: String,
        method: String = "POST",
        body: JSONObject? = null,
    ): Result = runCatching {
        val apiBase = ServerEndpointRoles.privateApiBase(base)
        val connection = (URL(apiBase.trimEnd('/') + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 2500
            readTimeout = 2500
            doOutput = body != null
            setRequestProperty("Content-Type", "application/json")
        }
        if (body != null) {
            connection.outputStream.use { it.write(body.toString().toByteArray()) }
        }

        val status = connection.responseCode
        val stream = if (status in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        val json = runCatching { JSONObject(text) }.getOrNull()
            ?: return@runCatching Result(false, "BAD_RESPONSE", "Invalid SERVER response", text, status)
        val error = json.optJSONObject("error")
        val ok = json.optBoolean("ok", status in 200..299)
        val code = when {
            ok -> json.optString("code", "OK")
            error != null -> error.optString("code", json.optString("code", "ERROR"))
            else -> json.optString("code", "ERROR")
        }
        val detail = when {
            error != null -> error.optString("message", error.optString("detail", code))
            else -> json.optString("detail", json.optString("message", code))
        }
        Result(ok, code, detail, text, status)
    }.getOrElse {
        Result(false, "NETWORK_ERROR", it.message ?: "Group action failed")
    }

    fun create(base: String, name: String, leaderNodeId: String) = request(
        base,
        "/v1/groups/create",
        body = JSONObject().put("name", name).put("leaderNodeId", leaderNodeId),
    )

    fun join(base: String, code: String, nodeId: String, label: String) = request(
        base,
        "/v1/groups/join",
        body = JSONObject()
            .put("inviteCode", code)
            .put("nodeId", nodeId)
            .put("nodeLabel", label)
            .put("deviceType", "android-client")
            .put("capabilities", "chat,missions,presence")
            .put("registrationState", "REGISTERED")
            .put("trustState", "UNTRUSTED")
            .put("proofState", "PENDING"),
    )

    fun list(base: String, nodeId: String) = request(
        base,
        "/v1/groups/list",
        body = JSONObject().put("nodeId", nodeId),
    )

    fun roster(base: String, groupId: String) = request(
        base,
        "/v1/groups/roster",
        body = JSONObject().put("groupId", groupId),
    )

    fun rotate(base: String, groupId: String, leaderNodeId: String) = request(
        base,
        "/v1/groups/invite/rotate",
        body = JSONObject().put("groupId", groupId).put("leaderNodeId", leaderNodeId),
    )
}
