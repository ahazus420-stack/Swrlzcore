package sh.swurlz.core.bubble

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.net.AdminRoutePolicy

/**
 * Single native Android bubble surface.
 *
 * Normal session: SWRLZ Client identity and blue dragon avatar.
 * Verified remote admin session: SWURVER Admin identity and fusion avatar.
 *
 * The retired three-window overlay dock is deliberately stopped here so tapping a
 * bubble never spawns duplicate activities or floating CLIENT/SERVER/FUSION windows.
 */
class ClientBubbleActivity : ComponentActivity() {

    companion object {
        const val EXTRA_SECTION = "bubble_section"
        const val EXTRA_SOURCE_ROLE = "bubble_source_role" // retained for compatibility
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val requested = intent.getStringExtra(EXTRA_SECTION)?.let {
                runCatching { BubbleSection.valueOf(it) }.getOrNull()
            }
            var section by remember {
                mutableStateOf(
                    requested ?: if (BubbleStateStore.restoreAfterRestart(this)) {
                        BubbleStateStore.section(this)
                    } else BubbleSection.HOME
                )
            }
            var restore by remember { mutableStateOf(BubbleStateStore.restoreAfterRestart(this)) }
            var verifiedAdmin by remember { mutableStateOf(false) }
            var adminUser by remember { mutableStateOf("") }

            LaunchedEffect(Unit) {
                val admin = withContext(Dispatchers.IO) { Prefs.adminSession(this@ClientBubbleActivity) }
                val token = withContext(Dispatchers.IO) { SecretStore.adminSessionToken(this@ClientBubbleActivity) }
                verifiedAdmin = AdminRoutePolicy.hasVerifiedSession(
                    modeEnabled = admin.modeEnabled,
                    savedToken = token,
                    lastVerifiedAt = admin.lastVerifiedAt,
                )
                adminUser = admin.username
                if (verifiedAdmin && InteractiveBubbleDockService.canDraw(this@ClientBubbleActivity)) {
                    InteractiveBubbleDockService.start(
                        this@ClientBubbleActivity,
                        BubbleLayoutMode.ALL_THREE,
                    )
                }
            }

            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (verifiedAdmin) "SWURVER · ADMIN" else "SWRLZ · CLIENT",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                            )
                            Spacer(Modifier.weight(1f))
                            AssistChip(
                                onClick = {},
                                label = { Text(if (verifiedAdmin) "AUTHENTICATED" else "CLIENT") },
                            )
                        }
                        Text(
                            if (verifiedAdmin) {
                                "Unified Client + authenticated SWURLZER command surface${adminUser.takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""}"
                            } else {
                                "Persistent SWRLZ conversation and command surface"
                            },
                            style = MaterialTheme.typography.bodySmall,
                        )

                        RadialMenu(section) { next ->
                            section = next
                            BubbleStateStore.setSection(this@ClientBubbleActivity, next)
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            tonalElevation = 4.dp,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                        ) {
                            Column(
                                Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Text(section.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(contentFor(section, verifiedAdmin))

                                if (section == BubbleSection.SETTINGS) {
                                    HorizontalDivider()
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = restore,
                                            onCheckedChange = {
                                                restore = it
                                                BubbleStateStore.setRestoreAfterRestart(this@ClientBubbleActivity, it)
                                            },
                                        )
                                        Text(" Restore last bubble page", modifier = Modifier.padding(start = 8.dp))
                                    }
                                    Text(
                                        "Verified admin mode enables the Client-owned SWRLZ, remote SWURLZER, and fused SWURVER bubble cluster. Layout preferences never grant authority.",
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun RadialMenu(selected: BubbleSection, onSelect: (BubbleSection) -> Unit) {
        val items = listOf(
            BubbleSection.CHAT,
            BubbleSection.MISSIONS,
            BubbleSection.NODES,
            BubbleSection.LOGS,
            BubbleSection.ASSISTANTS,
            BubbleSection.FUSION,
            BubbleSection.SETTINGS,
            BubbleSection.HOME,
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            items.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { item ->
                        OutlinedButton(
                            onClick = { onSelect(item) },
                            shape = CircleShape,
                            border = BorderStroke(
                                if (selected == item) 2.dp else 1.dp,
                                MaterialTheme.colorScheme.primary,
                            ),
                            contentPadding = PaddingValues(8.dp),
                            modifier = Modifier.size(72.dp),
                        ) {
                            Text(item.name.take(4), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    private fun contentFor(section: BubbleSection, verifiedAdmin: Boolean): String = when (section) {
        BubbleSection.HOME -> if (verifiedAdmin) "Authenticated SWURVER command home. Client and remote server controls remain in one native bubble." else "SWRLZ quick-access home. Your last page can be remembered."
        BubbleSection.CHAT -> "Conversation surface and message controls."
        BubbleSection.MISSIONS -> "Mission status, pause/resume, approvals, and takeover."
        BubbleSection.NODES -> if (verifiedAdmin) "Authenticated SWURLZER node status and permitted administrative actions." else "Connect and authenticate with SWURLZER to unlock administrative node controls."
        BubbleSection.LOGS -> "Recent events, notifications, communication history, and build activity."
        BubbleSection.ASSISTANTS -> "Assistant packs and swarm controls."
        BubbleSection.SETTINGS -> "Native bubble persistence and page restoration."
        BubbleSection.FUSION -> if (verifiedAdmin) "Fusion is active: SWRLZ Client + authenticated SWURLZER authority = SWURVER Admin." else "Fusion activates only after the Client has a verified SWURLZER admin session."
    }
}
