package sh.swurlz.core.bubble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import kotlin.math.hypot
import sh.swurlz.core.MainActivity
import sh.swurlz.core.R

/**
 * Client-owned custom bubble dock.
 *
 * The Client renders both the local SWRLZ identity and a remote SWURLZER identity.
 * The purple bubble is a control surface for an authenticated remote server; it does
 * not require the Server APK to be installed on this device. Because both windows are
 * owned by this service, drag collision and deterministic fusion are possible.
 */
class InteractiveBubbleDockService : Service() {

    companion object {
        private const val CHANNEL_ID = "swrlz_interactive_bubble_dock"
        private const val NOTIFICATION_ID = 4136
        private const val ACTION_APPLY_MODE = "sh.swurlz.core.bubble.APPLY_MODE"
        private const val EXTRA_MODE = "mode"

        fun canDraw(context: Context): Boolean =
            Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(context)

        fun start(context: Context, mode: BubbleLayoutMode = BubbleStateStore.mode(context)) {
            val intent = Intent(context, InteractiveBubbleDockService::class.java)
                .setAction(ACTION_APPLY_MODE)
                .putExtra(EXTRA_MODE, mode.name)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, InteractiveBubbleDockService::class.java))
        }
    }

    private data class BubbleWindow(
        val role: BubbleRole,
        val view: ImageView,
        val params: WindowManager.LayoutParams,
    )

    private enum class BubbleRole { CLIENT, SERVER, FUSION }

    private lateinit var windowManager: WindowManager
    private val windows = linkedMapOf<BubbleRole, BubbleWindow>()
    private var mode: BubbleLayoutMode = BubbleLayoutMode.DUAL
    private val bubbleSizePx by lazy { (92f * resources.displayMetrics.density).toInt() }
    private val fusionThresholdPx by lazy { 108f * resources.displayMetrics.density }
    private val magneticThresholdPx by lazy { 168f * resources.displayMetrics.density }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        ensureChannel()
        startForeground(NOTIFICATION_ID, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!canDraw(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val requestedMode = intent?.getStringExtra(EXTRA_MODE)?.let {
            runCatching { BubbleLayoutMode.valueOf(it) }.getOrNull()
        } ?: BubbleStateStore.mode(this)
        val authority = BubbleAuthorityResolver.resolveBlocking(this)
        mode = if (authority.verifiedAdmin) {
            if (requestedMode == BubbleLayoutMode.SINGLE) BubbleLayoutMode.ALL_THREE else requestedMode
        } else {
            BubbleLayoutMode.SINGLE
        }
        BubbleStateStore.setInteractiveDockEnabled(this, true)
        BubbleStateStore.setMode(this, mode)
        renderMode(mode)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        windows.values.forEach { runCatching { windowManager.removeView(it.view) } }
        windows.clear()
        super.onDestroy()
    }

    private fun renderMode(next: BubbleLayoutMode) {
        mode = next
        val required = when (next) {
            BubbleLayoutMode.SINGLE -> setOf(BubbleRole.CLIENT)
            BubbleLayoutMode.DUAL -> setOf(BubbleRole.CLIENT, BubbleRole.SERVER)
            BubbleLayoutMode.FUSION -> setOf(BubbleRole.FUSION)
            BubbleLayoutMode.ALL_THREE -> setOf(BubbleRole.CLIENT, BubbleRole.SERVER, BubbleRole.FUSION)
        }

        windows.keys.filterNot(required::contains).toList().forEach(::removeBubble)
        required.forEach { role -> if (!windows.containsKey(role)) addBubble(role) }
        notificationManager().notify(NOTIFICATION_ID, notification())
    }

    private fun addBubble(role: BubbleRole) {
        val saved = BubbleStateStore.position(this, role.name)
        val defaults = defaultPosition(role)
        val params = overlayParams(saved?.first ?: defaults.first, saved?.second ?: defaults.second)
        val view = ImageView(this).apply {
            setImageResource(iconFor(role))
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = when (role) {
                BubbleRole.CLIENT -> "SWRLZ Client bubble"
                BubbleRole.SERVER -> "Connected SWURLZER controls"
                BubbleRole.FUSION -> "SWURVER fusion bubble"
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x22000000)
                setStroke((2 * resources.displayMetrics.density).toInt(), 0x88FFFFFF.toInt())
            }
            clipToOutline = true
            setPadding(2, 2, 2, 2)
            setOnTouchListener(DragTouchListener(role, params))
        }
        windowManager.addView(view, params)
        windows[role] = BubbleWindow(role, view, params)
    }

    private inner class DragTouchListener(
        private val role: BubbleRole,
        private val params: WindowManager.LayoutParams,
    ) : View.OnTouchListener {
        private var initialX = 0
        private var initialY = 0
        private var downX = 0f
        private var downY = 0f
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    downX = event.rawX
                    downY = event.rawY
                    moved = false
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    moved = moved || hypot(dx.toDouble(), dy.toDouble()) > 8.0
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()
                    runCatching { windowManager.updateViewLayout(view, params) }
                    applyMagnetism(role)
                    return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    BubbleStateStore.setPosition(this@InteractiveBubbleDockService, role.name, params.x, params.y)
                    if (!moved) openRole(role)
                    else if ((role == BubbleRole.CLIENT || role == BubbleRole.SERVER) && bubblesTouch()) fuseAtMidpoint()
                    return true
                }
            }
            return false
        }
    }

    private fun applyMagnetism(dragged: BubbleRole) {
        if (dragged != BubbleRole.CLIENT && dragged != BubbleRole.SERVER) return
        val client = windows[BubbleRole.CLIENT] ?: return
        val server = windows[BubbleRole.SERVER] ?: return
        val distance = centerDistance(client.params, server.params)
        if (distance >= magneticThresholdPx || distance <= fusionThresholdPx) return

        val target = if (dragged == BubbleRole.CLIENT) server.params else client.params
        val moving = windows[dragged]?.params ?: return
        moving.x += ((target.x - moving.x) * 0.08f).toInt()
        moving.y += ((target.y - moving.y) * 0.08f).toInt()
        windows[dragged]?.let { runCatching { windowManager.updateViewLayout(it.view, moving) } }
    }

    private fun bubblesTouch(): Boolean {
        val client = windows[BubbleRole.CLIENT] ?: return false
        val server = windows[BubbleRole.SERVER] ?: return false
        return centerDistance(client.params, server.params) <= fusionThresholdPx
    }

    private fun centerDistance(a: WindowManager.LayoutParams, b: WindowManager.LayoutParams): Float =
        hypot((a.x - b.x).toFloat(), (a.y - b.y).toFloat())

    private fun fuseAtMidpoint() {
        if (!BubbleAuthorityResolver.resolveBlocking(this).verifiedAdmin) {
            renderMode(BubbleLayoutMode.SINGLE)
            return
        }
        val client = windows[BubbleRole.CLIENT] ?: return
        val server = windows[BubbleRole.SERVER] ?: return
        val midX = (client.params.x + server.params.x) / 2
        val midY = (client.params.y + server.params.y) / 2
        BubbleStateStore.setPosition(this, BubbleRole.FUSION.name, midX, midY)

        val resultMode = if (BubbleStateStore.keepOriginalsWhenFused(this)) {
            BubbleLayoutMode.ALL_THREE
        } else {
            BubbleLayoutMode.FUSION
        }
        BubbleStateStore.setMode(this, resultMode)
        renderMode(resultMode)
    }

    private fun openRole(role: BubbleRole) {
        val section = when (role) {
            BubbleRole.CLIENT -> BubbleSection.HOME
            BubbleRole.SERVER -> BubbleSection.NODES
            BubbleRole.FUSION -> BubbleSection.FUSION
        }
        val intent = Intent(this, ClientBubbleActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NEW_DOCUMENT)
            .putExtra(ClientBubbleActivity.EXTRA_SECTION, section.name)
            .putExtra(ClientBubbleActivity.EXTRA_SOURCE_ROLE, role.name)
        startActivity(intent)
    }

    private fun removeBubble(role: BubbleRole) {
        windows.remove(role)?.let { runCatching { windowManager.removeView(it.view) } }
    }

    private fun overlayParams(x: Int, y: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        }
        return WindowManager.LayoutParams(
            bubbleSizePx,
            bubbleSizePx,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
    }

    private fun defaultPosition(role: BubbleRole): Pair<Int, Int> {
        val width = resources.displayMetrics.widthPixels
        return when (role) {
            BubbleRole.CLIENT -> (width - bubbleSizePx - 30) to 220
            BubbleRole.SERVER -> (width - bubbleSizePx - 30) to (220 + bubbleSizePx + 24)
            BubbleRole.FUSION -> (width - bubbleSizePx - 30) to (220 + (bubbleSizePx / 2))
        }
    }

    private fun iconFor(role: BubbleRole): Int = when (role) {
        BubbleRole.CLIENT -> R.drawable.swrlz_client_named
        BubbleRole.SERVER -> R.drawable.swurlzer_server_named
        BubbleRole.FUSION -> R.drawable.swurver_fusion_named
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        notificationManager().createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "SWRLZ Interactive Bubble Dock",
                NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Keeps the Client-owned SWRLZ, remote SWURLZER, and SWURVER fusion bubbles available."
            }
        )
    }

    private fun notification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.swrlz_client_named)
            .setContentTitle("SWRLZ Interactive Bubble Dock")
            .setContentText("${mode.name.replace('_', ' ')} mode · drag Client and SWURLZER together to fuse")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager
}
