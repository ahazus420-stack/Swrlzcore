package sh.swurlz.core.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Duration
import java.time.Instant
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
fun GitHubForgeScreen() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()

    var owner by remember { mutableStateOf("ahazus420-stack") }
    var repository by remember { mutableStateOf("Swrlzcore") }
    var branch by remember { mutableStateOf("main") }
    var destination by remember { mutableStateOf("SOURCES/INBOX") }
    var message by remember { mutableStateOf("Upload CLIENT and SERVER source packages through SWRLZ Forge") }
    var token by remember { mutableStateOf(SecretStore.githubToken(context)) }
    var oauthClientId by remember { mutableStateOf(SecretStore.githubOAuthClientId(context)) }
    var connectedLogin by remember { mutableStateOf("") }
    var deviceAuth by remember { mutableStateOf<GitHubForgeClient.DeviceAuthorization?>(null) }
    var workflowId by remember { mutableStateOf("") }
    var dispatch by remember { mutableStateOf(false) }
    var autoRefresh by remember { mutableStateOf(true) }
    var autoRoute by remember { mutableStateOf(true) }
    var files by remember { mutableStateOf(emptyList<GitHubForgeClient.LocalFile>()) }
    var runs by remember { mutableStateOf(emptyList<GitHubForgeClient.WorkflowRun>()) }
    var artifacts by remember { mutableStateOf(emptyList<GitHubForgeClient.Artifact>()) }
    var jobsByRun by remember { mutableStateOf<Map<Long, List<GitHubForgeClient.WorkflowJob>>>(emptyMap()) }
    var selectedRunId by remember { mutableStateOf<Long?>(null) }
    var pendingArtifactBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingArtifactName by remember { mutableStateOf("artifact.zip") }
    var busy by remember { mutableStateOf(false) }
    var forgeProgress by remember { mutableIntStateOf(0) }
    var signingIn by remember { mutableStateOf(false) }
    var showManualToken by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect GitHub, stage CLIENT and SERVER packages, then forge one atomic commit.") }

    fun refreshRuns() {
        if (token.isBlank()) return
        busy = true
        status = "Refreshing workflow runs…"
        scope.launch {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token) } }
                .onSuccess { runs = it; status = "Loaded ${it.size} recent workflow run(s)." }
                .onFailure { status = "Workflow refresh failed: ${it.message}" }
            busy = false
        }
    }

    LaunchedEffect(autoRefresh, token, owner, repository, branch) {
        while (autoRefresh && token.isNotBlank()) {
            delay(5_000)
            runCatching {
                withContext(Dispatchers.IO) {
                    GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token)
                }
            }.onSuccess { refreshed ->
                runs = refreshed
                val active = refreshed.filter { it.status != "completed" }.take(3)
                active.forEach { run ->
                    runCatching {
                        withContext(Dispatchers.IO) {
                            GitHubForgeClient.listWorkflowJobs(owner, repository, run.id, token)
                        }
                    }.onSuccess { jobs ->
                        jobsByRun = jobsByRun + (run.id to jobs)
                    }
                }
            }
        }
    }

    LaunchedEffect(token) {
        if (token.isNotBlank() && connectedLogin.isBlank()) {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) } }
                .onSuccess { connectedLogin = it.login; status = "Connected to GitHub as ${it.login}." }
                .onFailure { SecretStore.forgetGithubToken(context); token = "" }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val additions = uris.distinct().map { uri ->
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            GitHubForgeClient.describe(context, uri)
        }
        files = (files + additions).distinctBy { it.uri.toString() }
        status = if (additions.isEmpty()) "No new files selected." else "${additions.size} file(s) added; ${files.size} total staged."
    }

    val artifactSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val bytes = pendingArtifactBytes
        if (uri != null && bytes != null) {
            runCatching { GitHubForgeClient.writeArtifact(context, uri, bytes) }
                .onSuccess { status = "Saved $pendingArtifactName successfully." }
                .onFailure { status = "Artifact save failed: ${it.message}" }
        }
        pendingArtifactBytes = null
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("▸ GITHUB FORGE", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Text("Mass-upload CLIENT and SERVER source ZIPs to their authoritative repository locations, dispatch builds, observe workflow state, and download resulting APK/ZIP artifacts.", color = tokens.text.secondary, fontSize = 13.sp, lineHeight = 19.sp)

        ForgePanel("GITHUB ACCOUNT") {
            if (connectedLogin.isNotBlank()) {
                Text("Connected as $connectedLogin", color = tokens.text.primary, fontWeight = FontWeight.Bold)
                Text("Token secured by Android Keystore-backed encrypted storage.", color = tokens.text.secondary, fontSize = 11.sp)
                TextButton(onClick = {
                    SecretStore.forgetGithubToken(context); token = ""; connectedLogin = ""; deviceAuth = null
                    status = "GitHub disconnected from this SWRLZ Client."
                }) { Text("DISCONNECT GITHUB") }
            } else {
                ForgeField("GITHUB OAUTH APP CLIENT ID", oauthClientId, { oauthClientId = it })
                Button(
                    enabled = !signingIn && oauthClientId.isNotBlank(),
                    onClick = {
                        signingIn = true
                        SecretStore.setGithubOAuthClientId(context, oauthClientId)
                        status = "Requesting a GitHub device authorization code…"
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.beginDeviceAuthorization(oauthClientId) } }
                                .onSuccess { auth ->
                                    deviceAuth = auth
                                    status = "Enter ${auth.userCode} on GitHub and approve SWRLZ."
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(auth.verificationUri))) }
                                    val deadline = System.currentTimeMillis() + auth.expiresInSeconds * 1000L
                                    var interval = auth.pollingIntervalSeconds
                                    while (signingIn && System.currentTimeMillis() < deadline) {
                                        delay(interval * 1000L)
                                        when (val result = withContext(Dispatchers.IO) { GitHubForgeClient.pollDeviceAuthorization(oauthClientId, auth.deviceCode, interval) }) {
                                            is GitHubForgeClient.DeviceTokenPoll.Authorized -> {
                                                token = result.token; SecretStore.setGithubToken(context, token)
                                                connectedLogin = withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token).login }
                                                status = "Connected to GitHub as $connectedLogin."; signingIn = false
                                            }
                                            is GitHubForgeClient.DeviceTokenPoll.Pending -> interval = result.retryAfterSeconds
                                            is GitHubForgeClient.DeviceTokenPoll.Failed -> { status = "GitHub sign-in failed: ${result.message}"; signingIn = false }
                                        }
                                    }
                                    if (signingIn) { status = "GitHub sign-in code expired."; signingIn = false }
                                }
                                .onFailure { status = "Unable to start sign-in: ${it.message}"; signingIn = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0),
                ) { Text(if (signingIn) "WAITING FOR GITHUB…" else "CONNECT GITHUB") }
                deviceAuth?.let { auth ->
                    Text("Device code: ${auth.userCode}", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = { showManualToken = !showManualToken }) { Text(if (showManualToken) "HIDE TOKEN FALLBACK" else "USE FINE-GRAINED TOKEN") }
                if (showManualToken) {
                    ForgeField("FINE-GRAINED TOKEN", token, { token = it }, secret = true)
                    OutlinedButton(enabled = token.isNotBlank(), onClick = {
                        busy = true
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) } }
                                .onSuccess { SecretStore.setGithubToken(context, token); connectedLogin = it.login; status = "Connected as ${it.login}." }
                                .onFailure { status = "Token validation failed: ${it.message}" }
                            busy = false
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("VALIDATE TOKEN") }
                }
            }
        }

        ForgePanel("REPOSITORY TARGET") {
            ForgeField("OWNER", owner, { owner = it })
            ForgeField("REPOSITORY", repository, { repository = it })
            ForgeField("BRANCH", branch, { branch = it })
            ForgeField("FALLBACK DESTINATION", destination, { destination = it })
            ForgeField("COMMIT MESSAGE", message, { message = it }, singleLine = false)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("AUTO-ROUTE SOURCE PACKAGES", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("CLIENT_* → SOURCES/CLIENT   |   SERVER_* → SOURCES/SERVER", color = tokens.text.secondary, fontSize = 11.sp)
                }
                Switch(checked = autoRoute, onCheckedChange = { autoRoute = it })
            }
        }

        OutlinedButton(enabled = connectedLogin.isNotBlank(), onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0), border = BorderStroke(1.dp, tokens.accents.primary)) {
            Text(if (files.isEmpty()) "SELECT CLIENT + SERVER FILES" else "ADD MORE FILES TO STAGING")
        }

        if (files.isNotEmpty()) ForgePanel("STAGED MASS UPLOAD") {
            files.forEach { file ->
                val path = GitHubForgeClient.destinationPath(file.displayName, destination, autoRoute)
                Text("• ${file.displayName}${formatSize(file.sizeBytes)}", color = tokens.text.primary, fontSize = 12.sp)
                Text("  ↳ $path", color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
            TextButton(onClick = { files = emptyList(); status = "Staging cleared." }) { Text("CLEAR STAGING") }
        }

        ForgePanel("BUILD DISPATCH") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("DISPATCH AFTER COMMIT", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Start a workflow_dispatch build immediately after upload.", color = tokens.text.secondary, fontSize = 11.sp)
                }
                Switch(checked = dispatch, onCheckedChange = { dispatch = it })
            }
            if (dispatch) ForgeField("WORKFLOW FILE OR ID", workflowId, { workflowId = it })
        }

        Button(
            enabled = !busy && files.isNotEmpty() && token.isNotBlank() && connectedLogin.isNotBlank(),
            onClick = {
                busy = true; forgeProgress = 1; status = "Uploading ${files.size} files and creating one atomic commit…"
                scope.launch {
                    val validation = withContext(Dispatchers.IO) {
                        GitHubForgeClient.validateSourcePairs(context, files)
                    }
                    if (!validation.valid) {
                        status = validation.message
                        forgeProgress = 0
                        busy = false
                        return@launch
                    }
                    status = validation.message
                    runCatching { withContext(Dispatchers.IO) {
                        GitHubForgeClient.upload(context, GitHubForgeClient.UploadRequest(owner, repository, branch, destination, message, token, files, workflowId, dispatch, autoRoute) { percent, detail -> forgeProgress = percent; status = detail })
                    }}.onSuccess { result ->
                        status = "Committed ${result.uploadedPaths.size} files at ${result.commitSha.take(12)}.${if (dispatch) " Build dispatched." else ""}"
                        if (dispatch) { delay(2500); runs = withContext(Dispatchers.IO) { GitHubForgeClient.listWorkflowRuns(owner, repository, branch, token) } }
                    }.onFailure { status = "Upload failed: ${it.message ?: it::class.simpleName}"; forgeProgress = 0 }
                    busy = false
                }
            },
            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(0),
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accents.primary, contentColor = tokens.surfaces.bgApp),
        ) { Text(if (busy) "FORGING… $forgeProgress%" else "COMMIT MASS UPLOAD", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) }

        if (busy || forgeProgress > 0) {
            LinearProgressIndicator(progress = { forgeProgress / 100f }, modifier = Modifier.fillMaxWidth())
            Text("$forgeProgress% · $status", color = tokens.text.secondary, fontSize = 11.sp)
        }

        ForgePanel("WORKFLOW OBSERVER") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("AUTO REFRESH · 5 SECONDS", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("Workflow state updates automatically while Forge is open.", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Switch(checked = autoRefresh, onCheckedChange = { autoRefresh = it })
            }
            OutlinedButton(enabled = connectedLogin.isNotBlank() && !busy, onClick = { refreshRuns() }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH NOW") }
            runs.forEach { run ->
                val stateTone = when {
                    run.status != "completed" -> tokens.status.warning
                    run.conclusion == "success" -> tokens.status.success
                    run.conclusion in setOf("failure", "cancelled", "timed_out", "action_required") -> tokens.status.danger
                    else -> tokens.status.info
                }
                Column(
                    Modifier.fillMaxWidth().border(1.dp, stateTone).background(stateTone.copy(alpha = 0.08f)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                Text(run.name, color = stateTone, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                val runAge = relativeTime(run.runStartedAt ?: run.createdAt)
                val runDuration = elapsedBetween(run.runStartedAt ?: run.createdAt, if (run.status == "completed") run.updatedAt else null)
                Text("${run.status}${run.conclusion?.let { " / $it" } ?: ""} · ${run.branch} · ${run.event}", color = tokens.text.secondary, fontSize = 11.sp)
                Text("Started $runAge · $runDuration", color = tokens.text.secondary, fontSize = 11.sp)
                if (run.status == "completed") {
                    LinearProgressIndicator(progress = { 1f }, modifier = Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text("Build is cooking — GitHub reports phases, not an exact compile percentage.", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Text(run.displayTitle, color = tokens.text.secondary, fontSize = 11.sp)
                val jobs = jobsByRun[run.id].orEmpty()
                jobs.forEach { job ->
                    Text("${job.name}: ${job.status}${job.conclusion?.let { " / $it" } ?: ""}", color = tokens.text.primary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    job.steps.forEach { step ->
                        val marker = when {
                            step.status == "in_progress" -> "▶"
                            step.conclusion == "success" -> "✓"
                            step.conclusion != null -> "✕"
                            else -> "○"
                        }
                        Text("$marker ${step.name}", color = tokens.text.secondary, fontSize = 10.sp)
                    }
                }
                if (run.status != "completed" && jobs.isEmpty()) {
                    Text("Waiting for GitHub job and step details…", color = tokens.text.secondary, fontSize = 10.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        selectedRunId = run.id; busy = true; status = "Loading artifacts for ${run.name}…"
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.listArtifacts(owner, repository, run.id, token) } }
                                .onSuccess { found ->
                                    artifacts = found
                                    status = "Loaded ${found.size} artifact(s) for run ${run.id}."
                                    val single = found.singleOrNull { !it.expired }
                                    if (single != null) {
                                        status = "Downloading ${single.name} from GitHub Actions…"
                                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadArtifact(owner, repository, single.id, token) } }
                                            .onSuccess { bytes ->
                                                pendingArtifactBytes = bytes
                                                pendingArtifactName = if (single.name.endsWith(".zip", true)) single.name else "${single.name}.zip"
                                                status = "Artifact received. Choose where to save it."
                                                artifactSaver.launch(pendingArtifactName)
                                            }
                                            .onFailure { status = "Artifact download failed: ${it.message}" }
                                    }
                                }
                                .onFailure { status = "Artifact lookup failed: ${it.message}" }
                            busy = false
                        }
                    }) { Text("ARTIFACTS") }
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(run.htmlUrl))) }) { Text("OPEN") }
                }
                }
            }
        }

        if (selectedRunId != null) ForgePanel("RUN ARTIFACTS") {
            if (artifacts.isEmpty()) Text("No downloadable artifacts found for the selected run.", color = tokens.text.secondary, fontSize = 11.sp)
            artifacts.forEach { artifact ->
                Text("${artifact.name}${formatSize(artifact.sizeBytes)} · ${relativeTime(artifact.createdAt)}${if (artifact.expired) " · EXPIRED" else ""}", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                OutlinedButton(enabled = !artifact.expired && !busy, onClick = {
                    busy = true; status = "Downloading ${artifact.name} from GitHub Actions…"
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.downloadArtifact(owner, repository, artifact.id, token) } }
                            .onSuccess { bytes ->
                                pendingArtifactBytes = bytes
                                pendingArtifactName = if (artifact.name.endsWith(".zip", true)) artifact.name else "${artifact.name}.zip"
                                status = "Artifact received. Choose where to save it."
                                artifactSaver.launch(pendingArtifactName)
                            }
                            .onFailure { status = "Artifact download failed: ${it.message}" }
                        busy = false
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("DOWNLOAD ${artifact.name.uppercase()}") }
            }
        }

        ForgePanel("FORGE STATUS") { Text(status, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp) }
        Text("Fine-grained token setup for this personal build: select only Swrlzcore; grant Contents read/write and Actions read/write. Pull requests read/write is optional for a later PR-first mode.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun ForgePanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
        content()
    }
}

@Composable
private fun ForgeField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean = true, secret: Boolean = false) {
    OutlinedTextField(value = value, onValueChange = onValueChange, label = { Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }, modifier = Modifier.fillMaxWidth(), singleLine = singleLine, visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None)
}

private fun formatSize(bytes: Long): String = when {
    bytes < 0 -> ""
    bytes < 1024 -> " · $bytes B"
    bytes < 1024 * 1024 -> " · ${bytes / 1024} KiB"
    else -> " · ${"%.1f".format(bytes / 1024.0 / 1024.0)} MiB"
}


private fun relativeTime(iso: String): String = runCatching {
    val seconds = Duration.between(Instant.parse(iso), Instant.now()).seconds.coerceAtLeast(0)
    when {
        seconds < 60 -> "${seconds}s ago"
        seconds < 3600 -> "${seconds / 60}m ago"
        seconds < 86400 -> "${seconds / 3600}h ago"
        else -> "${seconds / 86400}d ago"
    }
}.getOrDefault("time unavailable")

private fun elapsedBetween(startIso: String, endIso: String?): String = runCatching {
    val start = Instant.parse(startIso)
    val end = endIso?.takeIf { it.isNotBlank() }?.let(Instant::parse) ?: Instant.now()
    val seconds = Duration.between(start, end).seconds.coerceAtLeast(0)
    when {
        seconds < 60 -> "${seconds}s elapsed"
        seconds < 3600 -> "${seconds / 60}m ${seconds % 60}s elapsed"
        else -> "${seconds / 3600}h ${(seconds % 3600) / 60}m elapsed"
    }
}.getOrDefault("duration unavailable")
