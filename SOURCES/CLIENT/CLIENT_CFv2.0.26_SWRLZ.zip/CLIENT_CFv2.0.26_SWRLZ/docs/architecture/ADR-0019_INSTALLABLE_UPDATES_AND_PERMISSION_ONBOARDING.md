# ADR-0019: Installable Updates and First-Run Permission Orchestration

Status: Accepted

## Context

Android only accepts an APK as an update when the package name matches, the incoming `versionCode`
is higher, and the signing certificate is compatible with the installed application. App-private
data is preserved during an in-place update and erased by uninstall.

SWRLZ also needs a deterministic first-run experience. Runtime permissions can be requested through
the Activity Result API, but Accessibility and overlay access are special settings that Android
requires the user to grant in system UI. No application can silently grant those capabilities.

## Decision

1. Keep the existing package IDs unchanged.
2. Increment every shipped build's `versionCode`.
3. Sign client and server debug/release artifacts with the same SWRLZ development or production key,
   supplied through `local.properties` or environment variables.
4. Present a first-run permission centre when required permissions are incomplete.
5. Treat “Accept all” as a guided sequence: request ordinary runtime permissions, then open each
   protected Android settings screen that still requires user confirmation.
6. On the server, persist `start_server_on_launch`, default it to `true`, and start the foreground
   service only after permission onboarding is complete.
7. Expose the server launch toggle again in Settings.

## Signing configuration

Required values:

```properties
SWRLZ_DEV_KEYSTORE_FILE=keystore/swrlz-dev.jks
SWRLZ_DEV_KEYSTORE_PASSWORD=...
SWRLZ_DEV_KEY_ALIAS=...
SWRLZ_DEV_KEY_PASSWORD=...
```

The same keystore and alias must be used for every update in a distribution line. Do not commit the
keystore or passwords. Verify APK certificate continuity with `apksigner verify --print-certs`.

## Security

Accessibility and overlay grants remain explicit user decisions. “Accept all” does not bypass
Android consent, restricted-settings controls, or OEM security controls. The server does not start
before first-run permission setup is complete.

## Migration

Existing installations update in place when signed with the same certificate and a higher
`versionCode`. Installations signed with a different certificate cannot be repaired by source code;
they require uninstall/reinstall once, followed by consistent signing for future builds.
