# CLIENT CFv2.0.19 source evidence

- Checkpoint: INT-FIX-027D
- Android versionCode: 48
- Android versionName: `0.2.7.23-cfv2.0.19-int-fix-027d`
- Source-only package
- Build status: not built by this checkpoint
- Runtime status: not tested by this checkpoint

Static checks verify nested SERVER error parsing, sanitized user messaging, guarded group mutations, and unchanged `/v1/groups/*` route constants.
