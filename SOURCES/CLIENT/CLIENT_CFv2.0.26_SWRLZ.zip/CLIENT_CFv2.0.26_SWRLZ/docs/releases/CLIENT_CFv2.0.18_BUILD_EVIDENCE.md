# CLIENT CFv2.0.18 Build Evidence Record

## Predecessor evidence
GitHub Actions build input: CLIENT CFv2.0.17.

Observed terminal compiler evidence:

```text
> Task :app:compileDebugKotlin FAILED
ClientShellScreen.kt:1275:39 Unresolved reference 'error'.
BUILD FAILED
Gradle exit code: 1
```

## Corrective mapping

| Failed reference | Canonical replacement | Reason |
|---|---|---|
| `tokens.status.error` | `tokens.status.danger` | `StatusColors` exposes `danger`; it does not expose `error`. |

## Current verification status
CLIENT CFv2.0.18 is source-only and has not been compiled in this checkpoint. A subsequent GitHub Actions or local Gradle run is required for authoritative build evidence.
