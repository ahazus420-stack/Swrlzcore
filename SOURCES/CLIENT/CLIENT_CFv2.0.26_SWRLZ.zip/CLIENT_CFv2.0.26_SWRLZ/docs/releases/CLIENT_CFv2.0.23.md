# CLIENT CFv2.0.23 — Device Continuity

**Date:** 2026-07-23

## Changes

- Registration now uses protocol v2.
- Sends `deviceRecoveryId`, `candidateNodeId`, `installationId`, and
  `identitySchemaVersion`.
- Stops transmitting raw `ANDROID_ID`.
- Keeps the existing binding derivation namespace so previously enrolled devices remain matchable.
- Stores the SERVER-returned canonical node ID for heartbeat and disconnect operations.
- Includes legacy digest field names temporarily for protocol migration compatibility.

## Operational Requirement

All APKs intended to represent the same logical device must use the same application ID and signing
certificate. A different signing identity can change the app-scoped Android ID.

## Verification

Static source verification passed. Gradle execution was attempted but the wrapper distribution was
not available locally and network access to `services.gradle.org` was unavailable. CI must run
`./gradlew testDebugUnitTest` before release signing.
