# INT-ARCH-028 — Identity Lineage and Endpoint Roles

## Component
CLIENT CFv2.0.20

## Implemented
- Separates discovery-listener and private-API endpoint roles.
- Preserves SERVER-owned logical node identity across matching reinstall lineage.
- Treats installation identity as lineage metadata rather than logical node authority.
- Preserves explicit trust and proof gates; no reinstall grants trust.
- Exposes SERVER-owned group membership on node cards.
- Does not merge records by display name or phone model.

## Security boundary
Reconciliation occurs only from existing SERVER evidence selected by exact binding/device lookup. A different physical/signing identity is not silently merged. Existing group membership remains attached to the canonical logical node ID.

## Build boundary
Source-only checkpoint. No APK build, installation, GitHub modification, workflow dispatch, release, or deployment was performed.
