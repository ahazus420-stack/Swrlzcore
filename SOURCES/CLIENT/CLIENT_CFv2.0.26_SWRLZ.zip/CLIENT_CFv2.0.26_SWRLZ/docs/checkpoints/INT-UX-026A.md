# INT-UX-026A — Swipeable Navigation and Dedicated Group Workspaces

**Mode:** IMPLEMENT  
**Status:** PARTIAL (source implementation complete; compilation and runtime verification not run)

## Objective

Make navigation horizontally scrollable on CLIENT and SERVER, add a dedicated Groups destination to both interfaces, and expose SERVER-authoritative group creation, joining, inspection, assignment, and immediate state refresh behavior without weakening identity, trust, consent, or offline-first boundaries.

## Sources of truth inspected

- CLIENT CFv2.0.15 source package
- SERVER CFv2.0.15 source package
- `GroupClientApi.kt`
- SERVER `GroupProtocol.kt`, Room group entities/DAO, `HostUiState`, and `HostViewModel`
- Existing INT-UX-025B-REV1 and INT-UX-025D checkpoint records
- ADR-0017 SERVER heartbeat authority

## Confirmed facts

- SERVER remains the canonical owner of group identity, validation, membership, invite validity, and stored group state.
- CLIENT owns user intent capture, local presentation, and refresh requests.
- Existing CLIENT group controls were embedded in an otherwise unreachable Nodes composable and were not represented as a primary navigation destination.
- Existing SERVER group controls were embedded in Nodes and lacked a dedicated collaboration workspace.

## Contract slice

| Item | Shared contract | CLIENT | NODE_HOST | Classification |
|---|---|---|---|---|
| Group list | Existing SERVER response | Requests and presents | Validates and returns | MATCH |
| Create group | Existing operation | Captures name and submits | Validates uniqueness and persists | MATCH |
| Join by invite | Existing operation | Submits pending request | Validates invite and stores request | MATCH |
| Group assignment | Existing operation | Presents membership state | Operator assigns registered node | MATCH |
| Navigation | UI-only | Swipeable Groups tab added | Swipeable Groups tab added | MATCH |
| Immediate refresh | Existing observable state/request flow | Refreshes after accepted mutations | Publishes repository-backed state | UNVERIFIED at runtime |

## Compatibility impact

Additive UI change. No wire field or endpoint was removed or renamed. Existing protocol version remains valid. Older CLIENT or SERVER builds continue to operate without the new navigation destinations.

## Changes made

### CLIENT CFv2.0.16

- Added a primary `Groups` tab.
- Added horizontally scrollable bottom navigation.
- Added dedicated Groups workspace with SERVER sync status, create-group and join-code dialogs, group cards, and group-context actions.
- Group list refresh occurs on connection and after accepted create/join mutations.

### SERVER CFv2.0.16

- Added a primary `Groups` tab.
- Added horizontally scrollable bottom navigation.
- Added dedicated SERVER Groups workspace with active summary, group creation, group inspection, and registered-node assignment.
- Existing Nodes group summary remains as an operational shortcut.

## Verification performed

- Targeted source inspection.
- Presence checks for both new enum destinations and both destination render branches.
- Presence checks for horizontal scrolling and fixed-width navigation items.
- Kotlin delimiter balance check.
- ZIP integrity and SHA-256 verification during packaging.

No Gradle build, APK build, emulator run, device run, GitHub workflow, commit, push, release, or deployment was performed.

## Risks and unknowns

- Kotlin/Compose compilation remains unverified until an authorized build occurs.
- Runtime group roster, invite rotation, pending-request counts, and leader-management controls remain limited by the currently exposed repository/view-model data.
- HTTP request/response transport refreshes immediately after active operations but is not a persistent server-push channel.

## Recommended next checkpoint

`INT-VERIFY-026B` — Compile and device-verify CLIENT and SERVER CFv2.0.16 navigation, group workflows, and immediate refresh behavior.

STOP — Current integration checkpoint ended. Await explicit approval before continuing.
