# INT-UI-028D — CLIENT Core Group Overview

## Purpose
Add a compact, SERVER-authoritative group summary to the CLIENT Core session card without duplicating the full Groups workspace.

## Implemented
- Queries the canonical group list only while the current SERVER session is registered and online.
- Queries each returned group roster to derive active and online device counts from SERVER-owned membership and presence state.
- Displays the current group name, node role, and online/active device ratio for one group.
- Displays an aggregate group count and online/active device ratio for multiple memberships.
- Displays truthful loading, unavailable, and unassigned states.
- Makes the summary card open the dedicated Groups workspace.
- Does not infer membership or online state from local device labels.

## Identity
- CLIENT: CFv2.0.22
- Android versionCode: 51
- Android versionName: 0.2.7.26-cfv2.0.22-int-ui-028d

## Boundaries
- Source-only implementation.
- No SERVER changes.
- No APK build, installation, GitHub modification, workflow, release, or deployment.
