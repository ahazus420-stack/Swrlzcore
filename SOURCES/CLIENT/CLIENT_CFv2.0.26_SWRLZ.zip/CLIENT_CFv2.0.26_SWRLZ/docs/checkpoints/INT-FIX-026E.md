# INT-FIX-026E — CLIENT Status Token Compilation Repair

## Objective
Repair the single Kotlin compiler defect reported by GitHub Actions for CLIENT CFv2.0.17, advance CLIENT source identity to CFv2.0.18, and preserve the build evidence in repository documentation.

## Build evidence received
The GitHub Actions CLIENT build reached `:app:compileDebugKotlin` and failed at:

```text
ClientShellScreen.kt:1275:39 Unresolved reference 'error'
```

The affected branch referenced `tokens.status.error`, while the canonical CLIENT theme status palette exposes `tokens.status.danger` for error/destructive presentation.

The user separately reported SERVER CFv2.0.17 built successfully. This checkpoint does not modify or repackage SERVER.

## Source change

```kotlin
// Before
else -> tokens.status.error

// After
else -> tokens.status.danger
```

## Version change
- `versionCode`: 46 → 47
- `versionName`: `0.2.7.21-cfv2.0.17-int-fix-026c` → `0.2.7.22-cfv2.0.18-int-fix-026e`

## Scope boundary
This is a bounded source-only compiler repair. No protocol, group-routing, heartbeat, identity, trust, Truth Firewall, lineage, or SERVER-authority behavior was changed.

## Verification boundary
The invalid symbol was removed, the canonical replacement exists in the source theme contract, package identity was advanced, and archive/checksum verification was performed. No Gradle build, APK build, workflow run, runtime test, GitHub commit, push, release, or deployment was performed.
