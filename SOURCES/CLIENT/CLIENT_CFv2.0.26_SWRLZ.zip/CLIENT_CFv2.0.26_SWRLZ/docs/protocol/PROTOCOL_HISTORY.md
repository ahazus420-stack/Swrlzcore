## Protocol v2 — Reinstall-safe identity (2026-07-23)

Registration adds `candidateNodeId`, `deviceRecoveryId`, and `identitySchemaVersion`.
`installationId` remains per-install. The SERVER returns its canonical `nodeId`.
Raw Android identifiers are not required by protocol v2. Recovered installs without proof require
trust reapproval. Protocol v1 remains temporarily accepted.

## INT-UI-028D — CLIENT Core group overview

No protocol routes or schemas changed. The CLIENT reuses the existing SERVER-authoritative group-list and roster responses to render a compact Core-page overview.

# SWRLZ Protocol History

## Protocol v1 — INT-UX-025B-REV1 extension
- SERVER heartbeat authority metadata added to successful registration/heartbeat responses.
- Fields: authority, sequence, serverTimeEpochMs, intervalMs, delayedAfterMs, unavailableAfterMs, disconnectedAfterMs.
- Administrative disconnect state: DISCONNECTED_ADMIN / ADMIN_DISCONNECTED.
- Compatibility: additive JSON fields; existing v1 clients may ignore unknown fields.
- No trust, proof, identity, or mission-authorization bypass introduced.


## INT-UX-026A

No wire-breaking protocol change. Dedicated CLIENT and SERVER group workspaces consume the existing group operations. Runtime immediate-refresh behavior remains request/response based and is not represented as persistent server push.

## INT-FIX-026C

- `/v1/groups/list` is now registered by the SERVER group dispatcher.
- List responses add `nodeId`, `role`, `membershipState`, and `memberCount`.
- Roster responses add `code`, `name`, `leaderNodeId`, node labels, presence state, and last-seen timestamps.
- Changes are additive; protocolVersion and schemaVersion remain unchanged.

## INT-FIX-026E — CLIENT CFv2.0.18
- Protocol impact: none.
- Corrected one CLIENT UI theme-token reference that blocked Kotlin compilation.
- All v1 group, presence, heartbeat, trust, identity, and mission contracts remain unchanged.

## INT-FIX-027D

CLIENT error handling now accepts both group-protocol top-level errors and nested discovery/compatibility error envelopes. This is a presentation and compatibility-detection repair; canonical Groups routes remain `/v1/groups/*`, and SERVER authority over membership truth is unchanged.
