package sh.swurlz.core.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import sh.swurlz.core.MainActivity
import sh.swurlz.core.bubble.ClientBubbleController
import sh.swurlz.core.R
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.UiStyleSettings

object ClientStatusNotification {
    private const val CHANNEL_ID = "swurlz_client_status"
    private const val NOTIFICATION_ID = 4102

    fun update(
        context: Context,
        enabled: Boolean,
        mission: MissionBus.MissionLive,
        ambient: MissionBus.Ambient,
        truth: CoreNodeTruthState,
        style: UiStyleSettings,
    ) {
        if (!enabled) {
            NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
            ClientBubbleController.cancel(context)
            return
        }
        ensureChannel(context)
        val launchIntent = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val connected = truth.auto.success || truth.manual.success
        val title = "SWRLZ Client · ${ambient.name.uppercase()}"
        val line1 = if (connected) "Server session reachable" else "Local-first · server offline"
        val line2 = when {
            mission.goal.isNotBlank() -> "Mission: ${mission.goal.take(72)}"
            connected -> (truth.auto.summary.ifBlank { truth.manual.summary }).ifBlank { "Core node online" }
            else -> "Ready for a local mission"
        }
        val theme = "${style.themePack} · ${style.displayMode}"
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(line1)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .setBigContentTitle("Ω  $title")
                    .bigText("$line1\n$line2\nTheme armor: $theme")
            )
            .setSubText("Glitch Dragon Core")
            .setContentIntent(pending)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
        ClientBubbleController.publish(context, title, line2)
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "SWRLZ Client Status", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Persistent local client, mission, and server-session status."
                    setShowBadge(false)
                }
            )
        }
    }
}
