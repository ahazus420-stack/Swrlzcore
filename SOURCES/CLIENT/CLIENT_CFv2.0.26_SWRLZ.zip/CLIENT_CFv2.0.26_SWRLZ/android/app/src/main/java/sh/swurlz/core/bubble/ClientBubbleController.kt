package sh.swurlz.core.bubble

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import sh.swurlz.core.R

object ClientBubbleController {
    private const val CHANNEL_ID = "swurlz_client_conversation"
    private const val NOTIFICATION_ID = 4110
    private const val SHORTCUT_ID = "swurlz_client_chat"

    fun publish(context: Context, title: String, detail: String) {
        ensureChannel(context)
        val intent = Intent(context, ClientBubbleActivity::class.java)
        val pending = PendingIntent.getActivity(
            context, 4110, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE,
        )
        val icon = Icon.createWithResource(context, R.mipmap.ic_launcher)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            context.getSystemService(ShortcutManager::class.java)?.pushDynamicShortcut(
                ShortcutInfo.Builder(context, SHORTCUT_ID)
                    .setShortLabel("SWRLZ Chat")
                    .setLongLived(true)
                    .setIcon(icon)
                    .setIntent(intent.setAction(Intent.ACTION_VIEW))
                    .build(),
            )
        }
        val person = Person.Builder().setName("SWRLZ Client").setIcon(icon).setImportant(true).build()
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(detail)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setShortcutId(SHORTCUT_ID)
            .setStyle(
                NotificationCompat.MessagingStyle(person)
                    .setConversationTitle(title)
                    .addMessage(detail, System.currentTimeMillis(), person),
            )
            .setBubbleMetadata(
                NotificationCompat.BubbleMetadata.Builder(pending, icon)
                    .setDesiredHeight(640)
                    .setAutoExpandBubble(false)
                    .setSuppressNotification(false)
                    .build(),
            )
            .setOnlyAlertOnce(true)
            .build()
        runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "SWRLZ Chat and Missions",
                    NotificationManager.IMPORTANCE_DEFAULT,
                ).apply {
                    description = "Conversation bubbles for SWRLZ chat, mission status, and approvals."
                    setAllowBubbles(true)
                },
            )
        }
    }
}
