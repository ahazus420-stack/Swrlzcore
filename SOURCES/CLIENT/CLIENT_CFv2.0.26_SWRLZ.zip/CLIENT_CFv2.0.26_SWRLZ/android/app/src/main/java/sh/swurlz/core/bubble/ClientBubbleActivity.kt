package sh.swurlz.core.bubble

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import sh.swurlz.core.data.MissionBus

class ClientBubbleActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    var draft by remember { mutableStateOf("") }
                    var transcript by remember { mutableStateOf("Dragon link ready.") }
                    val mission = MissionBus.mission.value
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text("Ω  SWRLZ CHAT", style = MaterialTheme.typography.titleLarge)
                        Text(if (mission.goal.isBlank()) "No active mission" else "Mission: ${mission.goal.take(120)}")
                        Text(transcript)
                        OutlinedTextField(
                            value = draft,
                            onValueChange = { draft = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Message") },
                            maxLines = 3,
                        )
                        Row(Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    val text = draft.trim()
                                    if (text.isNotEmpty()) {
                                        transcript = "You: $text"
                                        draft = ""
                                    }
                                },
                                enabled = draft.isNotBlank(),
                                modifier = Modifier.weight(1f),
                            ) { Text("SEND") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                            }) {
                                Text(if (MissionBus.pauseRequest.value) "RESUME" else "PAUSE")
                            }
                        }
                    }
                }
            }
        }
    }
}
