# INT-FIX-027D implementation report

The CLIENT and SERVER source packages were inspected together. Their canonical route contracts match: CLIENT CFv2.0.18 requests `/v1/groups/*`, and SERVER CFv2.0.17 dispatches those routes through `GroupProtocol` before discovery fallback.

The screenshot's `Discovery route not found` response is therefore evidence of an older or otherwise nonmatching SERVER runtime. The CLIENT additionally mishandled the nested discovery error envelope and exposed its raw JSON to the user.

CLIENT CFv2.0.19 repairs parsing and presentation, preserves the raw payload for diagnostics, and fails closed for group mutation controls until synchronization proves the SERVER supports the Groups contract.
