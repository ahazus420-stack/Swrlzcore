# INT-UI-028D Implementation Report

The CLIENT Core session card now includes a concise SERVER-authoritative collaboration overview. It shows the node's group role and the number of active group devices currently online, with truthful unavailable and empty states. Selecting the summary opens the full Groups workspace.

The implementation reuses the canonical Groups list and roster APIs. It does not introduce local membership authority or change SERVER behavior.
