# INT-UX-031A Implementation Report

## Scope
Corrected the client onboarding placement and added default-on notification-shade status widgets for client and server.

## Client changes
- Added **Accept All** to `PreflightScreen`.
- Restored the earlier Accessibility/Overlay permission-centre interaction.
- Added `status_notification_enabled` to DataStore.
- Added `ClientStatusNotification`.
- Added a Notification widget toggle to user Settings.
- Bumped Android `versionCode` to 54 and source version to CFv2.0.25.

## Server changes
- Added `status_notification_enabled` to DataStore.
- Added a Notification widget toggle to Settings.
- Expanded the foreground notification with listener/runtime and theme information.
- Preserved the mandatory minimal foreground-service notification when enhanced details are disabled.
- Bumped Android `versionCode` to 24 and source version to CFv2.0.22.

## Verification
Static verification confirmed preference defaults, settings wiring, preflight bulk selection, restored permission-centre flow, notification channel construction, and version increments. A full Gradle build was not executed in this sandbox.
