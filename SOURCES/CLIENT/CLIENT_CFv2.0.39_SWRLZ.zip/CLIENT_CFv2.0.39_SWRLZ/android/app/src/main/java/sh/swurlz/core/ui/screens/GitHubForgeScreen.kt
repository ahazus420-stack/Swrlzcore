package sh.swurlz.core.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
fun GitHubForgeScreen() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()

    var owner by remember { mutableStateOf("ahazus420-stack") }
    var repository by remember { mutableStateOf("Swrlzcore") }
    var branch by remember { mutableStateOf("main") }
    var destination by remember { mutableStateOf("SOURCES/CLIENT") }
    var message by remember { mutableStateOf("Upload source package through SWRLZ GitHub Forge") }
    var token by remember { mutableStateOf(SecretStore.githubToken(context)) }
    var oauthClientId by remember { mutableStateOf(SecretStore.githubOAuthClientId(context)) }
    var connectedLogin by remember { mutableStateOf("") }
    var deviceAuth by remember { mutableStateOf<GitHubForgeClient.DeviceAuthorization?>(null) }
    var workflowId by remember { mutableStateOf("") }
    var dispatch by remember { mutableStateOf(false) }
    var files by remember { mutableStateOf(emptyList<GitHubForgeClient.LocalFile>()) }
    var busy by remember { mutableStateOf(false) }
    var signingIn by remember { mutableStateOf(false) }
    var showManualToken by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect GitHub, then select one or more files to stage an atomic repository commit.") }

    LaunchedEffect(token) {
        if (token.isNotBlank() && connectedLogin.isBlank()) {
            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) } }
                .onSuccess { connectedLogin = it.login; status = "Connected to GitHub as ${it.login}." }
                .onFailure { SecretStore.forgetGithubToken(context); token = "" }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        files = uris.distinct().map { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            GitHubForgeClient.describe(context, uri)
        }
        status = if (files.isEmpty()) "No files selected." else "${files.size} file(s) staged. Review destination and commit settings."
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("▸ GITHUB FORGE", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Text(
            "Connect your GitHub account, stage multiple files, create one atomic commit, and optionally dispatch the build workflow. This bypasses the website uploader's 25 MiB ceiling.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )

        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(12.dp)) {
            Text("GITHUB ACCOUNT", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(6.dp))
            if (connectedLogin.isNotBlank()) {
                Text("Connected as $connectedLogin", color = tokens.text.primary, fontWeight = FontWeight.Bold)
                Text("SWRLZ stores the access token in Android Keystore-backed encrypted storage.", color = tokens.text.secondary, fontSize = 11.sp)
                TextButton(onClick = {
                    SecretStore.forgetGithubToken(context)
                    token = ""
                    connectedLogin = ""
                    deviceAuth = null
                    status = "GitHub disconnected from this SWRLZ Client."
                }) { Text("DISCONNECT GITHUB") }
            } else {
                ForgeField("GITHUB OAUTH APP CLIENT ID", oauthClientId, { oauthClientId = it })
                Text(
                    "Enter the Client ID from your GitHub OAuth App once. SWRLZ uses GitHub's Device Authorization Flow; your GitHub password is never entered into the app.",
                    color = tokens.text.secondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                )
                Button(
                    enabled = !signingIn && oauthClientId.isNotBlank(),
                    onClick = {
                        signingIn = true
                        status = "Requesting a GitHub device authorization code…"
                        SecretStore.setGithubOAuthClientId(context, oauthClientId)
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.beginDeviceAuthorization(oauthClientId) } }
                                .onSuccess { auth ->
                                    deviceAuth = auth
                                    status = "Enter code ${auth.userCode} on GitHub, then approve SWRLZ. Waiting for authorization…"
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(auth.verificationUri))) }
                                    val deadline = System.currentTimeMillis() + auth.expiresInSeconds * 1000L
                                    var interval = auth.pollingIntervalSeconds
                                    while (signingIn && System.currentTimeMillis() < deadline) {
                                        delay(interval * 1000L)
                                        when (val result = withContext(Dispatchers.IO) {
                                            GitHubForgeClient.pollDeviceAuthorization(oauthClientId, auth.deviceCode, interval)
                                        }) {
                                            is GitHubForgeClient.DeviceTokenPoll.Authorized -> {
                                                token = result.token
                                                SecretStore.setGithubToken(context, token)
                                                val account = withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) }
                                                connectedLogin = account.login
                                                status = "Connected to GitHub as ${account.login}."
                                                signingIn = false
                                            }
                                            is GitHubForgeClient.DeviceTokenPoll.Pending -> interval = result.retryAfterSeconds
                                            is GitHubForgeClient.DeviceTokenPoll.Failed -> {
                                                status = "GitHub sign-in failed: ${result.message}"
                                                signingIn = false
                                            }
                                        }
                                    }
                                    if (signingIn) {
                                        status = "GitHub sign-in code expired. Start connection again."
                                        signingIn = false
                                    }
                                }
                                .onFailure { error ->
                                    status = "Unable to start GitHub sign-in: ${error.message ?: error::class.simpleName}"
                                    signingIn = false
                                }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(0),
                ) { Text(if (signingIn) "WAITING FOR GITHUB…" else "CONNECT GITHUB") }

                deviceAuth?.let { auth ->
                    Text("Device code: ${auth.userCode}", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    OutlinedButton(
                        onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(auth.verificationUri))) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(0),
                    ) { Text("OPEN GITHUB AUTHORIZATION") }
                }

                TextButton(onClick = { showManualToken = !showManualToken }) {
                    Text(if (showManualToken) "HIDE MANUAL TOKEN FALLBACK" else "USE MANUAL TOKEN FALLBACK")
                }
                if (showManualToken) {
                    ForgeField("FINE-GRAINED TOKEN", token, { token = it }, secret = true)
                    OutlinedButton(
                        enabled = token.isNotBlank(),
                        onClick = {
                            busy = true
                            scope.launch {
                                runCatching { withContext(Dispatchers.IO) { GitHubForgeClient.connectedAccount(token) } }
                                    .onSuccess {
                                        SecretStore.setGithubToken(context, token)
                                        connectedLogin = it.login
                                        status = "Connected to GitHub as ${it.login}."
                                    }
                                    .onFailure { status = "Token validation failed: ${it.message}" }
                                busy = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("VALIDATE TOKEN") }
                }
            }
        }

        ForgeField("OWNER", owner, { owner = it })
        ForgeField("REPOSITORY", repository, { repository = it })
        ForgeField("BRANCH", branch, { branch = it })
        ForgeField("DESTINATION DIRECTORY", destination, { destination = it })
        ForgeField("COMMIT MESSAGE", message, { message = it }, singleLine = false)

        OutlinedButton(
            enabled = connectedLogin.isNotBlank(),
            onClick = { picker.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(0),
            border = BorderStroke(1.dp, tokens.accents.primary),
        ) { Text("SELECT MULTIPLE FILES") }

        if (files.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(10.dp)) {
                Text("STAGED PAYLOAD", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
                files.forEach { file -> Text("• ${file.displayName}${formatSize(file.sizeBytes)}", color = tokens.text.secondary, fontSize = 12.sp) }
                TextButton(onClick = { files = emptyList(); status = "Staging cleared." }) { Text("CLEAR") }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("DISPATCH WORKFLOW", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("Trigger workflow_dispatch after the commit succeeds.", color = tokens.text.secondary, fontSize = 11.sp)
            }
            Switch(checked = dispatch, onCheckedChange = { dispatch = it })
        }
        if (dispatch) ForgeField("WORKFLOW FILE OR ID", workflowId, { workflowId = it })

        Button(
            enabled = !busy && files.isNotEmpty() && token.isNotBlank() && connectedLogin.isNotBlank(),
            onClick = {
                busy = true
                status = "Uploading ${files.size} file(s) and creating one atomic commit…"
                scope.launch {
                    runCatching {
                        withContext(Dispatchers.IO) {
                            GitHubForgeClient.upload(
                                context,
                                GitHubForgeClient.UploadRequest(owner, repository, branch, destination, message, token, files, workflowId, dispatch),
                            )
                        }
                    }.onSuccess { result ->
                        status = "Committed ${result.uploadedPaths.size} file(s). Commit ${result.commitSha.take(12)}${if (dispatch) "; workflow dispatched" else ""}."
                    }.onFailure { error -> status = "Upload failed: ${error.message ?: error::class.simpleName}" }
                    busy = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(0),
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accents.primary, contentColor = tokens.surfaces.bgApp),
        ) { Text(if (busy) "FORGING…" else "COMMIT TO GITHUB", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) }

        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
            Text("FORGE STATUS", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(5.dp))
            Text(status, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
        }

        Text(
            "Security: browser sign-in uses GitHub's Device Authorization Flow. The resulting token is encrypted locally and never shown or logged. Direct commits to main still require explicit confirmation through this screen.",
            color = tokens.text.secondary,
            fontSize = 11.sp,
            lineHeight = 16.sp,
        )
    }
}

@Composable
private fun ForgeField(label: String, value: String, onValueChange: (String) -> Unit, singleLine: Boolean = true, secret: Boolean = false) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = singleLine,
        visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
    )
}

private fun formatSize(bytes: Long): String = when {
    bytes < 0 -> ""
    bytes < 1024 -> " · $bytes B"
    bytes < 1024 * 1024 -> " · ${bytes / 1024} KiB"
    else -> " · ${"%.1f".format(bytes / 1024.0 / 1024.0)} MiB"
}
