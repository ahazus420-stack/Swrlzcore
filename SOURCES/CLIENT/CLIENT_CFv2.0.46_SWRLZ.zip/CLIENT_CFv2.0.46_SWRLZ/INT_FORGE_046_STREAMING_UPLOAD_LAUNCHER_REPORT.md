# CLIENT CFv2.0.46 — Streaming Forge + Launcher Match

## Forge upload repair
- Removed whole-file ByteArray and ByteArrayOutputStream buffering.
- Added streamed Base64 JSON request content for GitHub Git blob creation.
- Upload memory now remains bounded by small working buffers instead of expanding to multiple copies of each ZIP.
- Live byte progress updates continue throughout the network request, so the Forge meter no longer appears frozen at 30% while a large blob is transmitted.
- Preserves GitHub's 100 MiB per-blob limit and atomic tree/commit/ref update sequence.

## Launcher identity repair
- Removed the adaptive-icon monochrome entry from the canonical CLIENT and Glitch Dragon aliases.
- Android launchers with themed icons enabled now fall back to the same full-color cyan dragon foreground used by CLIENT notification identity rather than rendering the generic shield/diamond mask.
- Notification small-icon handling remains monochrome and unchanged, as required by Android.

## Version
- versionCode: 74
- versionName: 2.0.46-streaming-forge-launcher-match
