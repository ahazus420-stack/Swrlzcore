package sh.swurlz.core.ui.client

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeveloperMode
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.PanTool
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import sh.swurlz.core.net.GroupClientApi
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.PermissionHelper
import sh.swurlz.core.R
import sh.swurlz.core.data.MissionBus
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeTruthState
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.net.ClientPresenceRegistration
import sh.swurlz.core.net.CoreNodeAutoDiscovery
import sh.swurlz.core.overlay.OverlayService
import sh.swurlz.core.service.MissionRunnerService
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.screens.GitHubForgeScreen

private enum class ClientTab(val label: String, val icon: ImageVector) {
    Core("Core", Icons.Outlined.Home),
    Chat("Chat", Icons.Outlined.Chat),
    Groups("Groups", Icons.Outlined.Hub),
    Missions("Missions", Icons.Outlined.ListAlt),
    Activity("Activity", Icons.Outlined.Radar),
    Forge("Forge", Icons.Outlined.Build),
    Settings("Settings", Icons.Outlined.Settings),
}

private data class ClientMessage(val fromUser: Boolean, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClientShellScreen(
    onOpenDeveloper: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenStyle: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenForge: () -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    val mission by MissionBus.mission.collectAsState()
    val ambient by MissionBus.ambient.collectAsState()
    val timeline by MissionBus.timeline.collectAsState()
    val paused by MissionBus.pauseRequest.collectAsState()
    val needsApproval by MissionBus.needsApproval.collectAsState()
    val style by Prefs.uiStyleFlow(context).collectAsState(initial = UiStyleSettings())
    val nodeTruth by Prefs.coreNodeTruthStateFlow(context).collectAsState(initial = CoreNodeTruthState())
    val statusNotificationEnabled by Prefs.statusNotificationEnabledFlow(context).collectAsState(initial = true)

    val motionEnabled = style.animationLevel != "Off"
    var selectedTabName by rememberSaveable { mutableStateOf(ClientTab.Core.name) }
    val selectedTab = ClientTab.entries.firstOrNull { it.name == selectedTabName } ?: ClientTab.Core
    var showSovereignty by remember { mutableStateOf(false) }
    var showApproval by remember { mutableStateOf(false) }
    var chatDraft by rememberSaveable { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ClientMessage(
                fromUser = false,
                text = "I’m ready. Tell me the outcome you want; I’ll keep local work local and pause before sensitive steps.",
            )
        )
    }

    fun select(tab: ClientTab) {
        selectedTabName = tab.name
    }

    fun notify(message: String) {
        scope.launch { snackbar.showSnackbar(message) }
    }

    fun seedChat(prompt: String) {
        chatDraft = prompt
        select(ClientTab.Chat)
    }

    LaunchedEffect(needsApproval) {
        if (needsApproval) showApproval = true
    }

    Box(Modifier.fillMaxSize().background(tokens.surfaces.bgApp)) {
        GlitchDragonBackdrop(motionEnabled = motionEnabled)

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                ClientTopBar(
                    selectedTab = selectedTab,
                    ambient = ambient,
                    approvalWaiting = needsApproval,
                    onOpenSovereignty = { showSovereignty = true },
                )
            },
            bottomBar = {
                ClientBottomBar(selected = selectedTab, onSelect = ::select)
            },
        ) { innerPadding ->
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    if (!motionEnabled) {
                        EnterTransition.None togetherWith ExitTransition.None
                    } else {
                        val direction = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                        (
                            slideInHorizontally(tween(320)) { width -> direction * width / 5 } +
                                fadeIn(tween(240))
                            ) togetherWith (
                            slideOutHorizontally(tween(260)) { width -> -direction * width / 7 } +
                                fadeOut(tween(180))
                            )
                    }
                },
                label = "client-tab-transition",
                modifier = Modifier.fillMaxSize().padding(innerPadding),
            ) { tab ->
                when (tab) {
                    ClientTab.Core -> ClientCoreScreen(
                        mission = mission,
                        ambient = ambient,
                        paused = paused,
                        motionEnabled = motionEnabled,
                        onSpeak = { seedChat("") },
                        onCreate = { seedChat("Create ") },
                        onObserve = { seedChat("Observe this and help me ") },
                        onTeach = { seedChat("Teach and record this workflow: ") },
                        onConnect = onOpenDiscovery,
                        onOpenMission = { select(ClientTab.Missions) },
                        truth = nodeTruth,
                        onOpenDiscovery = onOpenDiscovery,
                        onOpenCoreAdmin = onOpenCoreAdmin,
                        onOpenGroups = { select(ClientTab.Groups) },
                        onNotify = ::notify,
                    )

                    ClientTab.Chat -> ClientChatScreen(
                        messages = messages,
                        draft = chatDraft,
                        mission = mission,
                        onDraftChange = { chatDraft = it },
                        onOpenPermissions = onOpenPermissions,
                        onSend = { goal ->
                            val accessibilityReady = PermissionHelper.isAccessibilityEnabled(context)
                            val overlayReady = PermissionHelper.isOverlayGranted(context)
                            messages += ClientMessage(true, goal)
                            chatDraft = ""
                            if (!accessibilityReady || !overlayReady) {
                                messages += ClientMessage(
                                    false,
                                    "I kept that intent local, but the operator permissions are incomplete. Open Permissions to finish setup before execution.",
                                )
                                notify("Mission not started: operator permissions are incomplete.")
                            } else {
                                OverlayService.start(context)
                                MissionRunnerService.start(context, goal)
                                messages += ClientMessage(
                                    false,
                                    "Mission accepted by the local operator. I’ll expose every approval gate and stop before anything sensitive.",
                                )
                                notify("Local mission started.")
                            }
                        },
                    )

                    ClientTab.Groups -> ClientGroupsScreen(
                        truth = nodeTruth,
                        onNotify = ::notify,
                    )

                    ClientTab.Missions -> ClientMissionsScreen(
                        mission = mission,
                        ambient = ambient,
                        timeline = timeline,
                        paused = paused,
                        needsApproval = needsApproval,
                        onPauseToggle = {
                            MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                            notify(if (MissionBus.pauseRequest.value) "Mission paused." else "Mission resumed.")
                        },
                        onTakeOver = {
                            MissionBus.takeoverRequest.value = true
                            MissionRunnerService.stop(context)
                            notify("You have control. SWRLZ is observing only.")
                        },
                        onReviewApproval = { showApproval = true },
                    )

                    ClientTab.Activity -> ClientActivityScreen(
                        timeline = timeline,
                        truth = nodeTruth,
                        permissionsReady = PermissionHelper.isAccessibilityEnabled(context) && PermissionHelper.isOverlayGranted(context),
                    )

                    ClientTab.Forge -> GitHubForgeScreen()

                    ClientTab.Settings -> ClientSettingsScreen(
                        style = style,
                        statusNotificationEnabled = statusNotificationEnabled,
                        onStatusNotificationChanged = { enabled ->
                            scope.launch { Prefs.setStatusNotificationEnabled(context, enabled) }
                        },
                        onMotionChanged = { enabled ->
                            scope.launch {
                                Prefs.setUiStyle(
                                    context,
                                    style.copy(animationLevel = if (enabled) "Standard" else "Off"),
                                )
                            }
                        },
                        onOpenStyle = onOpenStyle,
                        onOpenBubble = {
                            sh.swurlz.core.bubble.ClientBubbleController.showNow(
                                context,
                                title = "SWRLZ Client",
                                detail = if (nodeTruth.auto.success || nodeTruth.manual.success) "Server connected" else "Server offline",
                            )
                        },
                        onOpenBubbleSettings = {
                            sh.swurlz.core.bubble.ClientBubbleController.openBubbleSettings(context)
                        },
                        onOpenPermissions = onOpenPermissions,
                        onOpenSetup = onOpenSetup,
                        onOpenForge = onOpenForge,
                        onOpenDeveloper = onOpenDeveloper,
                    )
                }
            }
        }

        if (showSovereignty) {
            SovereigntyDialog(
                paused = paused,
                onDismiss = { showSovereignty = false },
                onPauseToggle = {
                    MissionBus.pauseRequest.value = !MissionBus.pauseRequest.value
                    showSovereignty = false
                    notify(if (MissionBus.pauseRequest.value) "Mission paused." else "Mission resumed.")
                },
                onTakeOver = {
                    MissionBus.takeoverRequest.value = true
                    MissionRunnerService.stop(context)
                    showSovereignty = false
                    notify("Take Over armed. No further automated action will run.")
                },
            )
        }

        if (showApproval && needsApproval) {
            ApprovalSheet(
                missionGoal = mission.goal,
                onApprove = {
                    MissionBus.approvalGranted.value = true
                    showApproval = false
                    notify("Approved once. The next gate will still pause.")
                },
                onRedirect = {
                    MissionBus.pauseRequest.value = true
                    chatDraft = "Redirect this mission step: "
                    select(ClientTab.Chat)
                    showApproval = false
                },
                onDecline = {
                    MissionBus.pauseRequest.value = true
                    showApproval = false
                    notify("Approval declined. Mission remains paused.")
                },
                onDismiss = { showApproval = false },
            )
        }
    }
}

@Composable
internal fun GlitchDragonBackdrop(
    motionEnabled: Boolean,
    artAlpha: Float = .27f,
) {
    val transition = rememberInfiniteTransition(label = "glitch-dragon-backdrop")
    val animatedDrift by transition.animateFloat(
        initialValue = -9f,
        targetValue = 9f,
        animationSpec = infiniteRepeatable(tween(9000), RepeatMode.Reverse),
        label = "dragon-drift",
    )
    val animatedPulse by transition.animateFloat(
        initialValue = .72f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200), RepeatMode.Reverse),
        label = "dragon-pulse",
    )
    val drift = if (motionEnabled) animatedDrift else 0f
    val pulse = if (motionEnabled) animatedPulse else .82f

    Box(Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.glitch_dragon_core),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationX = drift
                    translationY = -drift * .35f
                    scaleX = 1.08f
                    scaleY = 1.08f
                    alpha = artAlpha.coerceIn(0f, 1f) * pulse
                },
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xA8060612),
                        Color(0x8A050512),
                        Color(0xE8050610),
                    )
                )
            )
        )
        DragonShardField(motionEnabled = motionEnabled)
    }
}

@Composable
private fun DragonShardField(motionEnabled: Boolean) {
    val transition = rememberInfiniteTransition(label = "dragon-shards")
    val phaseAnimated by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000), RepeatMode.Restart),
        label = "shard-phase",
    )
    val phase = if (motionEnabled) phaseAnimated else .42f
    val cyan = Color(0xFF2FEAFF)
    val violet = Color(0xFF884DFF)
    val shardSpecs = listOf(
        floatArrayOf(.87f, .15f, 22f, .72f),
        floatArrayOf(.77f, .31f, -30f, .46f),
        floatArrayOf(.10f, .44f, 41f, .36f),
        floatArrayOf(.91f, .72f, 74f, .58f),
        floatArrayOf(.17f, .84f, -18f, .42f),
    )

    Canvas(Modifier.fillMaxSize()) {
        shardSpecs.forEachIndexed { index, spec ->
            val wave = kotlin.math.sin((phase * 6.283f) + index).toFloat()
            val x = size.width * spec[0]
            val y = size.height * spec[1] + wave * 10f
            val h = 52f * spec[3]
            val w = 15f * spec[3]
            val path = Path().apply {
                moveTo(x, y - h / 2f)
                lineTo(x + w / 2f, y + h * .22f)
                lineTo(x, y + h / 2f)
                lineTo(x - w / 2f, y + h * .22f)
                close()
            }
            rotate(spec[2], Offset(x, y)) {
                drawPath(
                    path = path,
                    brush = Brush.linearGradient(listOf(cyan, violet), Offset(x, y - h), Offset(x, y + h)),
                    alpha = .12f + (.10f * (wave + 1f)),
                )
            }
        }
        val scanY = size.height * phase
        drawLine(
            color = cyan.copy(alpha = .08f),
            start = Offset(0f, scanY),
            end = Offset(size.width, scanY),
            strokeWidth = 2f,
        )
    }
}

@Composable
private fun ClientTopBar(
    selectedTab: ClientTab,
    ambient: MissionBus.Ambient,
    approvalWaiting: Boolean,
    onOpenSovereignty: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val statusPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(tokens.surfaces.bgTopBar.copy(alpha = .58f))
            .border(1.dp, tokens.accents.primary.copy(alpha = .18f))
            .padding(top = statusPadding + 8.dp, bottom = 10.dp, start = 16.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(tokens.accents.primary.copy(alpha = .25f), tokens.accents.tertiary.copy(alpha = .24f))))
                .border(1.dp, tokens.accents.primary.copy(alpha = .65f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text("Ω", color = tokens.text.primary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("SWRLZ · USER", color = tokens.text.primary, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.1.sp)
            Text(
                "${selectedTab.label.uppercase()} · ${ambient.name.uppercase()}",
                color = if (approvalWaiting) tokens.status.warning else ambientColor(ambient),
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                letterSpacing = 1.3.sp,
            )
        }
        if (approvalWaiting) {
            TinyPill("APPROVAL", tokens.status.warning)
            Spacer(Modifier.width(4.dp))
        }
        IconButton(onClick = onOpenSovereignty) {
            Icon(Icons.Outlined.Shield, contentDescription = "Open Pause and Take Over controls", tint = tokens.accents.primary)
        }
    }
}

@Composable
private fun ClientBottomBar(selected: ClientTab, onSelect: (ClientTab) -> Unit) {
    val tokens = LocalSwurlzTokens.current
NavigationBar(
        containerColor = tokens.surfaces.bgTopBar.copy(alpha = .72f),
        tonalElevation = 0.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = Modifier.border(1.dp, tokens.accents.primary.copy(alpha = .16f)),
    ) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
            ClientTab.entries.forEach { tab ->
                NavigationBarItem(
                    selected = selected == tab,
                    onClick = { onSelect(tab) },
                    modifier = Modifier.width(88.dp),
                    icon = { Icon(tab.icon, contentDescription = null) },
                    label = { Text(tab.label, fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = tokens.accents.primary,
                        selectedTextColor = tokens.text.primary,
                        indicatorColor = tokens.accents.primary.copy(alpha = .13f),
                        unselectedIconColor = tokens.text.muted,
                        unselectedTextColor = tokens.text.muted,
                    ),
                )
            }
        }
    }
}

@Composable
private fun ClientCoreScreen(
    mission: MissionBus.MissionLive,
    ambient: MissionBus.Ambient,
    paused: Boolean,
    motionEnabled: Boolean,
    onSpeak: () -> Unit,
    onCreate: () -> Unit,
    onObserve: () -> Unit,
    onTeach: () -> Unit,
    onConnect: () -> Unit,
    onOpenMission: () -> Unit,
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenGroups: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("GOOD TO SEE YOU, KAMI", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
            Text(
                if (mission.goal.isBlank()) "Your core is ready." else "Your mission is in motion.",
                color = tokens.text.primary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = (-0.6f).sp,
            )
            Text(
                "Speak naturally. SWRLZ handles routing and exposes every sensitive gate.",
                color = tokens.text.secondary,
                fontSize = 13.sp,
                lineHeight = 18.sp,
            )
        }
        item {
            DragonCoreOrb(ambient = ambient, motionEnabled = motionEnabled, onClick = onSpeak)
        }
        if (mission.goal.isNotBlank()) {
            item {
                GlassPanel(highlighted = true, modifier = Modifier.clickable(onClick = onOpenMission)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            SectionLabel("ACTIVE MISSION")
                            Text(mission.goal, color = tokens.text.primary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                if (mission.total > 0) "Step ${mission.step} of ${mission.total}" else mission.state.replaceFirstChar { it.uppercase() },
                                color = tokens.text.muted,
                                fontSize = 11.sp,
                            )
                        }
                        TinyPill(if (paused) "PAUSED" else ambient.name.uppercase(), if (paused) tokens.status.warning else ambientColor(ambient))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickAction("Create", Icons.Outlined.CheckCircle, Modifier.weight(1f), onCreate)
                QuickAction("Observe", Icons.Outlined.Hub, Modifier.weight(1f), onObserve)
                QuickAction("Teach", Icons.Outlined.Mic, Modifier.weight(1f), onTeach)
                QuickAction("Connect", Icons.Outlined.Radar, Modifier.weight(1f), onConnect)
            }
        }
        item {
            ClientCoreNodePanel(
                truth = truth,
                onOpenDiscovery = onOpenDiscovery,
                onOpenCoreAdmin = onOpenCoreAdmin,
                onOpenGroups = onOpenGroups,
                onNotify = onNotify,
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.status.success, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Truth Firewall armed · local-first routing active", color = tokens.text.secondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun DragonCoreOrb(
    ambient: MissionBus.Ambient,
    motionEnabled: Boolean,
    onClick: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val transition = rememberInfiniteTransition(label = "client-core-orb")
    val pulseAnimated by transition.animateFloat(
        initialValue = .96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "core-pulse",
    )
    val pulse = if (motionEnabled) pulseAnimated else 1f
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Box(
            modifier = Modifier
                .size(190.dp)
                .graphicsLayer { scaleX = pulse; scaleY = pulse }
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            tokens.accents.primary.copy(alpha = .30f),
                            tokens.accents.tertiary.copy(alpha = .18f),
                            tokens.surfaces.bgOverlay.copy(alpha = .78f),
                        )
                    )
                )
                .border(1.dp, ambientColor(ambient).copy(alpha = .85f), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.glitch_dragon_core),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().alpha(.28f),
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Ω", color = tokens.text.primary, fontSize = 50.sp, fontWeight = FontWeight.Medium)
                Text("TAP TO SPEAK", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.8.sp)
            }
        }
        TinyPill("LOCAL FIRST", tokens.accents.primary, Modifier.align(Alignment.TopEnd).padding(top = 18.dp, end = 10.dp))
        TinyPill("TRUTH FIREWALL · ON", tokens.status.success, Modifier.align(Alignment.BottomStart).padding(bottom = 18.dp, start = 4.dp))
    }
}

@Composable
private fun ClientChatScreen(
    messages: List<ClientMessage>,
    draft: String,
    mission: MissionBus.MissionLive,
    onDraftChange: (String) -> Unit,
    onOpenPermissions: () -> Unit,
    onSend: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val permissionsReady = PermissionHelper.isAccessibilityEnabled(context) && PermissionHelper.isOverlayGranted(context)
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("COUNCIL CHAT", color = tokens.text.muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.8.sp)
        Text("Say it your way.", color = tokens.text.primary, fontSize = 28.sp, fontWeight = FontWeight.Medium)
        Text("No command syntax. Sensitive actions always stop for you.", color = tokens.text.secondary, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(9.dp),
            contentPadding = PaddingValues(bottom = 10.dp),
        ) {
            items(messages) { message -> ChatBubble(message) }
            if (mission.rationale.isNotBlank()) {
                item { ChatBubble(ClientMessage(false, mission.rationale)) }
            }
        }

        if (!permissionsReady) {
            GlassPanel(modifier = Modifier.fillMaxWidth()) {
                Text("Operator permissions are incomplete. Your message can be staged, but execution will not begin.", color = tokens.status.warning, fontSize = 11.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onOpenPermissions) { Text("OPEN PERMISSIONS") }
            }
            Spacer(Modifier.height(8.dp))
        }

        GlassPanel(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = draft,
                    onValueChange = onDraftChange,
                    placeholder = { Text("Message SWRLZ…") },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = tokens.accents.primary,
                    ),
                )
                IconButton(onClick = { if (draft.isNotBlank()) onSend(draft.trim()) }) {
                    Icon(Icons.Outlined.Send, contentDescription = "Send mission intent", tint = tokens.accents.primary)
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ClientMessage) {
    val tokens = LocalSwurlzTokens.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(.86f)
                .background(
                    if (message.fromUser) {
                        Brush.linearGradient(listOf(tokens.accents.primary.copy(alpha = .74f), tokens.accents.tertiary.copy(alpha = .70f)))
                    } else {
                        Brush.linearGradient(listOf(tokens.cards.bg.copy(alpha = .72f), tokens.cards.bgAlt.copy(alpha = .60f)))
                    },
                    RoundedCornerShape(18.dp),
                )
                .border(1.dp, if (message.fromUser) tokens.accents.tertiary.copy(alpha = .55f) else tokens.accents.primary.copy(alpha = .34f), RoundedCornerShape(18.dp))
                .padding(13.dp),
        ) {
            Column {
                if (!message.fromUser) {
                    Text("SWRLZ · LOCAL", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(4.dp))
                }
                Text(message.text, color = tokens.text.primary, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun ClientMissionsScreen(
    mission: MissionBus.MissionLive,
    ambient: MissionBus.Ambient,
    timeline: List<MissionBus.TimelineEntry>,
    paused: Boolean,
    needsApproval: Boolean,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
    onReviewApproval: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("MISSION CONTROL")
            Text("Outcome first. Detail on demand.", color = tokens.text.primary, fontSize = 26.sp, fontWeight = FontWeight.Medium)
            Text("Every action stays visible, pausable, and recoverable.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel(highlighted = mission.goal.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionLabel(if (mission.goal.isBlank()) "NO ACTIVE MISSION" else "ACTIVE MISSION")
                        Text(if (mission.goal.isBlank()) "Start from Core or Chat." else mission.goal, color = tokens.text.primary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        if (mission.goal.isNotBlank()) {
                            Spacer(Modifier.height(5.dp))
                            Text(
                                if (mission.total > 0) "Step ${mission.step} of ${mission.total}" else mission.state,
                                color = tokens.text.muted,
                                fontSize = 11.sp,
                            )
                        }
                    }
                    TinyPill(if (paused) "PAUSED" else ambient.name.uppercase(), if (paused) tokens.status.warning else ambientColor(ambient))
                }
                if (mission.goal.isNotBlank()) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onPauseToggle) {
                            Icon(if (paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text(if (paused) "RESUME" else "PAUSE")
                        }
                        OutlinedButton(onClick = onTakeOver, colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.status.danger)) {
                            Icon(Icons.Outlined.PanTool, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text("TAKE OVER")
                        }
                    }
                }
            }
        }
        if (needsApproval) {
            item {
                GlassPanel(highlighted = true) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.status.warning)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Approval required", color = tokens.status.warning, fontWeight = FontWeight.Medium)
                            Text("Review exact scope before execution continues.", color = tokens.text.secondary, fontSize = 11.sp)
                        }
                        Button(onClick = onReviewApproval) { Text("REVIEW") }
                    }
                }
            }
        }
        item { SectionLabel("ACTION TIMELINE") }
        if (timeline.isEmpty()) {
            item {
                GlassPanel { Text("No mission events yet.", color = tokens.text.muted, fontSize = 12.sp) }
            }
        } else {
            items(timeline.reversed()) { entry -> TimelineRow(entry) }
        }
    }
}

@Composable
private fun TimelineRow(entry: MissionBus.TimelineEntry) {
    val tokens = LocalSwurlzTokens.current
    val tone = phaseColor(entry.phase)
    GlassPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(tone))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.label, color = tokens.text.primary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("${entry.phase.uppercase()} · ${entry.type}", color = tone, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            TinyPill(entry.risk.uppercase(), riskColor(entry.risk))
        }
    }
}

private data class CoreGroupStatus(
    val name: String,
    val role: String,
    val onlineCount: Int,
    val activeCount: Int,
)

@Composable
private fun ClientCoreNodePanel(
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onOpenGroups: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val presencePrefs = context.getSharedPreferences("swrlz_presence_identity", android.content.Context.MODE_PRIVATE)
    val connectionPrefs = context.getSharedPreferences("swrlz_connection_preferences", android.content.Context.MODE_PRIVATE)
    var registrationState by remember { mutableStateOf(presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()) }
    var enrollmentState by remember { mutableStateOf(presencePrefs.getString("enrollmentState", "NOT_ENROLLED").orEmpty()) }
    var connectionHealth by remember { mutableStateOf(presencePrefs.getString("connectionHealth", "DISCONNECTED").orEmpty()) }
    var registrationDetail by remember { mutableStateOf(presencePrefs.getString("registrationDetail", "Connect to a SERVER to begin verified registration.").orEmpty()) }
    val scope = rememberCoroutineScope()
    var connecting by remember { mutableStateOf(false) }
    var connectionSummary by remember { mutableStateOf("") }
    var autoConnect by remember { mutableStateOf(connectionPrefs.getBoolean("autoConnectOnLaunch", true)) }
    var startupAttempted by remember { mutableStateOf(false) }
    val discoveryReachable = truth.auto.checked || truth.manual.checked
    val connected = connectionHealth == "ONLINE" && registrationState == "REGISTERED"
    var nodeMenu by remember { mutableStateOf(false) }
    var groupDialog by remember { mutableStateOf<String?>(null) }
    var groupInput by remember { mutableStateOf("") }
    val hadSuccessfulConnection = connectionPrefs.getBoolean("hadSuccessfulConnection", connected)
    var coreGroups by remember { mutableStateOf<List<CoreGroupStatus>>(emptyList()) }
    var coreGroupsLoading by remember { mutableStateOf(false) }
    var coreGroupsAvailable by remember { mutableStateOf(false) }

    suspend fun refreshCoreGroups() {
        if (!connected || !truth.config.configured) {
            coreGroups = emptyList()
            coreGroupsAvailable = false
            return
        }
        coreGroupsLoading = true
        val nodeId = presencePrefs.getString("nodeId", "client-unknown").orEmpty()
        val listResult = withContext(Dispatchers.IO) { GroupClientApi.list(truth.config.nodeUrl, nodeId) }
        if (!listResult.ok) {
            coreGroups = emptyList()
            coreGroupsAvailable = false
            coreGroupsLoading = false
            return
        }
        val parsed = runCatching {
            val array = org.json.JSONObject(listResult.payload).optJSONArray("groups") ?: org.json.JSONArray()
            (0 until array.length()).map { index ->
                val item = array.optJSONObject(index) ?: org.json.JSONObject()
                val groupId = item.optString("groupId")
                val activeCountFromList = item.optInt("memberCount", 0)
                val rosterResult = withContext(Dispatchers.IO) { GroupClientApi.roster(truth.config.nodeUrl, groupId) }
                var onlineCount = 0
                var activeCount = activeCountFromList
                if (rosterResult.ok) {
                    val roster = org.json.JSONObject(rosterResult.payload).optJSONArray("members") ?: org.json.JSONArray()
                    var rosterActive = 0
                    for (memberIndex in 0 until roster.length()) {
                        val member = roster.optJSONObject(memberIndex) ?: org.json.JSONObject()
                        if (member.optString("membershipState", "ACTIVE").equals("ACTIVE", ignoreCase = true)) {
                            rosterActive += 1
                            val presence = member.optString("presenceState", "UNKNOWN")
                            if (presence.equals("ONLINE", ignoreCase = true) || presence.equals("CONNECTED", ignoreCase = true)) {
                                onlineCount += 1
                            }
                        }
                    }
                    activeCount = maxOf(activeCount, rosterActive)
                }
                CoreGroupStatus(
                    name = item.optString("name", "Node group"),
                    role = item.optString("role", "MEMBER"),
                    onlineCount = onlineCount,
                    activeCount = activeCount,
                )
            }
        }.getOrDefault(emptyList())
        coreGroups = parsed
        coreGroupsAvailable = true
        coreGroupsLoading = false
    }

    LaunchedEffect(connected, truth.config.nodeUrl, registrationState) {
        refreshCoreGroups()
    }

    LaunchedEffect(autoConnect, connected) {
        if (autoConnect && !connected && !startupAttempted) {
            startupAttempted = true
            connecting = true
            connectionSummary = "Searching for an approved SWURLZER…"
            val result = withContext(Dispatchers.IO) { CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true, includeLoopbackRange = true) }
            connectionSummary = result.summary
            if (result.connected) connectionPrefs.edit().putBoolean("hadSuccessfulConnection", true).apply()
            registrationState = presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()
            enrollmentState = presencePrefs.getString("enrollmentState", "NOT_ENROLLED").orEmpty()
            connectionHealth = presencePrefs.getString("connectionHealth", if (result.discoveryReachable) "DISCOVERY_ONLY" else "DISCONNECTED").orEmpty()
            registrationDetail = presencePrefs.getString("registrationDetail", result.detail).orEmpty()
            connecting = false
            onNotify(result.summary)
        }
    }

    val actionLabel = when {
        connecting -> "CONNECTING…"
        connected -> "CONNECTED"
        hadSuccessfulConnection -> "RECONNECT"
        truth.auto.checked || truth.manual.checked -> "RETRY CONNECTION"
        else -> "CONNECT"
    }

    GlassPanel(highlighted = connected) {
        SectionLabel("CORE CONNECTION")
        val headline = when {
            connected -> "SERVER SESSION ONLINE"
            connectionHealth == "DISCOVERY_ONLY" || discoveryReachable -> "DISCOVERY REACHABLE"
            connectionHealth == "DEGRADED" -> "SERVER SESSION DEGRADED"
            else -> "CONNECT TO SWURLZER"
        }
        Text(headline, color = if (connected) tokens.status.success else if (discoveryReachable) tokens.status.warning else tokens.text.primary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        NodeLine(
            icon = Icons.Outlined.Hub,
            name = if (truth.config.configured) "Glitch Dragon Core" else "No saved SERVER",
            detail = if (truth.config.configured) truth.config.nodeUrl else "Discovery is available",
            status = when {
                connected -> "ONLINE"
                connectionHealth == "DISCOVERY_ONLY" || discoveryReachable -> "DISCOVERY ONLY"
                connectionHealth == "DEGRADED" -> "DEGRADED"
                else -> "OFFLINE"
            },
            tone = if (connected) tokens.status.info else tokens.status.warning,
        )
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AUTO-CONNECT ON APP LAUNCH", color = tokens.text.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text("Try the saved SERVER first, then approved discovery.", color = tokens.text.muted, fontSize = 9.sp)
            }
            Switch(
                checked = autoConnect,
                onCheckedChange = {
                    autoConnect = it
                    connectionPrefs.edit().putBoolean("autoConnectOnLaunch", it).apply()
                },
            )
        }
        Spacer(Modifier.height(10.dp))
        Text("Enrollment: $enrollmentState", color = if (enrollmentState == "ENROLLED") tokens.status.success else tokens.status.warning, fontSize = 11.sp)
        Text("Current session: $registrationState · $connectionHealth", color = if (connected) tokens.status.success else tokens.status.warning, fontSize = 11.sp)
        Text(registrationDetail.take(220), color = tokens.text.secondary, fontSize = 9.sp, lineHeight = 13.sp)
        if (connected) {
            Spacer(Modifier.height(10.dp))
            GlassPanel(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenGroups),
                highlighted = coreGroupsAvailable && coreGroups.isNotEmpty(),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Hub, contentDescription = null, tint = tokens.accents.primary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        SectionLabel(if (coreGroups.size == 1) "ACTIVE GROUP" else "ACTIVE GROUPS")
                        when {
                            coreGroupsLoading -> Text("Synchronizing group overview…", color = tokens.text.secondary, fontSize = 10.sp)
                            !coreGroupsAvailable -> Text("Group overview unavailable · open Groups to retry", color = tokens.status.warning, fontSize = 10.sp)
                            coreGroups.isEmpty() -> Text("Not assigned to an active group", color = tokens.text.muted, fontSize = 10.sp)
                            coreGroups.size == 1 -> {
                                val group = coreGroups.first()
                                Text("${group.name} · ${group.role}", color = tokens.accents.primary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("${group.onlineCount} of ${group.activeCount} devices online", color = tokens.text.secondary, fontSize = 10.sp)
                            }
                            else -> {
                                val online = coreGroups.sumOf { it.onlineCount }
                                val active = coreGroups.sumOf { it.activeCount }
                                Text("${coreGroups.size} groups · ${coreGroups.joinToString(" · ") { it.name }.take(72)}", color = tokens.accents.primary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text("$online of $active group devices online", color = tokens.text.secondary, fontSize = 10.sp)
                            }
                        }
                    }
                    Icon(Icons.Outlined.ChevronRight, contentDescription = "Open Groups", tint = tokens.text.muted)
                }
            }
        }
        if (connectionSummary.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(connectionSummary, color = tokens.text.secondary, fontSize = 10.sp)
        }
        Spacer(Modifier.height(10.dp))
        if (connected) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !connecting,
                    onClick = {
                        scope.launch {
                            connecting = true
                            connectionSummary = "Disconnecting while preserving registration…"
                            val result = withContext(Dispatchers.IO) { ClientPresenceRegistration.disconnect(context, truth.config.nodeUrl) }
                            connectionSummary = result.detail
                            registrationState = "NOT_IN_SESSION"
                            connectionHealth = "DISCONNECTED"
                            registrationDetail = result.detail
                            connecting = false
                            onNotify(result.detail)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text("DISCONNECT", maxLines = 1) }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("SERVER DETAILS", maxLines = 1) }
            }
        } else if (connecting) {
            Button(enabled = false, onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Radar, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("CONNECTING…", maxLines = 1)
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        scope.launch {
                            connecting = true
                            val result = withContext(Dispatchers.IO) { CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true, includeLoopbackRange = true) }
                            connectionSummary = result.summary
                            if (result.connected) connectionPrefs.edit().putBoolean("hadSuccessfulConnection", true).apply()
                            registrationState = presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()
                            enrollmentState = presencePrefs.getString("enrollmentState", "NOT_ENROLLED").orEmpty()
                            connectionHealth = presencePrefs.getString("connectionHealth", if (result.discoveryReachable) "DISCOVERY_ONLY" else "DISCONNECTED").orEmpty()
                            registrationDetail = presencePrefs.getString("registrationDetail", result.detail).orEmpty()
                            connecting = false
                            onNotify(result.summary)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) { Text(actionLabel, maxLines = 1) }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("DISCOVERY", maxLines = 1) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onOpenCoreAdmin, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.Shield, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text("MANAGE NODE TRUST")
        }
    }
}

@Composable
private fun ClientNodesScreen(
    truth: CoreNodeTruthState,
    onOpenDiscovery: () -> Unit,
    onOpenCoreAdmin: () -> Unit,
    onNotify: (String) -> Unit,
) {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val presencePrefs = context.getSharedPreferences("swrlz_presence_identity", android.content.Context.MODE_PRIVATE)
    val registrationState = presencePrefs.getString("registrationState", "NOT_REGISTERED").orEmpty()
    val registrationDetail = presencePrefs.getString("registrationDetail", "Connect to a SERVER to begin verified registration.").orEmpty()
    val scope = rememberCoroutineScope()
    var reconnecting by remember { mutableStateOf(false) }
    var reconnectSummary by remember { mutableStateOf("") }
    val connected = truth.auto.success || truth.manual.success
    var nodeMenu by remember { mutableStateOf(false) }
    var groupDialog by remember { mutableStateOf<String?>(null) }
    var groupInput by remember { mutableStateOf("") }
    var groupsPayload by remember { mutableStateOf("") }
    var groupsLoading by remember { mutableStateOf(false) }
    fun refreshGroups() { val nodeId=presencePrefs.getString("nodeId","client-unknown").orEmpty(); scope.launch { groupsLoading=true; val r=withContext(Dispatchers.IO){GroupClientApi.list(truth.config.nodeUrl,nodeId)}; groupsPayload=r.payload; groupsLoading=false } }
    LaunchedEffect(connected) { if(connected) refreshGroups() }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("YOUR MESH")
            Text("Near, known, and trusted.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Local and remote identity never collapse into one label.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item { NodeMeshGraphic(connected = connected) }
        item {
            GlassPanel(highlighted = registrationState == "REGISTERED") {
                SectionLabel("THIS CLIENT")
                Text(registrationState, color = if (registrationState == "REGISTERED") tokens.status.success else tokens.status.warning, fontWeight = FontWeight.SemiBold)
                Text(registrationDetail.take(320), color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 14.sp)
            }
        }
        item {
            GlassPanel {
                NodeLine(
                    icon = Icons.Outlined.Devices,
                    name = "This phone",
                    detail = "CLIENT · local operator",
                    status = "READY",
                    tone = tokens.status.success,
                )
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { NodeLine(
                        icon = Icons.Outlined.Hub,
                        name = if (truth.config.configured) "Glitch Dragon Core" else "Core Node",
                        detail = if (truth.config.configured) "NODE_HOST · local link · ${truth.config.nodeUrl}" else "No node configured",
                        status = if (connected) "CONNECTED" else if (truth.config.configured) "OFFLINE" else "UNPAIRED",
                        tone = if (connected) tokens.status.info else tokens.status.warning,
                    ) }
                    Box {
                        IconButton(onClick={nodeMenu=true}) { Icon(Icons.Outlined.MoreVert, contentDescription="Node actions") }
                        DropdownMenu(expanded=nodeMenu,onDismissRequest={nodeMenu=false}) {
                            DropdownMenuItem(text={Text("View node")},onClick={nodeMenu=false})
                            DropdownMenuItem(text={Text("Send mission")},onClick={nodeMenu=false})
                            DropdownMenuItem(text={Text("Create group")},onClick={nodeMenu=false;groupDialog="create"})
                            DropdownMenuItem(text={Text("Join group with code")},onClick={nodeMenu=false;groupDialog="join"})
                        }
                    }
                }
            }
        }
        if (reconnectSummary.isNotBlank()) {
            item { GlassPanel { Text(reconnectSummary, color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp) } }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    enabled = !reconnecting,
                    onClick = {
                        scope.launch {
                            reconnecting = true
                            val result = withContext(Dispatchers.IO) {
                                CoreNodeAutoDiscovery.connectOnLaunch(context, scanWhenNeeded = true)
                            }
                            reconnectSummary = result.summary
                            reconnecting = false
                            onNotify(result.summary)
                        }
                    },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Outlined.Radar, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (reconnecting) "CONNECTING…" else if (connected) "CONNECTED" else "CONNECT")
                }
                OutlinedButton(onClick = onOpenDiscovery, modifier = Modifier.weight(1f)) { Text("DISCOVERY") }
            }
        }
        item {
            OutlinedButton(onClick = onOpenCoreAdmin, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.Shield, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("MANAGE NODE TRUST")
            }
        }
        item { GlassPanel {
            SectionLabel("GROUPS")
            Text("SERVER-owned groups restore on reconnect. Invite entry creates a pending request; the leader must approve before roster visibility becomes active.",color=tokens.text.secondary,fontSize=10.sp,lineHeight=14.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment=Alignment.CenterVertically){ Text("MY GROUPS",color=tokens.text.primary,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f)); TextButton(enabled=connected&&!groupsLoading,onClick={refreshGroups()}){Text(if(groupsLoading)"SYNCING…" else "REFRESH")} }
            val groupMatches = remember(groupsPayload) {
                runCatching {
                    val array = org.json.JSONObject(groupsPayload).optJSONArray("groups") ?: org.json.JSONArray()
                    (0 until array.length()).map { index ->
                        val item = array.optJSONObject(index) ?: org.json.JSONObject()
                        item.optString("name", "Node group") to item.optString("groupId")
                    }
                }.getOrDefault(emptyList())
            }
            if(groupMatches.isEmpty()) Text(if(connected)"No active groups returned for this CLIENT." else "Connect to a SERVER to load groups.",color=tokens.text.muted,fontSize=10.sp)
            groupMatches.forEach { (name, gid) ->
                GlassPanel { Text(name,color=tokens.accents.primary,fontWeight=FontWeight.SemiBold); Text(gid,color=tokens.text.muted,fontSize=9.sp); Row{TextButton(onClick={onNotify("Group roster opens after SERVER roster sync: $gid")}){Text("OPEN")}; TextButton(onClick={onNotify("Node actions are available from the group roster.")}){Text("NODES")}} }
                Spacer(Modifier.height(6.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button(onClick={groupDialog="create"},modifier=Modifier.weight(1f)){Text("CREATE GROUP")}
                OutlinedButton(onClick={groupDialog="join"},modifier=Modifier.weight(1f)){Text("JOIN WITH CODE")}
            }
        } }
    }
    groupDialog?.let { action ->
        AlertDialog(onDismissRequest={groupDialog=null},title={Text(if(action=="create")"Create group" else "Join group")},text={OutlinedTextField(value=groupInput,onValueChange={groupInput=it},label={Text(if(action=="create")"Unique group name" else "Invite code")})},confirmButton={TextButton(onClick={
            val base=truth.config.nodeUrl; val nodeId=presencePrefs.getString("nodeId","client-unknown").orEmpty(); val value=groupInput.trim(); groupDialog=null
            scope.launch { val result=withContext(Dispatchers.IO){if(action=="create")GroupClientApi.create(base,value,nodeId) else GroupClientApi.join(base,value,nodeId,"This phone")}; onNotify("${result.code}: ${result.detail}"); if(result.ok) refreshGroups() }
        }){Text(if(action=="create")"CREATE" else "REQUEST JOIN")}},dismissButton={TextButton(onClick={groupDialog=null}){Text("CANCEL")}})
    }
}


@Composable
private fun ClientGroupsScreen(
    truth: CoreNodeTruthState,
    onNotify: (String) -> Unit,
) {
    data class GroupSummary(
        val name: String,
        val id: String,
        val role: String,
        val membershipState: String,
        val memberCount: Int,
        val leaderNodeId: String,
    )
    data class RosterMember(
        val nodeId: String,
        val label: String,
        val role: String,
        val membershipState: String,
        val presenceState: String,
    )

    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val prefs = context.getSharedPreferences("swrlz_presence_identity", android.content.Context.MODE_PRIVATE)
    val scope = rememberCoroutineScope()
    val connected = truth.auto.success || truth.manual.success
    var payload by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var syncOk by remember { mutableStateOf(false) }
    var syncError by remember { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var rosterTitle by remember { mutableStateOf<String?>(null) }
    var rosterMembers by remember { mutableStateOf<List<RosterMember>>(emptyList()) }
    var rosterLoading by remember { mutableStateOf(false) }

    fun refresh() {
        val nodeId = prefs.getString("nodeId", "client-unknown").orEmpty()
        scope.launch {
            loading = true
            val result = withContext(Dispatchers.IO) { GroupClientApi.list(truth.config.nodeUrl, nodeId) }
            payload = if (result.ok) result.payload else ""
            syncOk = result.ok
            syncError = if (result.ok) null else result.userMessage()
            loading = false
            if (!result.ok) onNotify("GROUP SYNC: ${result.userMessage()}")
        }
    }

    fun openRoster(group: GroupSummary) {
        scope.launch {
            rosterTitle = group.name
            rosterLoading = true
            rosterMembers = emptyList()
            val result = withContext(Dispatchers.IO) { GroupClientApi.roster(truth.config.nodeUrl, group.id) }
            if (result.ok) {
                rosterMembers = runCatching {
                    val array = org.json.JSONObject(result.payload).optJSONArray("members") ?: org.json.JSONArray()
                    (0 until array.length()).map { index ->
                        val item = array.optJSONObject(index) ?: org.json.JSONObject()
                        RosterMember(
                            nodeId = item.optString("nodeId"),
                            label = item.optString("label", item.optString("nodeId")),
                            role = item.optString("role", "MEMBER"),
                            membershipState = item.optString("membershipState", "UNKNOWN"),
                            presenceState = item.optString("presenceState", "UNKNOWN"),
                        )
                    }
                }.getOrDefault(emptyList())
            } else {
                onNotify("GROUP ROSTER: ${result.userMessage()}")
            }
            rosterLoading = false
        }
    }

    LaunchedEffect(connected, truth.config.nodeUrl) {
        if (connected) refresh() else {
            syncOk = false
            syncError = null
        }
    }

    val groups = remember(payload) {
        runCatching {
            val array = org.json.JSONObject(payload).optJSONArray("groups") ?: org.json.JSONArray()
            (0 until array.length()).map { index ->
                val item = array.optJSONObject(index) ?: org.json.JSONObject()
                GroupSummary(
                    name = item.optString("name", "Node group"),
                    id = item.optString("groupId"),
                    role = item.optString("role", "MEMBER"),
                    membershipState = item.optString("membershipState", "UNKNOWN"),
                    memberCount = item.optInt("memberCount", 0),
                    leaderNodeId = item.optString("leaderNodeId"),
                )
            }
        }.getOrDefault(emptyList())
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("COLLABORATION")
            Text("Node groups.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Membership truth is owned by the connected SERVER and restored after reconnect.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            val statusText = when {
                !connected -> "OFFLINE CACHE"
                loading -> "SYNCHRONIZING"
                syncOk -> "SYNCHRONIZED"
                else -> "GROUP SYNC ERROR"
            }
            val statusColor = when {
                !connected -> tokens.status.warning
                loading -> tokens.status.info
                syncOk -> tokens.status.success
                else -> tokens.status.danger
            }
            GlassPanel(highlighted = connected && syncOk) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        SectionLabel("SERVER GROUP STATUS")
                        Text(statusText, color = statusColor, fontWeight = FontWeight.SemiBold)
                        Text(
                            when {
                                !connected -> "Reconnect to validate current membership."
                                loading -> "Requesting canonical group state from the SERVER."
                                syncOk -> "Group membership was confirmed by the SERVER."
                                else -> syncError ?: "The SERVER connection is active, but group state was not synchronized."
                            },
                            color = tokens.text.secondary,
                            fontSize = 10.sp,
                        )
                    }
                    TextButton(enabled = connected && !loading, onClick = ::refresh) { Text(if (loading) "SYNCING…" else "REFRESH") }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = connected && syncOk, onClick = { dialog = "create" }, modifier = Modifier.weight(1f)) { Text("CREATE GROUP") }
                OutlinedButton(enabled = connected && syncOk, onClick = { dialog = "join" }, modifier = Modifier.weight(1f)) { Text("JOIN WITH CODE") }
            }
        }
        item { SectionLabel("MY GROUPS") }
        if (groups.isEmpty()) {
            item {
                GlassPanel {
                    Text(
                        when {
                            !connected -> "Connect to a SERVER to load groups."
                            !syncOk -> "Group membership is unavailable until synchronization succeeds."
                            else -> "No active groups returned for this CLIENT."
                        },
                        color = tokens.text.muted,
                        fontSize = 11.sp,
                    )
                }
            }
        } else {
            items(groups, key = { it.id }) { group ->
                GlassPanel {
                    Text(group.name, color = tokens.accents.primary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("${group.role} · ${group.membershipState}", color = if (group.membershipState == "ACTIVE") tokens.status.success else tokens.status.warning, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("${group.memberCount} active member${if (group.memberCount == 1) "" else "s"}", color = tokens.text.secondary, fontSize = 10.sp)
                    Text("Leader: ${group.leaderNodeId}", color = tokens.text.muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { openRoster(group) }) { Text("OPEN") }
                        TextButton(onClick = { openRoster(group) }) { Text("MEMBERS") }
                        TextButton(onClick = { onNotify("Invite controls remain SERVER-authoritative for ${group.name}.") }) { Text("INVITE") }
                    }
                }
            }
        }
    }

    dialog?.let { action ->
        AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(if (action == "create") "Create node group" else "Join node group") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text(if (action == "create") "Unique group name" else "Invite code") })
                    Text(if (action == "create") "The SERVER validates uniqueness and makes this CLIENT the initial leader." else "A valid code submits a pending request; membership begins only after leader approval.", fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(enabled = input.trim().isNotEmpty(), onClick = {
                    val value = input.trim()
                    val nodeId = prefs.getString("nodeId", "client-unknown").orEmpty()
                    dialog = null
                    input = ""
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            if (action == "create") GroupClientApi.create(truth.config.nodeUrl, value, nodeId)
                            else GroupClientApi.join(truth.config.nodeUrl, value, nodeId, "This phone")
                        }
                        onNotify(if (result.ok) result.code.replace('_', ' ') else result.userMessage())
                        if (result.ok) refresh()
                    }
                }) { Text(if (action == "create") "CREATE" else "REQUEST JOIN") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("CANCEL") } },
        )
    }

    rosterTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { rosterTitle = null },
            title = { Text("$title members") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when {
                        rosterLoading -> Text("Synchronizing roster with SERVER…")
                        rosterMembers.isEmpty() -> Text("No active members were returned.")
                        else -> rosterMembers.forEach { member ->
                            GlassPanel {
                                Text(member.label, fontWeight = FontWeight.SemiBold)
                                Text("${member.role} · ${member.membershipState}", fontSize = 10.sp)
                                Text("Presence: ${member.presenceState}", fontSize = 10.sp, color = tokens.text.secondary)
                                Text(member.nodeId, fontSize = 8.sp, color = tokens.text.muted, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { rosterTitle = null }) { Text("CLOSE") } },
        )
    }
}

@Composable
private fun NodeMeshGraphic(connected: Boolean) {
    val tokens = LocalSwurlzTokens.current
    GlassPanel(modifier = Modifier.fillMaxWidth().height(185.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val left = Offset(size.width * .23f, size.height * .68f)
            val center = Offset(size.width * .50f, size.height * .48f)
            val right = Offset(size.width * .79f, size.height * .28f)
            drawLine(tokens.accents.primary.copy(alpha = .50f), left, center, 2f)
            drawLine(tokens.accents.tertiary.copy(alpha = if (connected) .55f else .18f), center, right, 2f)
            listOf(left, center, right).forEachIndexed { index, point ->
                drawCircle(
                    color = when (index) {
                        1 -> tokens.accents.primary
                        2 -> if (connected) tokens.status.info else tokens.text.disabled
                        else -> tokens.status.success
                    },
                    radius = if (index == 1) 15f else 11f,
                    center = point,
                    alpha = .88f,
                )
                drawCircle(tokens.text.primary.copy(alpha = .14f), radius = 28f, center = point)
            }
        }
    }
}


@Composable
private fun ClientActivityScreen(
    timeline: List<MissionBus.TimelineEntry>,
    truth: CoreNodeTruthState,
    permissionsReady: Boolean,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            SectionLabel("USER ACTIVITY")
            Text("What SWRLZ is doing.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Actionable operator events only. Raw protocol traces remain in Developer Mode.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel {
                SettingLine("Operator permissions", if (permissionsReady) "Ready for local execution" else "Attention required", trailing = { TinyPill(if (permissionsReady) "READY" else "ACTION", if (permissionsReady) tokens.status.success else tokens.status.warning) })
                SettingDivider()
                SettingLine("Core node", truth.auto.summary.ifBlank { truth.manual.summary.ifBlank { "Not reported" } }, trailing = { TinyPill(if (truth.auto.success || truth.manual.success) "READY" else "CHECK", if (truth.auto.success || truth.manual.success) tokens.status.success else tokens.status.warning) })
            }
        }
        if (timeline.isEmpty()) {
            item { GlassPanel { Text("No mission activity has been recorded in this session.", color = tokens.text.secondary, fontSize = 12.sp) } }
        } else {
            items(timeline.asReversed()) { event ->
                GlassPanel {
                    Text(event.label, color = tokens.text.primary, fontWeight = FontWeight.SemiBold)
                    Text("${event.phase} · ${event.type} · risk ${event.risk}", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
                }
            }
        }
    }
}

@Composable
private fun ClientSettingsScreen(
    style: UiStyleSettings,
    statusNotificationEnabled: Boolean,
    onStatusNotificationChanged: (Boolean) -> Unit,
    onMotionChanged: (Boolean) -> Unit,
    onOpenStyle: () -> Unit,
    onOpenBubble: () -> Unit,
    onOpenBubbleSettings: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenForge: () -> Unit,
    onOpenDeveloper: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            SectionLabel("PERSONAL CORE")
            Text("Made to feel like yours.", color = tokens.text.primary, fontSize = 27.sp, fontWeight = FontWeight.Medium)
            Text("Everyday controls stay simple. The complete engineering cockpit remains one switch away.", color = tokens.text.secondary, fontSize = 12.sp)
        }
        item {
            GlassPanel(highlighted = true) {
                SettingLine(
                    title = style.themePack,
                    detail = if (style.themePack == "Glitch Dragon Glass") {
                        "Crystalline translucent armor · ${style.displayMode}"
                    } else {
                        "Active client armor · ${style.displayMode}"
                    },
                    trailing = {
                        IconButton(onClick = onOpenStyle) {
                            Icon(Icons.Outlined.Style, contentDescription = "Open visual style settings", tint = tokens.accents.primary)
                        }
                    },
                )
                SettingDivider()
                SettingLine(
                    title = "Motion",
                    detail = "Dragon drift, core pulse, and screen transitions",
                    trailing = {
                        Switch(checked = style.animationLevel != "Off", onCheckedChange = onMotionChanged)
                    },
                )
                SettingDivider()
                SettingLine(
                    title = "Notification widget",
                    detail = "Persistent Glitch Dragon client status in the notification shade",
                    trailing = {
                        Switch(
                            checked = statusNotificationEnabled,
                            onCheckedChange = onStatusNotificationChanged,
                        )
                    },
                )
                SettingDivider()
                SettingLine(
                    title = "Floating Dragon",
                    detail = "Open the compact chat and mission bubble. Android may require conversation bubble permission.",
                    trailing = { TextButton(onClick = onOpenBubble) { Text("OPEN") } },
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onOpenBubbleSettings) { Text("BUBBLE SETTINGS") }
                }
            }
        }
        item {
            SectionLabel("SOVEREIGNTY")
            GlassPanel {
                SettingLine(
                    title = "Truth Firewall",
                    detail = "Valid objections and uncertainty stay visible",
                    trailing = { TinyPill("ARMED", tokens.status.success) },
                )
                SettingDivider()
                SettingLine(
                    title = "Local-first core",
                    detail = "Online services enhance; they never become the leash",
                    trailing = { TinyPill("ACTIVE", tokens.status.success) },
                )
                SettingDivider()
                SettingLine(
                    title = "Sharing approvals",
                    detail = "Ask before anything leaves this device",
                    trailing = { TextButton(onClick = onOpenSetup) { Text("REVIEW") } },
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onOpenPermissions, modifier = Modifier.weight(1f)) { Text("PERMISSIONS") }
                OutlinedButton(onClick = onOpenStyle, modifier = Modifier.weight(1f)) { Text("STYLE") }
            }
        }
        item {
            OutlinedButton(onClick = onOpenForge, modifier = Modifier.fillMaxWidth()) {
                Text("OPEN GITHUB FORGE")
            }
        }
        item {
            OutlinedButton(onClick = onOpenDeveloper, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.DeveloperMode, contentDescription = null)
                Spacer(Modifier.width(7.dp))
                Text("SWITCH TO SWRLZ DEV MODE")
            }
        }
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val shape = RoundedCornerShape(22.dp)
    val borderBrush = Brush.linearGradient(
        if (highlighted) {
            listOf(tokens.accents.primary, tokens.accents.tertiary, tokens.accents.secondary)
        } else {
            listOf(tokens.accents.primary.copy(alpha = .38f), tokens.borders.neutral.copy(alpha = .34f), tokens.accents.tertiary.copy(alpha = .30f))
        }
    )
    Box(modifier.background(borderBrush, shape).padding(1.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(tokens.cards.bg.copy(alpha = .72f), tokens.cards.bgAlt.copy(alpha = .56f))
                    ),
                    shape,
                )
                .padding(15.dp),
            content = content,
        )
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(17.dp))
            .background(tokens.cards.bg.copy(alpha = .62f))
            .border(1.dp, tokens.accents.primary.copy(alpha = .24f), RoundedCornerShape(17.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, contentDescription = null, tint = tokens.accents.primary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = tokens.text.secondary, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun NodeLine(icon: ImageVector, name: String, detail: String, status: String, tone: Color) {
    val tokens = LocalSwurlzTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(tokens.accents.primary.copy(alpha = .12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = tone)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.muted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        TinyPill(status, tone)
    }
}

@Composable
private fun SettingLine(title: String, detail: String, trailing: @Composable () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = tokens.text.primary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = tokens.text.muted, fontSize = 10.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(10.dp))
        trailing()
    }
}

@Composable
private fun SettingDivider() {
    val tokens = LocalSwurlzTokens.current
    Spacer(Modifier.height(12.dp))
    Box(Modifier.fillMaxWidth().height(1.dp).background(tokens.borders.neutral.copy(alpha = .45f)))
    Spacer(Modifier.height(12.dp))
}

@Composable
private fun SectionLabel(text: String) {
    val tokens = LocalSwurlzTokens.current
    Text(text, color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.8.sp)
}

@Composable
private fun TinyPill(text: String, tone: Color, modifier: Modifier = Modifier) {
    val tokens = LocalSwurlzTokens.current
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(tokens.surfaces.bgOverlay.copy(alpha = .60f))
            .border(1.dp, tone.copy(alpha = .55f), CircleShape)
            .padding(horizontal = 8.dp, vertical = 5.dp),
    ) {
        Text(text, color = tone, fontFamily = FontFamily.Monospace, fontSize = 8.sp, letterSpacing = .8.sp, maxLines = 1)
    }
}

@Composable
private fun SovereigntyDialog(
    paused: Boolean,
    onDismiss: () -> Unit,
    onPauseToggle: () -> Unit,
    onTakeOver: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Outlined.Shield, contentDescription = null, tint = tokens.accents.primary) },
        title = { Text("Sovereign controls") },
        text = { Text("Pause freezes the current mission. Take Over stops automated execution and leaves SWRLZ observing only.") },
        confirmButton = {
            Button(onClick = onPauseToggle) {
                Icon(if (paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (paused) "RESUME" else "PAUSE")
            }
        },
        dismissButton = {
            TextButton(onClick = onTakeOver, colors = ButtonDefaults.textButtonColors(contentColor = tokens.status.danger)) {
                Icon(Icons.Outlined.PanTool, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("TAKE OVER")
            }
        },
        containerColor = tokens.surfaces.bgOverlay.copy(alpha = .97f),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ApprovalSheet(
    missionGoal: String,
    onApprove: () -> Unit,
    onRedirect: () -> Unit,
    onDecline: () -> Unit,
    onDismiss: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = tokens.surfaces.bgOverlay.copy(alpha = .96f),
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
            TinyPill("APPROVAL REQUIRED", tokens.status.warning)
            Spacer(Modifier.height(10.dp))
            Text("Review the next mission step", color = tokens.text.primary, fontSize = 21.sp, fontWeight = FontWeight.Medium)
            Text(
                if (missionGoal.isBlank()) "SWRLZ is waiting for your decision." else missionGoal,
                color = tokens.text.secondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
            )
            Spacer(Modifier.height(12.dp))
            GlassPanel {
                Text("Approval applies once. It does not grant future sharing, spending, deletion, messaging, account changes, or permanent actions.", color = tokens.text.secondary, fontSize = 11.sp, lineHeight = 16.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onApprove, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.CheckCircle, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("APPROVE ONCE")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRedirect, modifier = Modifier.weight(1f)) { Text("REDIRECT") }
                TextButton(onClick = onDecline, modifier = Modifier.weight(1f)) { Text("DECLINE") }
            }
            Spacer(Modifier.height(18.dp))
        }
    }
}

private fun ambientColor(ambient: MissionBus.Ambient): Color = when (ambient) {
    MissionBus.Ambient.Idle -> Color(0xFF9AA7B2)
    MissionBus.Ambient.Listening -> Color(0xFF45F5FF)
    MissionBus.Ambient.Observing -> Color(0xFF2FEAFF)
    MissionBus.Ambient.Planning -> Color(0xFF9C5CFF)
    MissionBus.Ambient.Acting -> Color(0xFF4DFF88)
    MissionBus.Ambient.Paused -> Color(0xFFFFD45A)
    MissionBus.Ambient.Error -> Color(0xFFFF4D68)
    MissionBus.Ambient.Done -> Color(0xFF4DFF88)
}

private fun phaseColor(phase: String): Color = when (phase.lowercase()) {
    "planned" -> Color(0xFF9C5CFF)
    "executing" -> Color(0xFF2FEAFF)
    "success" -> Color(0xFF4DFF88)
    "failure" -> Color(0xFFFF4D68)
    "rolled_back" -> Color(0xFFFFD45A)
    else -> Color(0xFF9AA7B2)
}

private fun riskColor(risk: String): Color = when (risk.lowercase()) {
    "green", "low" -> Color(0xFF4DFF88)
    "yellow", "medium" -> Color(0xFFFFD45A)
    "red", "high", "locked" -> Color(0xFFFF4D68)
    else -> Color(0xFF9AA7B2)
}
