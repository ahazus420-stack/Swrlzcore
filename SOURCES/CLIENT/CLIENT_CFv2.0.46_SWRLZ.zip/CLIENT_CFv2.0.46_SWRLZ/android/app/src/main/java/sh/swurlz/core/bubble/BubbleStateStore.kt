package sh.swurlz.core.bubble

import android.content.Context

enum class BubbleSection { HOME, CHAT, MISSIONS, NODES, LOGS, ASSISTANTS, SETTINGS, FUSION }
enum class BubbleLayoutMode { SINGLE, DUAL, FUSION, ALL_THREE }

object BubbleStateStore {
    private const val FILE = "swrlz_bubble_state"
    private const val KEY_SECTION = "last_section"
    private const val KEY_RESTORE = "restore_after_restart"
    private const val KEY_MODE = "layout_mode"
    private const val KEY_INTERACTIVE_ENABLED = "interactive_dock_enabled"
    private const val KEY_KEEP_ORIGINALS = "keep_originals_when_fused"

    private fun prefs(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun section(context: Context): BubbleSection = runCatching {
        BubbleSection.valueOf(prefs(context).getString(KEY_SECTION, BubbleSection.HOME.name)!!)
    }.getOrDefault(BubbleSection.HOME)

    fun setSection(context: Context, section: BubbleSection) {
        prefs(context).edit().putString(KEY_SECTION, section.name).apply()
    }

    fun restoreAfterRestart(context: Context): Boolean = prefs(context).getBoolean(KEY_RESTORE, true)

    fun setRestoreAfterRestart(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_RESTORE, enabled).apply()
    }

    fun mode(context: Context): BubbleLayoutMode = runCatching {
        BubbleLayoutMode.valueOf(prefs(context).getString(KEY_MODE, BubbleLayoutMode.DUAL.name)!!)
    }.getOrDefault(BubbleLayoutMode.DUAL)

    fun setMode(context: Context, mode: BubbleLayoutMode) {
        prefs(context).edit().putString(KEY_MODE, mode.name).apply()
    }

    fun interactiveDockEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_INTERACTIVE_ENABLED, false)

    fun setInteractiveDockEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_INTERACTIVE_ENABLED, enabled).apply()
    }

    fun keepOriginalsWhenFused(context: Context): Boolean =
        prefs(context).getBoolean(KEY_KEEP_ORIGINALS, false)

    fun setKeepOriginalsWhenFused(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_KEEP_ORIGINALS, enabled).apply()
    }

    fun position(context: Context, role: String): Pair<Int, Int>? {
        val p = prefs(context)
        val xKey = "position_${role}_x"
        val yKey = "position_${role}_y"
        if (!p.contains(xKey) || !p.contains(yKey)) return null
        return p.getInt(xKey, 0) to p.getInt(yKey, 0)
    }

    fun setPosition(context: Context, role: String, x: Int, y: Int) {
        prefs(context).edit()
            .putInt("position_${role}_x", x)
            .putInt("position_${role}_y", y)
            .apply()
    }
}
