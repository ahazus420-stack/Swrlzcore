# INT-CHAT-035A — Live Bubble Identity

- Bubble and conversation shortcut icons now follow the newly selected Theme Armor immediately.
- Theme changes re-publish the existing conversation notification without auto-expanding it.
- Launcher alias changes remain deferred so selecting a theme does not eject the user to Android Home.
- Notification accent color now follows the selected Theme Armor.
- Android system bubble badges are OS-rendered app identity badges; SWRLZ does not manually composite the lower-right badge.
- SYSTEM_ALERT_WINDOW remains required only for the mission HUD/telemetry overlay, not for Android conversation bubbles.
