# INT-GITHUB-FORGE-038 Implementation Report

## Scope
Adds a Client-owned GitHub Forge workflow to SWRLZ so Android can stage multiple local files and commit them directly to a configured repository path without using GitHub's 25 MiB browser uploader.

## Delivered
- More → GitHub Forge menu surface.
- Android multi-document picker.
- Staged file review and clear action.
- Configurable owner, repository, branch, destination directory, and commit message.
- Fine-grained GitHub token stored through Android Keystore-backed `SecretStore`.
- Atomic multi-file commit using GitHub Git Data API: ref → blobs → tree → commit → ref update.
- Optional `workflow_dispatch` after successful commit.
- Single-file safety ceiling of 100 MiB with explicit error reporting.
- Existing Client and fusion-bubble behavior preserved.

## Security boundary
Tokens are never written to ordinary DataStore, logs, source files, or commit payloads. The user must provide a fine-grained token restricted to the target repository. Recommended permissions:
- Contents: Read and write
- Actions: Write only when workflow dispatch is enabled

## Future chat integration
The dedicated Forge screen is the authoritative first implementation. A later chat attachment affordance can stage files into the same uploader and render an approval card before committing.
