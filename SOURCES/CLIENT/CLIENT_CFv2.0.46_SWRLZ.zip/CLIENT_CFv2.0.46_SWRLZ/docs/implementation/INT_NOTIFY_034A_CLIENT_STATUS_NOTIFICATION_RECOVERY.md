# INT-NOTIFY-034A — Client Status Notification Recovery

## Summary

CFv2.0.30 restores the persistent Client status surface in the Android notification shade.

## Root cause and correction

The Client status notification used the original `swurlz_client_status` channel. Android notification-channel behavior is immutable after a channel is created, and a previously silenced or restricted channel can remain suppressed across application updates. The Client now publishes through `swurlz_client_status_v2`, allowing Android to create a clean status channel.

The channel now uses default importance and an ongoing notification without forcing `setSilent(true)`. `setOnlyAlertOnce(true)` prevents repeated alerts while live connection and mission state refreshes update the notification.

The publisher now checks `POST_NOTIFICATIONS` before posting on Android 13+, avoiding failed publication before permission approval.

Disabling the Client status widget now cancels only the Client status notification. It no longer cancels the independent Floating Dragon conversation bubble.

## Display contract

The expanded notification reports:

- Client runtime/ambient state
- Server connected or offline state
- Configured/discovered server endpoint
- Current mission summary or registration evidence
- Active theme pack and display mode

## Migration

No database migration is required. Android creates the new channel on first publication. Users who previously disabled all application notifications must still re-enable notifications in system settings.

## Verification

Static verification confirms:

- distinct status and bubble notification IDs
- distinct status and conversation channels
- Android 13+ permission guard
- ongoing live status notification
- no bubble cancellation when the status widget is disabled
