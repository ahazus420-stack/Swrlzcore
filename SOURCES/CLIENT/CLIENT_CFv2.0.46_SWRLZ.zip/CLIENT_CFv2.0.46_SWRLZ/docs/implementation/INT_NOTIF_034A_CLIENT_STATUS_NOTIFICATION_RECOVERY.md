# INT-NOTIF-034A — Client Status Notification Recovery

## Problem

The Client status panel did not appear in the notification shade on Android 13+ even though the status-notification preference defaulted to enabled. The manifest declared `POST_NOTIFICATIONS`, but the Client never requested the runtime permission.

## Resolution

- `MainActivity` now requests `POST_NOTIFICATIONS` through the Activity Result API when Android 13+ reports it missing.
- After the permission result, the activity is recreated so the current immutable mission, connection, and theme state republishes immediately.
- The Permission Centre now exposes notification state before Accessibility and overlay controls.
- When permission is already granted, the same control opens Android app-notification settings for channel recovery.

## Notification content

The expanded Client notification reports:

- Client ambient state
- Server connected/offline state
- Configured or discovered endpoint
- Current mission or registration evidence
- Active theme family and display mode

## Security and privacy

Notification permission remains user-controlled. Sensitive content is not added to the lock-screen notification. Android and the OEM System UI retain final control over channel visibility, grouping, and rendering.

## Migration

No data migration is required. Existing installs receive the runtime prompt only when notification permission is absent. Existing channel choices remain authoritative.
