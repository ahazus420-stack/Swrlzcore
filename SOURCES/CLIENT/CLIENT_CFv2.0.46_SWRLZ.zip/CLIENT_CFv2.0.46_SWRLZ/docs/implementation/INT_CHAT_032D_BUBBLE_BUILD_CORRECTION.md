# INT_CHAT_032D — Bubble Kotlin Build Correction

## Status
Implemented

## Scope
Corrects the Kotlin compiler failures reported by GitHub Actions for the Floating Dragon bubble activities and controllers.

## Root cause
Two source-level compatibility errors were present in both Android applications:

1. `androidx.compose.foundation.layout.weight` was imported explicitly. With the Compose version used by these repositories, that symbol resolves to an internal parent-data accessor and cannot be imported directly. `Modifier.weight(...)` must resolve from the active `RowScope` or `ColumnScope`.
2. `LocusId` was imported from `android.app`. The public Android API is `android.content.LocusId`.

## Changes
- Removed the explicit `androidx.compose.foundation.layout.weight` import from the Client and Server bubble activities.
- Replaced `android.app.LocusId` with `android.content.LocusId` in both bubble controllers.
- Preserved all existing bubble behavior, shortcut identity, conversation metadata, theming, and notification routing.
- Advanced Android version codes so the repaired APKs can install over the previous builds.

## Verification
The uploaded workflow logs were inspected directly:

- Server workflow `81396360435`
- Client workflow `81399536226`

Every compiler diagnostic in those logs maps to one of the two corrected imports. Static source verification confirms that neither invalid import remains.

## Build verification
GitHub Actions remains the authoritative compile and APK packaging environment. Run the normal Client and Server APK workflows against these source packages.

## Migration
No data, database, protocol, or preference migration is required.
