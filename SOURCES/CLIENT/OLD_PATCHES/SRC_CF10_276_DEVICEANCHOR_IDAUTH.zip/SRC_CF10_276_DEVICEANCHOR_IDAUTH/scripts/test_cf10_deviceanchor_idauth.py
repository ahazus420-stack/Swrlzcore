#!/usr/bin/env python3
"""SWRLZ CF10 source-level test: stable device anchor and IDAuth doctrine are wired into client/server calls."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GRADLE = ROOT / "android/app/build.gradle.kts"
PREFS = ROOT / "android/app/src/main/java/sh/swurlz/core/data/Prefs.kt"
API = ROOT / "android/app/src/main/java/sh/swurlz/core/net/Api.kt"
NODES = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/NodesScreen.kt"
VAULT = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/VaultScreen.kt"

text = {
    "gradle": GRADLE.read_text(encoding="utf-8"),
    "prefs": PREFS.read_text(encoding="utf-8"),
    "api": API.read_text(encoding="utf-8"),
    "nodes": NODES.read_text(encoding="utf-8"),
    "vault": VAULT.read_text(encoding="utf-8"),
}

checks = {
    "cf10 patch label": "2.7.6-CF10-DEVICEANCHOR-IDAUTH" in text["gradle"],
    "cf10 version name": "0.2.7.6-cf10-deviceanchor" in text["gradle"],
    "cf10 version code": "versionCode = 33" in text["gradle"],
    "cf10 source zip identity": "SRC_CF10_276_DEVICEANCHOR_IDAUTH.zip" in text["gradle"],
    "device anchor key stored": "KEY_DEVICE_ANCHOR_ID" in text["prefs"],
    "ensure device anchor function": "suspend fun ensureDeviceAnchor" in text["prefs"],
    "stable anchor candidate": "DeviceIdentityAuthority.snapshot(ctx).deviceAnchor" in text["prefs"] and "deviceAnchor = \"swrlz-${anchorHash.take(24)}\"" in (ROOT / "android/app/src/main/java/sh/swurlz/core/data/DeviceIdentityAuthority.kt").read_text(encoding="utf-8"),
    "legacy random id migration": "legacyRandomId" in text["prefs"],
    "key rotation preserves anchor": "key rotation must not create a new server-visible device profile" in text["prefs"],
    "join group sends anchor": "device_anchor" in text["api"] and "identity_law" in text["api"],
    "checkin sends heartbeat truth": "online_truth" in text["api"] and "heartbeat_lease_only" in text["api"],
    "headers send identity law": "X-SWRLZ-Identity-Law" in text["api"],
    "creator owner admin delete route": "requestGroupDeleteAsCreatorOrAdmin" in text["api"] and "creator_owner_or_server_admin_only" in text["api"],
    "nodes shows identity authority": "IDENTITY AUTHORITY" in text["nodes"] and "Device UUID" in text["nodes"],
    "nodes shows group law": "CREATOR / OWNER / ADMIN" in text["nodes"],
    "vault shows cf10 identity authority": "CF10 IDENTITY AUTHORITY" in text["vault"],
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if failed:
    raise SystemExit("CF10 device anchor IDAuth source-level test failed: " + ", ".join(failed))
print("CF10 device anchor IDAuth source-level test PASS")
