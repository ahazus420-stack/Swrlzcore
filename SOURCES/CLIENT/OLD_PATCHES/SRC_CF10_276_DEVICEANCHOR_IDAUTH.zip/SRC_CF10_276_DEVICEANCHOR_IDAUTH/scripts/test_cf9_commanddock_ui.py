#!/usr/bin/env python3
"""SWRLZ CF9 source-level test: command dock shell and five-zone navigation are wired without removing CF8 RadarLive truth."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "android/app/src/main/java/sh/swurlz/core/MainActivity.kt"
GRADLE = ROOT / "android/app/build.gradle.kts"
NODES = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/NodesScreen.kt"
VAULT = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/VaultScreen.kt"
RADAR = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/NetworkDiscoveryScreen.kt"

main = MAIN.read_text(encoding="utf-8")
gradle = GRADLE.read_text(encoding="utf-8")
nodes = NODES.read_text(encoding="utf-8")
vault = VAULT.read_text(encoding="utf-8")
radar = RADAR.read_text(encoding="utf-8")

checks = {
    "cf9/cf10 patch label": ("2.7.6-CF9-COMMAND-DOCK-UI" in gradle or "2.7.6-CF10-DEVICEANCHOR-IDAUTH" in gradle),
    "cf9/cf10 version name": ("0.2.7.6-cf9-commanddock" in gradle or "0.2.7.6-cf10-deviceanchor" in gradle),
    "cf9/cf10 source zip identity": ("SRC_CF9_276_COMMAND_DOCK_UI.zip" in gradle or "SRC_CF10_276_DEVICEANCHOR_IDAUTH.zip" in gradle),
    "command dock zone enum": "enum class CommandDockZone" in main,
    "command dock header": "fun CommandDockHeader" in main,
    "command input dock": "fun CommandInputDock" in main,
    "command bottom dock": "fun CommandBottomDock" in main,
    "five dock buttons": all(x in main for x in ["Cockpit", "Radar", "Missions", "Nodes", "Vault"]),
    "nodes route": 'composable("nodes")' in main,
    "vault route": 'composable("vault")' in main,
    "nodes screen": "fun NodesScreen" in nodes and "NODE ROSTER" in nodes,
    "vault screen": "fun VaultScreen" in vault and "BUILD IDENTITY" in vault,
    "radarlive groups preserved": 'RadarMetricButton("GROUPS", radarGroupsLabel)' in radar,
    "radarlive devices preserved": 'RadarMetricButton("DEVICES", radarDevicesLabel)' in radar,
    "radarlive online preserved": 'RadarMetricButton("ONLINE", radarOnlineLabel)' in radar,
    "radarlive queue preserved": 'RadarMetricButton("QUEUE", radarQueueLabel)' in radar,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if failed:
    raise SystemExit("CF9 command dock source-level test failed: " + ", ".join(failed))
print("CF9 command dock source-level test PASS")
