#!/usr/bin/env python3
"""SWRLZ CF10 source-level test: Identity Authority, stable Device Anchor payloads, and server authority doctrine are wired without removing CF9/CF8 behavior."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GRADLE = ROOT / "android/app/build.gradle.kts"
IDENTITY = ROOT / "android/app/src/main/java/sh/swurlz/core/data/DeviceIdentityAuthority.kt"
PREFS = ROOT / "android/app/src/main/java/sh/swurlz/core/data/Prefs.kt"
API = ROOT / "android/app/src/main/java/sh/swurlz/core/net/Api.kt"
NODES = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/NodesScreen.kt"
VAULT = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/VaultScreen.kt"
MAIN = ROOT / "android/app/src/main/java/sh/swurlz/core/MainActivity.kt"
RADAR = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/NetworkDiscoveryScreen.kt"

gradle = GRADLE.read_text(encoding="utf-8")
identity = IDENTITY.read_text(encoding="utf-8")
prefs = PREFS.read_text(encoding="utf-8")
api = API.read_text(encoding="utf-8")
nodes = NODES.read_text(encoding="utf-8")
vault = VAULT.read_text(encoding="utf-8")
main = MAIN.read_text(encoding="utf-8")
radar = RADAR.read_text(encoding="utf-8")

checks = {
    "cf10 patch label": "2.7.6-CF10-DEVICEANCHOR-IDAUTH" in gradle,
    "cf10 version name": "0.2.7.6-cf10-deviceanchor" in gradle,
    "cf10 version code": "versionCode = 33" in gradle,
    "cf10 source zip identity": "SRC_CF10_276_DEVICEANCHOR_IDAUTH.zip" in gradle,
    "identity authority object": "object DeviceIdentityAuthority" in identity,
    "no raw hardware id exposure doctrine": "redacted fingerprint hash" in identity,
    "device anchor field": "deviceAnchor" in identity and "swrlz-${anchorHash.take(24)}" in identity,
    "fingerprint hash field": "fingerprintHash" in identity,
    "install seed hash field": "installSeedHash" in identity,
    "prefs stable candidate uses authority": "stableAnchorCandidate(ctx: Context): String = DeviceIdentityAuthority.snapshot(ctx).deviceAnchor" in prefs,
    "relay identity uses anchor": "val anchorId = ensureDeviceAnchor(ctx)" in prefs and "KEY_RELAY_DEVICE_ID" in prefs,
    "register device route": "suspend fun registerDevice" in api and "/devices/register" in api,
    "identity headers": all(x in api for x in ["X-SWRLZ-Device-UUID", "X-SWRLZ-Device-Anchor", "X-SWRLZ-Fingerprint-Hash", "X-SWRLZ-Identity-Schema"]),
    "join/checkin payload identity": all(x in api for x in ["device_uuid", "fingerprint_hash", "client_version", "patch_label"]),
    "group delete permission rule": "creator_owner_or_server_admin_only" in api,
    "nodes identity panel": "IDENTITY AUTHORITY" in nodes and "Device UUID" in nodes,
    "vault identity panel": "CF10 IDENTITY AUTHORITY" in vault,
    "cf9 command dock preserved": "enum class CommandDockZone" in main and "CommandBottomDock" in main,
    "cf8 radarlive preserved": 'RadarMetricButton("GROUPS", radarGroupsLabel)' in radar and 'RadarMetricButton("QUEUE", radarQueueLabel)' in radar,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if failed:
    raise SystemExit("CF10 identity authority source-level test failed: " + ", ".join(failed))
print("CF10 identity authority source-level test PASS")
