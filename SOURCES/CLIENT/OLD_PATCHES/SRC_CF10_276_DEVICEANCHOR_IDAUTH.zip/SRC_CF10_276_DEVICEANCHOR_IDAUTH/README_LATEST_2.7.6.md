# SWRLZ-Core latest source note

Latest patch: `CF10_276_DEVICEANCHOR_IDAUTH`

- Visible app version: `0.2.7.6-cf10-deviceanchor`
- Version code: `33`
- Patch label: `2.7.6-CF10-DEVICEANCHOR-IDAUTH`
- Source ZIP: `SRC_CF10_276_DEVICEANCHOR_IDAUTH.zip`

CF10 adds client-side Identity Authority on top of CF9 Command Dock and CF8 RadarLive.

Identity doctrine:

```text
Client proposes identity.
Server confirms identity.
Ledger preserves history.
Admin controls actions.
UI displays server truth.
Duplicates become lineage, not clutter.
```

Source-level tests:

```bash
python3 scripts/test_cf10_idauth.py
python3 scripts/test_cf9_commanddock_ui.py
python3 scripts/test_cf8_radarlive.py
python3 scripts/test_cf8_radarmenu.py
```
