package sh.swurlz.core

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.flow.collectLatest
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.ui.screens.*
import sh.swurlz.core.model.UiStyleSettings
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import sh.swurlz.core.ui.theme.SwurlzColors
import sh.swurlz.core.ui.theme.SwurlzTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val ctx = LocalContext.current
            var uiStyle by remember { mutableStateOf(UiStyleSettings()) }
            LaunchedEffect(Unit) { Prefs.uiStyleFlow(ctx).collectLatest { uiStyle = it } }
            SwurlzTheme(uiStyle) { AppNav() }
        }
    }
}

@Composable
fun AppNav() {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    var preflightAck by remember { mutableStateOf<Boolean?>(null) }

    LaunchedEffect(Unit) { Prefs.preflightFlow(ctx).collectLatest { preflightAck = it } }
    if (preflightAck == null) return
    val navEntry by nav.currentBackStackEntryAsState()
    val currentRoute = navEntry?.destination?.route ?: if (preflightAck == true) "cockpit" else "preflight"
    val activeDock = commandDockZone(currentRoute)

    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxSize().background(tokens.surfaces.bgApp)) {
        if (preflightAck == true) {
            CommandDockHeader(activeDock = activeDock, currentRoute = currentRoute)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            NavHost(nav, startDestination = if (preflightAck == true) "cockpit" else "preflight") {
                composable("preflight") {
                    PreflightScreen(onAcknowledged = {
                        nav.navigate("perms") { popUpTo("preflight") { inclusive = true } }
                    })
                }
                composable("home") {
                    HomeScreen(
                        onOpenCockpit = { nav.navigate("cockpit") },
                        onOpenPerms = { nav.navigate("perms") },
                        onOpenSetup = { nav.navigate("setup") },
                        onOpenDiscovery = { nav.navigate("discovery") },
                    )
                }
                composable("cockpit") { CockpitScreen() }
                composable("skills") { SkillsScreen() }
                composable("allow") { AllowlistScreen() }
                composable("setup") { SetupScreen() }
                composable("style") { StyleScreen() }
                composable("perms") { PermissionsScreen() }
                composable("core") { CoreNodeScreen() }
                composable("howto") { HowToScreen() }
                composable("info") { InfoScreen() }
                composable("commands") { CommandsScreen() }
                composable("discovery") { NetworkDiscoveryScreen(onOpenSetup = { nav.navigate("setup") }, onOpenCore = { nav.navigate("core") }) }
                composable("nodes") {
                    NodesScreen(
                        onOpenRadar = { nav.navigate("discovery") },
                        onOpenCore = { nav.navigate("core") },
                        onOpenPerms = { nav.navigate("perms") },
                        onOpenSetup = { nav.navigate("setup") },
                    )
                }
                composable("vault") {
                    VaultScreen(
                        onOpenHome = { nav.navigate("home") },
                        onOpenCore = { nav.navigate("core") },
                        onOpenPerms = { nav.navigate("perms") },
                        onOpenSetup = { nav.navigate("setup") },
                        onOpenStyle = { nav.navigate("style") },
                        onOpenHowTo = { nav.navigate("howto") },
                        onOpenInfo = { nav.navigate("info") },
                        onOpenMore = { nav.navigate("more") },
                    )
                }
                composable("more") { MoreScreen(nav) }
            }
        }
        if (preflightAck == true) {
            CommandInputDock(
                activeDock = activeDock,
                currentRoute = currentRoute,
                onOpenMissions = { nav.navigate("commands") },
                onOpenRadar = { nav.navigate("discovery") },
                onOpenServer = { nav.navigate("core") },
                onOpenNodes = { nav.navigate("nodes") },
                onOpenVault = { nav.navigate("vault") },
                onOpenPerms = { nav.navigate("perms") },
            )
            CommandBottomDock(
                activeDock = activeDock,
                onCockpit = { nav.navigate("cockpit") { launchSingleTop = true } },
                onRadar = { nav.navigate("discovery") { launchSingleTop = true } },
                onMissions = { nav.navigate("commands") { launchSingleTop = true } },
                onNodes = { nav.navigate("nodes") { launchSingleTop = true } },
                onVault = { nav.navigate("vault") { launchSingleTop = true } },
            )
        }
    }
}

private enum class CommandDockZone(val label: String, val sigil: String) {
    Cockpit("COCKPIT", "Ω"),
    Radar("RADAR", "◈"),
    Missions("MISSIONS", "▣"),
    Nodes("NODES", "◇"),
    Vault("VAULT", "⬡"),
}

private fun commandDockZone(route: String): CommandDockZone = when (route) {
    "cockpit" -> CommandDockZone.Cockpit
    "discovery" -> CommandDockZone.Radar
    "commands" -> CommandDockZone.Missions
    "nodes", "core", "allow" -> CommandDockZone.Nodes
    "vault", "home", "skills", "style", "perms", "setup", "howto", "info", "more" -> CommandDockZone.Vault
    else -> CommandDockZone.Cockpit
}

@Composable
private fun CommandDockHeader(activeDock: CommandDockZone, currentRoute: String) {
    val tokens = LocalSwurlzTokens.current
    Column(
        Modifier.fillMaxWidth()
            .background(tokens.surfaces.bgTopBar)
            .border(1.dp, tokens.borders.neutral)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Ω SWRLZ · COMMAND DOCK", color = tokens.accents.secondary, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            Text(activeDock.label, color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "LIVE TRUTH · route=$currentRoute · admin surfaces stay hidden until verified",
            color = tokens.text.muted,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
        )
    }
}

@Composable
private fun CommandInputDock(
    activeDock: CommandDockZone,
    currentRoute: String,
    onOpenMissions: () -> Unit,
    onOpenRadar: () -> Unit,
    onOpenServer: () -> Unit,
    onOpenNodes: () -> Unit,
    onOpenVault: () -> Unit,
    onOpenPerms: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val prompt = when (activeDock) {
        CommandDockZone.Cockpit -> "> start mission · teach flow · open overlay"
        CommandDockZone.Radar -> "> scan node · test signature · open server console"
        CommandDockZone.Missions -> "> review approvals · pause queue · archive receipts"
        CommandDockZone.Nodes -> "> inspect devices · show ghosts · open node truth"
        CommandDockZone.Vault -> "> build identity · permissions · roadmap · receipts"
    }
    Column(
        Modifier.fillMaxWidth()
            .background(tokens.surfaces.bgPanel)
            .border(1.dp, tokens.borders.soft)
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(activeDock.sigil, color = tokens.accents.secondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
            Text(prompt, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
            QuickChip("Mission", onOpenMissions)
            QuickChip("Radar", onOpenRadar)
            QuickChip("Server", onOpenServer)
            QuickChip("Nodes", onOpenNodes)
            QuickChip("Vault", onOpenVault)
            QuickChip("Perms", onOpenPerms)
        }
    }
}

@Composable
private fun CommandBottomDock(
    activeDock: CommandDockZone,
    onCockpit: () -> Unit,
    onRadar: () -> Unit,
    onMissions: () -> Unit,
    onNodes: () -> Unit,
    onVault: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    Row(
        Modifier.fillMaxWidth()
            .background(tokens.surfaces.bgTopBar)
            .border(1.dp, tokens.borders.neutral)
            .padding(horizontal = 6.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        DockButton("Ω", "Cockpit", activeDock == CommandDockZone.Cockpit, onCockpit, Modifier.weight(1f))
        DockButton("◈", "Radar", activeDock == CommandDockZone.Radar, onRadar, Modifier.weight(1f))
        DockButton("▣", "Missions", activeDock == CommandDockZone.Missions, onMissions, Modifier.weight(1f))
        DockButton("◇", "Nodes", activeDock == CommandDockZone.Nodes, onNodes, Modifier.weight(1f))
        DockButton("⬡", "Vault", activeDock == CommandDockZone.Vault, onVault, Modifier.weight(1f))
    }
}

@Composable
private fun DockButton(icon: String, label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tokens = LocalSwurlzTokens.current
    val borderColor by animateColorAsState(if (selected) tokens.tabs.selectedBorder else tokens.tabs.idleBorder, label = "dockBorder")
    val contentColor by animateColorAsState(if (selected) tokens.tabs.selectedText else tokens.tabs.idleText, label = "dockText")
    val bg = if (selected) tokens.tabs.selectedBg else tokens.tabs.idleBg
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp),
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = contentColor, containerColor = bg),
        border = androidx.compose.foundation.BorderStroke(if (selected) 2.dp else 1.dp, borderColor),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(0),
        modifier = modifier.height(48.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(label, fontFamily = FontFamily.Monospace, fontSize = 8.sp, maxLines = 1)
        }
    }
}

@Composable
private fun QuickChip(label: String, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    androidx.compose.material3.OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 9.dp, vertical = 3.dp),
        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = tokens.cards.chipText, containerColor = tokens.cards.chipBg),
        border = androidx.compose.foundation.BorderStroke(1.dp, tokens.borders.soft),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(0),
        modifier = Modifier.padding(end = 5.dp).height(30.dp),
    ) {
        Text(label.uppercase(), fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun HeaderBar(
    onHome: () -> Unit,
    onCockpit: () -> Unit,
    onSkills: () -> Unit,
    onAllow: () -> Unit,
    onSetup: () -> Unit,
    onStyle: () -> Unit,
    onPerms: () -> Unit,
    onCore: () -> Unit,
    onHowTo: () -> Unit,
    onInfo: () -> Unit,
    onCommands: () -> Unit,
    onDiscovery: () -> Unit,
    onMore: () -> Unit,
    currentRoute: String,
) {
    // Kept as a compatibility shell for older navigation experiments.
    CommandDockHeader(activeDock = commandDockZone(currentRoute), currentRoute = currentRoute)
}

object PermissionHelper {
    fun isAccessibilityEnabled(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == ctx.packageName }
    }

    fun isOverlayGranted(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun openAccessibility(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openOverlayPerm(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openAppDetails(ctx: Context) {
        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openSamsungAutoBlocker(ctx: Context) {
        val candidates = listOf(
            ComponentName("com.samsung.android.sm", "com.samsung.android.sm.security.ui.AutoBlockerActivity"),
            ComponentName("com.samsung.android.sm_cn", "com.samsung.android.sm.security.ui.AutoBlockerActivity"),
        )
        for (cn in candidates) {
            try {
                ctx.startActivity(Intent().setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) {}
        }
        try {
            ctx.startActivity(Intent("android.settings.SECURITY_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            openAppDetails(ctx)
        }
    }
}
