package sh.swurlz.core.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.data.DeviceIdentityAuthority
import sh.swurlz.core.data.DeviceIdentitySnapshot
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
fun NodesScreen(
    onOpenRadar: () -> Unit,
    onOpenCore: () -> Unit,
    onOpenPerms: () -> Unit,
    onOpenSetup: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val identity = DeviceIdentityAuthority.snapshot(LocalContext.current)
    Column(
        Modifier.fillMaxSize()
            .background(tokens.surfaces.bgApp)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        Text("◇ NODE ROSTER", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Device ledger command face. CF10 adds Identity Authority so reconnects, ordinary updates, and check-ins propose the same stable SWRLZ Device Anchor.",
            color = tokens.text.secondary,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
        )

        IdentityAuthorityPanel(identity)

        NodeStatusCard(
            title = "Controller Phone",
            sigil = "Ω",
            status = "IDENTITY LOCKED",
            detail = "Mission sender · command dock · approval review · anchor ${identity.deviceAnchor}",
            tone = "ANCHOR",
        )
        NodeStatusCard(
            title = "Core Node Server",
            sigil = "◈",
            status = "SERVER AUTHORITY",
            detail = "Server confirms identity, owns registry truth, merges suspected duplicates, and calculates online state from heartbeat leases.",
            tone = "VERIFY",
        )
        NodeStatusCard(
            title = "Group Ownership Law",
            sigil = "⌬",
            status = "CREATOR / OWNER / ADMIN",
            detail = "Group delete/archive must be allowed only for the group creator, explicit owner, or higher server admin. Other clients must be denied.",
            tone = "RULE",
        )
        NodeStatusCard(
            title = "Ghost Device Vault",
            sigil = "⬡",
            status = "LINEAGE SAFE",
            detail = "Old duplicate profiles become ghost/retired lineage instead of destructive clutter. Merge before delete; audit every destructive action.",
            tone = "ARCHIVE",
        )

        Spacer(Modifier.height(10.dp))
        Text("NODE ACTION DOCK", color = tokens.text.label, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("Radar", onOpenRadar, Modifier.weight(1f))
            ActionButton("Server", onOpenCore, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("Perms", onOpenPerms, Modifier.weight(1f))
            ActionButton("Setup", onOpenSetup, Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        NodeLawPanel()
    }
}

@Composable
private fun IdentityAuthorityPanel(identity: DeviceIdentitySnapshot) {
    val tokens = LocalSwurlzTokens.current
    Column(
        Modifier.fillMaxWidth()
            .padding(bottom = 10.dp)
            .background(tokens.surfaces.bgPanelAlt)
            .border(1.dp, tokens.accents.primary)
            .padding(12.dp)
    ) {
        Text("IDENTITY AUTHORITY", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(7.dp))
        NodeFact("Device UUID", identity.deviceAnchor)
        NodeFact("Fingerprint hash", "${identity.fingerprintHash.take(24)}…")
        NodeFact("Install seed hash", "${identity.installSeedHash.take(24)}…")
        NodeFact("Schema", identity.identitySchema.toString())
        Text(
            "Client proposes identity. Server confirms identity. Ledger preserves history. Duplicates become lineage, not live roster clutter.",
            color = tokens.text.secondary,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            modifier = Modifier.padding(top = 8.dp),
        )
    }
}

@Composable
private fun NodeFact(label: String, value: String) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().padding(bottom = 5.dp)) {
        Text(label.uppercase(), color = tokens.text.label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
        Text(value, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 15.sp)
    }
}

@Composable
private fun NodeStatusCard(title: String, sigil: String, status: String, detail: String, tone: String) {
    val tokens = LocalSwurlzTokens.current
    Column(
        Modifier.fillMaxWidth()
            .padding(bottom = 9.dp)
            .background(tokens.cards.bg)
            .border(1.dp, tokens.cards.border)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(sigil, color = tokens.accents.secondary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(status, color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
            Text(tone, color = tokens.text.label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, modifier = Modifier.border(1.dp, tokens.borders.soft).padding(horizontal = 6.dp, vertical = 3.dp))
        }
        Text(detail, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun NodeLawPanel() {
    val tokens = LocalSwurlzTokens.current
    Column(
        Modifier.fillMaxWidth()
            .background(tokens.surfaces.bgPanelAlt)
            .border(1.dp, tokens.borders.soft)
            .padding(12.dp)
    ) {
        Text("NODE LAW", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("• Stable Device Anchor persists across restarts and normal APK updates", color = tokens.text.secondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        Text("• Reconnect/check-in uses anchor + fingerprint hash for duplicate detection", color = tokens.text.secondary, fontSize = 12.sp)
        Text("• Online count means fresh heartbeat lease, not total saved devices", color = tokens.text.secondary, fontSize = 12.sp)
        Text("• Group delete/archive requires creator, owner, or higher admin", color = tokens.text.secondary, fontSize = 12.sp)
        Text("• Ghosts stay historical, not hard-deleted by default", color = tokens.text.secondary, fontSize = 12.sp)
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.buttons.secondaryText, containerColor = tokens.buttons.secondaryBg),
        border = BorderStroke(1.dp, tokens.buttons.secondaryBorder),
        shape = RoundedCornerShape(0),
        modifier = modifier.height(42.dp),
    ) {
        Text(label.uppercase(), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
