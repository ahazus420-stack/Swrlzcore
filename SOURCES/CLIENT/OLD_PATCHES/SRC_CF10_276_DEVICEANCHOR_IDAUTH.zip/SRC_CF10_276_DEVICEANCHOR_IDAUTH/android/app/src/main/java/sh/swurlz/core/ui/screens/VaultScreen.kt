package sh.swurlz.core.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.DeviceIdentityAuthority
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
fun VaultScreen(
    onOpenHome: () -> Unit,
    onOpenCore: () -> Unit,
    onOpenPerms: () -> Unit,
    onOpenSetup: () -> Unit,
    onOpenStyle: () -> Unit,
    onOpenHowTo: () -> Unit,
    onOpenInfo: () -> Unit,
    onOpenMore: () -> Unit,
) {
    val tokens = LocalSwurlzTokens.current
    val identity = DeviceIdentityAuthority.snapshot(LocalContext.current)
    Column(
        Modifier.fillMaxSize()
            .background(tokens.surfaces.bgApp)
            .verticalScroll(rememberScrollState())
            .padding(14.dp)
    ) {
        Text("⬡ VAULT", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(
            "Receipts, identity, settings, and deep controls. The Vault keeps SWRLZ honest: visible patch identity, source lane, identity authority, and admin truth.",
            color = tokens.text.secondary,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp),
        )

        VaultPanel("BUILD IDENTITY") {
            VaultLine("Patch", BuildConfig.PATCH_LABEL)
            VaultLine("Version", "${BuildConfig.VERSION_NAME} / code ${BuildConfig.VERSION_CODE}")
            VaultLine("Source", BuildConfig.SOURCE_ZIP)
            VaultLine("Line", BuildConfig.BUILD_LINE)
        }

        VaultPanel("CF10 IDENTITY AUTHORITY") {
            VaultLine("Device UUID", identity.deviceAnchor)
            VaultLine("Fingerprint hash", "${identity.fingerprintHash.take(24)}…")
            VaultLine("Android ID scope", "${identity.androidIdScopeHash.take(24)}…")
            VaultLine("Install seed", "${identity.installSeedHash.take(24)}…")
            VaultLine("Doctrine", "Client proposes identity · server confirms identity · ledger preserves history")
        }

        VaultPanel("CONTROL PATHS") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultButton("Home", onOpenHome, Modifier.weight(1f))
                VaultButton("Server", onOpenCore, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultButton("Perms", onOpenPerms, Modifier.weight(1f))
                VaultButton("Setup", onOpenSetup, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultButton("Style", onOpenStyle, Modifier.weight(1f))
                VaultButton("More", onOpenMore, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultButton("How To", onOpenHowTo, Modifier.weight(1f))
                VaultButton("Info", onOpenInfo, Modifier.weight(1f))
            }
        }

        VaultPanel("FUTURE VAULT LANES") {
            VaultLine("Receipts", "mission receipts · build receipts · admin audit")
            VaultLine("Ghosts", "retired lineage · duplicate merge · profile history")
            VaultLine("Forge", "source ZIP · SHA · build request · APK output")
            VaultLine("Security", "admin token · destructive action audit · endpoint manifest")
        }
    }
}

@Composable
private fun VaultPanel(title: String, content: @Composable () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    Column(
        Modifier.fillMaxWidth()
            .padding(bottom = 10.dp)
            .background(tokens.cards.bg)
            .border(1.dp, tokens.cards.border)
            .padding(12.dp)
    ) {
        Text(title, color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun VaultLine(label: String, value: String) {
    val tokens = LocalSwurlzTokens.current
    Column(Modifier.fillMaxWidth().padding(bottom = 7.dp)) {
        Text(label.uppercase(), color = tokens.text.label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.sp)
        Text(value, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun VaultButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.buttons.secondaryText, containerColor = tokens.buttons.secondaryBg),
        border = BorderStroke(1.dp, tokens.buttons.secondaryBorder),
        shape = RoundedCornerShape(0),
        modifier = modifier.height(42.dp),
    ) {
        Text(label.uppercase(), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
