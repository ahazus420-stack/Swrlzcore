package sh.swurlz.core.data

import android.content.Context
import android.os.Build
import android.provider.Settings
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.PermissionHelper
import java.security.MessageDigest
import java.util.UUID

/**
 * CF10 Identity Authority.
 *
 * Android does not give ordinary apps a permanent non-resettable hardware UUID.
 * SWRLZ therefore uses an allowed, best-effort identity strategy:
 * - stable app-scoped Android ID + package/device build traits for the Device Anchor
 * - redacted fingerprint hash for server-side duplicate detection
 * - persistent local install seed when app data survives update/restore
 * - server-side lineage/merge remains the real authority for duplicates
 */
data class DeviceIdentitySnapshot(
    val identitySchema: Int,
    val deviceAnchor: String,
    val fingerprintHash: String,
    val installSeedHash: String,
    val androidIdScopeHash: String,
    val displayName: String,
    val manufacturer: String,
    val brand: String,
    val model: String,
    val device: String,
    val product: String,
    val hardware: String,
    val board: String,
    val screenBucket: String,
    val supportedAbis: List<String>,
    val capabilities: List<String>,
)

object DeviceIdentityAuthority {
    const val SCHEMA = 1
    private const val PREF_NAME = "swrlz_identity_authority"
    private const val KEY_INSTALL_SEED = "install_seed"

    fun snapshot(ctx: Context): DeviceIdentitySnapshot {
        val androidId = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown-android-id"
        val installSeed = installSeed(ctx)
        val screenBucket = screenBucket(ctx)
        val supportedAbis = Build.SUPPORTED_ABIS.toList()
        val identityInput = listOf(
            "schema=$SCHEMA",
            "package=${ctx.packageName}",
            "android_id=$androidId",
            "manufacturer=${Build.MANUFACTURER.orEmpty()}",
            "brand=${Build.BRAND.orEmpty()}",
            "model=${Build.MODEL.orEmpty()}",
            "device=${Build.DEVICE.orEmpty()}",
            "product=${Build.PRODUCT.orEmpty()}",
            "hardware=${Build.HARDWARE.orEmpty()}",
            "board=${Build.BOARD.orEmpty()}",
            "abis=${supportedAbis.joinToString(",")}",
            "screen=$screenBucket",
        ).joinToString("|")
        val duplicateFingerprintInput = listOf(
            "schema=$SCHEMA",
            "manufacturer=${Build.MANUFACTURER.orEmpty()}",
            "brand=${Build.BRAND.orEmpty()}",
            "model=${Build.MODEL.orEmpty()}",
            "device=${Build.DEVICE.orEmpty()}",
            "product=${Build.PRODUCT.orEmpty()}",
            "hardware=${Build.HARDWARE.orEmpty()}",
            "board=${Build.BOARD.orEmpty()}",
            "abis=${supportedAbis.joinToString(",")}",
            "screen=$screenBucket",
        ).joinToString("|")
        val anchorHash = sha256(identityInput)
        return DeviceIdentitySnapshot(
            identitySchema = SCHEMA,
            deviceAnchor = "swrlz-${anchorHash.take(24)}",
            fingerprintHash = sha256(duplicateFingerprintInput),
            installSeedHash = sha256("${ctx.packageName}|$installSeed"),
            androidIdScopeHash = sha256("${ctx.packageName}|$androidId"),
            displayName = defaultDisplayName(),
            manufacturer = Build.MANUFACTURER.orEmpty(),
            brand = Build.BRAND.orEmpty(),
            model = Build.MODEL.orEmpty(),
            device = Build.DEVICE.orEmpty(),
            product = Build.PRODUCT.orEmpty(),
            hardware = Build.HARDWARE.orEmpty(),
            board = Build.BOARD.orEmpty(),
            screenBucket = screenBucket,
            supportedAbis = supportedAbis,
            capabilities = capabilities(ctx),
        )
    }

    fun shortAnchor(ctx: Context): String = snapshot(ctx).deviceAnchor.takeLast(10)

    private fun defaultDisplayName(): String = listOf(Build.MANUFACTURER, Build.MODEL)
        .filter { it.isNotBlank() }
        .joinToString(" ")
        .ifBlank { "Android Client" }
        .trim()

    private fun installSeed(ctx: Context): String {
        val prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_INSTALL_SEED, null)
        if (!existing.isNullOrBlank()) return existing
        val generated = UUID.randomUUID().toString()
        prefs.edit().putString(KEY_INSTALL_SEED, generated).apply()
        return generated
    }

    private fun capabilities(ctx: Context): List<String> = buildList {
        add("android-client")
        add("command-dock")
        add("radarlive")
        add("identity-authority")
        add("device-anchor")
        if (PermissionHelper.isAccessibilityEnabled(ctx)) add("accessibility-ready")
        if (PermissionHelper.isOverlayGranted(ctx)) add("overlay-ready")
        add("version:${BuildConfig.VERSION_NAME}")
        add("patch:${BuildConfig.PATCH_LABEL}")
    }

    private fun screenBucket(ctx: Context): String {
        val dm = ctx.resources.displayMetrics
        val w = (dm.widthPixels / 100) * 100
        val h = (dm.heightPixels / 100) * 100
        val dpi = (dm.densityDpi / 40) * 40
        return "${minOf(w, h)}x${maxOf(w, h)}@${dpi}dpi"
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
}
