# CF11 Discovery Authority Patch

Changes:
- Active device subnet scanned first
- Saved hotspot ranges demoted in priority
- Current WiFi interface becomes discovery authority
- Better behavior when moving between hotspot and WiFi networks
