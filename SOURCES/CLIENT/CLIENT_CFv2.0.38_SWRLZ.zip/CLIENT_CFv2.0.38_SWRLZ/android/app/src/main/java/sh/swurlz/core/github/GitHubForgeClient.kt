package sh.swurlz.core.github

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.client.request.header
import io.ktor.client.request.patch
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.isSuccess
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Repository-native multi-file uploader used by the SWRLZ GitHub Forge screen.
 *
 * Files are uploaded through GitHub's Git Data API and committed atomically. This avoids the
 * browser uploader's 25 MiB ceiling while preserving an auditable branch/commit history.
 */
object GitHubForgeClient {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val client = HttpClient(OkHttp) {
        install(ContentNegotiation) { json(json) }
    }

    data class LocalFile(
        val uri: Uri,
        val displayName: String,
        val sizeBytes: Long,
    )

    data class UploadRequest(
        val owner: String,
        val repository: String,
        val branch: String,
        val destinationDirectory: String,
        val commitMessage: String,
        val token: String,
        val files: List<LocalFile>,
        val workflowId: String = "",
        val dispatchWorkflow: Boolean = false,
    )

    data class UploadResult(val commitSha: String, val uploadedPaths: List<String>)

    suspend fun upload(context: Context, request: UploadRequest): UploadResult {
        require(request.files.isNotEmpty()) { "Select at least one file." }
        require(request.owner.isNotBlank() && request.repository.isNotBlank()) { "Repository owner and name are required." }
        require(request.branch.isNotBlank()) { "Branch is required." }
        require(request.token.isNotBlank()) { "GitHub token is required." }

        val repoBase = "https://api.github.com/repos/${request.owner.trim()}/${request.repository.trim()}"
        val auth = "Bearer ${request.token.trim()}"
        val ref = getJson<RefResponse>("$repoBase/git/ref/heads/${request.branch.trim()}", auth)
        val parentSha = ref.`object`.sha
        val parentCommit = getJson<CommitResponse>("$repoBase/git/commits/$parentSha", auth)

        val normalizedDir = request.destinationDirectory.trim().trim('/')
        val entries = mutableListOf<TreeEntry>()
        val uploadedPaths = mutableListOf<String>()

        request.files.forEach { file ->
            val bytes = context.contentResolver.openInputStream(file.uri)?.use { it.readBytes() }
                ?: error("Unable to read ${file.displayName}")
            require(bytes.size <= 100 * 1024 * 1024) {
                "${file.displayName} exceeds GitHub's 100 MiB single-blob limit."
            }
            val blob = postJson<BlobRequest, BlobResponse>(
                "$repoBase/git/blobs",
                auth,
                BlobRequest(Base64.encodeToString(bytes, Base64.NO_WRAP), "base64"),
            )
            val safeName = sanitizeFileName(file.displayName)
            val path = if (normalizedDir.isBlank()) safeName else "$normalizedDir/$safeName"
            entries += TreeEntry(path = path, mode = "100644", type = "blob", sha = blob.sha)
            uploadedPaths += path
        }

        val tree = postJson<TreeRequest, TreeResponse>(
            "$repoBase/git/trees",
            auth,
            TreeRequest(baseTree = parentCommit.tree.sha, tree = entries),
        )
        val commit = postJson<NewCommitRequest, NewCommitResponse>(
            "$repoBase/git/commits",
            auth,
            NewCommitRequest(
                message = request.commitMessage.ifBlank { "Upload files through SWRLZ GitHub Forge" },
                tree = tree.sha,
                parents = listOf(parentSha),
            ),
        )
        patchJson(
            "$repoBase/git/refs/heads/${request.branch.trim()}",
            auth,
            UpdateRefRequest(commit.sha, force = false),
        )

        if (request.dispatchWorkflow && request.workflowId.isNotBlank()) {
            val response = client.post("$repoBase/actions/workflows/${request.workflowId.trim()}/dispatches") {
                githubHeaders(auth)
                setBody(WorkflowDispatchRequest(ref = request.branch.trim()))
            }
            ensureSuccess(response)
        }
        return UploadResult(commit.sha, uploadedPaths)
    }

    fun describe(context: Context, uri: Uri): LocalFile {
        var name = uri.lastPathSegment ?: "upload.bin"
        var size = -1L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return LocalFile(uri, name, size)
    }

    private fun sanitizeFileName(value: String): String = value
        .replace("/", "_")
        .replace("\\", "_")
        .ifBlank { "upload.bin" }

    private suspend inline fun <reified T> getJson(url: String, auth: String): T {
        val response = client.get(url) { githubHeaders(auth) }
        ensureSuccess(response)
        return response.body()
    }

    private suspend inline fun <reified Req : Any, reified Res> postJson(url: String, auth: String, body: Req): Res {
        val response = client.post(url) {
            githubHeaders(auth)
            setBody(body)
        }
        ensureSuccess(response)
        return response.body()
    }

    private suspend fun patchJson(url: String, auth: String, body: UpdateRefRequest) {
        val response = client.patch(url) {
            githubHeaders(auth)
            setBody(body)
        }
        ensureSuccess(response)
    }

    private fun io.ktor.client.request.HttpRequestBuilder.githubHeaders(auth: String) {
        header(HttpHeaders.Authorization, auth)
        header(HttpHeaders.Accept, "application/vnd.github+json")
        header(HttpHeaders.ContentType, ContentType.Application.Json)
        header("X-GitHub-Api-Version", "2022-11-28")
    }

    private suspend fun ensureSuccess(response: HttpResponse) {
        if (!response.status.isSuccess()) {
            val text = response.body<String>()
            error("GitHub ${response.status.value}: ${text.take(500)}")
        }
    }
}

@Serializable private data class RefResponse(@SerialName("object") val `object`: GitObject)
@Serializable private data class GitObject(val sha: String)
@Serializable private data class CommitResponse(val tree: GitTree)
@Serializable private data class GitTree(val sha: String)
@Serializable private data class BlobRequest(val content: String, val encoding: String)
@Serializable private data class BlobResponse(val sha: String)
@Serializable private data class TreeEntry(val path: String, val mode: String, val type: String, val sha: String)
@Serializable private data class TreeRequest(@SerialName("base_tree") val baseTree: String, val tree: List<TreeEntry>)
@Serializable private data class TreeResponse(val sha: String)
@Serializable private data class NewCommitRequest(val message: String, val tree: String, val parents: List<String>)
@Serializable private data class NewCommitResponse(val sha: String)
@Serializable private data class UpdateRefRequest(val sha: String, val force: Boolean)
@Serializable private data class WorkflowDispatchRequest(val ref: String)
