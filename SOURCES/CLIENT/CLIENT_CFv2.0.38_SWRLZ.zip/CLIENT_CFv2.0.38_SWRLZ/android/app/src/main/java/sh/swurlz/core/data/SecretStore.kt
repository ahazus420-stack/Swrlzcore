package sh.swurlz.core.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/** Stores provider secrets outside ordinary DataStore preferences using Android Keystore-backed encryption. */
object SecretStore {
    private const val FILE = "swurlz_secrets"
    private const val KEY_MENTOR_TOKEN = "mentor_api_token"
    private const val KEY_CORE_NODE_TOKEN = "core_node_pairing_token"
    private const val KEY_RELAY_GROUP_KEY = "relay_group_key"
    private const val KEY_RELAY_DEVICE_KEY = "relay_device_key"
    private const val KEY_ADMIN_SESSION_TOKEN = "admin_session_token"
    private const val KEY_GITHUB_TOKEN = "github_forge_token"

    private fun prefs(ctx: Context) = EncryptedSharedPreferences.create(
        FILE,
        MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),
        ctx,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun mentorToken(ctx: Context): String = prefs(ctx).getString(KEY_MENTOR_TOKEN, "").orEmpty()

    fun setMentorToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_MENTOR_TOKEN, token.trim()).apply()
    }

    fun coreNodeToken(ctx: Context): String = prefs(ctx).getString(KEY_CORE_NODE_TOKEN, "").orEmpty()

    fun setCoreNodeToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_CORE_NODE_TOKEN, token.trim()).apply()
    }

    fun relayGroupKey(ctx: Context): String = prefs(ctx).getString(KEY_RELAY_GROUP_KEY, "").orEmpty()

    fun setRelayGroupKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY_RELAY_GROUP_KEY, key.trim()).apply()
    }

    fun relayDeviceKey(ctx: Context): String = prefs(ctx).getString(KEY_RELAY_DEVICE_KEY, "").orEmpty()

    fun setRelayDeviceKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(KEY_RELAY_DEVICE_KEY, key.trim()).apply()
    }

    fun adminSessionToken(ctx: Context): String = prefs(ctx).getString(KEY_ADMIN_SESSION_TOKEN, "").orEmpty()

    fun setAdminSessionToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_ADMIN_SESSION_TOKEN, token.trim()).apply()
    }

    fun githubToken(ctx: Context): String = prefs(ctx).getString(KEY_GITHUB_TOKEN, "").orEmpty()

    fun setGithubToken(ctx: Context, token: String) {
        prefs(ctx).edit().putString(KEY_GITHUB_TOKEN, token.trim()).apply()
    }

    fun forgetGithubToken(ctx: Context) {
        prefs(ctx).edit().remove(KEY_GITHUB_TOKEN).apply()
    }

    fun forgetAdminSessionToken(ctx: Context) {
        prefs(ctx).edit().remove(KEY_ADMIN_SESSION_TOKEN).apply()
    }
}
