package sh.swurlz.core.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.github.GitHubForgeClient
import sh.swurlz.core.ui.theme.LocalSwurlzTokens

@Composable
fun GitHubForgeScreen() {
    val context = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()

    var owner by remember { mutableStateOf("ahazus420-stack") }
    var repository by remember { mutableStateOf("Swrlzcore") }
    var branch by remember { mutableStateOf("main") }
    var destination by remember { mutableStateOf("SOURCES/CLIENT") }
    var message by remember { mutableStateOf("Upload source package through SWRLZ GitHub Forge") }
    var token by remember { mutableStateOf(SecretStore.githubToken(context)) }
    var workflowId by remember { mutableStateOf("") }
    var dispatch by remember { mutableStateOf(false) }
    var files by remember { mutableStateOf(emptyList<GitHubForgeClient.LocalFile>()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Select one or more files to stage an atomic repository commit.") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        files = uris.distinct().map { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            GitHubForgeClient.describe(context, uri)
        }
        status = if (files.isEmpty()) "No files selected." else "${files.size} file(s) staged. Review destination and commit settings."
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("▸ GITHUB FORGE", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Text(
            "Stage multiple files, commit them directly through GitHub's Git Data API, and optionally dispatch the build workflow. This bypasses the website uploader's 25 MiB ceiling.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )

        ForgeField("OWNER", owner, { owner = it })
        ForgeField("REPOSITORY", repository, { repository = it })
        ForgeField("BRANCH", branch, { branch = it })
        ForgeField("DESTINATION DIRECTORY", destination, { destination = it })
        ForgeField("COMMIT MESSAGE", message, { message = it }, singleLine = false)
        ForgeField("FINE-GRAINED TOKEN", token, { token = it }, secret = true)

        OutlinedButton(
            onClick = { picker.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(0),
            border = BorderStroke(1.dp, tokens.accents.primary),
        ) { Text("SELECT MULTIPLE FILES") }

        if (files.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bg).padding(10.dp)) {
                Text("STAGED PAYLOAD", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
                files.forEach { file ->
                    Text("• ${file.displayName}${formatSize(file.sizeBytes)}", color = tokens.text.secondary, fontSize = 12.sp)
                }
                TextButton(onClick = { files = emptyList(); status = "Staging cleared." }) { Text("CLEAR") }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text("DISPATCH WORKFLOW", color = tokens.text.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text("Trigger workflow_dispatch after the commit succeeds.", color = tokens.text.secondary, fontSize = 11.sp)
            }
            Switch(checked = dispatch, onCheckedChange = { dispatch = it })
        }
        if (dispatch) ForgeField("WORKFLOW FILE OR ID", workflowId, { workflowId = it })

        Button(
            enabled = !busy && files.isNotEmpty() && token.isNotBlank(),
            onClick = {
                SecretStore.setGithubToken(context, token)
                busy = true
                status = "Uploading ${files.size} file(s) and creating one atomic commit…"
                scope.launch {
                    runCatching {
                        withContext(Dispatchers.IO) {
                            GitHubForgeClient.upload(
                                context,
                                GitHubForgeClient.UploadRequest(
                                    owner = owner,
                                    repository = repository,
                                    branch = branch,
                                    destinationDirectory = destination,
                                    commitMessage = message,
                                    token = token,
                                    files = files,
                                    workflowId = workflowId,
                                    dispatchWorkflow = dispatch,
                                ),
                            )
                        }
                    }.onSuccess { result ->
                        status = "Committed ${result.uploadedPaths.size} file(s). Commit ${result.commitSha.take(12)}${if (dispatch) "; workflow dispatched" else ""}."
                    }.onFailure { error ->
                        status = "Upload failed: ${error.message ?: error::class.simpleName}"
                    }
                    busy = false
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(0),
            colors = ButtonDefaults.buttonColors(containerColor = tokens.accents.primary, contentColor = tokens.surfaces.bgApp),
        ) {
            Text(if (busy) "FORGING…" else "COMMIT TO GITHUB", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
        }

        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
            Text("FORGE STATUS", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 1.6.sp)
            Spacer(Modifier.height(5.dp))
            Text(status, color = tokens.text.secondary, fontSize = 12.sp, lineHeight = 17.sp)
        }

        Text(
            "Security: the token is stored in Android Keystore-backed encrypted preferences. Use a fine-grained token restricted to this repository with Contents: Read and write and Actions: Write only when workflow dispatch is enabled.",
            color = tokens.text.secondary,
            fontSize = 11.sp,
            lineHeight = 16.sp,
        )
    }
}

@Composable
private fun ForgeField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    singleLine: Boolean = true,
    secret: Boolean = false,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = singleLine,
        visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
    )
}

private fun formatSize(bytes: Long): String = when {
    bytes < 0 -> ""
    bytes < 1024 -> " · $bytes B"
    bytes < 1024 * 1024 -> " · ${bytes / 1024} KiB"
    else -> " · ${"%.1f".format(bytes / 1024.0 / 1024.0)} MiB"
}
