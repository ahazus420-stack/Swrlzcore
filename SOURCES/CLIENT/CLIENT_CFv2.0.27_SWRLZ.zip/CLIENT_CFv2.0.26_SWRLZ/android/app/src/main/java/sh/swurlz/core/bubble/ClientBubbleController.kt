package sh.swurlz.core.bubble

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.drawable.Icon
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.graphics.drawable.IconCompat

object ClientBubbleController {
    private const val CHANNEL_ID = "swurlz_client_conversation"
    private const val NOTIFICATION_ID = 4110
    private const val SHORTCUT_ID = "swurlz_client_chat"

    fun publish(context: Context, title: String, detail: String) {
        ensureChannel(context)

        val bubbleIntent = Intent(context, ClientBubbleActivity::class.java)
            .setAction(Intent.ACTION_VIEW)
        val bubblePendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            bubbleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE,
        )

        val appIconResource = context.applicationInfo.icon
        val shortcutIcon = Icon.createWithResource(context, appIconResource)
        val compatIcon = IconCompat.createWithResource(context, appIconResource)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            val shortcut = ShortcutInfo.Builder(context, SHORTCUT_ID)
                .setShortLabel("SWRLZ Chat")
                .setLongLived(true)
                .setIcon(shortcutIcon)
                .setIntent(bubbleIntent)
                .build()
            context.getSystemService(ShortcutManager::class.java)
                ?.pushDynamicShortcut(shortcut)
        }

        val person = Person.Builder()
            .setName("SWRLZ Client")
            .setIcon(compatIcon)
            .setImportant(true)
            .build()

        val style = NotificationCompat.MessagingStyle(person)
            .setConversationTitle(title)
            .addMessage(detail, System.currentTimeMillis(), person)

        val bubbleMetadata = NotificationCompat.BubbleMetadata.Builder(
            bubblePendingIntent,
            compatIcon,
        )
            .setDesiredHeight(640)
            .setAutoExpandBubble(false)
            .setSuppressNotification(false)
            .build()

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(appIconResource)
            .setContentTitle(title)
            .setContentText(detail)
            .setContentIntent(bubblePendingIntent)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setShortcutId(SHORTCUT_ID)
            .setStyle(style)
            .setBubbleMetadata(bubbleMetadata)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    private fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SWRLZ Chat and Missions",
                NotificationManager.IMPORTANCE_DEFAULT,
            ).apply {
                description = "Conversation bubbles for SWRLZ chat, mission status, and approvals."
                setAllowBubbles(true)
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }
}
