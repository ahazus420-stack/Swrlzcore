# INT-GITHUB-FORGE-040 — Mass Source Upload and Artifact Observer

## Implemented

- Client-owned GitHub Forge mass upload workflow.
- Multi-document staging for CLIENT and SERVER source ZIPs, checksums, and supporting files.
- Deterministic filename routing:
  - `CLIENT_*` → `SOURCES/CLIENT/`
  - `SERVER_*` → `SOURCES/SERVER/`
  - unmatched files → configurable fallback directory.
- One Git tree and one atomic commit for the complete staged payload.
- Optional `workflow_dispatch` immediately after the commit.
- Recent workflow run observer with status, conclusion, branch, event, and GitHub link.
- Per-run artifact discovery.
- Authenticated Actions artifact ZIP download and Android Storage Access Framework save flow.
- Fine-grained PAT fallback retained alongside GitHub Device Authorization.

## Security boundary

- Tokens remain in Android Keystore-backed encrypted storage.
- The full token is not rendered after connection and is not logged by Forge code.
- Repository and branch remain explicit in the UI.
- GitHub enforces token repository scope and permissions.

## Verification

- Source archive integrity is verified after packaging.
- Full Gradle compilation requires the configured online GitHub Actions build environment.
