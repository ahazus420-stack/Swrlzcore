> Current stabilization checkpoint: **CLIENT CFv2.0.55**. See `CFv2.0.55_FORGE_REPEAT_NOTIFICATIONS_SIBLING_CHECKPOINT.md`. CFv2.1.0 remains reserved for the real Chat conversational control plane.

# SWRLZ-Core Android Client

Current source package: **CLIENT CFv2.0.55 — Forge repeat-upload truth, result notifications, and same-location checksum matching**.

## Current app identity

- Version: `2.0.55-forge-repeat-notifications-sibling-v1`
- Code: `82`
- Patch: `CFv2.0.55-FORGE-REPEAT-NOTIFY-SIBLING-V1`
- Roadmap: `2.7.6`
- Source: `CLIENT_CFv2.0.55_SWRLZ.zip`

## Current Forge guarantees

- Every upload attempt receives a fresh transaction ID.
- Staging clears only after commit, branch, and uploaded-path verification.
- Repeated uploads in one installed CLIENT are independent transactions.
- Upload and artifact-build outcomes publish to Android notifications and the CLIENT bubble.
- Pending build watches survive leaving Forge while the CLIENT status service remains enabled.
- ZIP/SHA pairing begins from the selected ZIP location; no Downloads-root tree grant is required.
- Android may still require one exact SHA document selection when its provider does not expose sibling files from a single-document grant.

## Interface modes

- **User Mode** is the fresh-install default: Core, Chat, Missions, Nodes, and Settings on the animated translucent Glitch Dragon Glass shell.
- **SWRLZ Dev Mode** retains the complete engineering surface: Home, Radar, Network, Cockpit, Setup, Style, Permissions, Core Admin, Skills, Allowlist, How To, Info, and More.
- The selected interface persists locally and can be switched in either direction without deleting configuration, identity, mission, trust, or style state.

## Current server pair

- Local Node Server: `0.7.1 Presence Index`

## Project law

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Preserve local data and taught skills.
- Keep Mentor backend and Local Core Node separate.
- Status colors remain semantic; themes may not lie about operational state.
- User Mode never hides Pause, Take Over, approval state, local-versus-remote identity, or Truth Firewall status.


## 2.7.6-CODEFIX3-DISCOVERY-SCAN-TRIM

- Source: `SRC_2.7.6_CF3_SCAN_TRIM.zip`
- Objective: trim discovery scan overhead by skipping `127.0.0.x` range sweeps by default, while keeping a saved debug toggle for unusual loopback testing.
- Output naming convention: `SRC_` for source, `SHA_` for hashes, `REPORT_` for patch notes, `APK_` for APKs, and `BUNDLE_` for APK download bundles.


## 2.7.6 CF4 - Signing + Reconnect

Adds Connection Memory / Last-Good Node Auto-Reconnect and stable dev signing readiness. Source: `SRC_2.7.6_CF4_SIGN_RECONNECT.zip`.


## INT-CONV-012A communication foundation
See `docs/contracts/SWRLZ_PROTOCOL_AND_DATA_CONTRACTS_V1_INTEGRATED.md` and `reports/INT-CONV-012A_IMPLEMENTATION_REPORT.md` (CLIENT) or `INT-CONV-012A_IMPLEMENTATION_REPORT.md` (SERVER). This is source-only foundation work; no live endpoint is exposed.

## CFv2.0.55 Forge transaction update

The current CLIENT build uses a fresh transaction ID for every Forge upload, rebases on the latest branch head after blob transfer, retries branch races, verifies uploaded repository paths, and reports upload/build results through both Android notifications and the CLIENT conversation bubble. ZIP checksum matching now begins from the selected ZIP location and no longer requires a separate Downloads-root folder grant. See `CFv2.0.55_FORGE_REPEAT_NOTIFICATIONS_SIBLING_CHECKPOINT.md`.
