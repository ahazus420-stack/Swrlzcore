package sh.swurlz.core.identity

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import sh.swurlz.core.R

/** Keeps launcher, bubble, shortcut, and notification identity synchronized with Theme Armor. */
object ThemeIdentityManager {
    private enum class Alias(val componentClass: String, val iconRes: Int) {
        GlitchDragon("sh.swurlz.core.launcher.GlitchDragon", R.mipmap.ic_launcher_glitch_dragon),
        OriginalCore("sh.swurlz.core.launcher.OriginalCore", R.mipmap.ic_launcher_original_core),
        GlitchNeon("sh.swurlz.core.launcher.GlitchNeon", R.mipmap.ic_launcher_glitch_neon),
        PharaohEmerald("sh.swurlz.core.launcher.PharaohEmerald", R.mipmap.ic_launcher_pharaoh_emerald),
        VoidJester("sh.swurlz.core.launcher.VoidJester", R.mipmap.ic_launcher_void_jester);
    }

    fun requestApply(context: Context, themeFamily: String) {
        context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
            .edit().putString("pending_theme", themeFamily).apply()
    }

    fun applyPending(context: Context) {
        val prefs = context.getSharedPreferences("theme_identity", Context.MODE_PRIVATE)
        val themeFamily = prefs.getString("pending_theme", null) ?: return
        applyNow(context, themeFamily)
        prefs.edit().remove("pending_theme").apply()
    }

    private fun applyNow(context: Context, themeFamily: String) {
        val selected = when (themeFamily) {
        "Glitch Dragon Glass" -> Alias.GlitchDragon
        "Original Core" -> Alias.OriginalCore
        "Glitch Neon" -> Alias.GlitchNeon
        "Pharaoh Emerald" -> Alias.PharaohEmerald
        "Void Jester" -> Alias.VoidJester
            else -> Alias.GlitchDragon
        }
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context.packageName, selected.componentClass),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP,
        )
        Alias.entries.filter { it != selected }.forEach { alias ->
            context.packageManager.setComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP,
            )
        }
    }

    fun activeIconResource(context: Context): Int =
        Alias.entries.firstOrNull { alias ->
            context.packageManager.getComponentEnabledSetting(
                ComponentName(context.packageName, alias.componentClass),
            ) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        }?.iconRes ?: Alias.GlitchDragon.iconRes

    fun iconResource(themeFamily: String): Int = when (themeFamily) {
        "Glitch Dragon Glass" -> Alias.GlitchDragon
        "Original Core" -> Alias.OriginalCore
        "Glitch Neon" -> Alias.GlitchNeon
        "Pharaoh Emerald" -> Alias.PharaohEmerald
        "Void Jester" -> Alias.VoidJester
        else -> Alias.GlitchDragon
    }.iconRes

    fun accentColor(themeFamily: String): Int = when (themeFamily) {
        "Original Core" -> 0xFFA073FF.toInt()
        "Glitch Neon" -> 0xFFFF2DDC.toInt()
        "Pharaoh Emerald" -> 0xFF00E691.toInt()
        "Void Jester" -> 0xFFB150FF.toInt()
        else -> 0xFF00D2FF.toInt()
    }
}
