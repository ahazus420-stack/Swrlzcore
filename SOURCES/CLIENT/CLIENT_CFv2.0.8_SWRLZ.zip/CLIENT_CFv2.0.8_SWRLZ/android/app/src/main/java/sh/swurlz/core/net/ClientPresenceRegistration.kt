package sh.swurlz.core.net

import android.content.Context
import android.os.Build
import android.provider.Settings
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import org.json.JSONObject
import sh.swurlz.core.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal object ClientPresenceRegistration {
    data class Result(val ok:Boolean, val state:String, val detail:String)
    private const val PREFS="swrlz_presence_identity"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var heartbeatJob: Job? = null

    fun register(context:Context, baseUrl:String):Result {
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val installationId=prefs.getString("installationId",null) ?: UUID.randomUUID().toString().also { prefs.edit().putString("installationId",it).apply() }
        val deviceId=Settings.Secure.getString(context.contentResolver,Settings.Secure.ANDROID_ID).orEmpty().ifBlank { "unknown-device" }
        val nodeId="client-"+installationId.replace("-","").take(24)
        val body=JSONObject().apply {
            put("nodeId",nodeId); put("deviceId",deviceId); put("installationId",installationId)
            put("displayName","${Build.MANUFACTURER} ${Build.MODEL} · SWRLZ CLIENT")
            put("deviceType","android-client"); put("appVersion",BuildConfig.VERSION_NAME); put("protocolVersion",1)
            put("capabilities",org.json.JSONArray(listOf("chat","missions","presence")))
        }.toString()
        return post("${baseUrl.trimEnd('/')}/nodes/register",body).also { result ->
            prefs.edit().putString("registrationState",result.state).putString("registrationDetail",result.detail).apply()
            if (result.ok) startHeartbeat(context.applicationContext, baseUrl)
        }
    }
    private fun startHeartbeat(context: Context, baseUrl: String) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive) {
                delay(30_000L)
                val result = heartbeat(context, baseUrl)
                context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
                    .putString("registrationState", if (result.ok) "REGISTERED" else result.state)
                    .putString("registrationDetail", result.detail).apply()
            }
        }
    }
    fun heartbeat(context:Context, baseUrl:String, state:String="CONNECTED", missionId:String?=null):Result {
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val installationId=prefs.getString("installationId","").orEmpty(); if(installationId.isBlank()) return Result(false,"NOT_REGISTERED","Missing installation identity")
        val nodeId="client-"+installationId.replace("-","").take(24)
        val body=JSONObject().apply { put("nodeId",nodeId); put("state",state); if(!missionId.isNullOrBlank()) put("missionId",missionId) }.toString()
        return post("${baseUrl.trimEnd('/')}/nodes/heartbeat",body)
    }
    private fun post(url:String, body:String):Result { var c:HttpURLConnection?=null; return try { c=URL(url).openConnection() as HttpURLConnection; c.requestMethod="POST"; c.connectTimeout=1500;c.readTimeout=1500;c.doOutput=true;c.setRequestProperty("Accept","application/json");c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(body.toByteArray())}; val code=c.responseCode; val text=(if(code in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use{it.readText()}.orEmpty(); Result(code in 200..299, if(code in 200..299)"REGISTERED" else "REGISTRATION_FAILED",text.take(1200)) } catch(e:Throwable){Result(false,"REGISTRATION_FAILED","${e.javaClass.simpleName}: ${e.message}")} finally {c?.disconnect()} }
}
