# SWRLZ Local Node Server 0.6 Patch Report

## Patch identity

- Version: `local-node-server-0.6-process-control`
- Patch label: `LNS-0.6-PROCESS-CONTROL`
- Roadmap: `LOCAL-NODE-SERVER-0.6`

## Changes

- Added PID file management at `swrlz_node_data/local_node.pid`.
- Added `run_local_node.sh`, `stop_local_node.sh`, and `restart_local_node.sh`.
- Added occupied-port detection with exact fix commands for `Errno 98`.
- Expanded startup banner with PID, PID file, stop/restart commands, LAN URLs, logs, update folders, and command paths.
- Added process metadata into `/status`.
- Added `/admin/update/info`.
- Added `/admin/update/settings` GET/POST.
- Added manual update steps to update status payload.
- Added event IDs to request events and improved recent-event dedupe.
- Preserved clean disconnect handling.
- Added `completed_by` to command result updates.

## Safety notes

- No paid runtime dependency added.
- No hard-coded private user secrets added.
- Existing `swrlz_node_data` remains the protected persistence directory.
- Update staging does not hot-swap code automatically; restart remains manual and visible.
