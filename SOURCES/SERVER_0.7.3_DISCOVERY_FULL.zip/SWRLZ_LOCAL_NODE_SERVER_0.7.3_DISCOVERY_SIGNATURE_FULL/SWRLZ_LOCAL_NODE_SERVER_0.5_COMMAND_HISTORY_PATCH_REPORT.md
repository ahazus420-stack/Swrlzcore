# SWRLZ Local Node Server 0.5 — Command History

## Patch identity

- Server version: `local-node-server-0.5-command-history`
- Patch label: `LNS-0.5-COMMAND-HISTORY`
- Roadmap: `LOCAL-NODE-SERVER-0.5`
- Source ZIP: `SWRLZ_LOCAL_NODE_SERVER_0.5_COMMAND_HISTORY_SOURCE.zip`

## Purpose

This patch strengthens the command bridge by adding command lifecycle history and command lookup endpoints.

## Added

- Persistent command event log:
  - `swrlz_node_data/commands/command_events.jsonl`
- Command lifecycle event recording:
  - created
  - pending → accepted
  - pending/accepted → rejected
  - accepted → completed
  - accepted → failed/blocked
- New endpoints:
  - `GET /commands/<cmd_id>` — lookup one command by ID.
  - `GET /commands/recent-events` — lightweight recent command lifecycle events.
  - `GET /admin/commands/history` — admin command history view.
- Startup banner now displays command queue and history paths.
- `/status` capabilities now advertise command cards, command lookup, and command history.

## Preserved

- No external Python dependencies.
- Termux-safe standard-library HTTP server.
- Existing admin settings.
- Existing logs/session files.
- Existing command queue file: `swrlz_node_data/commands/commands.json`.

## How to run

```bash
cd ~/swurlz/SWRLZ_LOCAL_NODE_SERVER_0.5_COMMAND_HISTORY_SOURCE
python local_node_server.py
```

Or:

```bash
bash run_local_node.sh
```

## Test checklist

1. Start server.
2. Open SWRLZ-Core app.
3. Confirm `/status` reachable.
4. Create command from app `Cmds` screen.
5. Pull pending command.
6. ACK command.
7. COMPLETE command.
8. Confirm command history file exists:

```bash
ls -la swrlz_node_data/commands
cat swrlz_node_data/commands/command_events.jsonl
```
