# Local Node Server 0.7.1 Phone Test Checklist

## Start

```bash
cd ~/swurlz/SWRLZ_LOCAL_NODE_SERVER_0.7.1_PRESENCE_INDEX
bash run_local_node.sh
```

## Status

```bash
curl http://127.0.0.1:8787/status
```

Confirm:

- `server_version = local-node-server-0.7.1-presence-index`
- `patch_label = LNS-0.7.1-PRESENCE-INDEX`
- `capabilities.presence_index = true`

## Presence

```bash
curl 'http://127.0.0.1:8787/presence/summary'
```

After creating/joining a group, test:

```bash
curl 'http://127.0.0.1:8787/presence/summary?group_id=kami-lab&group_key=YOUR_KEY'
```

Confirm groups/devices arrays are readable for the app.
