# SWRLZ Local Node Server Roadmap 0.7

## Current release
**0.7 — Group Relay Ledger**

Architecture release for groups, devices, admin sessions, and offline queues.

## Completed
- Persistent group registry.
- Persistent device registry.
- Device check-in and online/offline window.
- Admin saved session token ledger.
- Offline per-device packet queue.
- Packet lifecycle receipts.
- Admin ledger endpoint.

## Next recommended server release
**0.8 — Offline Queue Protocol Hardening**

Focus:
- Queue cleanup controls.
- Packet search/filter.
- Better expiration policies.
- Group broadcast receipts summary.
- Optional QR export/import for group setup.
- Capability negotiation per device.
