# SWRLZ Local Node Server 0.7.3 Discovery Signature Full Patch Report

## Input

- Base: `SWRLZ_LOCAL_NODE_SERVER_0.7.2_DEVICE_LEDGER_SOURCE.zip`
- Base SHA256: `b3b84bab70081560335133261905f81cfa0921a1f7d1d7ff5845cef35636c5bb`

## Output

- Source folder: `SWRLZ_LOCAL_NODE_SERVER_0.7.3_DISCOVERY_SIGNATURE_FULL`
- Source ZIP: `SWRLZ_LOCAL_NODE_SERVER_0.7.3_DISCOVERY_SIGNATURE_FULL_SOURCE.zip`

## Identity

- `SERVER_VERSION`: `local-node-server-0.7.3-discovery-signature-full`
- `ROADMAP`: `LOCAL-NODE-SERVER-0.7.3`
- `PATCH_LABEL`: `LNS-0.7.3-DISCOVERY-SIGNATURE`
- Port: `8787`

## Added / updated network discovery features

- `GET /discovery/signature`
- `GET /discovery/manifest`
- `GET /discovery/ping`
- CORS + `OPTIONS` preflight support for WebView/browser clients
- Discovery signature URLs advertised in `/connection-info`
- Network discovery capability flags added to `/status`
- Startup banner prints discovery signature LAN endpoints
- `/presence/summary` no longer becomes a hard dead-end during discovery when group auth is missing; it can return a public discovery summary instead
- `/devices/checkin` can return a soft reachability checkin instead of failing hard when the device has not registered yet
- Existing 0.7.2 Device Ledger, Admin Registry, group relay, queues, and command routes are preserved

## Expected discovery signature

```json
{
  "ok": true,
  "server": "swrlz-local-node",
  "version": "0.7.3-discovery-signature",
  "patch": "LNS-0.7.3-DISCOVERY-SIGNATURE",
  "port": 8787
}
```

## Test commands

```bash
curl http://127.0.0.1:8787/discovery/signature
curl http://127.0.0.1:8787/discovery/manifest
curl http://127.0.0.1:8787/status
curl "http://127.0.0.1:8787/presence/summary?group_id=kami-lab&group_key="
curl -X POST http://127.0.0.1:8787/devices/checkin -H 'Content-Type: application/json' -d '{"group_id":"kami-lab","device_id":"test-client"}'
```

## Truth note

This is a real server-source patch made directly against the uploaded 0.7.2 server source from the release bundle.
