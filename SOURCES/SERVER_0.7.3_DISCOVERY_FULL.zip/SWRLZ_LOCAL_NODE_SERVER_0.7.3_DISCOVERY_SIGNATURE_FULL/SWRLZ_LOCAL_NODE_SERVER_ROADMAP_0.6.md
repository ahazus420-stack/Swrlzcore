# SWRLZ Local Core Node Server Roadmap

**Roadmap revision:** Local Node Server 0.6 — Command History + Safe Update Path  
**Current verified server baseline:** `local-node-server-0.6-process-control`  
**Latest verified server patch line:** `LNS-0.6-PROCESS-CONTROL`  
**Current bridge role:** Core Phone / Local Core Node Server  
**Core law:** Local-first, no paid runtime dependency, preserve `swrlz_node_data`.

---

## 1. Current Proven State

### ✅ 0.1 — Admin status / Termux-lite foundation
- [x] Server runs in Termux with plain Python.
- [x] Avoids FastAPI/Pydantic dependency issues on Termux.
- [x] Displays startup banner.
- [x] Displays local URL: `http://127.0.0.1:8787`.
- [x] Displays LAN URL: example `http://192.168.1.xxx:8787`.
- [x] Explains that `127.0.0.1` means same device.
- [x] Provides `/status`.
- [x] Provides admin credentials mode.

### ✅ 0.2 — Connection observer
- [x] Successful `/status` checks display in Termux.
- [x] Browser connections display as bridge check-ins.
- [x] App/Ktor connections display as bridge check-ins.
- [x] Server records result, HTTP status, path, client IP, device ID, app version, patch label, user-agent, detail, and timestamp.

### ✅ 0.3 — Session logs + updater folders
- [x] Creates `swrlz_node_data/logs`.
- [x] Creates session log file: `swrlz_node_data/logs/session_<timestamp>.log`.
- [x] Creates request log file: `swrlz_node_data/logs/requests_<date>.jsonl`.
- [x] Creates update folders:
  - `swrlz_node_data/updates/incoming`
  - `swrlz_node_data/updates/staged`
  - `swrlz_node_data/updates/rollback`
- [x] Startup banner displays log and update paths.

### ✅ 0.4 — Command queue
- [x] Creates command queue path: `swrlz_node_data/commands/commands.json`.
- [x] Creates command event history path: `swrlz_node_data/commands/command_events.jsonl`.
- [x] Supports command types: PING, SHOW_MESSAGE, REFRESH_CONTEXT, REPORT_STATUS.
- [x] Provides command endpoints:
  - `/commands/pending`
  - `/commands/<cmd_id>`
  - `/admin/commands/create`
  - `/admin/commands/all`
- [x] Supports command status lifecycle: pending, accepted, rejected, completed.

### ✅ 0.5 — Command history
- [x] Command creation tested.
- [x] Pending command pull tested.
- [x] ACK tested.
- [x] COMPLETE tested.
- [x] Server logs command creation.
- [x] Server logs command views.
- [x] Server logs command accept/complete events.
- [x] Client app and server agree on command ID.
- [x] Safe PING command card completed end-to-end.

---

## 2. Known Issues / Fix Queue

### 🔴 SERVER-FIX-001 — Address already in use
**Observed:** `OSError: [Errno 98] Address already in use`.

**Meaning:** Old server process is still bound to port 8787.

**Fix target:**
- Add `stop_local_node.sh`.
- Add PID file: `swrlz_node_data/local_node.pid`.
- Add `restart_local_node.sh`.
- On startup, detect occupied port and print exact fix command.

**Acceptance:**
- User can run one command to stop old ghost server.
- User can restart without hunting processes manually.

### 🟡 SERVER-FIX-002 — Clean connection-reset noise
**Observed:** Browser/app may cause connection reset tracebacks.

**Fix target:**
- Catch `ConnectionResetError`.
- Log as clean disconnected client event instead of full traceback.
- Preserve serious errors in session log.

**Acceptance:**
- Termux console stays readable.
- Logs record disconnects without scary stack dumps.

### 🟡 SERVER-FIX-003 — Recent events duplication
**Observed:** Recent events may appear duplicated in app output.

**Fix target:**
- Ensure recent events endpoint de-duplicates entries by timestamp/path/client/status or unique event ID.
- Add `event_id`.

**Acceptance:**
- Recent events list does not repeat the same event unless it truly happened twice.

### 🟡 SERVER-FIX-004 — Admin password setup flow
**Fix target:**
- First-run admin setup should prompt or clearly instruct.
- Default password should be treated as temporary.
- Add endpoint / doc for changing admin password safely.
- Store password hash instead of plain text if not already done.

**Acceptance:**
- Server clearly warns if default admin password is still active.
- App can change admin password through authenticated request.

---

## 3. Next Major Server Patch

## ✅ 0.6 — Process Control + Update Staging

### Goals
- Make Termux server easier to stop, restart, and update.
- Preserve data across source updates.
- Begin safe update workflow without hard-coding update URLs.

### Planned changes
- [x] Add `run_local_node.sh`.
- [x] Add `stop_local_node.sh`.
- [x] Add `restart_local_node.sh`.
- [x] Add PID file management.
- [x] Add occupied-port detection.
- [x] Add clearer startup banner with server version, patch label, LAN URLs, log paths, command paths, update folders, and PID.
- [x] Add `/admin/update/info`.
- [x] Add `/admin/update/settings`.
- [x] Add persistent settings:
  - server_update_url
  - client_update_url
  - allow_pairing
  - require_pairing_token
  - display_successful_connections
  - clean_disconnect_tracebacks
  - log_level
- [x] Add update staging folder documentation.
- [x] Add manual update command:
  - download ZIP
  - verify SHA
  - stop server
  - extract new source
  - preserve `swrlz_node_data`
  - restart

### Acceptance test
1. Start server.
2. Confirm PID file exists.
3. Confirm `/status` works.
4. Connect from SWRLZ-Core app.
5. Confirm bridge check-in displays.
6. Create command from app.
7. Pull/ACK/COMPLETE command.
8. Confirm command history persists.
9. Stop server using script.
10. Restart server using script.
11. Confirm old commands/logs remain.

---

## 4. Future Server Milestones

## 0.7 — Server-hosted command execution policies
- [ ] Add server policy file.
- [ ] Add command risk levels: low, medium, high, locked.
- [ ] Server refuses unsafe commands by default.
- [ ] Add allowed command type list.
- [ ] Add command expiration.
- [ ] Add command owner/device identity.

## 0.8 — Teach packet intake
- [ ] Add `/teach/packet`.
- [ ] Store teach packets append-only.
- [ ] Add teach packet schema validation.
- [ ] Add conflict report placeholder.
- [ ] Do not merge/execute taught skills automatically.

## 0.9 — Pairing mode
- [ ] Add short pairing window.
- [ ] Add pairing code/token display.
- [ ] Add trusted devices list.
- [ ] Add revoke device option.
- [ ] Add app-side device registration.

## 1.0 — Local Core Node stable baseline
- [ ] Stable Termux run/restart/update flow.
- [ ] Reliable command queue.
- [ ] Reliable logs.
- [ ] Reliable admin settings.
- [ ] Reliable paired-device identity.
- [ ] No paid dependency required.
- [ ] Full README.
- [ ] Full How To.
- [ ] Full test checklist.

---

## 5. Server Release Requirements

Every Local Node Server patch must include:
- [ ] Server version bump.
- [ ] Patch label bump.
- [ ] Roadmap revision update.
- [ ] README update.
- [ ] Termux instructions update.
- [ ] SHA-256 file.
- [ ] Patch report.
- [ ] Preserve `swrlz_node_data`.
- [ ] No hard-coded personal secrets.
- [ ] No paid runtime dependency.
- [ ] Clean startup banner.
- [ ] Test checklist.


---

## 0.6 completion note

Patch `LNS-0.6-PROCESS-CONTROL` is implemented in source folder `SWRLZ_LOCAL_NODE_SERVER_0.6_PROCESS_CONTROL_SOURCE` and prepared for source ZIP release as `SWRLZ_LOCAL_NODE_SERVER_0.6_PROCESS_CONTROL_SOURCE.zip`. Python syntax compile and live `/status` + `/admin/update/settings` smoke tests passed.
