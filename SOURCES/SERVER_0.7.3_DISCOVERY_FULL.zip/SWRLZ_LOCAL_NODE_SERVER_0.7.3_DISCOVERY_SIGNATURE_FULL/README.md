# SWRLZ Local Node Server 0.7.3 — Discovery Signature Full

This is the **0.7.2 Device Ledger server upgraded to 0.7.3 Network Discovery**.

It preserves the existing Device Ledger/Admin Registry/group relay/queue work and adds the discovery endpoints needed by SWRLZ-Core 2.7.6 Network Discovery.

## Identity

```text
SERVER_VERSION = local-node-server-0.7.3-discovery-signature-full
PATCH_LABEL    = LNS-0.7.3-DISCOVERY-SIGNATURE
ROADMAP        = LOCAL-NODE-SERVER-0.7.3
PORT           = 8787
```

## Termux quick start

```bash
pkg update -y
pkg install -y python unzip curl tmux
termux-wake-lock
mkdir -p ~/swrlz-server
unzip -o /sdcard/Download/SWRLZ_LOCAL_NODE_SERVER_0.7.3_DISCOVERY_SIGNATURE_FULL_SOURCE.zip -d ~/swrlz-server
cd ~/swrlz-server/SWRLZ_LOCAL_NODE_SERVER_0.7.3_DISCOVERY_SIGNATURE_FULL
bash start-termux.sh
```

## Test from the server phone

```bash
curl http://127.0.0.1:8787/discovery/signature
curl http://127.0.0.1:8787/discovery/manifest
curl http://127.0.0.1:8787/status
```

## Test from the SWRLZ-Core phone

Use the server phone LAN/hotspot IP, for example:

```text
http://10.24.230.21:8787
```

Then tap:

```text
Network → TEST SIGNATURE
Network → SAVE NODE
Network → SCAN LOCAL
```

## Discovery endpoints

```text
GET     /discovery/signature
GET     /discovery/manifest
GET     /discovery/ping
GET     /connection-info
GET     /status
GET     /presence/summary
POST    /devices/register
POST    /devices/checkin
```

## Compatibility note

The 2.7.6 client was seen polling:

```text
GET /presence/summary?group_id=kami-lab&group_key=
POST /devices/checkin
```

This release keeps those routes available and avoids discovery-time 404 dead ends.
