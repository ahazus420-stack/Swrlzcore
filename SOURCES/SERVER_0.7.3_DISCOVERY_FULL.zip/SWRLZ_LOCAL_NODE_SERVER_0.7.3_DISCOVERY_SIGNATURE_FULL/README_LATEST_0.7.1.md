# SWRLZ Local Node Server 0.7.1 — Presence Index

Presence Index adds cleaner server-side list data for the Relay Radar UI.

## Identity

- Server version: `local-node-server-0.7.1-presence-index`
- Patch: `LNS-0.7.1-PRESENCE-INDEX`
- Roadmap: `LOCAL-NODE-SERVER-0.7.1`

## New endpoints

```text
GET /presence/summary
GET /presence/devices
GET /presence/groups
```

Group mode uses `group_id` + `group_key` query params.
Admin mode uses the saved admin bearer session.

## Presence states

- `online`: seen within the normal online window.
- `idle`: seen recently but outside the online window.
- `offline`: stale check-in.
- `unknown`: registered without usable check-in timestamp.

## Why this exists

The 0.7 server had the correct group/device/packet architecture, but the app needed cleaner display-oriented data. Presence Index gives the client list-friendly group/device cards instead of making the user decode raw debug output.
