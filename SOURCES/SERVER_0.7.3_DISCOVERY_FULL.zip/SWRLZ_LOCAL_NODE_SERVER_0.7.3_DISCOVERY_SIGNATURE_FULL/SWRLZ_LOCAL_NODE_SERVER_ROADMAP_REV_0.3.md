# SWRLZ Local Node Server Roadmap Revision 0.3

## Current milestone

`LNS-0.3-SESSION-LOGS-UPDATER`

## Completed

- [x] Termux-safe no-dependency HTTP server.
- [x] `/status` endpoint.
- [x] Visible LAN URL / port display on startup.
- [x] Browser and SWRLZ-Core Ktor client connection observer.
- [x] Device ID and app version headers displayed when the Android app connects.
- [x] Full session logs folder.
- [x] Daily request logs.
- [x] Clean client disconnect handling.
- [x] Admin settings endpoint.
- [x] Admin password update endpoint.
- [x] Update URL storage.
- [x] Update ZIP download/staging foundation.
- [x] Incoming, staged, and rollback folders.

## Next: 0.4 Supervisor Launcher

- [ ] Separate launcher process that starts/stops the server.
- [ ] Apply staged updates without manual folder switching.
- [ ] Rollback command.
- [ ] Keep-alive/restart on crash.
- [ ] Optional local-only admin web page.

## Later

- [ ] Teach packet intake.
- [ ] Action proposal queue.
- [ ] Local skill merge report.
- [ ] Multi-device node registry.
- [ ] Offline mesh discovery.
