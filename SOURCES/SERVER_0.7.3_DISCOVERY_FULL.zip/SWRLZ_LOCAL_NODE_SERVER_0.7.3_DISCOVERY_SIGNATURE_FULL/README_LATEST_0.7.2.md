# SWRLZ Local Node Server 0.7.2 — Device Ledger

Adds operator-grade admin APIs for device and queue management.

## New admin routes

- `GET /admin/devices` — full device ledger with online/idle/offline/stale/blocked state.
- `GET /admin/devices/{device_id}` — inspect one device plus its queue.
- `POST /admin/devices/{device_id}/forget` — remove a ghost/stale device. Optional body: `{"clear_queue":true}`.
- `POST /admin/devices/{device_id}/clear-queue` — clear a device queue.
- `POST /admin/devices/{device_id}/force-offline` — manually mark offline until next check-in.
- `POST /admin/devices/{device_id}/trust` — mark trusted.
- `POST /admin/devices/{device_id}/block` — block/flag node.
- `POST /admin/devices/{device_id}/reset-key` — generate a new device key.
- `GET /admin/queues` — packet queue inspector.

## Lease states

- online <= 60s
- idle <= 300s
- offline > 300s
- stale > 24h
- blocked = admin blocked

Preserves existing groups, devices, queues, and admin session data in `swrlz_node_data`.
