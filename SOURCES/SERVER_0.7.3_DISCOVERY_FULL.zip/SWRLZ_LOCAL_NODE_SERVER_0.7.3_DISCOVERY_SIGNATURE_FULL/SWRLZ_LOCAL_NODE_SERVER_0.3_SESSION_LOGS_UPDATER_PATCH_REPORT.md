# SWRLZ Local Node Server 0.3 Patch Report

## Patch

`LNS-0.3-SESSION-LOGS-UPDATER`

## Source base

`SWRLZ_LOCAL_NODE_SERVER_0.2_CONNECTION_OBSERVER_SOURCE.zip`

## Adds

- Session logs.
- Daily request logs.
- Cleaner disconnect handling.
- Update staging folders.
- Update status endpoint.
- Update staging endpoint.
- Admin log endpoint.
- Updated README and Termux latest guide.
- Roadmap revision 0.3.

## Run command

```bash
python local_node_server.py
```
