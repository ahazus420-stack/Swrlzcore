#!/usr/bin/env python3
from __future__ import annotations

import atexit
import base64
import hashlib
import hmac
import json
import os
import secrets
import shutil
import signal
import socket
import sys
import zipfile
import uuid
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, urlopen

SERVER_VERSION = "local-node-server-0.7.3-discovery-signature-full"
ROADMAP = "LOCAL-NODE-SERVER-0.7.3"
PATCH_LABEL = "LNS-0.7.3-DISCOVERY-SIGNATURE"
HOST = os.getenv("SWRLZ_NODE_HOST", "0.0.0.0")
PORT = int(os.getenv("SWRLZ_NODE_PORT", "8787"))
DATA_DIR = Path(os.getenv("SWRLZ_NODE_DATA_DIR", "swrlz_node_data"))
ADMIN_USERNAME = os.getenv("SWRLZ_NODE_ADMIN_USER", "admin")
DEFAULT_ADMIN_PASSWORD = os.getenv("SWRLZ_NODE_ADMIN_PASSWORD", "swurlz-admin")
SESSION_ID = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
SESSION_STARTED_AT = datetime.now(timezone.utc).isoformat()

DEFAULT_SETTINGS: Dict[str, Any] = {
    "node_name": "SWRLZ Local Core Node",
    "server_update_url": "",
    "client_update_url": "",
    "allow_pairing": True,
    "require_pairing_token": True,
    "pairing_token_hint": "set-on-node",
    "log_level": "info",
    "display_successful_connections": True,
    "store_request_events": True,
    "session_logging_enabled": True,
    "clean_disconnect_tracebacks": True,
    "command_queue_enabled": True,
    "command_user_approval_required": True,
    "command_history_enabled": True,
    "command_event_limit": 200,
    "process_control_enabled": True,
    "pid_file_enabled": True,
    "update_manual_flow_enabled": True,
    "group_relay_enabled": True,
    "offline_packet_queue_enabled": True,
    "admin_saved_sessions_enabled": True,
    "admin_all_devices_visible": False,
    "device_online_window_seconds": 60,
    "default_packet_ttl_minutes": 1440,
    "safe_packet_types": ["PING", "SHOW_MESSAGE", "REPORT_STATUS", "REFRESH_CONTEXT", "ECHO_TEST"],
    "presence_index_enabled": True,
    "presence_idle_window_seconds": 300,
    "presence_offline_window_seconds": 300,
    "presence_stale_window_seconds": 86400,
    "device_ledger_admin_enabled": True,
    "network_discovery_enabled": True,
    "discovery_signature_enabled": True,
    "discovery_public_signature": True,
    "discovery_allow_public_presence_summary": True,
    "discovery_soft_checkin_enabled": True,
    "discovery_endpoint_version": "0.7.3",
}


# ---------- time / paths ----------
def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def today_key() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def settings_path() -> Path: return DATA_DIR / "settings.json"
def auth_path() -> Path: return DATA_DIR / "admin_auth.json"
def paired_devices_path() -> Path: return DATA_DIR / "paired_devices.json"
def logs_dir() -> Path: return DATA_DIR / "logs"
def updates_dir() -> Path: return DATA_DIR / "updates"
def incoming_updates_dir() -> Path: return updates_dir() / "incoming"
def staged_updates_dir() -> Path: return updates_dir() / "staged"
def rollback_updates_dir() -> Path: return updates_dir() / "rollback"
def session_log_path() -> Path: return logs_dir() / f"session_{SESSION_ID}.log"
def daily_request_log_path() -> Path: return logs_dir() / f"requests_{today_key()}.jsonl"
def legacy_request_events_path() -> Path: return DATA_DIR / "request_events.jsonl"
def update_state_path() -> Path: return updates_dir() / "update_state.json"
def commands_dir() -> Path: return DATA_DIR / "commands"
def commands_path() -> Path: return commands_dir() / "commands.json"
def command_events_path() -> Path: return commands_dir() / "command_events.jsonl"
def pid_path() -> Path: return DATA_DIR / "local_node.pid"
def groups_dir() -> Path: return DATA_DIR / "groups"
def groups_path() -> Path: return groups_dir() / "groups.json"
def devices_dir() -> Path: return DATA_DIR / "devices"
def devices_path() -> Path: return devices_dir() / "devices.json"
def device_checkins_path() -> Path: return devices_dir() / "device_checkins.jsonl"
def queues_dir() -> Path: return DATA_DIR / "queues"
def device_queues_dir() -> Path: return queues_dir() / "devices"
def group_queues_dir() -> Path: return queues_dir() / "groups"
def packet_events_path() -> Path: return queues_dir() / "packet_events.jsonl"
def packet_receipts_path() -> Path: return queues_dir() / "delivery_receipts.jsonl"
def delivered_packets_dir() -> Path: return queues_dir() / "delivered"
def expired_packets_dir() -> Path: return queues_dir() / "expired"
def admin_sessions_path() -> Path: return DATA_DIR / "admin_sessions.json"

# ---------- storage ----------
def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)

def read_json(path: Path, default: Any) -> Any:
    if not path.exists(): return default
    try: return json.loads(path.read_text(encoding="utf-8"))
    except Exception: return default

def append_jsonl(path: Path, value: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(value, sort_keys=True) + "\n")

def log_line(message: str) -> None:
    print(message)
    settings = read_json(settings_path(), DEFAULT_SETTINGS) if settings_path().exists() else DEFAULT_SETTINGS
    if settings.get("session_logging_enabled", True):
        logs_dir().mkdir(parents=True, exist_ok=True)
        with session_log_path().open("a", encoding="utf-8") as f:
            f.write(f"[{utc_now()}] {message}\n")

def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    logs_dir().mkdir(parents=True, exist_ok=True)
    incoming_updates_dir().mkdir(parents=True, exist_ok=True)
    staged_updates_dir().mkdir(parents=True, exist_ok=True)
    rollback_updates_dir().mkdir(parents=True, exist_ok=True)
    commands_dir().mkdir(parents=True, exist_ok=True)
    groups_dir().mkdir(parents=True, exist_ok=True)
    devices_dir().mkdir(parents=True, exist_ok=True)
    device_queues_dir().mkdir(parents=True, exist_ok=True)
    group_queues_dir().mkdir(parents=True, exist_ok=True)
    delivered_packets_dir().mkdir(parents=True, exist_ok=True)
    expired_packets_dir().mkdir(parents=True, exist_ok=True)
    if not settings_path().exists(): write_json(settings_path(), DEFAULT_SETTINGS)
    if not auth_path().exists(): set_admin_password(DEFAULT_ADMIN_PASSWORD)
    if not groups_path().exists(): write_json(groups_path(), [])
    if not devices_path().exists(): write_json(devices_path(), [])
    if not admin_sessions_path().exists(): write_json(admin_sessions_path(), [])

# ---------- process / pid ----------
def is_pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except Exception:
        return False

def read_pid_file() -> int | None:
    try:
        raw = pid_path().read_text(encoding="utf-8").strip()
        return int(raw) if raw else None
    except Exception:
        return None

def write_pid_file() -> None:
    pid_path().parent.mkdir(parents=True, exist_ok=True)
    pid_path().write_text(str(os.getpid()) + "\n", encoding="utf-8")

def remove_pid_file() -> None:
    try:
        current = read_pid_file()
        if current == os.getpid() and pid_path().exists():
            pid_path().unlink()
    except Exception:
        pass

def process_payload() -> Dict[str, Any]:
    stored = read_pid_file()
    return {
        "pid": os.getpid(),
        "pid_file": str(pid_path()),
        "pid_file_value": stored,
        "pid_file_matches_current": stored == os.getpid(),
        "pid_file_process_running": is_pid_running(stored or -1),
        "stop_script": "bash stop_local_node.sh",
        "restart_script": "bash restart_local_node.sh",
        "port": PORT,
    }

def port_looks_busy() -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        sock.bind((HOST, PORT))
        return False
    except OSError:
        return True
    finally:
        try: sock.close()
        except Exception: pass

def print_port_busy_help() -> None:
    ensure_data_dir()
    old_pid = read_pid_file()
    log_line("\n" + "!" * 64)
    log_line("SWRLZ Local Core Node could not start: port already in use")
    log_line(f"Port: {PORT}")
    if old_pid:
        log_line(f"PID file says old process may be: {old_pid} · running={is_pid_running(old_pid)}")
    log_line("Fix commands:")
    log_line("  bash stop_local_node.sh")
    log_line("  bash restart_local_node.sh")
    log_line("Fallback if script is missing:")
    log_line("  pkill -f local_node_server.py")
    log_line("!" * 64 + "\n")

# ---------- auth ----------
def hash_password(password: str, salt_b64: str | None = None) -> Dict[str, str]:
    salt = secrets.token_bytes(16) if salt_b64 is None else base64.b64decode(salt_b64.encode("ascii"))
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 240_000)
    return {"algorithm": "pbkdf2_sha256", "salt": base64.b64encode(salt).decode("ascii"), "hash": base64.b64encode(digest).decode("ascii")}

def set_admin_password(password: str) -> None:
    write_json(auth_path(), {"username": ADMIN_USERNAME, "password": hash_password(password), "updated_at": utc_now()})

def load_settings() -> Dict[str, Any]:
    ensure_data_dir()
    loaded = read_json(settings_path(), {})
    merged = dict(DEFAULT_SETTINGS)
    if isinstance(loaded, dict): merged.update(loaded)
    return merged

def save_settings(settings: Dict[str, Any]) -> None:
    merged = dict(DEFAULT_SETTINGS)
    if isinstance(settings, dict): merged.update(settings)
    write_json(settings_path(), merged)

def verify_password(username: str, password: str) -> bool:
    ensure_data_dir()
    auth = read_json(auth_path(), {})
    if username != str(auth.get("username", ADMIN_USERNAME)): return False
    block = auth.get("password", {})
    if not isinstance(block, dict): return False
    salt = block.get("salt", "")
    expected_hash = block.get("hash", "")
    if not salt or not expected_hash: return False
    return hmac.compare_digest(hash_password(password, salt)["hash"], expected_hash)

# ---------- network identity ----------
def get_lan_ipv4_addresses() -> List[str]:
    addresses = set()
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127."): addresses.add(ip)
    except Exception: pass
    for target in ("8.8.8.8", "1.1.1.1", "192.168.1.1"):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.connect((target, 80))
            ip = sock.getsockname()[0]
            sock.close()
            if not ip.startswith("127."): addresses.add(ip)
        except Exception: pass
    return sorted(addresses)

def connection_info() -> Dict[str, Any]:
    ips = get_lan_ipv4_addresses()
    urls = [f"http://{ip}:{PORT}" for ip in ips]
    return {
        "host": HOST,
        "port": PORT,
        "local_url": f"http://127.0.0.1:{PORT}",
        "lan_ips": ips,
        "lan_urls": urls,
        "status_urls": [f"{url}/status" for url in urls],
        "connection_info_urls": [f"{url}/connection-info" for url in urls],
        "discovery_signature_urls": [f"{url}/discovery/signature" for url in urls],
        "discovery_manifest_urls": [f"{url}/discovery/manifest" for url in urls],
        "note": "Use a LAN URL from the Core Node device on the Action Phone. 127.0.0.1 means the same device.",
    }

def discovery_signature_payload() -> Dict[str, Any]:
    settings = load_settings() if settings_path().exists() else DEFAULT_SETTINGS
    info = connection_info()
    return {
        "ok": True,
        "server": "swrlz-local-node",
        "node_type": "local-core",
        "version": "0.7.3-discovery-signature",
        "server_version": SERVER_VERSION,
        "patch": "LNS-0.7.3-DISCOVERY-SIGNATURE",
        "patch_label": PATCH_LABEL,
        "roadmap": ROADMAP,
        "host": HOST,
        "port": PORT,
        "node_name": settings.get("node_name", "SWRLZ Local Core Node"),
        "local_first": True,
        "paid_ai_required": False,
        "auth_required_for_admin": True,
        "timestamp": utc_now(),
        "urls": {
            "local": info.get("local_url"),
            "lan": info.get("lan_urls", []),
            "discovery_signature": info.get("discovery_signature_urls", []),
            "status": info.get("status_urls", []),
        },
        "endpoints": {
            "health": "/health",
            "status": "/status",
            "connection_info": "/connection-info",
            "discovery_signature": "/discovery/signature",
            "discovery_manifest": "/discovery/manifest",
            "discovery_ping": "/discovery/ping",
            "presence_summary": "/presence/summary",
            "devices_register": "/devices/register",
            "devices_checkin": "/devices/checkin",
            "admin_devices": "/admin/devices",
            "admin_ledger": "/admin/ledger",
            "admin_queues": "/admin/queues",
        },
        "capabilities": {
            "network_discovery": True,
            "signature_probe": True,
            "lan_url_advertise": True,
            "presence_summary": True,
            "device_register": True,
            "device_checkin": True,
            "device_ledger": True,
            "offline_packet_queue": True,
            "admin_registry": True,
            "ghost_device_vault_ready": True,
            "cors": True,
            "options_preflight": True,
        },
        "expected_client": {
            "path": "/discovery/signature",
            "server": "swrlz-local-node",
            "version": "0.7.3-discovery-signature",
            "patch": "LNS-0.7.3-DISCOVERY-SIGNATURE",
            "port": PORT,
        },
    }

def discovery_manifest_payload() -> Dict[str, Any]:
    return {
        "ok": True,
        "schema": 1,
        "kind": "swrlz-local-node-discovery-manifest",
        "signature": discovery_signature_payload(),
        "status": status_payload(),
        "presence": presence_payload(group_id="", admin_view=False),
        "created_at": utc_now(),
    }

def public_presence_summary_payload(group_id: str = "") -> Dict[str, Any]:
    payload = presence_payload(group_id="", admin_view=False)
    payload["visibility_mode"] = "public-discovery"
    payload["requested_group_id"] = safe_id(group_id, "group") if group_id else ""
    payload["authorization_required"] = bool(group_id)
    payload["message"] = "Public discovery summary only. Use valid group_key or admin auth for private device presence."
    return payload

def soft_checkin_payload(handler: BaseHTTPRequestHandler, body: Dict[str, Any]) -> Dict[str, Any]:
    ctx = auth_context(handler, body)
    return {
        "ok": True,
        "soft_checkin": True,
        "registered": False,
        "group_id": ctx.get("group_id", ""),
        "device_id": ctx.get("device_id", ""),
        "packets_waiting": 0,
        "server_version": SERVER_VERSION,
        "patch_label": PATCH_LABEL,
        "message": "Device checkin endpoint is reachable. Register device/group for authenticated ledger checkins.",
        "time": utc_now(),
    }

# ---------- status/log/update payloads ----------
def status_payload() -> Dict[str, Any]:
    settings = load_settings()
    return {
        "ok": True,
        "node_type": "local-core",
        "server_version": SERVER_VERSION,
        "roadmap": ROADMAP,
        "patch_label": PATCH_LABEL,
        "node_name": settings["node_name"],
        "paid_ai_required": False,
        "pairing_required": bool(settings.get("require_pairing_token", True)),
        "admin_enabled": True,
        "settings_persistent": True,
        "connection": connection_info(),
        "process": process_payload(),
        "logs": {
            "session_id": SESSION_ID,
            "session_started_at": SESSION_STARTED_AT,
            "session_log": str(session_log_path()),
            "request_log_today": str(daily_request_log_path()),
            "logs_dir": str(logs_dir()),
            "enabled": bool(settings.get("session_logging_enabled", True)),
        },
        "update": update_status_payload(),
        "capabilities": {
            "status": True,
            "connection_info": True,
            "connection_observer": True,
            "admin_settings": True,
            "recent_events": True,
            "session_logs": True,
            "update_staging": True,
            "pairing": True,
            "logs": True,
            "teach_packets": False,
            "command_queue": True,
            "pending_commands": True,
            "command_results": True,
            "command_cards": True,
            "command_history": True,
            "command_lookup": True,
            "action_proposals": True,
            "group_relay": True,
            "device_registry": True,
            "offline_packet_queue": True,
            "admin_saved_sessions": True,
            "presence_index": True,
            "relay_radar": True,
            "network_discovery": True,
            "discovery_signature": True,
            "discovery_manifest": True,
            "discovery_ping": True,
            "device_checkin": True,
            "device_ledger": True,
            "ghost_device_vault_ready": True,
        },
        "devices": {"total": len(load_devices()) if devices_path().exists() else 0},
        "groups": {"total": len(load_groups()) if groups_path().exists() else 0},
        "packets": packet_summary(),
        "commands": command_summary(),
        "created_at": utc_now(),
    }

def update_status_payload() -> Dict[str, Any]:
    settings = load_settings() if settings_path().exists() else DEFAULT_SETTINGS
    state = read_json(update_state_path(), {})
    return {
        "server_update_url_configured": bool(settings.get("server_update_url")),
        "client_update_url_configured": bool(settings.get("client_update_url")),
        "server_update_url": settings.get("server_update_url", ""),
        "client_update_url": settings.get("client_update_url", ""),
        "incoming_dir": str(incoming_updates_dir()),
        "staged_dir": str(staged_updates_dir()),
        "rollback_dir": str(rollback_updates_dir()),
        "last_state": state,
        "manual_update_steps": [
            "download update ZIP",
            "verify SHA-256",
            "stage ZIP under swrlz_node_data/updates/staged",
            "stop server with bash stop_local_node.sh",
            "extract new source while preserving swrlz_node_data",
            "restart with bash run_local_node.sh",
        ],
        "hot_swap_enabled": False,
        "restart_required_after_stage": True,
        "process": process_payload(),
    }

def get_recent_events(limit: int = 30) -> List[Dict[str, Any]]:
    lines: List[str] = []
    for path in (daily_request_log_path(), legacy_request_events_path()):
        if path.exists():
            lines.extend(path.read_text(encoding="utf-8", errors="ignore").splitlines())
    parsed: List[Dict[str, Any]] = []
    seen = set()
    for line in lines:
        try:
            event = json.loads(line)
        except Exception:
            continue
        key = event.get("event_id") or (event.get("time"), event.get("path"), event.get("client_ip"), event.get("client_port"), event.get("status"), event.get("result"))
        if key in seen:
            continue
        seen.add(key)
        parsed.append(event)
    return parsed[-limit:]

def tail_text(path: Path, limit: int = 120) -> List[str]:
    if not path.exists(): return []
    return path.read_text(encoding="utf-8", errors="ignore").splitlines()[-limit:]

def tail_jsonl(path: Path, limit: int = 120) -> List[Dict[str, Any]]:
    parsed: List[Dict[str, Any]] = []
    for line in tail_text(path, limit):
        try:
            value = json.loads(line)
            if isinstance(value, dict): parsed.append(value)
        except Exception:
            continue
    return parsed



# ---------- group relay / admin sessions / offline packet queue ----------
def safe_id(raw: str, prefix: str = "id") -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "-" for ch in str(raw).strip())
    cleaned = "-".join(part for part in cleaned.split("-") if part)
    if not cleaned:
        cleaned = prefix + "-" + secrets.token_hex(3)
    return cleaned[:64]

def hash_secret(value: str, salt_b64: str | None = None) -> Dict[str, str]:
    salt = secrets.token_bytes(16) if salt_b64 is None else base64.b64decode(salt_b64.encode("ascii"))
    digest = hashlib.pbkdf2_hmac("sha256", value.encode("utf-8"), salt, 180_000)
    return {"algorithm": "pbkdf2_sha256", "salt": base64.b64encode(salt).decode("ascii"), "hash": base64.b64encode(digest).decode("ascii")}

def verify_secret(value: str, block: Dict[str, str]) -> bool:
    try:
        return hmac.compare_digest(hash_secret(value, block.get("salt", ""))["hash"], block.get("hash", ""))
    except Exception:
        return False

def load_groups() -> List[Dict[str, Any]]:
    value = read_json(groups_path(), [])
    return value if isinstance(value, list) else []

def save_groups(groups: List[Dict[str, Any]]) -> None:
    write_json(groups_path(), groups)

def load_devices() -> List[Dict[str, Any]]:
    value = read_json(devices_path(), [])
    return value if isinstance(value, list) else []

def save_devices(devices: List[Dict[str, Any]]) -> None:
    write_json(devices_path(), devices)

def load_admin_sessions() -> List[Dict[str, Any]]:
    value = read_json(admin_sessions_path(), [])
    return value if isinstance(value, list) else []

def save_admin_sessions(sessions: List[Dict[str, Any]]) -> None:
    write_json(admin_sessions_path(), sessions)

def find_group(group_id: str) -> Dict[str, Any] | None:
    gid = safe_id(group_id, "group")
    for group in load_groups():
        if group.get("group_id") == gid:
            return group
    return None

def group_key_ok(group_id: str, group_key: str) -> bool:
    group = find_group(group_id)
    if not group:
        return False
    return verify_secret(group_key, group.get("group_key_hash", {}))

def find_device(device_id: str) -> Dict[str, Any] | None:
    for device in load_devices():
        if device.get("device_id") == device_id:
            return device
    return None

def device_key_ok(device_id: str, device_key: str) -> bool:
    device = find_device(device_id)
    if not device:
        return False
    return verify_secret(device_key, device.get("device_key_hash", {}))

def create_or_update_group(group_id: str, group_key: str, label: str, created_by: str = "local-user") -> Dict[str, Any]:
    gid = safe_id(group_id, "group")
    now = utc_now()
    groups = load_groups()
    existing = next((g for g in groups if g.get("group_id") == gid), None)
    if existing:
        existing["label"] = label or existing.get("label") or gid
        existing["updated_at"] = now
        save_groups(groups)
        return sanitize_group(existing)
    record = {
        "group_id": gid,
        "label": label or gid,
        "group_key_hash": hash_secret(group_key),
        "created_by": created_by,
        "created_at": now,
        "updated_at": now,
        "member_count": 0,
    }
    groups.append(record)
    save_groups(groups)
    append_jsonl(packet_events_path(), {"time": now, "action": "group_created", "group_id": gid, "actor": created_by})
    return sanitize_group(record)

def sanitize_group(group: Dict[str, Any]) -> Dict[str, Any]:
    return {k: v for k, v in group.items() if k != "group_key_hash"}

def sanitize_device(device: Dict[str, Any], admin_view: bool = False) -> Dict[str, Any]:
    out = {k: v for k, v in device.items() if k != "device_key_hash"}
    if not admin_view:
        out.pop("client_ip", None)
        out.pop("user_agent", None)
    return out

def is_online(device: Dict[str, Any]) -> bool:
    seconds = int(load_settings().get("device_online_window_seconds", 180))
    raw = str(device.get("last_seen_at", ""))
    if not raw:
        return False
    try:
        last = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - last).total_seconds() <= seconds
    except Exception:
        return False

def update_group_member_count(group_id: str) -> None:
    devices = load_devices()
    count = sum(1 for d in devices if d.get("group_id") == group_id)
    groups = load_groups()
    for group in groups:
        if group.get("group_id") == group_id:
            group["member_count"] = count
            group["updated_at"] = utc_now()
    save_groups(groups)

def register_device(group_id: str, group_key: str, device_id: str, device_label: str, role: str, device_key: str = "", handler: BaseHTTPRequestHandler | None = None) -> Dict[str, Any]:
    gid = safe_id(group_id, "group")
    if not group_key_ok(gid, group_key):
        raise PermissionError("group key rejected")
    did = safe_id(device_id or ("node-" + secrets.token_hex(4)), "node")
    dkey = device_key.strip() or "DEV-" + secrets.token_hex(8).upper()
    now = utc_now()
    devices = load_devices()
    existing = next((d for d in devices if d.get("device_id") == did), None)
    payload = {
        "device_id": did,
        "group_id": gid,
        "device_label": device_label or did,
        "role": role or "Action Phone",
        "last_seen_at": now,
        "last_checkin_at": now,
        "app_version": handler.headers.get("X-SWRLZ-App-Version", "") if handler else "",
        "patch_label": handler.headers.get("X-SWRLZ-Patch-Label", "") if handler else "",
        "client_ip": handler.client_address[0] if handler and handler.client_address else "",
        "user_agent": handler.headers.get("User-Agent", "") if handler else "",
        "capabilities": ["PING", "SHOW_MESSAGE", "REPORT_STATUS", "REFRESH_CONTEXT", "ECHO_TEST", "RADAR_READY"],
        "device_anchor_hash": hashlib.sha256(str((handler.headers.get("X-SWRLZ-Device-Anchor-Id", "") if handler else "") or "").encode("utf-8")).hexdigest()[:16] if ((handler.headers.get("X-SWRLZ-Device-Anchor-Id", "") if handler else "")) else hashlib.sha256(str(locals().get("device_anchor_id", "")).encode("utf-8")).hexdigest()[:16] if locals().get("device_anchor_id") else "",
        "trust_level": "group",
        "blocked": False,
        "updated_at": now,
    }
    if existing:
        existing.update(payload)
        if device_key and verify_secret(device_key, existing.get("device_key_hash", {})):
            pass
        elif device_key:
            existing["device_key_hash"] = hash_secret(device_key)
            dkey = device_key
        else:
            dkey = "saved-on-device"
    else:
        payload.update({"device_key_hash": hash_secret(dkey), "created_at": now})
        devices.append(payload)
    save_devices(devices)
    update_group_member_count(gid)
    append_jsonl(device_checkins_path(), {"time": now, "action": "device_registered", "device_id": did, "group_id": gid, "role": role})
    record = find_device(did) or payload
    out = sanitize_device(record, admin_view=False)
    out["device_key"] = dkey
    out["online"] = True
    out["queued_packets"] = count_pending_packets_for_device(did)
    return out

def checkin_device(group_id: str, device_id: str, device_key: str, handler: BaseHTTPRequestHandler | None = None) -> Dict[str, Any]:
    gid = safe_id(group_id, "group")
    did = safe_id(device_id, "node")
    if not find_group(gid):
        raise PermissionError("group not found")
    if not device_key_ok(did, device_key):
        raise PermissionError("device key rejected")
    now = utc_now()
    devices = load_devices()
    for device in devices:
        if device.get("device_id") == did:
            device["last_seen_at"] = now
            device["last_checkin_at"] = now
            device["app_version"] = handler.headers.get("X-SWRLZ-App-Version", "") if handler else device.get("app_version", "")
            device["patch_label"] = handler.headers.get("X-SWRLZ-Patch-Label", "") if handler else device.get("patch_label", "")
            device["client_ip"] = handler.client_address[0] if handler and handler.client_address else device.get("client_ip", "")
            device["user_agent"] = handler.headers.get("User-Agent", "") if handler else device.get("user_agent", "")
            device["activity_state"] = handler.headers.get("X-SWRLZ-Activity-State", device.get("activity_state", "idle")) if handler else device.get("activity_state", "idle")
            device["current_screen"] = handler.headers.get("X-SWRLZ-Current-Screen", device.get("current_screen", "")) if handler else device.get("current_screen", "")
            device["forced_offline"] = False
            device["updated_at"] = now
            save_devices(devices)
            queued = pending_packets_for_device(did, mark_delivered=False)
            append_jsonl(device_checkins_path(), {"time": now, "action": "device_checkin", "device_id": did, "group_id": gid, "queued_packets": len(queued)})
            out = sanitize_device(device)
            out["online"] = True
            out["queued_packets"] = len(queued)
            return out
    raise PermissionError("device not registered")

def devices_for_group(group_id: str, online_only: bool = False, admin_view: bool = False) -> List[Dict[str, Any]]:
    gid = safe_id(group_id, "group")
    out = []
    for device in load_devices():
        if device.get("group_id") != gid:
            continue
        if online_only and not is_online(device):
            continue
        d = sanitize_device(device, admin_view=admin_view)
        d["online"] = is_online(device)
        d["queued_packets"] = count_pending_packets_for_device(str(device.get("device_id", "")))
        out.append(d)
    return sorted(out, key=lambda d: (not d.get("online", False), d.get("device_label", "")))

def all_devices(admin_view: bool = True) -> List[Dict[str, Any]]:
    out = []
    for device in load_devices():
        d = sanitize_device(device, admin_view=admin_view)
        d["online"] = is_online(device)
        d["queued_packets"] = count_pending_packets_for_device(str(device.get("device_id", "")))
        out.append(d)
    return sorted(out, key=lambda d: (d.get("group_id", ""), not d.get("online", False), d.get("device_label", "")))

def seconds_since(raw: str) -> int | None:
    parsed = parse_iso(str(raw or ""))
    if not parsed:
        return None
    return int((datetime.now(timezone.utc) - parsed).total_seconds())

def device_presence_state(device: Dict[str, Any]) -> str:
    if device.get("blocked"):
        return "blocked"
    if device.get("forced_offline"):
        return "offline"
    settings = load_settings()
    online_window = int(settings.get("device_online_window_seconds", 60))
    idle_window = int(settings.get("presence_offline_window_seconds", 300))
    stale_window = int(settings.get("presence_stale_window_seconds", 86400))
    age = seconds_since(str(device.get("last_seen_at", "")))
    if age is None:
        return "unknown"
    if age <= online_window:
        return "online"
    if age <= idle_window:
        return "idle"
    if age > stale_window:
        return "stale"
    return "offline"

def decorate_presence_device(device: Dict[str, Any], admin_view: bool = False) -> Dict[str, Any]:
    d = sanitize_device(device, admin_view=admin_view)
    state = device_presence_state(device)
    d["online_state"] = state
    d["online"] = state == "online"
    d["last_seen_seconds"] = seconds_since(str(device.get("last_seen_at", "")))
    d["queued_packets"] = count_pending_packets_for_device(str(device.get("device_id", "")))
    return d

def presence_devices_for_group(group_id: str, admin_view: bool = False) -> List[Dict[str, Any]]:
    gid = safe_id(group_id, "group")
    out = []
    for device in load_devices():
        if device.get("group_id") == gid:
            out.append(decorate_presence_device(device, admin_view=admin_view))
    return sorted(out, key=lambda d: (d.get("online_state") != "online", d.get("device_label", "")))

def presence_all_devices(admin_view: bool = True) -> List[Dict[str, Any]]:
    out = [decorate_presence_device(device, admin_view=admin_view) for device in load_devices()]
    return sorted(out, key=lambda d: (d.get("group_id", ""), d.get("online_state") != "online", d.get("device_label", "")))

def group_presence_summaries(admin_view: bool = False, only_group_id: str = "") -> List[Dict[str, Any]]:
    groups = [sanitize_group(g) for g in load_groups()]
    if only_group_id:
        gid = safe_id(only_group_id, "group")
        groups = [g for g in groups if g.get("group_id") == gid]
    out = []
    for group in groups:
        gid = str(group.get("group_id", ""))
        devices = presence_devices_for_group(gid, admin_view=admin_view)
        summary = dict(group)
        summary["member_count"] = len(devices)
        summary["online_count"] = sum(1 for d in devices if d.get("online_state") == "online")
        summary["idle_count"] = sum(1 for d in devices if d.get("online_state") == "idle")
        summary["offline_count"] = sum(1 for d in devices if d.get("online_state") in {"offline", "unknown"})
        summary["queued_count"] = sum(int(d.get("queued_packets", 0) or 0) for d in devices)
        summary["status"] = "active" if summary["online_count"] else ("idle" if summary["idle_count"] else "offline")
        out.append(summary)
    return sorted(out, key=lambda g: (g.get("status") != "active", g.get("label", "")))

def presence_payload(group_id: str = "", admin_view: bool = False) -> Dict[str, Any]:
    if admin_view:
        devices = presence_all_devices(admin_view=True)
        groups = group_presence_summaries(admin_view=True)
        mode = "admin"
    else:
        gid = safe_id(group_id, "group")
        devices = presence_devices_for_group(gid, admin_view=False) if gid else []
        groups = group_presence_summaries(admin_view=False, only_group_id=gid) if gid else []
        mode = "group"
    return {
        "ok": True,
        "server_version": SERVER_VERSION,
        "patch_label": PATCH_LABEL,
        "roadmap": ROADMAP,
        "server_time": utc_now(),
        "visibility_mode": mode,
        "groups": groups,
        "devices": devices,
        "summary": {
            "groups": len(groups),
            "devices": len(devices),
            "online": sum(1 for d in devices if d.get("online_state") == "online"),
            "idle": sum(1 for d in devices if d.get("online_state") == "idle"),
            "offline": sum(1 for d in devices if d.get("online_state") in {"offline", "unknown"}),
            "queued": sum(int(d.get("queued_packets", 0) or 0) for d in devices),
        },
    }

def auth_context(handler: BaseHTTPRequestHandler, body: Dict[str, Any] | None = None) -> Dict[str, str]:
    body = body or {}
    return {
        "group_id": safe_id(str(body.get("group_id") or body.get("groupId") or handler.headers.get("X-SWRLZ-Group-Id", "")), "group"),
        "group_key": str(body.get("group_key") or body.get("groupKey") or handler.headers.get("X-SWRLZ-Group-Key", "")),
        "device_id": safe_id(str(body.get("device_id") or body.get("deviceId") or handler.headers.get("X-SWRLZ-Device-Node-Id", "")), "node"),
        "device_key": str(body.get("device_key") or body.get("deviceKey") or handler.headers.get("X-SWRLZ-Device-Key", "")),
    }

def authorize_group(handler: BaseHTTPRequestHandler, body: Dict[str, Any] | None = None) -> Dict[str, str]:
    ctx = auth_context(handler, body)
    if not ctx["group_id"] or not ctx["group_key"] or not group_key_ok(ctx["group_id"], ctx["group_key"]):
        raise PermissionError("group authorization failed")
    return ctx

def admin_token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()

def create_admin_session(username: str, password: str, device_id: str = "") -> Dict[str, Any]:
    if not verify_password(username, password):
        raise PermissionError("admin authentication failed")
    token = "adm_" + secrets.token_urlsafe(32)
    now = utc_now()
    session = {
        "session_id": "as_" + secrets.token_hex(8),
        "token_hash": admin_token_hash(token),
        "username": username,
        "device_id": device_id,
        "enabled": True,
        "created_at": now,
        "last_used_at": now,
        "revoked_at": "",
    }
    sessions = [s for s in load_admin_sessions() if s.get("revoked_at") == ""][-24:]
    sessions.append(session)
    save_admin_sessions(sessions)
    append_jsonl(logs_dir() / "admin_sessions.jsonl", {"time": now, "action": "admin_session_created", "session_id": session["session_id"], "device_id": device_id})
    return {"session_id": session["session_id"], "admin_session_token": token, "created_at": now, "enabled": True}

def verify_admin_bearer(header: str) -> bool:
    if not header.startswith("Bearer "):
        return False
    token = header.split(" ", 1)[1].strip()
    th = admin_token_hash(token)
    changed = False
    sessions = load_admin_sessions()
    ok = False
    for session in sessions:
        if session.get("token_hash") == th and session.get("enabled") is True and not session.get("revoked_at"):
            session["last_used_at"] = utc_now()
            ok = True
            changed = True
    if changed:
        save_admin_sessions(sessions)
    return ok

def revoke_admin_session(token: str) -> bool:
    th = admin_token_hash(token)
    sessions = load_admin_sessions()
    found = False
    for session in sessions:
        if session.get("token_hash") == th and not session.get("revoked_at"):
            session["enabled"] = False
            session["revoked_at"] = utc_now()
            found = True
    if found:
        save_admin_sessions(sessions)
        append_jsonl(logs_dir() / "admin_sessions.jsonl", {"time": utc_now(), "action": "admin_session_revoked"})
    return found

def queue_packet_path(device_id: str) -> Path:
    return device_queues_dir() / f"{safe_id(device_id, 'node')}.json"

def load_all_packets() -> List[Dict[str, Any]]:
    packets: List[Dict[str, Any]] = []
    for path in sorted(device_queues_dir().glob("*.json")):
        value = read_json(path, [])
        if isinstance(value, list):
            packets.extend([p for p in value if isinstance(p, dict)])
    return packets

def save_packets_for_device(device_id: str, packets: List[Dict[str, Any]]) -> None:
    write_json(queue_packet_path(device_id), packets)

def load_packets_for_device(device_id: str) -> List[Dict[str, Any]]:
    value = read_json(queue_packet_path(device_id), [])
    return value if isinstance(value, list) else []

def append_packet(device_id: str, packet: Dict[str, Any]) -> None:
    packets = load_packets_for_device(device_id)
    packets.append(packet)
    save_packets_for_device(device_id, packets)

def packet_status_terminal(status: str) -> bool:
    return status.upper() in {"COMPLETED", "REJECTED", "FAILED", "EXPIRED", "BLOCKED"}

def parse_iso(raw: str) -> datetime | None:
    try:
        return datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except Exception:
        return None

def packet_expired(packet: Dict[str, Any]) -> bool:
    expires = parse_iso(str(packet.get("expires_at", "")))
    return bool(expires and datetime.now(timezone.utc) > expires)

def expire_packet_if_needed(packet: Dict[str, Any]) -> Dict[str, Any]:
    if not packet_status_terminal(str(packet.get("status", ""))) and packet_expired(packet):
        packet["status"] = "EXPIRED"
        packet["updated_at"] = utc_now()
        append_jsonl(expired_packets_dir() / f"expired_{today_key()}.jsonl", packet)
        append_packet_event(packet, "expired")
    return packet

def pending_packets_for_device(device_id: str, mark_delivered: bool = False) -> List[Dict[str, Any]]:
    packets = load_packets_for_device(device_id)
    out: List[Dict[str, Any]] = []
    changed = False
    for packet in packets:
        previous = packet.get("status")
        packet = expire_packet_if_needed(packet)
        status = str(packet.get("status", "")).upper()
        if status in {"CREATED", "QUEUED", "DELIVERED", "DISPLAYED", "ACKNOWLEDGED"}:
            if mark_delivered and status in {"CREATED", "QUEUED"}:
                packet["status"] = "DELIVERED"
                packet["delivered_at"] = utc_now()
                packet["updated_at"] = utc_now()
                append_packet_event(packet, "delivered")
                append_jsonl(packet_receipts_path(), {"time": utc_now(), "packet_id": packet.get("packet_id"), "target_device_id": device_id, "receipt": "DELIVERED"})
            out.append(packet)
        if previous != packet.get("status"):
            changed = True
    if changed or mark_delivered:
        save_packets_for_device(device_id, packets)
    return out

def count_pending_packets_for_device(device_id: str) -> int:
    return len(pending_packets_for_device(device_id, mark_delivered=False)) if device_id else 0

def append_packet_event(packet: Dict[str, Any], action: str, detail: str = "") -> None:
    append_jsonl(packet_events_path(), {
        "time": utc_now(),
        "packet_id": packet.get("packet_id", ""),
        "command_id": packet.get("command_id", ""),
        "action": action,
        "status": packet.get("status", ""),
        "group_id": packet.get("group_id", ""),
        "from_device_id": packet.get("from_device_id", ""),
        "target_device_id": packet.get("target_device_id", ""),
        "packet_type": packet.get("packet_type", ""),
        "command_type": packet.get("command_type", ""),
        "detail": detail,
        "server_version": SERVER_VERSION,
        "patch_label": PATCH_LABEL,
    })

def packet_summary() -> Dict[str, Any]:
    packets = load_all_packets()
    counts: Dict[str, int] = {}
    for packet in packets:
        status = str(packet.get("status", "UNKNOWN")).upper()
        counts[status] = counts.get(status, 0) + 1
    return {
        "enabled": bool(load_settings().get("offline_packet_queue_enabled", True)) if settings_path().exists() else True,
        "total": len(packets),
        "counts": counts,
        "queues_dir": str(queues_dir()),
        "device_queues_dir": str(device_queues_dir()),
        "events_path": str(packet_events_path()),
        "receipts_path": str(packet_receipts_path()),
    }

def create_packet_for_device(group_id: str, from_device_id: str, target_device_id: str, packet_type: str, command_type: str, title: str, payload: Dict[str, Any], requires_approval: bool = True, ttl_minutes: int | None = None) -> Dict[str, Any]:
    now_dt = datetime.now(timezone.utc)
    now = now_dt.isoformat()
    ttl = ttl_minutes if ttl_minutes is not None else int(load_settings().get("default_packet_ttl_minutes", 1440))
    expires = (now_dt.timestamp() + ttl * 60)
    expires_at = datetime.fromtimestamp(expires, timezone.utc).isoformat()
    ptype = packet_type.strip().upper() or "COMMAND"
    ctype = command_type.strip().upper() or "PING"
    safe_types = set(load_settings().get("safe_packet_types", ["PING", "SHOW_MESSAGE", "REPORT_STATUS", "REFRESH_CONTEXT", "ECHO_TEST"]))
    if ptype == "COMMAND" and ctype not in safe_types:
        raise ValueError(f"unsupported safe command type: {ctype}")
    packet = {
        "packet_id": "pkt_" + uuid.uuid4().hex[:12],
        "command_id": "cmd_" + uuid.uuid4().hex[:12],
        "schema_version": 2,
        "packet_type": ptype,
        "command_type": ctype,
        "title": title or f"{ctype} packet",
        "status": "QUEUED",
        "risk": "low",
        "requires_user_approval": requires_approval,
        "group_id": safe_id(group_id, "group"),
        "from_device_id": safe_id(from_device_id, "node"),
        "target_device_id": safe_id(target_device_id, "node"),
        "payload": payload if isinstance(payload, dict) else {},
        "created_at": now,
        "updated_at": now,
        "expires_at": expires_at,
        "delivered_at": "",
        "displayed_at": "",
        "acked_at": "",
        "completed_at": "",
        "result": "",
        "result_detail": "",
    }
    append_packet(packet["target_device_id"], packet)
    append_packet_event(packet, "queued")
    return packet

def update_packet(packet_id: str, target_device_id: str, status: str, detail: str = "") -> Dict[str, Any]:
    did = safe_id(target_device_id, "node")
    packets = load_packets_for_device(did)
    status = status.upper()
    for idx, packet in enumerate(packets):
        if packet.get("packet_id") == packet_id or packet.get("command_id") == packet_id:
            packet = expire_packet_if_needed(packet)
            if packet_status_terminal(str(packet.get("status", ""))):
                packets[idx] = packet
                save_packets_for_device(did, packets)
                return packet
            packet["status"] = status
            packet["updated_at"] = utc_now()
            if status == "DISPLAYED": packet["displayed_at"] = utc_now()
            if status == "ACKNOWLEDGED": packet["acked_at"] = utc_now()
            if status in {"COMPLETED", "FAILED", "REJECTED", "BLOCKED"}:
                packet["completed_at"] = utc_now()
                packet["result"] = status.lower()
                packet["result_detail"] = detail
                append_jsonl(delivered_packets_dir() / f"delivered_{today_key()}.jsonl", packet)
            packets[idx] = packet
            save_packets_for_device(did, packets)
            append_packet_event(packet, status.lower(), detail)
            append_jsonl(packet_receipts_path(), {"time": utc_now(), "packet_id": packet.get("packet_id"), "target_device_id": did, "receipt": status, "detail": detail})
            return packet
    raise KeyError(f"packet not found: {packet_id}")


def admin_packet_records() -> List[Dict[str, Any]]:
    records: List[Dict[str, Any]] = []
    for device_file in device_queues_dir().glob("*.json"):
        device_id = device_file.stem
        value = read_json(device_file, [])
        if not isinstance(value, list):
            continue
        for packet in value:
            if isinstance(packet, dict):
                item = dict(packet)
                item["queue_device_id"] = device_id
                records.append(item)
    return sorted(records, key=lambda p: str(p.get("updated_at") or p.get("created_at") or ""), reverse=True)

def clear_queue_for_device(device_id: str, archive: bool = True) -> Dict[str, Any]:
    did = safe_id(device_id, "node")
    packets = load_packets_for_device(did)
    if archive and packets:
        append_jsonl(delivered_packets_dir() / f"admin_cleared_{today_key()}.jsonl", {"time": utc_now(), "device_id": did, "packets": packets, "action": "admin_clear_queue"})
    save_packets_for_device(did, [])
    append_jsonl(packet_events_path(), {"time": utc_now(), "action": "admin_clear_queue", "device_id": did, "cleared": len(packets), "server_version": SERVER_VERSION, "patch_label": PATCH_LABEL})
    return {"device_id": did, "cleared": len(packets)}

def forget_device(device_id: str, clear_queue: bool = False) -> Dict[str, Any]:
    did = safe_id(device_id, "node")
    devices = load_devices()
    kept = [d for d in devices if d.get("device_id") != did]
    removed = [d for d in devices if d.get("device_id") == did]
    if not removed:
        raise KeyError(f"device not found: {did}")
    save_devices(kept)
    for d in removed:
        update_group_member_count(str(d.get("group_id", "")))
    cleared = clear_queue_for_device(did, archive=True) if clear_queue else {"device_id": did, "cleared": 0}
    append_jsonl(device_checkins_path(), {"time": utc_now(), "action": "admin_forget_device", "device_id": did, "clear_queue": clear_queue, "cleared_queue": cleared.get("cleared", 0)})
    return {"device_id": did, "removed": len(removed), "cleared_queue": cleared.get("cleared", 0)}

def update_device_admin_state(device_id: str, **fields: Any) -> Dict[str, Any]:
    did = safe_id(device_id, "node")
    devices = load_devices()
    now = utc_now()
    for device in devices:
        if device.get("device_id") == did:
            device.update(fields)
            device["updated_at"] = now
            save_devices(devices)
            append_jsonl(device_checkins_path(), {"time": now, "action": "admin_update_device", "device_id": did, "fields": sorted(fields.keys())})
            return decorate_presence_device(device, admin_view=True)
    raise KeyError(f"device not found: {did}")

def inspect_device_payload(device_id: str) -> Dict[str, Any]:
    did = safe_id(device_id, "node")
    device = find_device(did)
    if not device:
        raise KeyError(f"device not found: {did}")
    packets = load_packets_for_device(did)
    return {"ok": True, "device": decorate_presence_device(device, admin_view=True), "packets": packets, "queue_count": len(packets)}

# ---------- command queue ----------
def load_commands() -> List[Dict[str, Any]]:
    ensure_data_dir()
    value = read_json(commands_path(), [])
    return value if isinstance(value, list) else []

def save_commands(commands: List[Dict[str, Any]]) -> None:
    write_json(commands_path(), commands)

def command_summary() -> Dict[str, Any]:
    commands = load_commands() if commands_path().exists() else []
    counts: Dict[str, int] = {}
    for cmd in commands:
        status = str(cmd.get("status", "unknown"))
        counts[status] = counts.get(status, 0) + 1
    return {
        "enabled": bool(load_settings().get("command_queue_enabled", True)) if settings_path().exists() else True,
        "total": len(commands),
        "counts": counts,
        "commands_path": str(commands_path()),
        "supported_types": ["PING", "SHOW_MESSAGE", "REFRESH_CONTEXT", "REPORT_STATUS", "ECHO_TEST"],
        "history_path": str(command_events_path()),
    }

def append_command_event(command_id: str, action: str, status: str, actor: str, detail: str = "") -> None:
    if not load_settings().get("command_history_enabled", True):
        return
    append_jsonl(command_events_path(), {
        "time": utc_now(),
        "command_id": command_id,
        "action": action,
        "status": status,
        "actor": actor,
        "detail": detail,
        "server_version": SERVER_VERSION,
        "patch_label": PATCH_LABEL,
    })

def recent_command_events(limit: int = 50) -> List[Dict[str, Any]]:
    if not command_events_path().exists():
        return []
    parsed: List[Dict[str, Any]] = []
    for line in command_events_path().read_text(encoding="utf-8", errors="ignore").splitlines():
        try:
            event = json.loads(line)
            if isinstance(event, dict): parsed.append(event)
        except Exception:
            continue
    return parsed[-limit:]

def command_by_id(command_id: str) -> Dict[str, Any] | None:
    for cmd in load_commands():
        if cmd.get("id") == command_id:
            return cmd
    return None

def create_command(body: Dict[str, Any], created_by: str = "admin") -> Dict[str, Any]:
    commands = load_commands()
    command_type = str(body.get("type", "PING")).strip().upper() or "PING"
    title = str(body.get("title", f"{command_type} command")).strip() or f"{command_type} command"
    now = utc_now()
    cmd = {
        "id": "cmd_" + uuid.uuid4().hex[:12],
        "schema_version": 1,
        "type": command_type,
        "title": title,
        "description": str(body.get("description", "")),
        "risk": str(body.get("risk", "low")),
        "requires_user_approval": bool(body.get("requires_user_approval", True)),
        "status": "pending",
        "steps": body.get("steps", []),
        "payload": body.get("payload", {}),
        "created_by": created_by,
        "created_at": now,
        "updated_at": now,
        "acked_by": "",
        "acked_at": "",
        "result": "",
        "result_detail": "",
        "completed_at": "",
    }
    commands.append(cmd)
    save_commands(commands)
    append_command_event(cmd["id"], "created", cmd["status"], created_by, title)
    return cmd

def pending_commands() -> List[Dict[str, Any]]:
    return [c for c in load_commands() if c.get("status") in {"pending", "accepted"}]

def update_command(command_id: str, updates: Dict[str, Any]) -> Dict[str, Any]:
    commands = load_commands()
    for idx, cmd in enumerate(commands):
        if cmd.get("id") == command_id:
            previous_status = str(cmd.get("status", "unknown"))
            cmd.update(updates)
            cmd["updated_at"] = utc_now()
            commands[idx] = cmd
            save_commands(commands)
            next_status = str(cmd.get("status", "unknown"))
            actor = str(updates.get("acked_by") or updates.get("completed_by") or "action-phone")
            append_command_event(command_id, f"status:{previous_status}->{next_status}", next_status, actor, str(updates.get("result_detail", "")))
            return cmd
    raise KeyError(f"command not found: {command_id}")

# ---------- events ----------
def make_event(handler: BaseHTTPRequestHandler, path: str, result: str, status: int, detail: str = "") -> Dict[str, Any]:
    return {
        "event_id": "evt_" + uuid.uuid4().hex[:12],
        "time": utc_now(),
        "result": result,
        "status": status,
        "path": path,
        "client_ip": handler.client_address[0] if handler.client_address else "",
        "client_port": handler.client_address[1] if handler.client_address else None,
        "user_agent": handler.headers.get("User-Agent", ""),
        "x_swurlz_device_node_id": handler.headers.get("X-SWRLZ-Device-Node-Id", ""),
        "x_swurlz_app_version": handler.headers.get("X-SWRLZ-App-Version", ""),
        "x_swurlz_patch_label": handler.headers.get("X-SWRLZ-Patch-Label", ""),
        "detail": detail,
    }

def display_event(event: Dict[str, Any]) -> None:
    line = "-" * 58
    lines = [
        "\n" + line,
        "[SWRLZ BRIDGE CHECK-IN]",
        f"Result:      {event.get('result')}",
        f"HTTP Status: {event.get('status')}",
        f"Path:        {event.get('path')}",
        f"Client IP:   {event.get('client_ip')}:{event.get('client_port')}",
    ]
    if event.get("x_swurlz_device_node_id"): lines.append(f"Device ID:   {event.get('x_swurlz_device_node_id')}")
    if event.get("x_swurlz_app_version"): lines.append(f"App Version: {event.get('x_swurlz_app_version')}")
    if event.get("x_swurlz_patch_label"): lines.append(f"Patch:       {event.get('x_swurlz_patch_label')}")
    ua = event.get("user_agent") or ""
    if ua: lines.append(f"User-Agent:  {ua[:120]}")
    if event.get("detail"): lines.append(f"Detail:      {event.get('detail')}")
    lines.append(f"Time:        {event.get('time')}")
    lines.append(line + "\n")
    for item in lines: log_line(item)

def record_event(handler: BaseHTTPRequestHandler, path: str, result: str, status: int, detail: str = "") -> None:
    settings = load_settings()
    event = make_event(handler, path, result, status, detail)
    if settings.get("display_successful_connections", True) or result != "SUCCESS": display_event(event)
    if settings.get("store_request_events", True):
        append_jsonl(daily_request_log_path(), event)
        append_jsonl(legacy_request_events_path(), event)

# ---------- update staging ----------
def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def stage_update(url: str, expected_sha256: str = "", kind: str = "server") -> Dict[str, Any]:
    if not url: raise ValueError("update url required")
    kind = kind if kind in {"server", "client"} else "server"
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = url.rstrip('/').split('/')[-1] or f"{kind}_update_{ts}.zip"
    incoming = incoming_updates_dir() / f"{kind}_{ts}_{filename}"
    staged = staged_updates_dir() / f"{kind}_{ts}"
    req = Request(url, headers={"User-Agent": f"SWRLZLocalNode/{SERVER_VERSION}"})
    with urlopen(req, timeout=45) as response:
        data = response.read()
    incoming.write_bytes(data)
    actual = sha256_file(incoming)
    if expected_sha256 and actual.lower() != expected_sha256.lower():
        state = {"ok": False, "error": "sha256 mismatch", "expected_sha256": expected_sha256, "actual_sha256": actual, "incoming": str(incoming), "time": utc_now()}
        write_json(update_state_path(), state)
        raise ValueError(f"sha256 mismatch: expected {expected_sha256} got {actual}")
    staged.mkdir(parents=True, exist_ok=True)
    extracted = False
    if zipfile.is_zipfile(incoming):
        with zipfile.ZipFile(incoming, 'r') as z: z.extractall(staged)
        extracted = True
    report = {
        "ok": True,
        "kind": kind,
        "url": url,
        "incoming": str(incoming),
        "staged": str(staged),
        "sha256": actual,
        "zip_extracted": extracted,
        "restart_required": True,
        "hot_swap_enabled": False,
        "time": utc_now(),
        "next_step": "Stop this server, cd into the staged source folder if needed, then run python local_node_server.py. Keep current folder as rollback.",
    }
    write_json(staged / "SWRLZ_UPDATE_STAGE_REPORT.json", report)
    write_json(update_state_path(), report)
    return report

# ---------- startup / shutdown ----------
def print_startup_banner() -> None:
    ensure_data_dir()
    info = connection_info()
    settings = load_settings()
    line = "=" * 64
    for item in [
        "\n" + line,
        "SWRLZ LOCAL CORE NODE",
        line,
        f"Version: {SERVER_VERSION}",
        f"Patch:   {PATCH_LABEL}",
        f"Node:    {settings.get('node_name')}",
        f"Host:    {HOST}",
        f"Port:    {PORT}",
        f"PID:     {os.getpid()}",
        f"PID file:{pid_path()}",
        "",
        "Local URL:",
        f"  {info['local_url']}",
    ]:
        log_line(item)
    if info["lan_urls"]:
        log_line("")
        log_line("LAN URLs for SWRLZ-Core app:")
        for url in info["lan_urls"]: log_line(f"  {url}")
        log_line("")
        log_line("Status endpoints:")
        for url in info["status_urls"]: log_line(f"  {url}")
        log_line("")
        log_line("Discovery signature endpoints:")
        for url in info.get("discovery_signature_urls", []): log_line(f"  {url}")
    else:
        log_line("")
        log_line("No LAN IP detected yet. Make sure Wi-Fi/hotspot is connected.")
    log_line("")
    log_line("Admin:")
    log_line(f"  username: {ADMIN_USERNAME}")
    log_line("  password: swurlz-admin  (change after first run)")
    log_line("")
    log_line("Logs:")
    log_line(f"  Session log: {session_log_path()}")
    log_line(f"  Request log: {daily_request_log_path()}")
    log_line("")
    log_line("Updates:")
    log_line(f"  Incoming: {incoming_updates_dir()}")
    log_line(f"  Staged:   {staged_updates_dir()}")
    log_line(f"  Rollback: {rollback_updates_dir()}")
    log_line("")
    log_line("Process:")
    log_line(f"  Stop:     bash stop_local_node.sh")
    log_line(f"  Restart:  bash restart_local_node.sh")
    log_line("")
    log_line("Commands:")
    log_line(f"  Queue:    {commands_path()}")
    log_line(f"  History:  {command_events_path()}")
    log_line("  Pending:  /commands/pending")
    log_line("  Lookup:   /commands/<cmd_id>")
    log_line("  Create:   /admin/commands/create")
    log_line("")
    log_line("Group relay / offline queue:")
    log_line(f"  Groups:   {groups_path()}")
    log_line(f"  Devices:  {devices_path()}")
    log_line(f"  Queues:   {device_queues_dir()}")
    log_line("  Join:     /groups/join")
    log_line("  Check-in: /devices/checkin")
    log_line("  Packets:  /packets/create and /packets/pending")
    log_line("")
    log_line("Important:")
    log_line("  127.0.0.1 means this same device.")
    log_line("  For phone-to-phone, enter the Core Node phone LAN URL in SWRLZ-Core.")
    log_line(line + "\n")

def shutdown_log() -> None:
    try: log_line(f"SWRLZ Local Core Node stopped. Session {SESSION_ID}")
    except Exception: pass

def handle_shutdown_signal(signum: int, frame: Any) -> None:
    log_line(f"\nSWRLZ Local Core Node received signal {signum}; shutting down.")
    raise KeyboardInterrupt

class QuietThreadingHTTPServer(ThreadingHTTPServer):
    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, BrokenPipeError, TimeoutError, OSError)):
            log_line(f"[client disconnect] {client_address[0] if client_address else '?'} closed/reset connection: {exc}")
            return
        return super().handle_error(request, client_address)

class Handler(BaseHTTPRequestHandler):
    server_version = "SWRLZLocalNode/0.7.3"

    def _send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, X-SWRLZ-Device-Node-Id, X-SWRLZ-Device-Key, X-SWRLZ-Group-Id, X-SWRLZ-Group-Key, X-SWRLZ-App-Version, X-SWRLZ-Patch-Label, X-SWRLZ-Activity-State, X-SWRLZ-Current-Screen, X-SWRLZ-Client-Role")
        self.send_header("Access-Control-Max-Age", "86400")
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length <= 0: return {}
        raw = self.rfile.read(length)
        value = json.loads(raw.decode("utf-8"))
        return value if isinstance(value, dict) else {}

    def _admin_ok(self) -> bool:
        header = self.headers.get("Authorization", "")
        if verify_admin_bearer(header):
            return True
        if not header.startswith("Basic "): return False
        try:
            decoded = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
            username, password = decoded.split(":", 1)
            return verify_password(username, password)
        except Exception: return False

    def _require_admin(self) -> bool:
        if self._admin_ok(): return True
        self._send_json(401, {"ok": False, "error": "admin authentication failed"})
        return False

    def do_OPTIONS(self) -> None:
        self._send_json(200, {"ok": True, "preflight": True, "server_version": SERVER_VERSION, "patch_label": PATCH_LABEL})

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/discovery/signature":
            record_event(self, path, "SUCCESS", 200, "network discovery signature requested")
            return self._send_json(200, discovery_signature_payload())
        if path == "/discovery/manifest":
            record_event(self, path, "SUCCESS", 200, "network discovery manifest requested")
            return self._send_json(200, discovery_manifest_payload())
        if path == "/discovery/ping":
            record_event(self, path, "SUCCESS", 200, "network discovery ping requested")
            return self._send_json(200, {"ok": True, "pong": True, "server": "swrlz-local-node", "version": "0.7.3-discovery-signature", "patch": "LNS-0.7.3-DISCOVERY-SIGNATURE", "port": PORT, "time": utc_now()})
        if path == "/health":
            record_event(self, path, "SUCCESS", 200, "health check")
            return self._send_json(200, {"ok": True, "server_version": SERVER_VERSION, "created_at": utc_now()})
        if path == "/status":
            record_event(self, path, "SUCCESS", 200, "Core Node status requested")
            return self._send_json(200, status_payload())
        if path == "/connection-info":
            record_event(self, path, "SUCCESS", 200, "connection info requested")
            return self._send_json(200, connection_info())
        if path == "/admin/session/status":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin session status denied"); return
            record_event(self, path, "SUCCESS", 200, "admin session verified")
            return self._send_json(200, {"ok": True, "admin_session_active": True, "server_version": SERVER_VERSION, "patch_label": PATCH_LABEL})
        if path in {"/presence/summary", "/presence/devices", "/presence/groups"}:
            query = parse_qs(urlparse(self.path).query)
            group_id = query.get("group_id", query.get("groupId", [self.headers.get("X-SWRLZ-Group-Id", "")]))[0]
            group_key = query.get("group_key", query.get("groupKey", [self.headers.get("X-SWRLZ-Group-Key", "")]))[0]
            admin_view = self._admin_ok()
            if not admin_view:
                if group_id and not group_key_ok(group_id, group_key):
                    if load_settings().get("discovery_allow_public_presence_summary", True):
                        record_event(self, path, "SUCCESS", 200, "public discovery presence summary returned")
                        return self._send_json(200, public_presence_summary_payload(group_id))
                    record_event(self, path, "DENIED", 401, "presence group auth denied")
                    return self._send_json(401, {"ok": False, "error": "group authorization failed", "hint": "join/create the group or use admin mode"})
            payload = presence_payload(group_id=group_id, admin_view=admin_view)
            record_event(self, path, "SUCCESS", 200, f"presence index viewed mode={payload['visibility_mode']}")
            if path == "/presence/devices":
                return self._send_json(200, {"ok": True, "devices": payload["devices"], "count": len(payload["devices"]), "summary": payload["summary"]})
            if path == "/presence/groups":
                return self._send_json(200, {"ok": True, "groups": payload["groups"], "count": len(payload["groups"]), "summary": payload["summary"]})
            return self._send_json(200, payload)
        if path == "/groups/list":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "groups list denied"); return
            groups = [sanitize_group(g) for g in load_groups()]
            record_event(self, path, "SUCCESS", 200, "groups listed")
            return self._send_json(200, {"ok": True, "groups": groups, "count": len(groups)})
        if path == "/devices/online":
            query = parse_qs(urlparse(self.path).query)
            group_id = query.get("group_id", query.get("groupId", [self.headers.get("X-SWRLZ-Group-Id", "")]))[0]
            group_key = query.get("group_key", query.get("groupKey", [self.headers.get("X-SWRLZ-Group-Key", "")]))[0]
            if not group_key_ok(group_id, group_key):
                record_event(self, path, "DENIED", 401, "device online group auth denied")
                return self._send_json(401, {"ok": False, "error": "group authorization failed"})
            devices = devices_for_group(group_id, online_only=False, admin_view=False)
            record_event(self, path, "SUCCESS", 200, f"devices listed for group {safe_id(group_id, 'group')}")
            return self._send_json(200, {"ok": True, "group_id": safe_id(group_id, "group"), "devices": devices, "count": len(devices)})
        if path == "/admin/devices":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin devices denied"); return
            settings = load_settings()
            devices = presence_all_devices(admin_view=True)
            record_event(self, path, "SUCCESS", 200, "admin devices listed")
            return self._send_json(200, {"ok": True, "admin_all_devices_visible": True, "devices": devices, "count": len(devices)})
        if path.startswith("/admin/devices/") and path.count("/") == 3:
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin device inspect denied"); return
            device_id = path.split("/")[3]
            try:
                payload = inspect_device_payload(device_id)
                record_event(self, path, "SUCCESS", 200, f"admin inspected device {device_id}")
                return self._send_json(200, payload)
            except Exception as exc:
                record_event(self, path, "NOT_FOUND", 404, str(exc))
                return self._send_json(404, {"ok": False, "error": str(exc)})
        if path == "/admin/queues":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin queues denied"); return
            packets = admin_packet_records()
            record_event(self, path, "SUCCESS", 200, "admin queues listed")
            return self._send_json(200, {"ok": True, "packets": packets[:250], "count": len(packets), "summary": packet_summary()})

            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin packets denied"); return
            packets = load_all_packets()
            record_event(self, path, "SUCCESS", 200, "admin packets listed")
            return self._send_json(200, {"ok": True, "packets": packets[-200:], "count": len(packets), "summary": packet_summary()})
        if path == "/admin/ledger":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin ledger denied"); return
            record_event(self, path, "SUCCESS", 200, "admin ledger viewed")
            return self._send_json(200, {"ok": True, "devices": all_devices(admin_view=True), "groups": [sanitize_group(g) for g in load_groups()], "packets": packet_summary(), "commands": command_summary(), "recent_packet_events": tail_jsonl(packet_events_path(), 80)})
        if path == "/packets/pending":
            query = parse_qs(urlparse(self.path).query)
            device_id = query.get("device_id", query.get("deviceId", [self.headers.get("X-SWRLZ-Device-Node-Id", "")]))[0]
            group_id = query.get("group_id", query.get("groupId", [self.headers.get("X-SWRLZ-Group-Id", "")]))[0]
            device_key = query.get("device_key", query.get("deviceKey", [self.headers.get("X-SWRLZ-Device-Key", "")]))[0]
            if not device_key_ok(safe_id(device_id, "node"), device_key):
                record_event(self, path, "DENIED", 401, "packet pending device auth denied")
                return self._send_json(401, {"ok": False, "error": "device authorization failed"})
            packets = pending_packets_for_device(device_id, mark_delivered=True)
            record_event(self, path, "SUCCESS", 200, f"pending packets delivered to {safe_id(device_id, 'node')}")
            return self._send_json(200, {"ok": True, "group_id": safe_id(group_id, "group"), "device_id": safe_id(device_id, "node"), "packets": packets, "count": len(packets)})

        if path == "/admin/settings":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin settings denied"); return
            record_event(self, path, "SUCCESS", 200, "admin settings viewed")
            return self._send_json(200, {"ok": True, "settings": load_settings(), "server_identity": {"server_version": SERVER_VERSION, "roadmap": ROADMAP, "patch_label": PATCH_LABEL}})
        if path == "/admin/events/recent":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "recent events denied"); return
            record_event(self, path, "SUCCESS", 200, "recent events viewed")
            return self._send_json(200, {"ok": True, "events": get_recent_events()})
        if path == "/admin/logs/session":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "session log denied"); return
            record_event(self, path, "SUCCESS", 200, "session log viewed")
            return self._send_json(200, {"ok": True, "session_id": SESSION_ID, "path": str(session_log_path()), "lines": tail_text(session_log_path())})
        if path == "/commands/pending":
            record_event(self, path, "SUCCESS", 200, "pending commands viewed")
            return self._send_json(200, {"ok": True, "commands": pending_commands(), "count": len(pending_commands()), "server_version": SERVER_VERSION, "patch_label": PATCH_LABEL})
        if path == "/admin/commands/all":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "all commands denied"); return
            commands = load_commands()
            record_event(self, path, "SUCCESS", 200, "all commands viewed")
            return self._send_json(200, {"ok": True, "commands": commands, "count": len(commands), "summary": command_summary()})
        if path == "/admin/commands/history":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "command history denied"); return
            events = recent_command_events()
            record_event(self, path, "SUCCESS", 200, "command history viewed")
            return self._send_json(200, {"ok": True, "events": events, "count": len(events), "path": str(command_events_path())})
        if path == "/commands/recent-events":
            events = recent_command_events(25)
            record_event(self, path, "SUCCESS", 200, "command recent events viewed")
            return self._send_json(200, {"ok": True, "events": events, "count": len(events)})
        if path.startswith("/commands/") and path.count("/") == 2:
            command_id = path.split("/")[2]
            command = command_by_id(command_id)
            if command is None:
                record_event(self, path, "NOT_FOUND", 404, f"command not found {command_id}")
                return self._send_json(404, {"ok": False, "error": "command not found", "id": command_id})
            record_event(self, path, "SUCCESS", 200, f"command viewed {command_id}")
            return self._send_json(200, {"ok": True, "command": command})
        if path in {"/admin/update/status", "/admin/update/info"}:
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "update info denied"); return
            record_event(self, path, "SUCCESS", 200, "update info viewed")
            return self._send_json(200, {"ok": True, "server_identity": {"server_version": SERVER_VERSION, "roadmap": ROADMAP, "patch_label": PATCH_LABEL}, "update": update_status_payload(), "process": process_payload()})
        if path == "/admin/update/settings":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "update settings denied"); return
            settings = load_settings()
            keys = ["server_update_url", "client_update_url", "allow_pairing", "require_pairing_token", "display_successful_connections", "clean_disconnect_tracebacks", "log_level"]
            record_event(self, path, "SUCCESS", 200, "update settings viewed")
            return self._send_json(200, {"ok": True, "settings": {k: settings.get(k) for k in keys}, "update": update_status_payload()})
        record_event(self, path, "NOT_FOUND", 404, "unknown GET path")
        return self._send_json(404, {"ok": False, "error": "not found", "path": path})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try: body = self._read_json()
        except Exception:
            record_event(self, path, "BAD_REQUEST", 400, "invalid JSON body")
            return self._send_json(400, {"ok": False, "error": "invalid JSON body"})
        if path == "/admin/session/login":
            username = str(body.get("username", ADMIN_USERNAME))
            password = str(body.get("password", ""))
            if not password:
                header = self.headers.get("Authorization", "")
                if header.startswith("Basic "):
                    try:
                        decoded = base64.b64decode(header.split(" ", 1)[1]).decode("utf-8")
                        username, password = decoded.split(":", 1)
                    except Exception:
                        pass
            try:
                device_id = self.headers.get("X-SWRLZ-Device-Node-Id", str(body.get("device_id", "")))
                session = create_admin_session(username, password, device_id)
                record_event(self, path, "SUCCESS", 200, "admin session created")
                return self._send_json(200, {"ok": True, **session, "message": "admin session saved token created"})
            except PermissionError as exc:
                record_event(self, path, "DENIED", 401, str(exc))
                return self._send_json(401, {"ok": False, "error": str(exc)})
        if path == "/admin/session/revoke":
            header = self.headers.get("Authorization", "")
            token = str(body.get("admin_session_token", ""))
            if header.startswith("Bearer "):
                token = header.split(" ", 1)[1].strip()
            if token and revoke_admin_session(token):
                record_event(self, path, "SUCCESS", 200, "admin session revoked")
                return self._send_json(200, {"ok": True, "message": "admin session revoked"})
            record_event(self, path, "NOT_FOUND", 404, "admin session not found")
            return self._send_json(404, {"ok": False, "error": "admin session not found"})
        if path == "/groups/create":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "group create denied"); return
            group_id = str(body.get("group_id") or body.get("groupId") or "")
            group_key = str(body.get("group_key") or body.get("groupKey") or "")
            if not group_id or len(group_key) < 4:
                record_event(self, path, "BAD_REQUEST", 400, "group id/key required")
                return self._send_json(400, {"ok": False, "error": "group_id and group_key required; key needs at least 4 characters"})
            group = create_or_update_group(group_id, group_key, str(body.get("label", "")), "admin")
            record_event(self, path, "SUCCESS", 200, f"group created {group['group_id']}")
            return self._send_json(200, {"ok": True, "group": group, "message": "group ready"})
        if path == "/groups/join" or path == "/devices/register":
            group_id = str(body.get("group_id") or body.get("groupId") or "")
            group_key = str(body.get("group_key") or body.get("groupKey") or "")
            device_id = str(body.get("device_id") or body.get("deviceId") or self.headers.get("X-SWRLZ-Device-Node-Id", ""))
            device_label = str(body.get("device_label") or body.get("deviceLabel") or "Action Phone")
            role = str(body.get("role") or self.headers.get("X-SWRLZ-Client-Role", "Action Phone"))
            device_key = str(body.get("device_key") or body.get("deviceKey") or self.headers.get("X-SWRLZ-Device-Key", ""))
            if body.get("device_anchor_id") or body.get("deviceAnchorId"):
                self.headers["X-SWRLZ-Device-Anchor-Id"] = str(body.get("device_anchor_id") or body.get("deviceAnchorId"))
            try:
                device = register_device(group_id, group_key, device_id, device_label, role, device_key, self)
                record_event(self, path, "SUCCESS", 200, f"device registered {device['device_id']}")
                return self._send_json(200, {"ok": True, "device": device, "message": "device joined group"})
            except PermissionError as exc:
                record_event(self, path, "DENIED", 401, str(exc))
                return self._send_json(401, {"ok": False, "error": str(exc)})
        if path == "/devices/checkin":
            ctx = auth_context(self, body)
            try:
                device = checkin_device(ctx["group_id"], ctx["device_id"], ctx["device_key"], self)
                record_event(self, path, "SUCCESS", 200, f"device checkin {device['device_id']}")
                return self._send_json(200, {"ok": True, "device": device, "packets_waiting": device.get("queued_packets", 0)})
            except PermissionError as exc:
                if load_settings().get("discovery_soft_checkin_enabled", True):
                    record_event(self, path, "SUCCESS", 200, "soft discovery checkin returned")
                    return self._send_json(200, soft_checkin_payload(self, body))
                record_event(self, path, "DENIED", 401, str(exc))
                return self._send_json(401, {"ok": False, "error": str(exc)})
        if path.startswith("/admin/devices/") and path.count("/") == 4:
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin device action denied"); return
            _, _, _, device_id, action = path.split("/", 4)
            try:
                if action == "forget":
                    result = forget_device(device_id, clear_queue=bool(body.get("clear_queue", body.get("clearQueue", False))))
                    payload = {"ok": True, "action": action, **result, "devices": presence_all_devices(admin_view=True)}
                elif action == "clear-queue":
                    result = clear_queue_for_device(device_id, archive=True)
                    payload = {"ok": True, "action": action, **result, "devices": presence_all_devices(admin_view=True)}
                elif action == "force-offline":
                    device = update_device_admin_state(device_id, forced_offline=True)
                    payload = {"ok": True, "action": action, "device": device, "devices": presence_all_devices(admin_view=True)}
                elif action == "trust":
                    device = update_device_admin_state(device_id, trust_level="trusted", blocked=False)
                    payload = {"ok": True, "action": action, "device": device, "devices": presence_all_devices(admin_view=True)}
                elif action == "block":
                    device = update_device_admin_state(device_id, trust_level="blocked", blocked=True)
                    payload = {"ok": True, "action": action, "device": device, "devices": presence_all_devices(admin_view=True)}
                elif action == "reset-key":
                    new_key = "DEV-" + secrets.token_hex(8).upper()
                    device = update_device_admin_state(device_id, device_key_hash=hash_secret(new_key))
                    payload = {"ok": True, "action": action, "device": device, "new_device_key": new_key, "warning": "copy this once; it will not be shown again"}
                else:
                    raise ValueError(f"unsupported admin device action: {action}")
                record_event(self, path, "SUCCESS", 200, f"admin device action {action} {device_id}")
                return self._send_json(200, payload)
            except Exception as exc:
                record_event(self, path, "BAD_REQUEST", 400, str(exc))
                return self._send_json(400, {"ok": False, "error": str(exc)})
        if path == "/packets/create":
            try:
                ctx = authorize_group(self, body)
                from_device_id = str(body.get("from_device_id") or body.get("fromDeviceId") or ctx["device_id"] or "core-phone")
                target_mode = str(body.get("target_mode") or body.get("targetMode") or "device").lower()
                target_device_id = str(body.get("target_device_id") or body.get("targetDeviceId") or ctx["device_id"])
                packet_type = str(body.get("packet_type") or body.get("packetType") or "COMMAND")
                command_type = str(body.get("command_type") or body.get("commandType") or body.get("type") or "PING")
                title = str(body.get("title") or f"{command_type.upper()} packet")
                payload = body.get("payload", {}) if isinstance(body.get("payload", {}), dict) else {}
                ttl = body.get("ttl_minutes") or body.get("ttlMinutes")
                ttl_int = int(ttl) if ttl not in (None, "") else None
                packets: List[Dict[str, Any]] = []
                if target_mode == "self":
                    target_device_id = ctx["device_id"]
                    packets.append(create_packet_for_device(ctx["group_id"], from_device_id, target_device_id, packet_type, command_type, title, payload, True, ttl_int))
                elif target_mode == "group":
                    targets = [d.get("device_id", "") for d in devices_for_group(ctx["group_id"], online_only=False)]
                    targets = [t for t in targets if t]
                    for target in targets:
                        packets.append(create_packet_for_device(ctx["group_id"], from_device_id, str(target), packet_type, command_type, title, payload, True, ttl_int))
                else:
                    packets.append(create_packet_for_device(ctx["group_id"], from_device_id, target_device_id, packet_type, command_type, title, payload, True, ttl_int))
                record_event(self, path, "SUCCESS", 200, f"packets queued {len(packets)}")
                return self._send_json(200, {"ok": True, "packets": packets, "count": len(packets), "message": "packet queued"})
            except PermissionError as exc:
                record_event(self, path, "DENIED", 401, str(exc))
                return self._send_json(401, {"ok": False, "error": str(exc)})
            except Exception as exc:
                record_event(self, path, "BAD_REQUEST", 400, str(exc))
                return self._send_json(400, {"ok": False, "error": str(exc)})
        if path.startswith("/packets/") and path.count("/") == 2:
            packet_id = path.split("/")[2]
            ctx = auth_context(self, body)
            desired = str(body.get("status") or body.get("receipt") or "DISPLAYED").upper()
            if desired not in {"DISPLAYED", "ACKNOWLEDGED", "REJECTED", "COMPLETED", "FAILED", "BLOCKED"}:
                desired = "DISPLAYED"
            try:
                packet = update_packet(packet_id, ctx["device_id"], desired, str(body.get("detail", "")))
                record_event(self, path, "SUCCESS", 200, f"packet {desired} {packet_id}")
                return self._send_json(200, {"ok": True, "packet": packet, "message": f"packet {desired.lower()}"})
            except Exception as exc:
                record_event(self, path, "NOT_FOUND", 404, str(exc))
                return self._send_json(404, {"ok": False, "error": str(exc)})
        if path == "/admin/settings":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "admin settings update denied"); return
            settings = load_settings()
            allowed = {"node_name", "server_update_url", "client_update_url", "allow_pairing", "require_pairing_token", "pairing_token_hint", "log_level", "display_successful_connections", "store_request_events", "session_logging_enabled", "clean_disconnect_tracebacks", "command_queue_enabled", "command_user_approval_required", "command_history_enabled", "command_event_limit", "group_relay_enabled", "offline_packet_queue_enabled", "admin_saved_sessions_enabled", "admin_all_devices_visible", "device_online_window_seconds", "default_packet_ttl_minutes", "presence_index_enabled", "presence_idle_window_seconds", "presence_offline_window_seconds", "presence_stale_window_seconds", "device_ledger_admin_enabled"}
            for key, value in body.items():
                if key in allowed: settings[key] = value
            save_settings(settings)
            record_event(self, path, "SUCCESS", 200, "admin settings updated")
            return self._send_json(200, {"ok": True, "settings": settings, "updated_at": utc_now()})
        if path == "/admin/password":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "password update denied"); return
            new_password = str(body.get("new_password", ""))
            if len(new_password) < 8:
                record_event(self, path, "BAD_REQUEST", 400, "password too short")
                return self._send_json(400, {"ok": False, "error": "new_password must be at least 8 characters"})
            set_admin_password(new_password)
            record_event(self, path, "SUCCESS", 200, "admin password updated")
            return self._send_json(200, {"ok": True, "message": "admin password updated", "updated_at": utc_now()})
        if path == "/admin/commands/create":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "command create denied"); return
            if not load_settings().get("command_queue_enabled", True):
                record_event(self, path, "DENIED", 403, "command queue disabled")
                return self._send_json(403, {"ok": False, "error": "command queue disabled"})
            command = create_command(body)
            record_event(self, path, "SUCCESS", 200, f"command created {command['id']}")
            return self._send_json(200, {"ok": True, "command": command, "message": "command created"})
        if path.startswith("/commands/") and path.endswith("/ack"):
            command_id = path.split("/")[2] if len(path.split("/")) >= 4 else ""
            decision = str(body.get("decision", "accepted")).lower()
            if decision not in {"accepted", "rejected"}: decision = "accepted"
            try:
                device = self.headers.get("X-SWRLZ-Device-Node-Id", "action-phone")
                updated = update_command(command_id, {"status": decision, "acked_by": device, "acked_at": utc_now()})
                record_event(self, path, "SUCCESS", 200, f"command {decision} {command_id}")
                return self._send_json(200, {"ok": True, "command": updated, "message": f"command {decision}"})
            except KeyError as exc:
                record_event(self, path, "NOT_FOUND", 404, str(exc))
                return self._send_json(404, {"ok": False, "error": str(exc)})
        if path.startswith("/commands/") and path.endswith("/result"):
            command_id = path.split("/")[2] if len(path.split("/")) >= 4 else ""
            result = str(body.get("result", "completed")).lower()
            if result not in {"completed", "failed", "blocked"}: result = "completed"
            try:
                device = self.headers.get("X-SWRLZ-Device-Node-Id", "action-phone")
                updated = update_command(command_id, {"status": result, "result": result, "result_detail": str(body.get("detail", "")), "completed_by": device, "completed_at": utc_now()})
                record_event(self, path, "SUCCESS", 200, f"command result {result} {command_id}")
                return self._send_json(200, {"ok": True, "command": updated, "message": f"command {result}"})
            except KeyError as exc:
                record_event(self, path, "NOT_FOUND", 404, str(exc))
                return self._send_json(404, {"ok": False, "error": str(exc)})
        if path == "/admin/update/settings":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "update settings denied"); return
            settings = load_settings()
            allowed = {"server_update_url", "client_update_url", "allow_pairing", "require_pairing_token", "display_successful_connections", "clean_disconnect_tracebacks", "log_level"}
            for key, value in body.items():
                if key in allowed: settings[key] = value
            save_settings(settings)
            record_event(self, path, "SUCCESS", 200, "update settings saved")
            return self._send_json(200, {"ok": True, "settings": {k: settings.get(k) for k in allowed}, "update": update_status_payload(), "updated_at": utc_now()})
        if path == "/admin/update/stage":
            if not self._require_admin(): record_event(self, path, "DENIED", 401, "update stage denied"); return
            try:
                settings = load_settings()
                kind = str(body.get("kind", "server"))
                url = str(body.get("url", "")).strip()
                if not url:
                    url = str(settings.get("server_update_url" if kind != "client" else "client_update_url", "")).strip()
                expected = str(body.get("sha256", "")).strip()
                report = stage_update(url, expected, kind)
                record_event(self, path, "SUCCESS", 200, f"staged {kind} update")
                return self._send_json(200, report)
            except Exception as exc:
                record_event(self, path, "ERROR", 500, f"update stage failed: {exc}")
                return self._send_json(500, {"ok": False, "error": str(exc)})
        if path == "/pair":
            settings = load_settings()
            if not settings.get("allow_pairing", True): record_event(self, path, "DENIED", 403, "pairing disabled"); return self._send_json(403, {"ok": False, "error": "pairing disabled"})
            token = str(body.get("pairingToken", ""))
            expected = str(settings.get("pairing_token_hint", "set-on-node"))
            if settings.get("require_pairing_token", True):
                if not token: record_event(self, path, "DENIED", 401, "pairing token required"); return self._send_json(401, {"ok": False, "error": "pairing token required"})
                if expected not in ("", "set-on-node") and not hmac.compare_digest(token, expected): record_event(self, path, "DENIED", 401, "pairing token rejected"); return self._send_json(401, {"ok": False, "error": "pairing token rejected"})
            device_id = str(body.get("deviceNodeId", "")).strip()
            if len(device_id) < 3: record_event(self, path, "BAD_REQUEST", 400, "deviceNodeId required"); return self._send_json(400, {"ok": False, "error": "deviceNodeId required"})
            devices = read_json(paired_devices_path(), [])
            if not isinstance(devices, list): devices = []
            record = {"deviceNodeId": device_id, "deviceLabel": str(body.get("deviceLabel", "Action Phone")), "appVersion": str(body.get("appVersion", "")), "trustLevel": "paired-action-node", "pairedAt": utc_now()}
            devices = [d for d in devices if d.get("deviceNodeId") != device_id]
            devices.append(record)
            write_json(paired_devices_path(), devices)
            record_event(self, path, "SUCCESS", 200, f"paired device {device_id}")
            return self._send_json(200, {"ok": True, "paired": True, "deviceId": device_id, "trustLevel": "paired-action-node", "message": "Device paired"})
        record_event(self, path, "NOT_FOUND", 404, "unknown POST path")
        return self._send_json(404, {"ok": False, "error": "not found", "path": path})

    def log_message(self, fmt: str, *args: Any) -> None:
        return

def main() -> None:
    ensure_data_dir()
    if port_looks_busy():
        print_port_busy_help()
        raise SystemExit(98)
    write_pid_file()
    atexit.register(remove_pid_file)
    atexit.register(shutdown_log)
    signal.signal(signal.SIGTERM, handle_shutdown_signal)
    signal.signal(signal.SIGINT, handle_shutdown_signal)
    print_startup_banner()
    try:
        httpd = QuietThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print_port_busy_help()
        raise SystemExit(98) from exc
    try: httpd.serve_forever()
    except KeyboardInterrupt:
        log_line("\nSWRLZ Local Core Node shutting down.")
    finally:
        httpd.server_close()
        remove_pid_file()

if __name__ == "__main__":
    main()
