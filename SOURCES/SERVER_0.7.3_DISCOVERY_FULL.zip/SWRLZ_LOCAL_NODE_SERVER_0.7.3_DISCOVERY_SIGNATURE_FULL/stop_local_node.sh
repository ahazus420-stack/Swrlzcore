#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DATA_DIR="${SWRLZ_NODE_DATA_DIR:-swrlz_node_data}"
PID_FILE="$DATA_DIR/local_node.pid"
if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE" | tr -dc '0-9')"
  if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
    echo "Stopping SWRLZ Local Core Node PID $PID"
    kill "$PID" 2>/dev/null || true
    for _ in 1 2 3 4 5; do
      kill -0 "$PID" 2>/dev/null || break
      sleep 1
    done
    if kill -0 "$PID" 2>/dev/null; then
      echo "PID $PID still alive; sending stronger stop"
      kill -9 "$PID" 2>/dev/null || true
    fi
  else
    echo "PID file exists but process is not running: $PID_FILE"
  fi
  rm -f "$PID_FILE"
else
  echo "No PID file found. Trying fallback pkill for local_node_server.py"
  pkill -f "local_node_server.py" 2>/dev/null || true
fi
echo "SWRLZ Local Core Node stop command complete."
