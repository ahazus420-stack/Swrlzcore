# SWRLZ Local Node Server Roadmap — Revision 0.4

## Current verified state

- 0.1 Admin status server: built.
- 0.2 Connection observer: field tested with browser and SWRLZ app.
- 0.3 Session logs + update staging: field tested through SWRLZ-Core app.
- 0.4 Command queue: source patch created.

## 0.4 Command Queue goals

- [x] Persistent command queue file.
- [x] Admin command creation endpoint.
- [x] Pending command endpoint for Action Phone.
- [x] Command ack/reject endpoint.
- [x] Command result endpoint.
- [x] Command capability advertised in `/status`.
- [x] Recent event dedupe.

## Next: 0.5 Action Proposals

- [ ] Rich command proposal schema.
- [ ] Risk level and safety gate enforcement.
- [ ] Pairing-token enforcement for command endpoints.
- [ ] Device-specific command targeting.
- [ ] Teach-packet receiver.
- [ ] Update manager finalize/restart helper.

