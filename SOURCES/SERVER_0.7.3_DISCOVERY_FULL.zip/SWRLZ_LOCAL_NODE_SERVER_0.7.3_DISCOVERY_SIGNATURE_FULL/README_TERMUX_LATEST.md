# SWRLZ Local Core Node — Termux Latest 0.6

## What this server does

This is the lightweight, Termux-safe Local Core Node server. It lets SWRLZ-Core connect over local Wi-Fi/hotspot and exchange status, admin settings, logs, update info, and safe command queue messages.

## Start it

```bash
cd ~/swurlz/SWRLZ_LOCAL_NODE_SERVER_0.6_PROCESS_CONTROL_SOURCE
bash run_local_node.sh
```

Or:

```bash
python local_node_server.py
```

## Stop / restart it

```bash
bash stop_local_node.sh
bash restart_local_node.sh
```

The server writes a PID file here:

```text
swrlz_node_data/local_node.pid
```

## Address already in use

If you see:

```text
OSError: [Errno 98] Address already in use
```

run:

```bash
bash stop_local_node.sh
bash run_local_node.sh
```

Fallback:

```bash
pkill -f local_node_server.py
```

## What URL to put in the SWRLZ-Core app

Use the LAN URL printed by the server, for example:

```text
http://192.168.1.177:8787
```

Do not use `127.0.0.1` when the app is on a different phone. `127.0.0.1` means the same device.

## Main endpoints

```text
/status
/connection-info
/commands/pending
/commands/<cmd_id>
/commands/recent-events
/admin/settings
/admin/events/recent
/admin/logs/session
/admin/commands/all
/admin/commands/history
/admin/commands/create
/admin/update/info
/admin/update/settings
/admin/update/stage
```

## Admin defaults

```text
username: admin
password: swurlz-admin
```

Change the password after first-run testing.

## Logs and command files

```text
swrlz_node_data/logs/
swrlz_node_data/commands/commands.json
swrlz_node_data/commands/command_events.jsonl
swrlz_node_data/updates/
swrlz_node_data/local_node.pid
```

## Manual update flow

1. Download update ZIP.
2. Verify SHA-256.
3. Stage ZIP in `swrlz_node_data/updates/staged`.
4. Stop server with `bash stop_local_node.sh`.
5. Extract new source while preserving `swrlz_node_data`.
6. Start server with `bash run_local_node.sh`.

This server intentionally uses only the Python standard library to avoid Termux dependency failures like pydantic-core / Rust / FastAPI build issues.


Latest presence/radar docs: `README_LATEST_0.7.1.md` and `SWRLZ_LOCAL_NODE_SERVER_0.7.1_PRESENCE_INDEX_PATCH_REPORT.md`.
