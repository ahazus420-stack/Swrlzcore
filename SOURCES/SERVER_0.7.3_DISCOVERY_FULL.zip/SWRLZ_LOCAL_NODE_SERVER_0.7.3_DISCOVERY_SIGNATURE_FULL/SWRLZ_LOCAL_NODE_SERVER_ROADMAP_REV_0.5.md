# SWRLZ Local Node Server Roadmap Rev 0.5 — Command History

## Current server milestone

The Local Core Node is now a working command queue with lifecycle history.

## Completed

- [x] Termux-safe no-dependency server.
- [x] `/status` local bridge endpoint.
- [x] LAN URL display on startup.
- [x] Admin username/password mode.
- [x] Persistent settings.
- [x] Recent events.
- [x] Session logs.
- [x] Update URL staging directories.
- [x] Command creation.
- [x] Pending command pull.
- [x] ACK/REJECT command response.
- [x] COMPLETE/FAILED/BLOCKED command result.
- [x] Command lifecycle history log.
- [x] Command lookup by ID.

## Next server target: 0.6

Recommended next server update:

- Command expiration / TTL.
- Command filters: pending, accepted, completed, failed.
- Safer admin password change endpoint UI integration.
- Server restart helper script.
- Update staging with automatic rollback manifest.
- Optional local web dashboard.
