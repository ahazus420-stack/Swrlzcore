# SWRLZ Local Node Server 0.2 Connection Observer Patch Report

## Adds

- Visible successful connection display in Termux.
- Client IP and port display.
- Request path display.
- User-Agent display.
- Optional SWRLZ device headers if future Android app sends them.
- Persistent request event log at `swrlz_node_data/request_events.jsonl`.
- Admin endpoint `/admin/events/recent`.

## Still needs future Android app patch

The current Android app only calls `/status`. Full Android device identity in the server console requires the app to send headers such as:

```text
X-SWRLZ-Device-Node-Id
X-SWRLZ-App-Version
```

Until then, the server can display client IP/port/User-Agent and successful status check events.
