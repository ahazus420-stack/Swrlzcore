# SWRLZ Local Node Server 0.7 Group Relay Ledger Patch Report

## Patch purpose
Add persistent group/device relay identity, saved admin session tokens, and offline packet queues.

## Added
- Admin bearer session token login/status/revoke.
- Group create/list/join support.
- Device register/check-in/online list support.
- Offline packet queues by target device.
- Packet lifecycle state machine.
- Packet event and receipt JSONL ledgers.
- Admin ledger endpoint.

## Smoke test results
Passed:
- status
- admin session login
- group create
- device join
- queue packet
- check-in shows packet waiting
- pending pull marks delivered
- packet completion receipt
- admin ledger
