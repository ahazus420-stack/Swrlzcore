# SWRLZ Local Node Server 0.7 — Group Relay Ledger

Group Relay Ledger is the server architecture upgrade for SWRLZ two-phone and multi-device communication.

## What it does

- Saves admin sessions as bearer-token hashes.
- Registers groups using Group ID + Group Key.
- Registers devices using Device ID + Device Key.
- Tracks online/offline devices through check-ins.
- Queues packets for offline devices.
- Delivers queued packets when devices reconnect and pull their queue.
- Records packet lifecycle events and receipts.

## Start

```bash
bash run_local_node.sh
```

## Useful endpoints

```text
/status
/admin/session/login
/groups/create
/groups/join
/devices/checkin
/devices/online
/packets/create
/packets/pending
/admin/ledger
```

## Safety

Offline packets are queued only. They do not execute invisibly. The client displays packet cards and the user approves/rejects/completes manually.
