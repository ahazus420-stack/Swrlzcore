# SWRLZ Local Node Server 0.6 Test Checklist

1. Start server:

```bash
bash run_local_node.sh
```

2. Confirm startup banner shows:

- version `local-node-server-0.6-process-control`
- patch `LNS-0.6-PROCESS-CONTROL`
- PID
- PID file
- local URL
- LAN URL if network is available

3. Confirm PID file exists:

```bash
cat swrlz_node_data/local_node.pid
```

4. Confirm `/status` works in browser:

```text
http://127.0.0.1:8787/status
```

5. In SWRLZ-Core app, save Core Node URL and test status.

6. Create safe PING command from app.

7. Pull pending command card.

8. ACK command.

9. COMPLETE command.

10. Confirm command history exists:

```bash
tail -n 20 swrlz_node_data/commands/command_events.jsonl
```

11. Stop server:

```bash
bash stop_local_node.sh
```

12. Restart server:

```bash
bash restart_local_node.sh
```

13. Confirm old commands/logs remain under `swrlz_node_data`.
