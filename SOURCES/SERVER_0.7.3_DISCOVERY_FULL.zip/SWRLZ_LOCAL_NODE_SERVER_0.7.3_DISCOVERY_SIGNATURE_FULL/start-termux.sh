#!/usr/bin/env bash
set -euo pipefail
termux-wake-lock 2>/dev/null || true
export SWRLZ_NODE_HOST="${SWRLZ_NODE_HOST:-0.0.0.0}"
export SWRLZ_NODE_PORT="${SWRLZ_NODE_PORT:-8787}"
cd "$(dirname "$0")"
echo "Starting SWRLZ Local Node Server 0.7.3 Discovery Signature Full"
echo "Host: $SWRLZ_NODE_HOST"
echo "Port: $SWRLZ_NODE_PORT"
python local_node_server.py
