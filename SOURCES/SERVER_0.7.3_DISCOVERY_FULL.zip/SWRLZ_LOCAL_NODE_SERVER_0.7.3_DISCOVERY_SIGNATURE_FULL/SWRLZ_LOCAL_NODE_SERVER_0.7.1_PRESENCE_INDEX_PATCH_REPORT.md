# Local Node Server 0.7.1 Patch Report — Presence Index

## Added

- `/presence/summary` for Relay Radar dashboard data.
- `/presence/devices` for list-friendly device data.
- `/presence/groups` for list-friendly group data.
- Per-device `online_state`: online / idle / offline / unknown.
- `last_seen_seconds` for display logic.
- Group summaries with member count, online count, idle count, offline count, queued count, and status.
- Presence capability flags in `/status`.

## Preserved

- 0.7 group relay ledger.
- Offline packet queue.
- Admin saved sessions.
- Command queue/history.
- Termux process-control scripts.

## Compatibility

SWRLZ-Core 2.7.1 Relay Radar works best with this server version.
