#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash stop_local_node.sh
sleep 1
bash run_local_node.sh
