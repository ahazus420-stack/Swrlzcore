# SWRLZ Local Node Server 0.7 Phone Test Checklist

## Start server
```bash
bash run_local_node.sh
```

## Confirm status
Open:
```text
http://127.0.0.1:8787/status
```

Confirm:
```text
server_version = local-node-server-0.7-group-relay-ledger
capabilities.group_relay = true
capabilities.offline_packet_queue = true
capabilities.admin_saved_sessions = true
```

## App test
- Activate admin from SWRLZ-Core 2.7.
- Create group.
- Join device.
- Check in.
- Send packet to self.
- Pull queue.
- Complete packet.
- View admin ledger.

## Two-phone test
- Run server on Core Node phone.
- Put LAN URL into Action Phone.
- Join both devices to same group.
- Send packet from Core Phone to Action Phone.
- Pull queue from Action Phone.
- Complete packet.
