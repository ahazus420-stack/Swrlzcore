# SWRLZ-Core Android Client

Latest patch: **2.7.6 — Network Discovery**.

See `README_LATEST_2.7.6.md`, `SWRLZ_CORE_2.7.6_NETWORK_DISCOVERY_PATCH_REPORT.md`, and `SWRLZ_CORE_2.7.6_PHONE_TEST_CHECKLIST.md`.

## Current app identity

- Version: `0.2.7.6-codefix3-scan-trim`
- Code: `17`
- Patch: `2.7.6-NETWORK-DISCOVERY`
- Roadmap: `2.7.6`

## Current server pair

- Local Node Server: `0.7.1 Presence Index`

## Project law

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Preserve local data and taught skills.
- Keep Mentor backend and Local Core Node separate.
- Status colors remain semantic; themes may not lie about operational state.


## 2.7.6-CODEFIX3-DISCOVERY-SCAN-TRIM

- Source: `SRC_2.7.6_CF3_SCAN_TRIM.zip`
- Objective: trim discovery scan overhead by skipping `127.0.0.x` range sweeps by default, while keeping a saved debug toggle for unusual loopback testing.
- Output naming convention: `SRC_` for source, `SHA_` for hashes, `REPORT_` for patch notes, `APK_` for APKs, and `BUNDLE_` for APK download bundles.
