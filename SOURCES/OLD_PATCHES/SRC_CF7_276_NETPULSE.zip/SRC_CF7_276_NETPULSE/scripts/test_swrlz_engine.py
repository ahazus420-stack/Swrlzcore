#!/usr/bin/env python3
"""
Run SWRLZ-Core engine-first local tests using JSON fixtures.

Usage:
  python3 scripts/test_swrlz_engine.py --root .
  python3 scripts/test_swrlz_engine.py --root . --write-report tests/ENGINE_TEST_LAST_RUN.md
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
from pathlib import Path
import sys

from swrlz_engine_core import (
    validate_approval_router,
    validate_device_registry,
    validate_packets,
    validate_state_transitions,
    validate_workaround_cycling,
)


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="Project root containing tests/fixtures")
    parser.add_argument("--write-report", default="", help="Optional markdown report path to write")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    fixtures = root / "tests" / "fixtures"

    devices = load_json(fixtures / "mock_devices.json")
    missions = load_json(fixtures / "mock_missions.json")
    approvals = load_json(fixtures / "mock_approvals.json")
    lineage = load_json(fixtures / "mock_ghost_lineage.json")

    # Merge lineage cases into registry validation so ghost/retired links are tested together.
    registry_devices = devices["devices"] + lineage["devices"]
    packets = missions["packets"]

    checks = [
        ("Device Registry + Ghost Lineage", validate_device_registry(registry_devices)),
        ("Mission Queue State Transitions", validate_state_transitions(missions["missions"])),
        ("Packet Format", validate_packets(packets)),
        ("Approval Router", validate_approval_router(packets, approvals["approvals"])),
        ("Workaround Cycling", validate_workaround_cycling(missions["workaround_scenarios"])),
    ]

    lines = []
    all_ok = True
    for name, (ok, messages) in checks:
        status = "PASS" if ok else "FAIL"
        all_ok = all_ok and ok
        lines.append(f"## {name}: {status}")
        lines.extend(f"- {m}" for m in messages)
        lines.append("")

    summary = "PASS" if all_ok else "FAIL"
    header = [
        "# SWRLZ Engine Test Run",
        "",
        f"- Result: `{summary}`",
        f"- Tested at UTC: `{_dt.datetime.utcnow().replace(microsecond=0).isoformat()}Z`",
        "- Scope: source-level + logic simulated",
        "- Android runtime: not used",
        "",
    ]
    report = "\n".join(header + lines)
    print(report)

    if args.write_report:
        out = root / args.write_report
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(report + "\n", encoding="utf-8")

    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
