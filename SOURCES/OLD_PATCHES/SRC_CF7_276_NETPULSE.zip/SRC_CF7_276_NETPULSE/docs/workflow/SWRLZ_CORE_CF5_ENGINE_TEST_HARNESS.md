# SWRLZ-Core CF5 Engine Test Harness

## Purpose

CF5 is the first source update to apply the Engine-First Testing Standard inside the source tree.

The goal is to let SWRLZ/assistant validate pure logic through command-line scripts before Adam spends time building, installing, and testing the APK on Android.

## Added command-testable areas

- Device Registry validation
- Ghost / retired device lineage validation
- Mission Queue state transition validation
- Approval Router simulation
- Workaround Cycling simulation
- Packet / Message Format validation
- Build request naming validation

## Primary command

```bash
python3 scripts/test_swrlz_engine.py --root . --write-report tests/ENGINE_TEST_LAST_RUN.md
```

## Build request validation command

```bash
python3 scripts/validate_build_request.py --root . --file tests/fixtures/build_request_cf5.request --allow-missing
```

## Testing boundary

CF5 does not prove Android UI, permissions, Accessibility Service, install-over-old signing behavior, notifications, or real device hardware/runtime behavior. Those remain Adam's field-test lane.
