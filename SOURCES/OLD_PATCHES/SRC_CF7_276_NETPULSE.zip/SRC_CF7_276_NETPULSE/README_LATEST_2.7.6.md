# SWRLZ-Core 2.7.6 CF6 Boot-Sync

CF6 adds Home/app-launch Core Node boot-sync, server truth testing, and lifecycle-based permission refresh.

Source: `SRC_CF6_276_BOOTSYNC.zip`
Patch: `2.7.6-CF6-BOOTSYNC-PERMISSION-REFRESH`
Version: `0.2.7.6-cf6-bootsync`
Version code: `28`

Field goal: open the app, auto-connect to the local node when available, and refresh both permission cards after returning from Android settings without requiring manual refresh.
