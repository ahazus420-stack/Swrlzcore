# SWRLZ-Core 2.7.6-NETWORK-DISCOVERY

Roadmap: 2.7.6

## Build identity

- versionName: `0.2.7.6-network-discovery`
- versionCode: `22`
- Patch: `2.7.6-NETWORK-DISCOVERY`
- Build line: `Network Discovery / discovery signature / local node scan / saved server verify / Admin Registry bridge`
- Source: `SWRLZ_CORE_2.7.6_NETWORK_DISCOVERY_SOURCE.zip`

## Main change

Adds visible **Network Discovery** to the app:

- top tab: Network
- Home button: Network Discovery
- More drawer entry: Network Discovery
- `/discovery/signature` tester
- local candidate scan
- save verified node URL into Core Node config

## Law

No invisible patches. No mystery APKs. Integrate, do not overwrite.
