package sh.swurlz.core.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.model.CoreNodeConfig
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.util.Collections
import java.util.Locale

@Composable
fun NetworkDiscoveryScreen(
    onOpenSetup: () -> Unit,
    onOpenCore: () -> Unit,
) {
    val ctx = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    var nodeUrl by remember { mutableStateOf("http://127.0.0.1:8787") }
    var token by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("Standing by. Tap TEST SIGNATURE to probe /discovery/signature.") }
    var foundUrl by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val saved = Prefs.coreNodeConfig(ctx)
        if (saved.nodeUrl.isNotBlank()) nodeUrl = saved.nodeUrl
        token = saved.pairingToken
    }

    fun test(url: String) {
        scope.launch {
            result = "Probing ${normalizeBaseUrl(url)}/discovery/signature …"
            val probe = withContext(Dispatchers.IO) { probeSignature(url) }
            result = probe
            if (probe.startsWith("VALID SWRLZ NODE")) foundUrl = normalizeBaseUrl(url)
        }
    }

    fun scanCandidates() {
        scope.launch {
            val typedNow = normalizeBaseUrl(nodeUrl)
            val savedNow = withContext(Dispatchers.IO) { Prefs.coreNodeConfig(ctx).nodeUrl }
            val candidates = withContext(Dispatchers.IO) { candidateUrls(primary = typedNow, saved = savedNow) }
            val preview = candidates.take(18).joinToString("\n")
            result = "Scanning port 8787 on local subnet.\n" +
                "Typed/saved URLs are tried first, then this device's LAN prefix is swept as x.x.x.1-254.\n\n" +
                "First candidates:\n$preview" +
                if (candidates.size > 18) "\n… ${candidates.size - 18} more" else ""

            val scan = withContext(Dispatchers.IO) { scanForValidNode(candidates) }
            if (scan.foundUrl.isNotBlank()) {
                foundUrl = scan.foundUrl
                nodeUrl = foundUrl
                result = "FOUND\n${scan.probe}\n\nScanned ${scan.tried.size} candidate(s)."
                return@launch
            }
            result = "No valid SWRLZ node found on the current local subnet.\n\n" +
                "Current field tried first:\n$typedNow\n\n" +
                "Scanned ${scan.tried.size} candidate(s):\n" + scan.tried.joinToString("\n")
        }
    }

    fun save() {
        scope.launch {
            val normalized = normalizeBaseUrl(foundUrl.ifBlank { nodeUrl })
            Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(nodeUrl = normalized, pairingToken = token))
            result = "Saved Core Node URL:\n$normalized\n\nNext: open Core Admin or Radar and refresh."
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
    ) {
        Text("▸ NETWORK DISCOVERY", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Find, verify, save, and reuse a local SWRLZ node without manual IP hunting.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(12.dp))

        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.selected).background(tokens.cards.bg).padding(12.dp)) {
            Text("BUILD IDENTITY", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Version: v${BuildConfig.VERSION_NAME} · code ${BuildConfig.VERSION_CODE}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Patch: ${BuildConfig.PATCH_LABEL}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Roadmap: ${BuildConfig.ROADMAP_REVISION}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Source: ${BuildConfig.SOURCE_ZIP}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = nodeUrl,
            onValueChange = { nodeUrl = it },
            label = { Text("Node URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Pairing token / API token, optional") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("TEST SIGNATURE", onClick = { test(nodeUrl) })
            DiscoveryButton("SCAN LOCAL", onClick = { scanCandidates() })
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("SAVE NODE", onClick = { save() })
            DiscoveryButton("OPEN CORE ADMIN", onClick = onOpenCore)
        }
        Spacer(Modifier.height(8.dp))
        DiscoveryButton("OPEN SETUP", onClick = onOpenSetup)

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
            Text("DISCOVERY RESULT", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(result, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 16.sp)
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.info).background(tokens.cards.bg).padding(12.dp)) {
            Text("EXPECTED SIGNATURE", color = tokens.status.info, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "GET /discovery/signature\n\n{\"ok\":true,\"server\":\"swrlz-local-node\",\"version\":\"0.7.3-discovery-signature\",\"patch\":\"LNS-0.7.3-DISCOVERY-SIGNATURE\",\"port\":8787}",
                color = tokens.text.secondary,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                lineHeight = 15.sp,
            )
        }
    }
}

@Composable
private fun DiscoveryButton(label: String, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.accents.primary, containerColor = tokens.buttons.ghostBg),
        border = BorderStroke(1.dp, tokens.accents.primary),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp),
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
    }
}

private data class DiscoveryScanResult(
    val foundUrl: String = "",
    val probe: String = "",
    val tried: List<String> = emptyList(),
)

private suspend fun scanForValidNode(
    candidates: List<String>,
    timeoutMs: Int = 650,
    batchSize: Int = 32,
): DiscoveryScanResult {
    val tried = mutableListOf<String>()
    for (batch in candidates.chunked(batchSize)) {
        val results = coroutineScope {
            batch.map { candidate ->
                async { candidate to probeSignature(candidate, timeoutMs = timeoutMs) }
            }.awaitAll()
        }
        tried += batch
        val hit = results.firstOrNull { (_, probe) -> probe.startsWith("VALID SWRLZ NODE") }
        if (hit != null) {
            return DiscoveryScanResult(
                foundUrl = normalizeBaseUrl(hit.first),
                probe = hit.second,
                tried = tried.toList(),
            )
        }
    }
    return DiscoveryScanResult(tried = tried.toList())
}

private fun candidateUrls(primary: String, saved: String = ""): List<String> {
    val normalizedPrimary = normalizeBaseUrl(primary)
    val normalizedSaved = normalizeBaseUrl(saved)
    val candidates = mutableListOf<String>()

    // Manual / proxy / hosted server path stays sovereign: if the user typed it,
    // try it before local scanning.
    if (normalizedPrimary.isNotBlank()) candidates += normalizedPrimary
    if (normalizedSaved.isNotBlank()) candidates += normalizedSaved

    val port = firstUsablePort(normalizedPrimary, normalizedSaved, defaultPort = 8787)

    // Infer from typed or saved IP first. This handles cases where the user typed
    // http://10.24.230.21:8787 and wants the app to sweep 10.24.230.1-254.
    candidates += inferredSubnetSweepCandidates(normalizedPrimary, port)
    candidates += inferredSubnetSweepCandidates(normalizedSaved, port)

    // Then derive the LAN prefix from this Android device's current interface.
    // Hotspot might be 10.x.x.x, shelter Wi-Fi might be 192.168.1.x, etc.
    localIpv4Addresses().forEach { ip ->
        candidates += subnetSweepCandidatesFromIpv4(ip, port)
    }

    // Keep old fast defaults as fallbacks only.
    candidates += listOf(
        "http://127.0.0.1:$port",
        "http://localhost:$port",
        "http://10.0.2.2:$port",
        "http://192.168.0.1:$port",
        "http://192.168.1.1:$port",
        "http://192.168.4.1:$port",
    )
    return candidates.map { normalizeBaseUrl(it) }.filter { it.isNotBlank() }.distinct()
}

private fun firstUsablePort(vararg urls: String, defaultPort: Int): Int {
    urls.forEach { url ->
        try {
            val parsed = URL(normalizeBaseUrl(url))
            if (parsed.port in 1..65535) return parsed.port
        } catch (_: Throwable) {
            // Try next candidate.
        }
    }
    return defaultPort
}

private fun inferredSubnetSweepCandidates(baseUrl: String, fallbackPort: Int): List<String> {
    if (baseUrl.isBlank()) return emptyList()
    return try {
        val parsed = URL(normalizeBaseUrl(baseUrl))
        val host = parsed.host ?: return emptyList()
        val port = if (parsed.port > 0) parsed.port else fallbackPort
        subnetSweepCandidatesFromIpv4(host, port)
    } catch (_: Throwable) {
        emptyList()
    }
}

private fun subnetSweepCandidatesFromIpv4(ipv4: String, port: Int): List<String> {
    val parts = ipv4.split('.')
    if (parts.size != 4 || parts.any { it.toIntOrNull() !in 0..255 }) return emptyList()
    val prefix = parts.take(3).joinToString(".")
    return (1..254).map { last -> "http://$prefix.$last:$port" }
}

private fun localIpv4Addresses(): List<String> {
    return try {
        Collections.list(NetworkInterface.getNetworkInterfaces())
            .filter { iface -> iface.isUp && !iface.isLoopback }
            .flatMap { iface -> Collections.list(iface.inetAddresses) }
            .filterIsInstance<Inet4Address>()
            .map { it.hostAddress ?: "" }
            .filter { ip ->
                ip.isNotBlank() &&
                    !ip.startsWith("127.") &&
                    !ip.startsWith("169.254.")
            }
            .distinct()
    } catch (_: Throwable) {
        emptyList()
    }
}

private fun normalizeBaseUrl(input: String): String {
    val trimmed = input.trim().trimEnd('/')
    return when {
        trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
        trimmed.isNotBlank() -> "http://$trimmed"
        else -> ""
    }
}

private fun probeSignature(input: String, timeoutMs: Int = 1500): String {
    val base = normalizeBaseUrl(input)
    if (base.isBlank()) return "INVALID URL: empty node URL"
    val url = "$base/discovery/signature"
    var connection: HttpURLConnection? = null
    return try {
        connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = timeoutMs
        connection.readTimeout = timeoutMs
        connection.requestMethod = "GET"
        connection.setRequestProperty("Accept", "application/json")
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        val lower = body.lowercase()
        if (code in 200..299 && lower.contains("swrlz-local-node") && lower.contains("discovery-signature")) {
            "VALID SWRLZ NODE\nURL: $base\nHTTP: $code\n\n$body"
        } else {
            "NOT A VALID SWRLZ DISCOVERY SIGNATURE\nURL: $base\nHTTP: $code\n\n$body"
        }
    } catch (err: Throwable) {
        "PROBE FAILED\nURL: $base\nError: ${err.javaClass.simpleName}: ${err.message}"
    } finally {
        connection?.disconnect()
    }
}
