# SWRLZ-Core Android Client

Latest patch: **2.7.6 — Network Discovery**.

See `README_LATEST_2.7.6.md`, `SWRLZ_CORE_2.7.6_NETWORK_DISCOVERY_PATCH_REPORT.md`, and `SWRLZ_CORE_2.7.6_PHONE_TEST_CHECKLIST.md`.

## Current app identity

- Version: `0.2.7.6-cockpit-shell`
- Code: `17`
- Patch: `2.7.6-NETWORK-DISCOVERY`
- Roadmap: `2.7.6`

## Current server pair

- Local Node Server: `0.7.1 Presence Index`

## Project law

- Integrate, do not overwrite.
- No invisible patches.
- No mystery APKs.
- Preserve local data and taught skills.
- Keep Mentor backend and Local Core Node separate.
- Status colors remain semantic; themes may not lie about operational state.
