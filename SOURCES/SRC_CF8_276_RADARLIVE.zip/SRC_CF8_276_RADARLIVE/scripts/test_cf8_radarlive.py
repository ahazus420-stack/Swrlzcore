#!/usr/bin/env python3
"""SWRLZ CF8 corrected test: radar count boxes bind to server-derived counts and open mini floating menus."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NET = ROOT / "android/app/src/main/java/sh/swurlz/core/ui/screens/NetworkDiscoveryScreen.kt"
GRADLE = ROOT / "android/app/build.gradle.kts"
text = NET.read_text(encoding="utf-8")
gradle = GRADLE.read_text(encoding="utf-8")

checks = {
    "cf8 corrected patch label": "2.7.6-CF8-RADAR-LIVECOUNT-MENUS" in gradle,
    "cf8 corrected source zip identity": "SRC_CF8_276_RADARLIVE.zip" in gradle,
    "radar snapshot helper": "data class RadarMetricSnapshot" in text,
    "status group total parser": "statusObjectTotal(status, \"groups\")" in text,
    "status device total parser": "statusObjectTotal(status, \"devices\")" in text,
    "presence online parser": "onlineCountFromDevices(devices)" in text,
    "queue admin label": 'if (!adminMode) "ADMIN"' in text,
    "radar metric button composable": "fun RowScope.RadarMetricButton" in text,
    "groups box shows live label": 'RadarMetricButton("GROUPS", radarGroupsLabel)' in text,
    "devices box shows live label": 'RadarMetricButton("DEVICES", radarDevicesLabel)' in text,
    "online box shows live label": 'RadarMetricButton("ONLINE", radarOnlineLabel)' in text,
    "queue box shows live label": 'RadarMetricButton("QUEUE", radarQueueLabel)' in text,
    "mini float menu label": "MINI FLOAT DIAG MENU" in text,
    "missing endpoint note": "endpoint unavailable" in text,
    "no fake queue zero for non-admin": "queue count requires admin mode" in text,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(f"{'PASS' if ok else 'FAIL'}: {name}")
if failed:
    raise SystemExit("CF8 radar livecount source-level test failed: " + ", ".join(failed))
print("CF8 radar livecount source-level test PASS")
