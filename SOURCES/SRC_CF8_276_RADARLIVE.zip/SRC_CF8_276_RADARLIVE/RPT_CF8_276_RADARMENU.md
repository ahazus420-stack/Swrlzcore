# SWRLZ-Core CF8 Radar Menu / Floating Admin Dialog Handoff Report

## 1. Files changed

- `android/app/build.gradle.kts`
- `android/app/src/main/java/sh/swurlz/core/ui/screens/NetworkDiscoveryScreen.kt`
- `scripts/test_cf8_radarmenu.py`
- `RPT_CF8_276_RADARMENU.md`

## 2. Features updated

- Converts the top Radar metric boxes into tap targets that open a mini floating diagnostic menu.
- `GROUPS` opens a Groups radar menu with view, add group, rename info, and delete info lanes.
- `DEVICES` opens a Devices radar menu with list devices plus admin-only kick/offline, trust, block, reset-key, and edit-info lanes.
- `ONLINE` opens an Online devices radar menu with online list, refresh, and admin-only kick/queue actions.
- `QUEUE` opens a Queue radar menu with view queue, clear target queue, pull-offline info, and refresh lanes.
- `ADMIN LEDGER` opens the same floating menu pattern for ledger view/refresh when admin mode is enabled.
- Admin-only actions remain hidden unless the app is in admin mode.
- Server endpoint honesty preserved: group rename/delete and device profile edit are shown as future server endpoints instead of fake-working buttons when server 0.7.3 does not expose them.

## 3. Non-UI logic tested

- Source-level identity updated to `2.7.6-CF8-RADAR-MENU-DIALOGS`.
- Source ZIP identity updated to `SRC_CF8_276_RADARMENU.zip`.
- Radar metric buttons verified to call `openRadarMenu(...)` instead of raw endpoint-only dialogs.
- Mini floating menu body verified to contain admin/non-admin gating.

## 4. Commands/scripts run

```bash
python3 scripts/test_cf8_radarmenu.py
cd android && ./gradlew :app:assembleDebug --no-daemon
```

## 5. Results

```text
Source-level tested: PASS
Logic simulated: PASS
Build-tested: ATTEMPTED LOCALLY; BLOCKED BY SANDBOX DNS/NETWORK
Device-tested: NOT RUN by assistant

Gradle attempted to download `https://services.gradle.org/distributions/gradle-8.7-bin.zip` but failed with `UnknownHostException: services.gradle.org` in the sandbox. This is an environment/network limit, not a source-level failure.
```

## 6. Still requires Adam phone testing

- Tap `GROUPS`, `DEVICES`, `ONLINE`, and `QUEUE` top radar boxes.
- Confirm each one opens the mini floating diagnostic menu instead of only dumping raw text.
- Confirm admin-only actions stay hidden when admin mode is off.
- Confirm admin-only actions appear when admin mode is enabled.
- Confirm menu contents scroll properly on phone screen.
- Confirm server payload appears beneath the action buttons.

## 7. Known limitation

Server `0.7.3` does not yet expose every desired admin mutation endpoint. CF8 keeps those lanes honest by displaying endpoint-needed notes for group rename/delete and device profile editing. The matching server-side patch should be `0.7.4`.

## 8. Recommended next patch

`SERVER_0.7.4_ADMIN_MUTATION_ENDPOINTS` should add:

- `/admin/groups/{group_id}/rename`
- `/admin/groups/{group_id}/delete`
- `/admin/devices/{device_id}/profile/update`
- `/admin/queues/offline/pull`
- a true disconnect reason packet so kicked clients display the server reason.
