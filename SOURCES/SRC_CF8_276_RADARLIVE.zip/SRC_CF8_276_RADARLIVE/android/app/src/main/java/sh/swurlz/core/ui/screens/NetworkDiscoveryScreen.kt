package sh.swurlz.core.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import sh.swurlz.core.BuildConfig
import sh.swurlz.core.data.Prefs
import sh.swurlz.core.data.SecretStore
import sh.swurlz.core.model.CoreNodeConfig
import sh.swurlz.core.ui.theme.LocalSwurlzTokens
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL
import java.time.Instant
import java.util.Collections

@Composable
fun NetworkDiscoveryScreen(
    onOpenSetup: () -> Unit,
    onOpenCore: () -> Unit,
) {
    val ctx = LocalContext.current
    val tokens = LocalSwurlzTokens.current
    val scope = rememberCoroutineScope()
    var nodeUrl by remember { mutableStateOf("http://127.0.0.1:8787") }
    var token by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("Standing by. CF8 Radar LiveCount can refresh real server counts and open mini floating server/admin menus.") }
    var foundUrl by remember { mutableStateOf("") }
    var scanLoopbackRange by remember { mutableStateOf(false) }
    var autoReconnect by remember { mutableStateOf(true) }
    var autoRefresh by remember { mutableStateOf(true) }
    var refreshIntervalMs by remember { mutableStateOf(5000L) }
    var lastGoodUrl by remember { mutableStateOf("") }
    var lastGoodAt by remember { mutableStateOf("") }
    var livePanel by remember { mutableStateOf("Live dashboard has not refreshed yet.") }
    var lastPulseAt by remember { mutableStateOf("") }
    var adminMode by remember { mutableStateOf(false) }
    var adminTokenSaved by remember { mutableStateOf(false) }
    var adminToken by remember { mutableStateOf("") }
    var dialogTitle by remember { mutableStateOf("") }
    var dialogBody by remember { mutableStateOf("") }
    var dialogKind by remember { mutableStateOf("") }
    var adminTargetDeviceId by remember { mutableStateOf("") }
    var radarGroupsLabel by remember { mutableStateOf("—") }
    var radarDevicesLabel by remember { mutableStateOf("—") }
    var radarOnlineLabel by remember { mutableStateOf("—") }
    var radarQueueLabel by remember { mutableStateOf("—") }
    var radarCountsNote by remember { mutableStateOf("Waiting for first server count refresh.") }
    var newGroupId by remember { mutableStateOf("") }
    var newGroupKey by remember { mutableStateOf("") }
    var newGroupLabel by remember { mutableStateOf("") }

    fun activeBaseUrl(): String = normalizeBaseUrl(foundUrl.ifBlank { nodeUrl.ifBlank { lastGoodUrl } })

    suspend fun refreshLiveDashboard(reason: String = "manual") {
        val base = activeBaseUrl()
        if (base.isBlank()) {
            livePanel = "No Core Node URL available yet. Save, scan, or reconnect first."
            return
        }
        val bearer = if (adminMode) adminToken else ""
        val status = withContext(Dispatchers.IO) { getJson(base, "/status") }
        val signature = withContext(Dispatchers.IO) { getJson(base, "/discovery/signature") }
        val presence = withContext(Dispatchers.IO) { getJson(base, "/presence/summary", bearer) }
        val groups = withContext(Dispatchers.IO) { getJson(base, "/presence/groups", bearer) }
        val devices = withContext(Dispatchers.IO) { getJson(base, if (adminMode) "/admin/devices" else "/presence/devices", bearer) }
        val queues = if (adminMode) withContext(Dispatchers.IO) { getJson(base, "/admin/queues", bearer) } else "ADMIN ONLY: /admin/queues requires admin mode."
        val radarSnapshot = radarMetricSnapshot(status, presence, groups, devices, queues, adminMode)
        radarGroupsLabel = radarSnapshot.groups
        radarDevicesLabel = radarSnapshot.devices
        radarOnlineLabel = radarSnapshot.online
        radarQueueLabel = radarSnapshot.queue
        radarCountsNote = radarSnapshot.note
        lastPulseAt = Instant.now().toString()
        livePanel = buildString {
            appendLine("CF8 RADAR LIVECOUNT · $reason")
            appendLine("Base: $base")
            appendLine("Admin: ${if (adminMode) "ON" else "OFF"} · token saved: ${if (adminTokenSaved) "yes" else "no"}")
            appendLine("Refresh: ${if (autoRefresh) "ON" else "OFF"} · interval: ${refreshIntervalMs / 1000}s")
            appendLine("Last pulse: $lastPulseAt")
            appendLine("Counts: groups=${radarSnapshot.groups} · devices=${radarSnapshot.devices} · online=${radarSnapshot.online} · queue=${radarSnapshot.queue}")
            appendLine("Counts note: ${radarSnapshot.note}")
            appendLine()
            appendLine("STATUS: ${shortEndpointLine(status)}")
            appendLine("SIGNATURE: ${shortEndpointLine(signature)}")
            appendLine("PRESENCE: ${shortEndpointLine(presence)}")
            appendLine("GROUPS: ${shortEndpointLine(groups)}")
            appendLine("DEVICES: ${shortEndpointLine(devices)}")
            appendLine("QUEUE: ${shortEndpointLine(queues)}")
        }
        if (isValidJsonSignature(signature)) {
            foundUrl = base
            nodeUrl = base
            lastGoodUrl = base
            lastGoodAt = saveLastGoodNode(ctx, base)
            Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(nodeUrl = base, pairingToken = token))
        }
    }

    LaunchedEffect(Unit) {
        val saved = withContext(Dispatchers.IO) { Prefs.coreNodeConfig(ctx) }
        val admin = withContext(Dispatchers.IO) { Prefs.adminSession(ctx) }
        if (saved.nodeUrl.isNotBlank()) nodeUrl = saved.nodeUrl
        token = saved.pairingToken
        scanLoopbackRange = loadLoopbackRangeEnabled(ctx)
        autoReconnect = loadAutoReconnectEnabled(ctx)
        autoRefresh = loadAutoRefreshEnabled(ctx)
        refreshIntervalMs = loadRefreshIntervalMs(ctx)
        lastGoodUrl = loadLastGoodNodeUrl(ctx)
        lastGoodAt = loadLastGoodNodeAt(ctx)
        adminMode = admin.modeEnabled
        adminTokenSaved = admin.sessionTokenSaved
        adminToken = withContext(Dispatchers.IO) { SecretStore.adminSessionToken(ctx) }

        if (autoReconnect) {
            val remembered = lastGoodUrl
            val firstTarget = saved.nodeUrl.ifBlank { remembered }
            if (firstTarget.isNotBlank()) {
                result = "AUTO RECONNECT armed. Checking saved/last-good node…\n${normalizeBaseUrl(firstTarget)}/discovery/signature"
                val firstProbe = withContext(Dispatchers.IO) { probeSignature(firstTarget, timeoutMs = 850) }
                if (isValidProbe(firstProbe)) {
                    val good = normalizeBaseUrl(firstTarget)
                    foundUrl = good
                    nodeUrl = good
                    lastGoodUrl = good
                    lastGoodAt = saveLastGoodNode(ctx, good)
                    withContext(Dispatchers.IO) { Prefs.setCoreNodeConfig(ctx, saved.copy(nodeUrl = good)) }
                    result = "AUTO RECONNECTED\n$firstProbe\n\nLast-good node refreshed: $lastGoodAt"
                    refreshLiveDashboard("auto reconnect")
                } else if (remembered.isNotBlank() && normalizeBaseUrl(remembered) != normalizeBaseUrl(firstTarget)) {
                    result = "AUTO RECONNECT saved node failed. Trying last-good fallback…\n\n$firstProbe"
                    val fallbackProbe = withContext(Dispatchers.IO) { probeSignature(remembered, timeoutMs = 850) }
                    if (isValidProbe(fallbackProbe)) {
                        val good = normalizeBaseUrl(remembered)
                        foundUrl = good
                        nodeUrl = good
                        lastGoodUrl = good
                        lastGoodAt = saveLastGoodNode(ctx, good)
                        withContext(Dispatchers.IO) { Prefs.setCoreNodeConfig(ctx, saved.copy(nodeUrl = good)) }
                        result = "AUTO RECONNECTED FROM LAST GOOD\n$fallbackProbe\n\nSaved node was stale; last-good fallback won."
                        refreshLiveDashboard("last-good fallback")
                    } else {
                        result = "AUTO RECONNECT checked saved and last-good nodes, but neither verified.\n\nSaved check:\n$firstProbe\n\nLast-good check:\n$fallbackProbe"
                    }
                } else {
                    result = "AUTO RECONNECT checked saved node, but it did not verify.\n\n$firstProbe"
                }
            }
        }
    }

    // CF7: this loop only exists while the Network screen is composed/active.
    // Switching tabs disposes this screen and cancels polling automatically.
    LaunchedEffect(autoRefresh, refreshIntervalMs, nodeUrl, foundUrl, adminMode, adminToken) {
        if (!autoRefresh) return@LaunchedEffect
        while (isActive) {
            refreshLiveDashboard("auto")
            delay(refreshIntervalMs.coerceIn(3000L, 60000L))
        }
    }

    fun test(url: String) {
        scope.launch {
            result = "Probing ${normalizeBaseUrl(url)}/discovery/signature …"
            val probe = withContext(Dispatchers.IO) { probeSignature(url) }
            result = probe
            if (isValidProbe(probe)) {
                val good = normalizeBaseUrl(url)
                foundUrl = good
                nodeUrl = good
                lastGoodUrl = good
                lastGoodAt = saveLastGoodNode(ctx, good)
                Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(nodeUrl = good, pairingToken = token))
                result = "$probe\n\nLast-good node saved: $lastGoodAt"
                refreshLiveDashboard("test signature")
            }
        }
    }

    fun scanCandidates() {
        scope.launch {
            val typedNow = normalizeBaseUrl(nodeUrl)
            val savedNow = withContext(Dispatchers.IO) { Prefs.coreNodeConfig(ctx).nodeUrl }
            val loopbackSweepNow = scanLoopbackRange
            val candidates = withContext(Dispatchers.IO) {
                candidateUrls(primary = typedNow, saved = savedNow, includeLoopbackSweep = loopbackSweepNow)
            }
            val preview = candidates.take(18).joinToString("\n")
            result = "Scanning port 8787 with device-subnet-first discovery.\n" +
                "Typed/saved URLs are tried first. Then SWRLZ reads this device's LAN IP and sweeps that x.x.x.1-254 range.\n" +
                "127.0.0.x loopback range sweep: ${if (loopbackSweepNow) "ENABLED" else "OFF; only 127.0.0.1/localhost are tested"}.\n\n" +
                "First candidates:\n$preview" +
                if (candidates.size > 18) "\n… ${candidates.size - 18} more" else ""

            val scan = withContext(Dispatchers.IO) { scanForValidNode(candidates) }
            if (scan.foundUrl.isNotBlank()) {
                foundUrl = scan.foundUrl
                nodeUrl = foundUrl
                lastGoodUrl = foundUrl
                lastGoodAt = saveLastGoodNode(ctx, foundUrl)
                Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(nodeUrl = foundUrl, pairingToken = token))
                result = "FOUND\n${scan.probe}\n\nScanned ${scan.tried.size} candidate(s).\nLast-good node saved: $lastGoodAt"
                refreshLiveDashboard("scan local")
                return@launch
            }
            result = "No valid SWRLZ node found on the current local subnet/device-derived scan path.\n\n" +
                "Current field tried first:\n$typedNow\n\n" +
                "Scanned ${scan.tried.size} candidate(s):\n" + scan.tried.joinToString("\n")
        }
    }

    fun save() {
        scope.launch {
            val normalized = normalizeBaseUrl(foundUrl.ifBlank { nodeUrl })
            Prefs.setCoreNodeConfig(ctx, CoreNodeConfig(nodeUrl = normalized, pairingToken = token))
            lastGoodUrl = normalized
            lastGoodAt = saveLastGoodNode(ctx, normalized)
            result = "Saved Core Node URL:\n$normalized\n\nLast-good node refreshed: $lastGoodAt\nNext: use Network Pulse panels or open Core Admin."
            refreshLiveDashboard("save node")
        }
    }

    fun openEndpoint(title: String, path: String, adminOnly: Boolean = false) {
        scope.launch {
            val base = activeBaseUrl()
            if (base.isBlank()) {
                dialogTitle = title
                dialogBody = "No Core Node URL available yet."
                return@launch
            }
            if (adminOnly && !adminMode) {
                dialogTitle = title
                dialogBody = "Admin-only. Enable and verify admin mode first."
                return@launch
            }
            dialogTitle = title
            dialogBody = "Loading $path …"
            dialogBody = withContext(Dispatchers.IO) { prettyJsonOrText(getJson(base, path, if (adminOnly || adminMode) adminToken else "")) }
        }
    }

    fun openRadarMenu(kind: String) {
        scope.launch {
            val normalizedKind = kind.uppercase()
            val base = activeBaseUrl()
            dialogKind = normalizedKind
            dialogTitle = "$normalizedKind · RADAR MENU"
            if (base.isBlank()) {
                dialogBody = "No Core Node URL available yet. Save, scan, or reconnect first."
                return@launch
            }
            val bearer = if (adminMode) adminToken else ""
            dialogBody = "Loading $normalizedKind server payload …"
            dialogBody = withContext(Dispatchers.IO) {
                when (normalizedKind) {
                    "GROUPS" -> {
                        val primary = getJson(base, "/presence/groups", bearer)
                        if (endpointOk(primary) || !adminMode) prettyJsonOrText(primary) else prettyJsonOrText(getJson(base, "/groups/list", bearer))
                    }
                    "DEVICES" -> prettyJsonOrText(getJson(base, if (adminMode) "/admin/devices" else "/presence/devices", bearer))
                    "ONLINE" -> prettyJsonOrText(getJson(base, "/presence/devices", bearer))
                    "QUEUE" -> if (adminMode) prettyJsonOrText(getJson(base, "/admin/queues", bearer)) else "Admin-only queue inspector. Enable admin mode to view /admin/queues."
                    "LEDGER" -> if (adminMode) prettyJsonOrText(getJson(base, "/admin/ledger", bearer)) else "Admin-only ledger. Enable admin mode to view /admin/ledger."
                    else -> "Unknown radar menu: $normalizedKind"
                }
            }
        }
    }

    fun runAdminAction(action: String, body: String = "{}") {
        scope.launch {
            val deviceId = adminTargetDeviceId.trim()
            val base = activeBaseUrl()
            if (!adminMode) {
                dialogTitle = "ADMIN ACTION"
                dialogBody = "Admin-only. Enable and verify admin mode first."
                return@launch
            }
            if (base.isBlank()) {
                dialogTitle = "ADMIN ACTION"
                dialogBody = "No Core Node URL available yet."
                return@launch
            }
            if (deviceId.isBlank()) {
                dialogTitle = "ADMIN DEVICE ACTION"
                dialogBody = "Enter a target Device ID first."
                return@launch
            }
            dialogTitle = "DEVICE $action"
            dialogBody = withContext(Dispatchers.IO) { prettyJsonOrText(postJson(base, "/admin/devices/$deviceId/$action", body, adminToken)) }
            refreshLiveDashboard("admin device $action")
        }
    }

    fun createGroup() {
        scope.launch {
            val base = activeBaseUrl()
            if (!adminMode) {
                dialogTitle = "CREATE GROUP"
                dialogBody = "Admin-only. Enable and verify admin mode first."
                return@launch
            }
            if (newGroupId.isBlank() || newGroupKey.length < 4) {
                dialogTitle = "CREATE GROUP"
                dialogBody = "Enter Group ID and a Group Key of at least 4 characters."
                return@launch
            }
            val body = """{"group_id":"${escapeJson(newGroupId)}","group_key":"${escapeJson(newGroupKey)}","label":"${escapeJson(newGroupLabel)}"}"""
            dialogTitle = "CREATE GROUP"
            dialogBody = withContext(Dispatchers.IO) { prettyJsonOrText(postJson(base, "/groups/create", body, adminToken)) }
            refreshLiveDashboard("create group")
        }
    }

    if (dialogTitle.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { dialogTitle = ""; dialogBody = ""; dialogKind = "" },
            confirmButton = { TextButton(onClick = { dialogTitle = ""; dialogBody = ""; dialogKind = "" }) { Text("CLOSE") } },
            title = { Text(dialogTitle, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    if (dialogKind.isNotBlank()) {
                        Text("MINI FLOAT DIAG MENU", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(6.dp))
                        when (dialogKind) {
                            "GROUPS" -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("VIEW GROUPS") { openEndpoint("GROUPS", "/presence/groups", adminOnly = false) }
                                    if (adminMode) DiscoveryButton("ADD GROUP") { createGroup() }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("RENAME INFO") { dialogBody = "Server 0.7.3 does not expose a group rename endpoint yet. Next server patch should add /admin/groups/{group_id}/rename." }
                                    DiscoveryButton("DELETE INFO") { dialogBody = "Server 0.7.3 does not expose a group delete endpoint yet. Next server patch should add /admin/groups/{group_id}/delete with confirmation." }
                                }
                            }
                            "DEVICES" -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("LIST DEVICES") { openEndpoint("DEVICES", if (adminMode) "/admin/devices" else "/presence/devices", adminOnly = false) }
                                    if (adminMode) DiscoveryButton("KICK/OFFLINE") { runAdminAction("force-offline") }
                                }
                                Spacer(Modifier.height(6.dp))
                                if (adminMode) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        DiscoveryButton("TRUST") { runAdminAction("trust") }
                                        DiscoveryButton("BLOCK") { runAdminAction("block") }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        DiscoveryButton("RESET KEY") { runAdminAction("reset-key") }
                                        DiscoveryButton("EDIT INFO") { dialogBody = "Device profile edit needs a matching server endpoint. Next server patch should add /admin/devices/{device_id}/profile/update with label, role, group, trust, and notes fields." }
                                    }
                                } else {
                                    Text("Admin actions hidden. Enable admin mode to edit, trust, block, reset, or kick devices.", fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp)
                                }
                            }
                            "ONLINE" -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("ONLINE LIST") { openEndpoint("ONLINE DEVICES", "/presence/devices", adminOnly = false) }
                                    DiscoveryButton("REFRESH") { openRadarMenu("ONLINE") }
                                }
                                Spacer(Modifier.height(6.dp))
                                if (adminMode) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("KICK/OFFLINE") { runAdminAction("force-offline") }
                                    DiscoveryButton("CLEAR QUEUE") { runAdminAction("clear-queue") }
                                }
                            }
                            "QUEUE" -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("VIEW QUEUE") { openEndpoint("QUEUE", "/admin/queues", adminOnly = true) }
                                    if (adminMode) DiscoveryButton("CLEAR TARGET") { runAdminAction("clear-queue") }
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("PULL OFFLINE") { dialogBody = "Pull offline queue uses the existing app button for now. Next server patch should expose a compact /admin/queues/offline/pull endpoint for this mini menu." }
                                    DiscoveryButton("REFRESH") { openRadarMenu("QUEUE") }
                                }
                            }
                            "LEDGER" -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DiscoveryButton("VIEW LEDGER") { openEndpoint("ADMIN LEDGER", "/admin/ledger", adminOnly = true) }
                                    DiscoveryButton("REFRESH") { openRadarMenu("LEDGER") }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("SERVER PAYLOAD", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(6.dp))
                    }
                    Text(dialogBody, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp)
                }
            },
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
    ) {
        Text("▸ NETWORK PULSE", color = tokens.accents.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Find, verify, save, auto-refresh, show real Core Node counts, and inspect groups/devices/online/queue through mini floating menus.",
            color = tokens.text.secondary,
            fontSize = 13.sp,
            lineHeight = 19.sp,
        )
        Spacer(Modifier.height(12.dp))

        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.selected).background(tokens.cards.bg).padding(12.dp)) {
            Text("BUILD IDENTITY", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text("Version: v${BuildConfig.VERSION_NAME} · code ${BuildConfig.VERSION_CODE}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Patch: ${BuildConfig.PATCH_LABEL}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Roadmap: ${BuildConfig.ROADMAP_REVISION}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Source: ${BuildConfig.SOURCE_ZIP}", color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = nodeUrl,
            onValueChange = { nodeUrl = it },
            label = { Text("Node URL") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Pairing token / API token, optional") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("TEST SIGNATURE", onClick = { test(nodeUrl) })
            DiscoveryButton("SCAN LOCAL", onClick = { scanCandidates() })
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("SAVE NODE", onClick = { save() })
            DiscoveryButton("REFRESH NOW", onClick = { scope.launch { refreshLiveDashboard("manual") } })
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DiscoveryButton("OPEN CORE ADMIN", onClick = onOpenCore)
            DiscoveryButton("OPEN SETUP", onClick = onOpenSetup)
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.info).background(tokens.cards.bg).padding(12.dp)) {
            Text("AUTO REFRESH", color = tokens.status.info, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "State is saved. Polling only runs while this Network tab is active; switching tabs pauses the loop.",
                color = tokens.text.secondary,
                fontSize = 11.sp,
                lineHeight = 16.sp,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DiscoveryButton("AUTO REFRESH: ${if (autoRefresh) "ON" else "OFF"}") {
                    autoRefresh = !autoRefresh
                    saveAutoRefreshEnabled(ctx, autoRefresh)
                    result = "Auto refresh is now ${if (autoRefresh) "ON" else "OFF"}. Saved state will persist across tab switches and app restarts."
                }
                DiscoveryButton("INTERVAL: ${refreshIntervalMs / 1000}s") {
                    refreshIntervalMs = nextRefreshInterval(refreshIntervalMs)
                    saveRefreshIntervalMs(ctx, refreshIntervalMs)
                    result = "Network Pulse refresh interval saved: every ${refreshIntervalMs / 1000} seconds."
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DiscoveryButton("LOOPBACK RANGE: ${if (scanLoopbackRange) "ON" else "OFF"}") {
                    scanLoopbackRange = !scanLoopbackRange
                    saveLoopbackRangeEnabled(ctx, scanLoopbackRange)
                    result = "Loopback range sweep is now ${if (scanLoopbackRange) "ON" else "OFF"}."
                }
                DiscoveryButton("AUTO RECONNECT: ${if (autoReconnect) "ON" else "OFF"}") {
                    autoReconnect = !autoReconnect
                    saveAutoReconnectEnabled(ctx, autoReconnect)
                    result = "Auto reconnect is now ${if (autoReconnect) "ON" else "OFF"}."
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.success).background(tokens.cards.bg).padding(12.dp)) {
            Text("LIVE SERVER DASHBOARD", color = tokens.status.success, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(radarCountsNote, color = tokens.text.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 14.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RadarMetricButton("GROUPS", radarGroupsLabel) { openRadarMenu("GROUPS") }
                RadarMetricButton("DEVICES", radarDevicesLabel) { openRadarMenu("DEVICES") }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                RadarMetricButton("ONLINE", radarOnlineLabel) { openRadarMenu("ONLINE") }
                RadarMetricButton("QUEUE", radarQueueLabel) { openRadarMenu("QUEUE") }
            }
            Spacer(Modifier.height(8.dp))
            Text(livePanel, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, lineHeight = 15.sp)
            Spacer(Modifier.height(8.dp))
            if (adminMode) {
                DiscoveryButton("ADMIN LEDGER") { openRadarMenu("LEDGER") }
            } else {
                Text("Admin controls hidden: enable admin mode to show ledger, device actions, queues, and group creation.", color = tokens.text.secondary, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }

        if (adminMode) {
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.warning).background(tokens.cards.bgAlt).padding(12.dp)) {
                Text("ADMIN ACTIONS", color = tokens.status.warning, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Actions are hidden unless admin mode is enabled. Force offline works as the current disconnect/kick approximation for server 0.7.3.",
                    color = tokens.text.secondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = adminTargetDeviceId,
                    onValueChange = { adminTargetDeviceId = it },
                    label = { Text("Target Device ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiscoveryButton("KICK/OFFLINE") { runAdminAction("force-offline") }
                    DiscoveryButton("TRUST") { runAdminAction("trust") }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiscoveryButton("BLOCK") { runAdminAction("block") }
                    DiscoveryButton("CLEAR QUEUE") { runAdminAction("clear-queue") }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiscoveryButton("RESET KEY") { runAdminAction("reset-key") }
                    DiscoveryButton("FORGET") { runAdminAction("forget", "{\"clear_queue\":true}") }
                }

                Spacer(Modifier.height(12.dp))
                Text("GROUP CREATE", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = newGroupId, onValueChange = { newGroupId = it }, label = { Text("New Group ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = newGroupKey, onValueChange = { newGroupKey = it }, label = { Text("New Group Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = newGroupLabel, onValueChange = { newGroupLabel = it }, label = { Text("Group Label") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DiscoveryButton("ADD GROUP") { createGroup() }
                    DiscoveryButton("RENAME/DELETE INFO") {
                        dialogTitle = "GROUP ACTIONS"
                        dialogBody = "Server 0.7.3 supports /groups/create and /groups/list. Rename/delete group endpoints are not exposed yet, so CF7 hides destructive group actions behind this info notice instead of pretending they work. Next server patch should add /admin/groups/{id}/rename and /admin/groups/{id}/delete."
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.borders.neutral).background(tokens.cards.bgAlt).padding(12.dp)) {
            Text("DISCOVERY RESULT", color = tokens.accents.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(result, color = tokens.text.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 16.sp)
        }

        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().border(1.dp, tokens.status.info).background(tokens.cards.bg).padding(12.dp)) {
            Text("REINSTALL / STATE NOTE", color = tokens.status.info, fontFamily = FontFamily.Monospace, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Settings persist across app updates. Full uninstall/reinstall can erase local app data unless Android backup/device-transfer restores it. CF7 enables backup for ordinary settings, but secret admin tokens may still require re-login because Android Keystore secrets do not always restore safely. Server-owned groups/devices/queues remain on the Core Node.",
                color = tokens.text.secondary,
                fontSize = 10.sp,
                lineHeight = 15.sp,
            )
        }
    }
}

@Composable
private fun RowScope.RadarMetricButton(label: String, value: String, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.text.primary, containerColor = tokens.buttons.ghostBg),
        border = BorderStroke(1.dp, tokens.accents.primary),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
        modifier = Modifier.weight(1f),
    ) {
        Column {
            Text(value, fontFamily = FontFamily.Monospace, fontSize = 18.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Bold, color = tokens.accents.secondary)
            Spacer(Modifier.height(2.dp))
            Text(label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold, color = tokens.text.secondary)
            Spacer(Modifier.height(2.dp))
            Text("TAP MENU", fontFamily = FontFamily.Monospace, fontSize = 7.sp, letterSpacing = 1.sp, color = tokens.accents.primary)
        }
    }
}

@Composable
private fun DiscoveryButton(label: String, onClick: () -> Unit) {
    val tokens = LocalSwurlzTokens.current
    OutlinedButton(
        onClick = onClick,
        colors = ButtonDefaults.outlinedButtonColors(contentColor = tokens.accents.primary, containerColor = tokens.buttons.ghostBg),
        border = BorderStroke(1.dp, tokens.accents.primary),
        shape = RoundedCornerShape(0),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 9.dp),
    ) {
        Text(label, fontFamily = FontFamily.Monospace, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
    }
}

private data class RadarMetricSnapshot(
    val groups: String,
    val devices: String,
    val online: String,
    val queue: String,
    val note: String,
)

private fun radarMetricSnapshot(
    status: String,
    presence: String,
    groups: String,
    devices: String,
    queues: String,
    adminMode: Boolean,
): RadarMetricSnapshot {
    val groupCount = statusObjectTotal(status, "groups") ?: endpointCount(groups) ?: summaryValue(presence, "groups")
    val deviceCount = statusObjectTotal(status, "devices") ?: endpointCount(devices) ?: summaryValue(presence, "devices")
    val onlineCount = onlineCountFromDevices(devices) ?: summaryValue(presence, "online")
    val queueCount = endpointCount(queues) ?: summaryValue(presence, "queued") ?: packetSummaryValue(queues, "pending")

    val groupsLabel = metricLabel(groupCount, groups, fallbackWhenDenied = "N/A")
    val devicesLabel = metricLabel(deviceCount, devices, fallbackWhenDenied = "N/A")
    val onlineLabel = metricLabel(onlineCount, devices, fallbackWhenDenied = "AUTH")
    val queueLabel = if (!adminMode) "ADMIN" else metricLabel(queueCount, queues, fallbackWhenDenied = "AUTH")

    val notes = mutableListOf<String>()
    if (!endpointOk(groups) && groupCount == null) notes += "groups endpoint unavailable"
    if (!endpointOk(devices) && deviceCount == null) notes += "devices endpoint unavailable"
    if (!adminMode) notes += "queue count requires admin mode on server 0.7.3"
    if (adminMode && !endpointOk(queues) && queueCount == null) notes += "admin queue endpoint unavailable/auth failed"
    if (notes.isEmpty()) notes += "Counts refreshed from server truth. Tap a box for mini diag/admin menu."
    return RadarMetricSnapshot(groupsLabel, devicesLabel, onlineLabel, queueLabel, notes.joinToString(" · "))
}

private fun metricLabel(value: Int?, raw: String, fallbackWhenDenied: String): String = when {
    value != null -> value.toString()
    raw.startsWith("HTTP 401") || raw.startsWith("HTTP 403") -> fallbackWhenDenied
    raw.startsWith("HTTP 404") -> "N/A"
    raw.startsWith("FAILED") -> "ERR"
    else -> "—"
}

private fun endpointOk(raw: String): Boolean =
    raw.startsWith("HTTP 2") &&
        raw.contains("\"ok\"", ignoreCase = true) &&
        !Regex("\"ok\"\\s*:\\s*false", RegexOption.IGNORE_CASE).containsMatchIn(raw)

private fun endpointCount(raw: String): Int? = Regex("\\\"count\\\"\\s*:\\s*(\\d+)").find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()

private fun statusObjectTotal(raw: String, objectName: String): Int? =
    Regex("\\\"${Regex.escape(objectName)}\\\"\\s*:\\s*\\{[^}]*\\\"total\\\"\\s*:\\s*(\\d+)").find(raw)?.groupValues?.getOrNull(1)?.toIntOrNull()

private fun summaryValue(raw: String, key: String): Int? {
    val body = Regex("\\\"summary\\\"\\s*:\\s*\\{([^}]*)\\}").find(raw)?.groupValues?.getOrNull(1) ?: return null
    return Regex("\\\"${Regex.escape(key)}\\\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.getOrNull(1)?.toIntOrNull()
}

private fun packetSummaryValue(raw: String, key: String): Int? {
    val body = Regex("\\\"summary\\\"\\s*:\\s*\\{([^}]*)\\}").find(raw)?.groupValues?.getOrNull(1) ?: return null
    return Regex("\\\"${Regex.escape(key)}\\\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.getOrNull(1)?.toIntOrNull()
}

private fun onlineCountFromDevices(raw: String): Int? {
    if (!endpointOk(raw)) return null
    val onlineStates = Regex("\\\"online_state\\\"\\s*:\\s*\\\"online\\\"", RegexOption.IGNORE_CASE).findAll(raw).count()
    return onlineStates.takeIf { it > 0 } ?: summaryValue(raw, "online")
}

private data class DiscoveryScanResult(
    val foundUrl: String = "",
    val probe: String = "",
    val tried: List<String> = emptyList(),
)

private suspend fun scanForValidNode(
    candidates: List<String>,
    timeoutMs: Int = 650,
    batchSize: Int = 32,
): DiscoveryScanResult {
    val tried = mutableListOf<String>()
    for (batch in candidates.chunked(batchSize)) {
        val results = coroutineScope {
            batch.map { candidate ->
                async { candidate to probeSignature(candidate, timeoutMs = timeoutMs) }
            }.awaitAll()
        }
        tried += batch
        val hit = results.firstOrNull { (_, probe) -> isValidProbe(probe) }
        if (hit != null) {
            return DiscoveryScanResult(
                foundUrl = normalizeBaseUrl(hit.first),
                probe = hit.second,
                tried = tried.toList(),
            )
        }
    }
    return DiscoveryScanResult(tried = tried.toList())
}

private fun candidateUrls(primary: String, saved: String = "", includeLoopbackSweep: Boolean = false): List<String> {
    val normalizedPrimary = normalizeBaseUrl(primary)
    val normalizedSaved = normalizeBaseUrl(saved)
    val candidates = mutableListOf<String>()
    if (normalizedPrimary.isNotBlank()) candidates += normalizedPrimary
    if (normalizedSaved.isNotBlank()) candidates += normalizedSaved
    val port = firstUsablePort(normalizedPrimary, normalizedSaved, defaultPort = 8787)
    candidates += inferredSubnetSweepCandidates(normalizedPrimary, port, includeLoopbackSweep)
    candidates += inferredSubnetSweepCandidates(normalizedSaved, port, includeLoopbackSweep)
    localIpv4Addresses().forEach { ip -> candidates += subnetSweepCandidatesFromIpv4(ip, port, includeLoopbackSweep) }
    candidates += listOf(
        "http://127.0.0.1:$port",
        "http://localhost:$port",
        "http://10.0.2.2:$port",
        "http://192.168.0.1:$port",
        "http://192.168.1.1:$port",
        "http://192.168.4.1:$port",
    )
    return candidates.map { normalizeBaseUrl(it) }.filter { it.isNotBlank() }.distinct()
}

private fun firstUsablePort(vararg urls: String, defaultPort: Int): Int {
    urls.forEach { url ->
        try {
            val parsed = URL(normalizeBaseUrl(url))
            if (parsed.port in 1..65535) return parsed.port
        } catch (_: Throwable) { }
    }
    return defaultPort
}

private fun inferredSubnetSweepCandidates(baseUrl: String, fallbackPort: Int, includeLoopbackSweep: Boolean = false): List<String> {
    if (baseUrl.isBlank()) return emptyList()
    return try {
        val parsed = URL(normalizeBaseUrl(baseUrl))
        val host = parsed.host ?: return emptyList()
        val port = if (parsed.port > 0) parsed.port else fallbackPort
        subnetSweepCandidatesFromIpv4(host, port, includeLoopbackSweep)
    } catch (_: Throwable) {
        emptyList()
    }
}

private fun subnetSweepCandidatesFromIpv4(ipv4: String, port: Int, includeLoopbackSweep: Boolean = false): List<String> {
    val parts = ipv4.split('.')
    if (parts.size != 4 || parts.any { it.toIntOrNull() !in 0..255 }) return emptyList()
    val prefix = parts.take(3).joinToString(".")
    if (prefix == "127.0.0" && !includeLoopbackSweep) return emptyList()
    return (1..254).map { last -> "http://$prefix.$last:$port" }
}

private fun loadLoopbackRangeEnabled(context: Context): Boolean =
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LOOPBACK_RANGE, false)

private fun saveLoopbackRangeEnabled(context: Context, enabled: Boolean) {
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LOOPBACK_RANGE, enabled).apply()
}

private fun loadAutoReconnectEnabled(context: Context): Boolean =
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_RECONNECT, true)

private fun saveAutoReconnectEnabled(context: Context, enabled: Boolean) {
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO_RECONNECT, enabled).apply()
}

private fun loadAutoRefreshEnabled(context: Context): Boolean =
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_REFRESH, true)

private fun saveAutoRefreshEnabled(context: Context, enabled: Boolean) {
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_AUTO_REFRESH, enabled).apply()
}

private fun loadRefreshIntervalMs(context: Context): Long =
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).getLong(KEY_REFRESH_INTERVAL_MS, 5000L).coerceIn(3000L, 60000L)

private fun saveRefreshIntervalMs(context: Context, intervalMs: Long) {
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).edit().putLong(KEY_REFRESH_INTERVAL_MS, intervalMs.coerceIn(3000L, 60000L)).apply()
}

private fun nextRefreshInterval(current: Long): Long = when (current) {
    3000L -> 5000L
    5000L -> 10000L
    10000L -> 30000L
    30000L -> 60000L
    else -> 3000L
}

private fun loadLastGoodNodeUrl(context: Context): String =
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_GOOD_URL, "").orEmpty().trim()

private fun loadLastGoodNodeAt(context: Context): String =
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).getString(KEY_LAST_GOOD_AT, "").orEmpty().trim()

private fun saveLastGoodNode(context: Context, url: String): String {
    val normalized = normalizeBaseUrl(url)
    val now = Instant.now().toString()
    context.getSharedPreferences(DISCOVERY_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_LAST_GOOD_URL, normalized)
        .putString(KEY_LAST_GOOD_AT, now)
        .apply()
    return now
}

private const val DISCOVERY_PREFS = "swrlz_discovery_settings"
private const val KEY_LOOPBACK_RANGE = "scan_loopback_range"
private const val KEY_AUTO_RECONNECT = "auto_reconnect_last_good_node"
private const val KEY_AUTO_REFRESH = "network_auto_refresh_enabled"
private const val KEY_REFRESH_INTERVAL_MS = "network_refresh_interval_ms"
private const val KEY_LAST_GOOD_URL = "last_good_node_url"
private const val KEY_LAST_GOOD_AT = "last_good_node_at"

private fun localIpv4Addresses(): List<String> = try {
    Collections.list(NetworkInterface.getNetworkInterfaces())
        .filter { iface -> iface.isUp && !iface.isLoopback }
        .flatMap { iface -> Collections.list(iface.inetAddresses) }
        .filterIsInstance<Inet4Address>()
        .map { it.hostAddress ?: "" }
        .filter { ip -> ip.isNotBlank() && !ip.startsWith("127.") && !ip.startsWith("169.254.") }
        .distinct()
} catch (_: Throwable) {
    emptyList()
}

private fun normalizeBaseUrl(input: String): String {
    val trimmed = input.trim().trimEnd('/')
    return when {
        trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
        trimmed.isNotBlank() -> "http://$trimmed"
        else -> ""
    }
}

private fun isValidProbe(probe: String): Boolean = probe.startsWith("VALID SWRLZ NODE")

private fun isValidJsonSignature(raw: String): Boolean =
    raw.contains("swrlz-local-node", ignoreCase = true) && raw.contains("discovery-signature", ignoreCase = true)

private fun probeSignature(input: String, timeoutMs: Int = 1500): String {
    val base = normalizeBaseUrl(input)
    if (base.isBlank()) return "INVALID URL: empty node URL"
    val raw = getJson(base, "/discovery/signature", timeoutMs = timeoutMs)
    return if (isValidJsonSignature(raw)) "VALID SWRLZ NODE\nURL: $base\n\n$raw" else "NOT A VALID SWRLZ DISCOVERY SIGNATURE\nURL: $base\n\n$raw"
}

private fun getJson(base: String, path: String, bearerToken: String = "", timeoutMs: Int = 1500): String =
    requestJson("GET", base, path, "", bearerToken, timeoutMs)

private fun postJson(base: String, path: String, body: String, bearerToken: String = "", timeoutMs: Int = 2500): String =
    requestJson("POST", base, path, body, bearerToken, timeoutMs)

private fun requestJson(method: String, base: String, path: String, body: String = "", bearerToken: String = "", timeoutMs: Int = 1500): String {
    val cleanBase = normalizeBaseUrl(base)
    if (cleanBase.isBlank()) return "INVALID URL: empty node URL"
    var connection: HttpURLConnection? = null
    return try {
        connection = URL(cleanBase + path).openConnection() as HttpURLConnection
        connection.connectTimeout = timeoutMs
        connection.readTimeout = timeoutMs
        connection.requestMethod = method
        connection.setRequestProperty("Accept", "application/json")
        if (bearerToken.isNotBlank()) connection.setRequestProperty("Authorization", "Bearer $bearerToken")
        if (method == "POST") {
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        "HTTP $code $method $path\n$text"
    } catch (err: Throwable) {
        "FAILED $method $path\n${err.javaClass.simpleName}: ${err.message}"
    } finally {
        connection?.disconnect()
    }
}

private fun shortEndpointLine(raw: String): String {
    val firstLine = raw.lineSequence().firstOrNull().orEmpty()
    val count = Regex("\"count\"\\s*:\\s*(\\d+)").find(raw)?.groupValues?.getOrNull(1)
    val ok = if (raw.contains("\"ok\"", ignoreCase = true)) {
        Regex("\"ok\"\\s*:\\s*(true|false)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.getOrNull(1) ?: "?"
    } else "?"
    return listOfNotNull(firstLine.ifBlank { null }, "ok=$ok", count?.let { "count=$it" }).joinToString(" · ").take(160)
}

private fun prettyJsonOrText(raw: String): String {
    val header = raw.lineSequence().firstOrNull().orEmpty()
    val body = raw.lines().drop(1).joinToString("\n")
    return try {
        val elem: JsonElement = Json.parseToJsonElement(body.ifBlank { raw })
        header + "\n" + Json { prettyPrint = true }.encodeToString(JsonElement.serializer(), elem)
    } catch (_: Throwable) {
        raw
    }
}

private fun escapeJson(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"").trim()
